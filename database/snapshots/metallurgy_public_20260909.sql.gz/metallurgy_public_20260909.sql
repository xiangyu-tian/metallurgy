--
-- PostgreSQL database dump
--

\restrict jk3qyWcELiEmqhuiQOgsiNT398IbykbBCAaK3l4ntC5VXYAYX7wyC8F6xA7uFcD

-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: User; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA "User";


--
-- Name: metallurgy_v2; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA metallurgy_v2;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: User; Owner: -
--

CREATE TABLE "User".accounts (
    id bigint NOT NULL,
    username character varying(20) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    real_name character varying(100),
    organization character varying(255),
    role character varying(32) DEFAULT 'user'::character varying NOT NULL,
    account_type character varying(32) DEFAULT 'user'::character varying NOT NULL,
    account_status character varying(32) DEFAULT 'active'::character varying NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    last_login_at timestamp with time zone,
    CONSTRAINT chk_accounts_role CHECK (((role)::text = ANY ((ARRAY['user'::character varying, 'admin'::character varying])::text[]))),
    CONSTRAINT chk_accounts_status CHECK (((account_status)::text = ANY ((ARRAY['active'::character varying, 'disabled'::character varying, 'locked'::character varying])::text[]))),
    CONSTRAINT chk_accounts_type CHECK (((account_type)::text = ANY ((ARRAY['user'::character varying, 'admin'::character varying])::text[])))
);


--
-- Name: TABLE accounts; Type: COMMENT; Schema: User; Owner: -
--

COMMENT ON TABLE "User".accounts IS '平台登录账号：密码仅保存 bcrypt 哈希，不保存明文密码';


--
-- Name: accounts_id_seq; Type: SEQUENCE; Schema: User; Owner: -
--

CREATE SEQUENCE "User".accounts_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: accounts_id_seq; Type: SEQUENCE OWNED BY; Schema: User; Owner: -
--

ALTER SEQUENCE "User".accounts_id_seq OWNED BY "User".accounts.id;


--
-- Name: benchmark_cases; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.benchmark_cases (
    case_id character varying(64) NOT NULL,
    model_id character varying(32) NOT NULL,
    case_type character varying(32) NOT NULL,
    input_json json NOT NULL,
    expected_json json,
    reference_source text NOT NULL,
    tolerance_json json,
    expert_label text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE benchmark_cases; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.benchmark_cases IS '评测用例表：模型验证的标准测试用例集';


--
-- Name: bof_slag_model_parameter; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.bof_slag_model_parameter (
    id bigint NOT NULL,
    dataset_id character varying(64) NOT NULL,
    model_code character varying(32) NOT NULL,
    parameter_set_id character varying(160) NOT NULL,
    parameter_code character varying(128) NOT NULL,
    parameter_value numeric(24,12) NOT NULL,
    unit character varying(96) NOT NULL,
    source_version character varying(128) NOT NULL,
    source_ref text NOT NULL,
    source_url text NOT NULL,
    temperature_min_k numeric(12,4) NOT NULL,
    temperature_max_k numeric(12,4) NOT NULL,
    usage_scope character varying(64) NOT NULL,
    applicability jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_approved boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_bof_slag_parameter_model CHECK (((model_code)::text = ANY ((ARRAY['D010'::character varying, 'D011'::character varying, 'D012'::character varying, 'D013'::character varying])::text[]))),
    CONSTRAINT chk_bof_slag_parameter_temperature CHECK (((temperature_min_k > (0)::numeric) AND (temperature_max_k > temperature_min_k))),
    CONSTRAINT chk_bof_slag_parameter_usage CHECK (((usage_scope)::text = ANY ((ARRAY['REFERENCE_VALIDATION_ONLY'::character varying, 'ENGINEERING_SCREENING_ONLY'::character varying])::text[])))
);


--
-- Name: bof_slag_model_parameter_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.bof_slag_model_parameter_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: bof_slag_model_parameter_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.bof_slag_model_parameter_id_seq OWNED BY metallurgy_v2.bof_slag_model_parameter.id;


--
-- Name: casting_boundary_profile; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.casting_boundary_profile (
    id bigint NOT NULL,
    boundary_profile_id character varying(160) NOT NULL,
    dataset_id character varying(64) NOT NULL,
    property_set_id character varying(128),
    profile_name character varying(255) NOT NULL,
    profile_type character varying(64) NOT NULL,
    independent_variable character varying(32) NOT NULL,
    profile_version character varying(128) NOT NULL,
    domain_min numeric(20,8) NOT NULL,
    domain_max numeric(20,8) NOT NULL,
    independent_unit character varying(32) NOT NULL,
    value_unit character varying(64) NOT NULL,
    profile_json jsonb NOT NULL,
    equipment_scope jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_kind character varying(64) NOT NULL,
    source_ref text NOT NULL,
    source_url text,
    license text NOT NULL,
    usage_scope character varying(64) NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_approved boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_casting_boundary_domain CHECK ((domain_max > domain_min))
);


--
-- Name: casting_boundary_profile_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.casting_boundary_profile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: casting_boundary_profile_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.casting_boundary_profile_id_seq OWNED BY metallurgy_v2.casting_boundary_profile.id;


--
-- Name: casting_endpoint_benchmark_case; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.casting_endpoint_benchmark_case (
    id bigint NOT NULL,
    benchmark_id character varying(160) NOT NULL,
    dataset_id character varying(64) NOT NULL,
    model_code character varying(32) NOT NULL,
    machine_configuration_id character varying(160) NOT NULL,
    reference_type character varying(96) NOT NULL,
    input_json jsonb NOT NULL,
    expected_json jsonb NOT NULL,
    tolerance_json jsonb NOT NULL,
    source_ref text NOT NULL,
    source_url text,
    within_domain boolean NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: casting_endpoint_benchmark_case_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.casting_endpoint_benchmark_case_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: casting_endpoint_benchmark_case_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.casting_endpoint_benchmark_case_id_seq OWNED BY metallurgy_v2.casting_endpoint_benchmark_case.id;


--
-- Name: casting_machine_configuration; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.casting_machine_configuration (
    id bigint NOT NULL,
    machine_configuration_id character varying(160) NOT NULL,
    dataset_id character varying(64) NOT NULL,
    equipment_id character varying(128) NOT NULL,
    configuration_name character varying(255) NOT NULL,
    configuration_version character varying(128) NOT NULL,
    section_shape character varying(32) NOT NULL,
    section_width_m numeric(16,8) NOT NULL,
    section_thickness_m numeric(16,8) NOT NULL,
    mold_length_m numeric(16,8) NOT NULL,
    effective_metallurgical_length_m numeric(16,8) NOT NULL,
    casting_speed_min_m_s numeric(16,8) NOT NULL,
    casting_speed_max_m_s numeric(16,8) NOT NULL,
    unit_system character varying(16) DEFAULT 'SI'::character varying NOT NULL,
    usage_scope character varying(64) NOT NULL,
    source_kind character varying(64) NOT NULL,
    source_ref text NOT NULL,
    source_url text,
    license text NOT NULL,
    uncertainty_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_approved boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_casting_machine_geometry CHECK (((section_width_m > (0)::numeric) AND (section_thickness_m > (0)::numeric) AND (mold_length_m > (0)::numeric) AND (effective_metallurgical_length_m >= mold_length_m))),
    CONSTRAINT chk_casting_machine_speed CHECK (((casting_speed_min_m_s > (0)::numeric) AND (casting_speed_max_m_s > casting_speed_min_m_s)))
);


--
-- Name: casting_machine_configuration_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.casting_machine_configuration_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: casting_machine_configuration_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.casting_machine_configuration_id_seq OWNED BY metallurgy_v2.casting_machine_configuration.id;


--
-- Name: casting_material_property_correlation; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.casting_material_property_correlation (
    id bigint NOT NULL,
    correlation_id character varying(160) NOT NULL,
    property_set_id character varying(128) NOT NULL,
    property_type character varying(64) NOT NULL,
    equation_type character varying(96) NOT NULL,
    phase character varying(32) NOT NULL,
    temperature_min_k numeric(12,4) NOT NULL,
    temperature_max_k numeric(12,4) NOT NULL,
    input_unit character varying(32) NOT NULL,
    output_unit character varying(64) NOT NULL,
    coefficients jsonb NOT NULL,
    uncertainty_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_kind character varying(64) NOT NULL,
    source_ref text NOT NULL,
    source_url text,
    source_record_key character varying(255) NOT NULL,
    priority integer DEFAULT 100 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_casting_correlation_priority CHECK ((priority > 0)),
    CONSTRAINT chk_casting_correlation_temperature CHECK (((temperature_min_k > (0)::numeric) AND (temperature_max_k > temperature_min_k)))
);


--
-- Name: casting_material_property_correlation_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.casting_material_property_correlation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: casting_material_property_correlation_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.casting_material_property_correlation_id_seq OWNED BY metallurgy_v2.casting_material_property_correlation.id;


--
-- Name: casting_material_property_set; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.casting_material_property_set (
    id bigint NOT NULL,
    property_set_id character varying(128) NOT NULL,
    dataset_id character varying(64) NOT NULL,
    material_name character varying(255) NOT NULL,
    material_grade character varying(128) NOT NULL,
    reference_material_id character varying(128),
    property_set_version character varying(128) NOT NULL,
    composition_basis character varying(96) NOT NULL,
    composition_json jsonb NOT NULL,
    temperature_min_k numeric(12,4) NOT NULL,
    temperature_max_k numeric(12,4) NOT NULL,
    solidus_temperature_k numeric(12,4),
    liquidus_temperature_k numeric(12,4),
    phase_model character varying(128) NOT NULL,
    unit_system character varying(16) DEFAULT 'SI'::character varying NOT NULL,
    usage_scope character varying(64) NOT NULL,
    source_ref text NOT NULL,
    source_url text,
    license text NOT NULL,
    uncertainty_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_approved boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_casting_property_set_phase_endpoints CHECK ((((solidus_temperature_k IS NULL) AND (liquidus_temperature_k IS NULL)) OR ((solidus_temperature_k IS NOT NULL) AND (liquidus_temperature_k IS NOT NULL) AND (solidus_temperature_k >= temperature_min_k) AND (liquidus_temperature_k <= temperature_max_k) AND (liquidus_temperature_k > solidus_temperature_k)))),
    CONSTRAINT chk_casting_property_set_temperature CHECK (((temperature_min_k > (0)::numeric) AND (temperature_max_k > temperature_min_k)))
);


--
-- Name: casting_material_property_set_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.casting_material_property_set_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: casting_material_property_set_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.casting_material_property_set_id_seq OWNED BY metallurgy_v2.casting_material_property_set.id;


--
-- Name: casting_model_benchmark_case; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.casting_model_benchmark_case (
    id bigint NOT NULL,
    benchmark_id character varying(160) NOT NULL,
    model_code character varying(32) NOT NULL,
    property_set_id character varying(128) NOT NULL,
    boundary_profile_id character varying(160),
    reference_type character varying(96) NOT NULL,
    input_json jsonb NOT NULL,
    expected_json jsonb NOT NULL,
    tolerance_json jsonb NOT NULL,
    source_ref text NOT NULL,
    source_url text,
    within_domain boolean NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: casting_model_benchmark_case_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.casting_model_benchmark_case_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: casting_model_benchmark_case_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.casting_model_benchmark_case_id_seq OWNED BY metallurgy_v2.casting_model_benchmark_case.id;


--
-- Name: dataset_import_issue; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.dataset_import_issue (
    id bigint NOT NULL,
    run_id uuid NOT NULL,
    severity character varying(16) NOT NULL,
    natural_key text NOT NULL,
    issue_code character varying(64) NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: dataset_import_issue_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.dataset_import_issue_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: dataset_import_issue_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.dataset_import_issue_id_seq OWNED BY metallurgy_v2.dataset_import_issue.id;


--
-- Name: dataset_import_run; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.dataset_import_run (
    run_id uuid NOT NULL,
    dataset_id character varying(64) NOT NULL,
    source_version character varying(128) NOT NULL,
    source_checksum character varying(128) NOT NULL,
    dry_run boolean NOT NULL,
    status character varying(32) NOT NULL,
    staged_count integer DEFAULT 0 NOT NULL,
    inserted_count integer DEFAULT 0 NOT NULL,
    unchanged_count integer DEFAULT 0 NOT NULL,
    conflict_count integer DEFAULT 0 NOT NULL,
    details jsonb DEFAULT '{}'::jsonb NOT NULL,
    started_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    completed_at timestamp without time zone
);


--
-- Name: dataset_registry; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.dataset_registry (
    dataset_id character varying(64) NOT NULL,
    name character varying(255) NOT NULL,
    category character varying(64) NOT NULL,
    provider character varying(255),
    license character varying(255) NOT NULL,
    access_url text,
    ingestion_mode character varying(64) NOT NULL,
    version character varying(64),
    retrieved_at timestamp without time zone NOT NULL,
    checksum character varying(128),
    owner character varying(64) NOT NULL,
    security_level character varying(32) DEFAULT '公开'::character varying NOT NULL,
    quality_grade character varying(16),
    lineage_json json,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE dataset_registry; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.dataset_registry IS '数据集注册表：记录44+个外部数据源的基本信息、许可和入库状态';


--
-- Name: element_reference; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.element_reference (
    id bigint NOT NULL,
    dataset_id character varying(64) NOT NULL,
    symbol character varying(3) NOT NULL,
    atomic_weight_g_mol numeric(18,9) NOT NULL,
    unit character varying(32) DEFAULT 'g/mol'::character varying NOT NULL,
    source_version character varying(128) NOT NULL,
    source_ref text NOT NULL,
    source_record_key character varying(255) NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_element_weight_positive CHECK ((atomic_weight_g_mol > (0)::numeric))
);


--
-- Name: element_reference_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.element_reference_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: element_reference_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.element_reference_id_seq OWNED BY metallurgy_v2.element_reference.id;


--
-- Name: emission_factor; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.emission_factor (
    id bigint NOT NULL,
    dataset_id character varying(64) NOT NULL,
    factor_set_id character varying(128) NOT NULL,
    factor_code character varying(160) NOT NULL,
    activity_name text NOT NULL,
    activity_unit character varying(32) NOT NULL,
    scope character varying(16) NOT NULL,
    co2_kg_per_unit numeric(24,10),
    ch4_kg_per_unit numeric(24,10),
    n2o_kg_per_unit numeric(24,10),
    co2e_kg_per_unit numeric(24,10),
    gwp_ch4 numeric(12,6),
    gwp_n2o numeric(12,6),
    methodology text NOT NULL,
    applicability jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_version character varying(160) NOT NULL,
    source_ref text NOT NULL,
    source_url text NOT NULL,
    is_approved boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_emission_factor_nonnegative CHECK ((((co2_kg_per_unit IS NULL) OR (co2_kg_per_unit >= (0)::numeric)) AND ((ch4_kg_per_unit IS NULL) OR (ch4_kg_per_unit >= (0)::numeric)) AND ((n2o_kg_per_unit IS NULL) OR (n2o_kg_per_unit >= (0)::numeric)) AND ((co2e_kg_per_unit IS NULL) OR (co2e_kg_per_unit >= (0)::numeric)))),
    CONSTRAINT chk_emission_factor_payload CHECK (((co2e_kg_per_unit IS NOT NULL) OR ((co2_kg_per_unit IS NOT NULL) AND (ch4_kg_per_unit IS NOT NULL) AND (n2o_kg_per_unit IS NOT NULL) AND (gwp_ch4 IS NOT NULL) AND (gwp_n2o IS NOT NULL)))),
    CONSTRAINT chk_emission_factor_scope CHECK (((scope)::text = ANY ((ARRAY['scope1'::character varying, 'scope2'::character varying, 'scope3'::character varying])::text[])))
);


--
-- Name: TABLE emission_factor; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.emission_factor IS 'Versioned public activity emission factors used by E020; runtime access is read-only.';


--
-- Name: emission_factor_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.emission_factor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: emission_factor_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.emission_factor_id_seq OWNED BY metallurgy_v2.emission_factor.id;


--
-- Name: experiment_run; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.experiment_run (
    experiment_id character varying(64) NOT NULL,
    trace_id character varying(64) NOT NULL,
    benchmark_case_id character varying(64),
    mode character varying(32) NOT NULL,
    result_validation_enabled boolean DEFAULT true NOT NULL,
    status character varying(32) DEFAULT 'completed'::character varying NOT NULL,
    metrics_json jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    benchmark_run_id character varying(64),
    CONSTRAINT chk_experiment_mode CHECK (((mode)::text = ANY ((ARRAY['direct'::character varying, 'forced'::character varying, 'autonomous'::character varying])::text[])))
);


--
-- Name: TABLE experiment_run; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.experiment_run IS '直接回答、强制调用、自主调用三模式实验记录';


--
-- Name: COLUMN experiment_run.benchmark_run_id; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON COLUMN metallurgy_v2.experiment_run.benchmark_run_id IS 'Groups all case experiments produced by one benchmark batch';


--
-- Name: invocation_logs; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.invocation_logs (
    id bigint NOT NULL,
    trace_id character varying(64) NOT NULL,
    call_id character varying(64) NOT NULL,
    model_id character varying(32) NOT NULL,
    model_version character varying(64) NOT NULL,
    requested_at timestamp without time zone DEFAULT now() NOT NULL,
    input_json json NOT NULL,
    boundary_check json NOT NULL,
    output_json json,
    confidence numeric(8,6),
    validation_result json,
    runtime_ms integer,
    status character varying(32) NOT NULL,
    error_code character varying(64),
    user_or_agent character varying(128) NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE invocation_logs; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.invocation_logs IS '调用日志表：记录每次模型调用的完整输入输出和校验信息';


--
-- Name: invocation_logs_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.invocation_logs_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: invocation_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.invocation_logs_id_seq OWNED BY metallurgy_v2.invocation_logs.id;


--
-- Name: kinetic_parameter; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.kinetic_parameter (
    id integer NOT NULL,
    dataset_id character varying(64),
    material_system character varying(128) NOT NULL,
    diffusing_element character varying(64),
    matrix_phase character varying(64),
    parameter_type character varying(64) NOT NULL,
    parameter_value numeric(18,8) NOT NULL,
    unit character varying(32) NOT NULL,
    temperature_min numeric(10,2),
    temperature_max numeric(10,2),
    method character varying(128),
    source_ref text,
    quality_grade character varying(8),
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE kinetic_parameter; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.kinetic_parameter IS '动力学参数表：扩散系数、指前因子、激活能等';


--
-- Name: kinetic_parameter_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.kinetic_parameter_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: kinetic_parameter_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.kinetic_parameter_id_seq OWNED BY metallurgy_v2.kinetic_parameter.id;


--
-- Name: knowledge_docs; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.knowledge_docs (
    doc_id character varying(64) NOT NULL,
    dataset_id character varying(64) NOT NULL,
    title text NOT NULL,
    doc_type character varying(32) NOT NULL,
    doi_or_standard_no character varying(128),
    publication_date date,
    license character varying(255) NOT NULL,
    content_uri text,
    source_url text NOT NULL,
    language character varying(16) DEFAULT 'zh-CN'::character varying NOT NULL,
    chunk_policy_version character varying(32),
    embedding_model character varying(128),
    citation_text text,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE knowledge_docs; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.knowledge_docs IS '知识文档表：论文、标准、专利、手册等文档元数据';


--
-- Name: llm_tool_trace; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.llm_tool_trace (
    trace_id character varying(64) NOT NULL,
    user_query text NOT NULL,
    llm_name character varying(128) NOT NULL,
    prompt_version character varying(64) NOT NULL,
    mode character varying(32) NOT NULL,
    candidate_models jsonb DEFAULT '[]'::jsonb NOT NULL,
    selected_model character varying(32),
    selection_reason text,
    generated_arguments jsonb DEFAULT '{}'::jsonb NOT NULL,
    validation_result jsonb,
    execution_result jsonb,
    retry_count integer DEFAULT 0 NOT NULL,
    final_answer text,
    latency_ms numeric(14,3),
    token_usage jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    experiment_engine character varying(32) DEFAULT 'deterministic'::character varying NOT NULL,
    tool_call_chain jsonb DEFAULT '[]'::jsonb NOT NULL,
    llm_trace jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: TABLE llm_tool_trace; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.llm_tool_trace IS '大模型工具选择、参数、校验、执行与最终回答的完整轨迹';


--
-- Name: COLUMN llm_tool_trace.experiment_engine; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON COLUMN metallurgy_v2.llm_tool_trace.experiment_engine IS 'Experiment engine, for example deterministic or deepseek';


--
-- Name: COLUMN llm_tool_trace.tool_call_chain; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON COLUMN metallurgy_v2.llm_tool_trace.tool_call_chain IS 'Ordered function calls with generated arguments, validation and execution';


--
-- Name: COLUMN llm_tool_trace.llm_trace; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON COLUMN metallurgy_v2.llm_tool_trace.llm_trace IS 'Sanitized provider requests and responses without credentials';


--
-- Name: melt_viscosity_model_definition; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.melt_viscosity_model_definition (
    id bigint NOT NULL,
    dataset_id character varying(64) NOT NULL,
    model_id character varying(128) NOT NULL,
    material_kind character varying(32) NOT NULL,
    equation_type character varying(64) NOT NULL,
    temperature_min_k numeric(12,4) NOT NULL,
    temperature_max_k numeric(12,4) NOT NULL,
    parameters jsonb NOT NULL,
    component_groups jsonb DEFAULT '{}'::jsonb NOT NULL,
    applicability jsonb DEFAULT '{}'::jsonb NOT NULL,
    source_version character varying(128) NOT NULL,
    source_ref text NOT NULL,
    source_url text NOT NULL,
    is_approved boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_melt_viscosity_temperature CHECK (((temperature_min_k > (0)::numeric) AND (temperature_max_k > temperature_min_k)))
);


--
-- Name: TABLE melt_viscosity_model_definition; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.melt_viscosity_model_definition IS 'Versioned, approved public correlation definitions used by C008; runtime access is read-only.';


--
-- Name: melt_viscosity_model_definition_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.melt_viscosity_model_definition_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: melt_viscosity_model_definition_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.melt_viscosity_model_definition_id_seq OWNED BY metallurgy_v2.melt_viscosity_model_definition.id;


--
-- Name: model_execution_log; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.model_execution_log (
    execution_id character varying(64) NOT NULL,
    trace_id character varying(64) NOT NULL,
    model_code character varying(32) NOT NULL,
    model_version character varying(64),
    input_json jsonb NOT NULL,
    actual_data_records jsonb DEFAULT '[]'::jsonb NOT NULL,
    boundary_check jsonb,
    output_json jsonb,
    status character varying(32) NOT NULL,
    error_code character varying(64),
    error_message text,
    runtime_ms numeric(14,3),
    user_or_agent character varying(128) NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone
);


--
-- Name: TABLE model_execution_log; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.model_execution_log IS '统一小模型执行轨迹，记录输入、实际数据、输出、错误与耗时';


--
-- Name: model_metrics; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.model_metrics (
    id integer NOT NULL,
    evaluation_id character varying(64) NOT NULL,
    model_id character varying(32) NOT NULL,
    model_version character varying(64) NOT NULL,
    dataset_snapshot_id character varying(64) NOT NULL,
    metric_name character varying(64) NOT NULL,
    metric_value numeric(18,8) NOT NULL,
    slice_json json,
    passed boolean NOT NULL,
    evaluated_at timestamp without time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE model_metrics; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.model_metrics IS '模型评测指标表：各版本模型在测试集上的量化表现';


--
-- Name: model_metrics_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.model_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.model_metrics_id_seq OWNED BY metallurgy_v2.model_metrics.id;


--
-- Name: model_registry; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.model_registry (
    model_id character varying(32) NOT NULL,
    name character varying(255) NOT NULL,
    scenario character varying(64) NOT NULL,
    model_type character varying(64) NOT NULL,
    api_name character varying(128) NOT NULL,
    input_schema_json json NOT NULL,
    output_schema_json json NOT NULL,
    applicable_boundary text NOT NULL,
    validation_rules json DEFAULT '[]'::json NOT NULL,
    priority character varying(8) DEFAULT 'P2'::character varying NOT NULL,
    owner character varying(64) NOT NULL,
    status character varying(32) DEFAULT 'planned'::character varying NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE model_registry; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.model_registry IS '模型注册表：120个小模型的统一注册中心，JSON Schema驱动前端动态表单';


--
-- Name: model_versions; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.model_versions (
    id integer NOT NULL,
    model_id character varying(32) NOT NULL,
    version character varying(64) NOT NULL,
    artifact_uri text NOT NULL,
    git_commit character varying(64),
    data_snapshot_id character varying(64),
    parameter_json json,
    dependency_lock text NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    approved_by character varying(64),
    release_notes text
);


--
-- Name: TABLE model_versions; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.model_versions IS '模型版本表：每个模型的版本历史、制品地址和审核记录';


--
-- Name: model_versions_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.model_versions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: model_versions_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.model_versions_id_seq OWNED BY metallurgy_v2.model_versions.id;


--
-- Name: phase_equilibrium_record; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.phase_equilibrium_record (
    id integer NOT NULL,
    dataset_id character varying(64),
    system_name character varying(128) NOT NULL,
    temperature numeric(10,2) NOT NULL,
    pressure numeric(10,2) DEFAULT 101325,
    composition_json json NOT NULL,
    phases_present json NOT NULL,
    calculation_method character varying(64),
    software_version character varying(64),
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE phase_equilibrium_record; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.phase_equilibrium_record IS '相图平衡记录表：相图计算结果及实验数据点';


--
-- Name: phase_equilibrium_record_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.phase_equilibrium_record_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: phase_equilibrium_record_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.phase_equilibrium_record_id_seq OWNED BY metallurgy_v2.phase_equilibrium_record.id;


--
-- Name: process_parameter_set; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.process_parameter_set (
    id bigint NOT NULL,
    dataset_id character varying(64) NOT NULL,
    parameter_set_id character varying(64) NOT NULL,
    process character varying(64) NOT NULL,
    parameter_code character varying(128) NOT NULL,
    parameter_value numeric(24,12) NOT NULL,
    unit character varying(64) NOT NULL,
    source_version character varying(128) NOT NULL,
    source_ref text NOT NULL,
    applicability jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: process_parameter_set_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.process_parameter_set_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: process_parameter_set_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.process_parameter_set_id_seq OWNED BY metallurgy_v2.process_parameter_set.id;


--
-- Name: reaction_definition; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.reaction_definition (
    id integer NOT NULL,
    reaction_id character varying(32) NOT NULL,
    reaction_equation text NOT NULL,
    name character varying(255),
    category character varying(64),
    reactants json NOT NULL,
    products json NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


--
-- Name: TABLE reaction_definition; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.reaction_definition IS '反应定义表：化学反应的标准化定义';


--
-- Name: reaction_definition_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.reaction_definition_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reaction_definition_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.reaction_definition_id_seq OWNED BY metallurgy_v2.reaction_definition.id;


--
-- Name: reaction_property; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.reaction_property (
    id integer NOT NULL,
    reaction_id character varying(32) NOT NULL,
    dataset_id character varying(64),
    property_type character varying(64) NOT NULL,
    temperature numeric(10,2),
    value numeric(18,8) NOT NULL,
    unit character varying(32) NOT NULL,
    uncertainty numeric(18,8),
    data_type character varying(32) DEFAULT 'experimental'::character varying,
    source_ref text,
    quality_grade character varying(8),
    created_at timestamp without time zone DEFAULT now(),
    source_version character varying(128),
    source_record_key character varying(255),
    temperature_min_k numeric(12,4),
    temperature_max_k numeric(12,4),
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL
);


--
-- Name: TABLE reaction_property; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.reaction_property IS '反应物性表：特定反应在特定温度下的热力学性质';


--
-- Name: reaction_property_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.reaction_property_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: reaction_property_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.reaction_property_id_seq OWNED BY metallurgy_v2.reaction_property.id;


--
-- Name: solidification_benchmark_case; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.solidification_benchmark_case (
    id bigint NOT NULL,
    benchmark_id character varying(128) NOT NULL,
    model_asset_id character varying(128) NOT NULL,
    composition_json jsonb NOT NULL,
    reference_type character varying(64) NOT NULL,
    expected_json jsonb NOT NULL,
    tolerance_json jsonb NOT NULL,
    source_ref text NOT NULL,
    source_url text,
    within_domain boolean NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


--
-- Name: solidification_benchmark_case_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.solidification_benchmark_case_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: solidification_benchmark_case_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.solidification_benchmark_case_id_seq OWNED BY metallurgy_v2.solidification_benchmark_case.id;


--
-- Name: solidification_model_definition; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.solidification_model_definition (
    id bigint NOT NULL,
    model_asset_id character varying(128) NOT NULL,
    dataset_id character varying(64) NOT NULL,
    model_family character varying(128) NOT NULL,
    model_version character varying(128) NOT NULL,
    solver_name character varying(64) NOT NULL,
    solver_version character varying(32) NOT NULL,
    solidification_solver_name character varying(64),
    solidification_solver_version character varying(32),
    asset_uri text NOT NULL,
    asset_sha256 character(64) NOT NULL,
    license text NOT NULL,
    source_url text NOT NULL,
    source_commit character(40) NOT NULL,
    temperature_min_k numeric(12,4) NOT NULL,
    temperature_max_k numeric(12,4) NOT NULL,
    composition_basis character varying(96) NOT NULL,
    domain_json jsonb NOT NULL,
    supported_components jsonb NOT NULL,
    phase_set jsonb NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_approved boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT chk_solidification_sha256 CHECK ((asset_sha256 ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT chk_solidification_temperature_range CHECK (((temperature_min_k > (0)::numeric) AND (temperature_max_k > temperature_min_k)))
);


--
-- Name: solidification_model_definition_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.solidification_model_definition_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: solidification_model_definition_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.solidification_model_definition_id_seq OWNED BY metallurgy_v2.solidification_model_definition.id;


--
-- Name: thermo_property_definition; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.thermo_property_definition (
    id bigint NOT NULL,
    property_code character varying(50) NOT NULL,
    name_zh character varying(100) NOT NULL,
    name_en character varying(100),
    symbol character varying(50),
    default_unit character varying(50),
    description text
);


--
-- Name: thermo_property_definition_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.thermo_property_definition_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: thermo_property_definition_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.thermo_property_definition_id_seq OWNED BY metallurgy_v2.thermo_property_definition.id;


--
-- Name: thermodynamic_correlation; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.thermodynamic_correlation (
    id bigint NOT NULL,
    species_id character varying(128) NOT NULL,
    phase character varying(20) DEFAULT 's'::character varying NOT NULL,
    equation_type character varying(50) NOT NULL,
    temperature_min_k numeric(12,4) NOT NULL,
    temperature_max_k numeric(12,4) NOT NULL,
    reference_temperature_k numeric(12,4) DEFAULT 298.15,
    reference_pressure_pa numeric(16,4) DEFAULT 101325,
    coefficients jsonb NOT NULL,
    coefficient_units jsonb DEFAULT '{}'::jsonb,
    source_id character varying(64),
    source_record_key character varying(255),
    reference_text text,
    priority integer DEFAULT 100,
    quality_level character varying(30),
    is_active boolean DEFAULT true,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp without time zone DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_correlation_temp CHECK ((temperature_max_k > temperature_min_k))
);


--
-- Name: TABLE thermodynamic_correlation; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.thermodynamic_correlation IS '热力学关联式表：Shomate/NASA 等多多项式系数，通过 JSONB 统一存储';


--
-- Name: thermodynamic_correlation_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.thermodynamic_correlation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: thermodynamic_correlation_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.thermodynamic_correlation_id_seq OWNED BY metallurgy_v2.thermodynamic_correlation.id;


--
-- Name: thermodynamic_property; Type: TABLE; Schema: metallurgy_v2; Owner: -
--

CREATE TABLE metallurgy_v2.thermodynamic_property (
    id integer NOT NULL,
    dataset_id character varying(64),
    species character varying(128) NOT NULL,
    chemical_formula character varying(128),
    phase character varying(64),
    property_type character varying(64) NOT NULL,
    temperature numeric(10,2),
    temperature_min numeric(10,2),
    temperature_max numeric(10,2),
    value numeric(18,8) NOT NULL,
    unit character varying(32) NOT NULL,
    uncertainty numeric(18,8),
    data_type character varying(32) DEFAULT 'experimental'::character varying,
    source_ref text,
    quality_grade character varying(8),
    created_at timestamp without time zone DEFAULT now(),
    property_code character varying(50),
    pressure_pa numeric(16,4),
    data_origin character varying(30) DEFAULT 'unknown'::character varying,
    correlation_id bigint,
    source_id bigint,
    metadata jsonb DEFAULT '{}'::jsonb
);


--
-- Name: TABLE thermodynamic_property; Type: COMMENT; Schema: metallurgy_v2; Owner: -
--

COMMENT ON TABLE metallurgy_v2.thermodynamic_property IS '热力学物性表：存储温度-热力学函数表数据';


--
-- Name: thermodynamic_property_id_seq; Type: SEQUENCE; Schema: metallurgy_v2; Owner: -
--

CREATE SEQUENCE metallurgy_v2.thermodynamic_property_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: thermodynamic_property_id_seq; Type: SEQUENCE OWNED BY; Schema: metallurgy_v2; Owner: -
--

ALTER SEQUENCE metallurgy_v2.thermodynamic_property_id_seq OWNED BY metallurgy_v2.thermodynamic_property.id;


--
-- Name: accounts id; Type: DEFAULT; Schema: User; Owner: -
--

ALTER TABLE ONLY "User".accounts ALTER COLUMN id SET DEFAULT nextval('"User".accounts_id_seq'::regclass);


--
-- Name: bof_slag_model_parameter id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.bof_slag_model_parameter ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.bof_slag_model_parameter_id_seq'::regclass);


--
-- Name: casting_boundary_profile id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_boundary_profile ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.casting_boundary_profile_id_seq'::regclass);


--
-- Name: casting_endpoint_benchmark_case id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_endpoint_benchmark_case ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.casting_endpoint_benchmark_case_id_seq'::regclass);


--
-- Name: casting_machine_configuration id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_machine_configuration ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.casting_machine_configuration_id_seq'::regclass);


--
-- Name: casting_material_property_correlation id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_material_property_correlation ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.casting_material_property_correlation_id_seq'::regclass);


--
-- Name: casting_material_property_set id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_material_property_set ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.casting_material_property_set_id_seq'::regclass);


--
-- Name: casting_model_benchmark_case id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_model_benchmark_case ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.casting_model_benchmark_case_id_seq'::regclass);


--
-- Name: dataset_import_issue id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.dataset_import_issue ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.dataset_import_issue_id_seq'::regclass);


--
-- Name: element_reference id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.element_reference ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.element_reference_id_seq'::regclass);


--
-- Name: emission_factor id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.emission_factor ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.emission_factor_id_seq'::regclass);


--
-- Name: invocation_logs id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.invocation_logs ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.invocation_logs_id_seq'::regclass);


--
-- Name: kinetic_parameter id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.kinetic_parameter ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.kinetic_parameter_id_seq'::regclass);


--
-- Name: melt_viscosity_model_definition id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.melt_viscosity_model_definition ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.melt_viscosity_model_definition_id_seq'::regclass);


--
-- Name: model_metrics id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.model_metrics ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.model_metrics_id_seq'::regclass);


--
-- Name: model_versions id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.model_versions ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.model_versions_id_seq'::regclass);


--
-- Name: phase_equilibrium_record id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.phase_equilibrium_record ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.phase_equilibrium_record_id_seq'::regclass);


--
-- Name: process_parameter_set id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.process_parameter_set ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.process_parameter_set_id_seq'::regclass);


--
-- Name: reaction_definition id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.reaction_definition ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.reaction_definition_id_seq'::regclass);


--
-- Name: reaction_property id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.reaction_property ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.reaction_property_id_seq'::regclass);


--
-- Name: solidification_benchmark_case id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.solidification_benchmark_case ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.solidification_benchmark_case_id_seq'::regclass);


--
-- Name: solidification_model_definition id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.solidification_model_definition ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.solidification_model_definition_id_seq'::regclass);


--
-- Name: thermo_property_definition id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.thermo_property_definition ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.thermo_property_definition_id_seq'::regclass);


--
-- Name: thermodynamic_correlation id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.thermodynamic_correlation ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.thermodynamic_correlation_id_seq'::regclass);


--
-- Name: thermodynamic_property id; Type: DEFAULT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.thermodynamic_property ALTER COLUMN id SET DEFAULT nextval('metallurgy_v2.thermodynamic_property_id_seq'::regclass);


--
-- Data for Name: benchmark_cases; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.benchmark_cases (case_id, model_id, case_type, input_json, expected_json, reference_source, tolerance_json, expert_label, created_at) FROM stdin;
\.


--
-- Data for Name: bof_slag_model_parameter; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.bof_slag_model_parameter (id, dataset_id, model_code, parameter_set_id, parameter_code, parameter_value, unit, source_version, source_ref, source_url, temperature_min_k, temperature_max_k, usage_scope, applicability, metadata, is_approved, created_at) FROM stdin;
1	DS_BOF_P_PARTITION_ISIJ_2016	D010	D010_SPOONER_ISIJ_2016_V1	CAO_COEFF	0.060000000000	1/mass_percent	ISIJINT-2016-361-EQ6-v1	Spooner et al., ISIJ International 56 (2016), Eq.6	https://doi.org/10.2355/isijinternational.ISIJINT-2016-361	1600.0000	2000.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "slag oxide and TFe mass percent", "equilibrium_only": true, "implementation_guard": "1600-2000 K conservative BOF screening interval", "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
2	DS_BOF_P_PARTITION_ISIJ_2016	D010	D010_SPOONER_ISIJ_2016_V1	MGO_COEFF	0.022200000000	1/mass_percent	ISIJINT-2016-361-EQ6-v1	Spooner et al., ISIJ International 56 (2016), Eq.6	https://doi.org/10.2355/isijinternational.ISIJINT-2016-361	1600.0000	2000.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "slag oxide and TFe mass percent", "equilibrium_only": true, "implementation_guard": "1600-2000 K conservative BOF screening interval", "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
3	DS_BOF_P_PARTITION_ISIJ_2016	D010	D010_SPOONER_ISIJ_2016_V1	P2O5_COEFF	0.279000000000	1/mass_percent	ISIJINT-2016-361-EQ6-v1	Spooner et al., ISIJ International 56 (2016), Eq.6	https://doi.org/10.2355/isijinternational.ISIJINT-2016-361	1600.0000	2000.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "slag oxide and TFe mass percent", "equilibrium_only": true, "implementation_guard": "1600-2000 K conservative BOF screening interval", "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
4	DS_BOF_P_PARTITION_ISIJ_2016	D010	D010_SPOONER_ISIJ_2016_V1	AL2O3_COEFF	-0.003000000000	1/mass_percent	ISIJINT-2016-361-EQ6-v1	Spooner et al., ISIJ International 56 (2016), Eq.6	https://doi.org/10.2355/isijinternational.ISIJINT-2016-361	1600.0000	2000.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "slag oxide and TFe mass percent", "equilibrium_only": true, "implementation_guard": "1600-2000 K conservative BOF screening interval", "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
5	DS_BOF_P_PARTITION_ISIJ_2016	D010	D010_SPOONER_ISIJ_2016_V1	SIO2_COEFF	-0.012000000000	1/mass_percent	ISIJINT-2016-361-EQ6-v1	Spooner et al., ISIJ International 56 (2016), Eq.6	https://doi.org/10.2355/isijinternational.ISIJINT-2016-361	1600.0000	2000.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "slag oxide and TFe mass percent", "equilibrium_only": true, "implementation_guard": "1600-2000 K conservative BOF screening interval", "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
6	DS_BOF_P_PARTITION_ISIJ_2016	D010	D010_SPOONER_ISIJ_2016_V1	INV_T_COEFF	11570.000000000000	K	ISIJINT-2016-361-EQ6-v1	Spooner et al., ISIJ International 56 (2016), Eq.6	https://doi.org/10.2355/isijinternational.ISIJINT-2016-361	1600.0000	2000.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "slag oxide and TFe mass percent", "equilibrium_only": true, "implementation_guard": "1600-2000 K conservative BOF screening interval", "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
7	DS_BOF_P_PARTITION_ISIJ_2016	D010	D010_SPOONER_ISIJ_2016_V1	INTERCEPT	-10.520000000000	1	ISIJINT-2016-361-EQ6-v1	Spooner et al., ISIJ International 56 (2016), Eq.6	https://doi.org/10.2355/isijinternational.ISIJINT-2016-361	1600.0000	2000.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "slag oxide and TFe mass percent", "equilibrium_only": true, "implementation_guard": "1600-2000 K conservative BOF screening interval", "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
8	DS_BOF_P_PARTITION_ISIJ_2016	D010	D010_SPOONER_ISIJ_2016_V1	TFE_EXPONENT	2.500000000000	1	ISIJINT-2016-361-EQ6-v1	Spooner et al., ISIJ International 56 (2016), Eq.6	https://doi.org/10.2355/isijinternational.ISIJINT-2016-361	1600.0000	2000.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "slag oxide and TFe mass percent", "equilibrium_only": true, "implementation_guard": "1600-2000 K conservative BOF screening interval", "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
9	DS_SLAG_S_CAPACITY_ISIJ_2013	D011	D011_ZHANG_MA_ISIJ_V1	CS_INTERCEPT	-6.080000000000	1	ISIJ-53-761-EQ10-TABLE2-v1	Zhang, Chou and Uday, ISIJ International 53 (2013), Eq.10 and Table 2	https://doi.org/10.2355/isijinternational.53.761	1773.0000	1923.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "oxide mole amount weighted by oxygen stoichiometry; CaF2 uses oxygen-equivalent 1", "equilibrium_only": true, "supported_components": ["CaO", "MgO", "Al2O3", "SiO2", "FeO", "MnO", "TiO2", "CaF2"], "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
10	DS_SLAG_S_CAPACITY_ISIJ_2013	D011	D011_ZHANG_MA_ISIJ_V1	CS_INV_LAMBDA	4.490000000000	1	ISIJ-53-761-EQ10-TABLE2-v1	Zhang, Chou and Uday, ISIJ International 53 (2013), Eq.10 and Table 2	https://doi.org/10.2355/isijinternational.53.761	1773.0000	1923.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "oxide mole amount weighted by oxygen stoichiometry; CaF2 uses oxygen-equivalent 1", "equilibrium_only": true, "supported_components": ["CaO", "MgO", "Al2O3", "SiO2", "FeO", "MnO", "TiO2", "CaF2"], "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
11	DS_SLAG_S_CAPACITY_ISIJ_2013	D011	D011_ZHANG_MA_ISIJ_V1	CS_INV_T	15893.000000000000	K	ISIJ-53-761-EQ10-TABLE2-v1	Zhang, Chou and Uday, ISIJ International 53 (2013), Eq.10 and Table 2	https://doi.org/10.2355/isijinternational.53.761	1773.0000	1923.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "oxide mole amount weighted by oxygen stoichiometry; CaF2 uses oxygen-equivalent 1", "equilibrium_only": true, "supported_components": ["CaO", "MgO", "Al2O3", "SiO2", "FeO", "MnO", "TiO2", "CaF2"], "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
12	DS_SLAG_S_CAPACITY_ISIJ_2013	D011	D011_ZHANG_MA_ISIJ_V1	CS_INV_LAMBDA_INV_T	-15864.000000000000	K	ISIJ-53-761-EQ10-TABLE2-v1	Zhang, Chou and Uday, ISIJ International 53 (2013), Eq.10 and Table 2	https://doi.org/10.2355/isijinternational.53.761	1773.0000	1923.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "oxide mole amount weighted by oxygen stoichiometry; CaF2 uses oxygen-equivalent 1", "equilibrium_only": true, "supported_components": ["CaO", "MgO", "Al2O3", "SiO2", "FeO", "MnO", "TiO2", "CaF2"], "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
13	DS_S_DISTRIBUTION_ISIJ_2016	D011	D011_ZHANG_MA_ISIJ_V1	LOGK5_INV_T	-420.000000000000	K	ISIJINT-2016-274-EQ7-8-v1	Ma et al., ISIJ International 56 (2016), Eq.7-8	https://doi.org/10.2355/isijinternational.ISIJINT-2016-274	1773.0000	1923.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "oxide mole amount weighted by oxygen stoichiometry; CaF2 uses oxygen-equivalent 1", "equilibrium_only": true, "supported_components": ["CaO", "MgO", "Al2O3", "SiO2", "FeO", "MnO", "TiO2", "CaF2"], "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
14	DS_S_DISTRIBUTION_ISIJ_2016	D011	D011_ZHANG_MA_ISIJ_V1	LOGK5_INTERCEPT	1.140000000000	1	ISIJINT-2016-274-EQ7-8-v1	Ma et al., ISIJ International 56 (2016), Eq.7-8	https://doi.org/10.2355/isijinternational.ISIJINT-2016-274	1773.0000	1923.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "oxide mole amount weighted by oxygen stoichiometry; CaF2 uses oxygen-equivalent 1", "equilibrium_only": true, "supported_components": ["CaO", "MgO", "Al2O3", "SiO2", "FeO", "MnO", "TiO2", "CaF2"], "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
15	DS_SLAG_S_CAPACITY_ISIJ_2013	D011	D011_ZHANG_MA_ISIJ_V1	OPTICAL_BASICITY_CAO	1.000000000000	1	ISIJ-53-761-EQ10-TABLE2-v1	Zhang, Chou and Uday, ISIJ International 53 (2013), Eq.10 and Table 2	https://doi.org/10.2355/isijinternational.53.761	1773.0000	1923.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "oxide mole amount weighted by oxygen stoichiometry; CaF2 uses oxygen-equivalent 1", "equilibrium_only": true, "supported_components": ["CaO", "MgO", "Al2O3", "SiO2", "FeO", "MnO", "TiO2", "CaF2"], "plant_control_approved": false}	{"component_formula": "CaO", "oxygen_equivalent": 1}	t	2026-09-01 12:31:27.272612
16	DS_SLAG_S_CAPACITY_ISIJ_2013	D011	D011_ZHANG_MA_ISIJ_V1	OPTICAL_BASICITY_MGO	0.780000000000	1	ISIJ-53-761-EQ10-TABLE2-v1	Zhang, Chou and Uday, ISIJ International 53 (2013), Eq.10 and Table 2	https://doi.org/10.2355/isijinternational.53.761	1773.0000	1923.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "oxide mole amount weighted by oxygen stoichiometry; CaF2 uses oxygen-equivalent 1", "equilibrium_only": true, "supported_components": ["CaO", "MgO", "Al2O3", "SiO2", "FeO", "MnO", "TiO2", "CaF2"], "plant_control_approved": false}	{"component_formula": "MgO", "oxygen_equivalent": 1}	t	2026-09-01 12:31:27.272612
17	DS_SLAG_S_CAPACITY_ISIJ_2013	D011	D011_ZHANG_MA_ISIJ_V1	OPTICAL_BASICITY_AL2O3	0.610000000000	1	ISIJ-53-761-EQ10-TABLE2-v1	Zhang, Chou and Uday, ISIJ International 53 (2013), Eq.10 and Table 2	https://doi.org/10.2355/isijinternational.53.761	1773.0000	1923.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "oxide mole amount weighted by oxygen stoichiometry; CaF2 uses oxygen-equivalent 1", "equilibrium_only": true, "supported_components": ["CaO", "MgO", "Al2O3", "SiO2", "FeO", "MnO", "TiO2", "CaF2"], "plant_control_approved": false}	{"component_formula": "Al2O3", "oxygen_equivalent": 3}	t	2026-09-01 12:31:27.272612
18	DS_SLAG_S_CAPACITY_ISIJ_2013	D011	D011_ZHANG_MA_ISIJ_V1	OPTICAL_BASICITY_SIO2	0.480000000000	1	ISIJ-53-761-EQ10-TABLE2-v1	Zhang, Chou and Uday, ISIJ International 53 (2013), Eq.10 and Table 2	https://doi.org/10.2355/isijinternational.53.761	1773.0000	1923.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "oxide mole amount weighted by oxygen stoichiometry; CaF2 uses oxygen-equivalent 1", "equilibrium_only": true, "supported_components": ["CaO", "MgO", "Al2O3", "SiO2", "FeO", "MnO", "TiO2", "CaF2"], "plant_control_approved": false}	{"component_formula": "SiO2", "oxygen_equivalent": 2}	t	2026-09-01 12:31:27.272612
19	DS_SLAG_S_CAPACITY_ISIJ_2013	D011	D011_ZHANG_MA_ISIJ_V1	OPTICAL_BASICITY_FEO	1.240000000000	1	ISIJ-53-761-EQ10-TABLE2-v1	Zhang, Chou and Uday, ISIJ International 53 (2013), Eq.10 and Table 2	https://doi.org/10.2355/isijinternational.53.761	1773.0000	1923.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "oxide mole amount weighted by oxygen stoichiometry; CaF2 uses oxygen-equivalent 1", "equilibrium_only": true, "supported_components": ["CaO", "MgO", "Al2O3", "SiO2", "FeO", "MnO", "TiO2", "CaF2"], "plant_control_approved": false}	{"component_formula": "FeO", "oxygen_equivalent": 1}	t	2026-09-01 12:31:27.272612
20	DS_SLAG_S_CAPACITY_ISIJ_2013	D011	D011_ZHANG_MA_ISIJ_V1	OPTICAL_BASICITY_MNO	1.430000000000	1	ISIJ-53-761-EQ10-TABLE2-v1	Zhang, Chou and Uday, ISIJ International 53 (2013), Eq.10 and Table 2	https://doi.org/10.2355/isijinternational.53.761	1773.0000	1923.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "oxide mole amount weighted by oxygen stoichiometry; CaF2 uses oxygen-equivalent 1", "equilibrium_only": true, "supported_components": ["CaO", "MgO", "Al2O3", "SiO2", "FeO", "MnO", "TiO2", "CaF2"], "plant_control_approved": false}	{"component_formula": "MnO", "oxygen_equivalent": 1}	t	2026-09-01 12:31:27.272612
21	DS_SLAG_S_CAPACITY_ISIJ_2013	D011	D011_ZHANG_MA_ISIJ_V1	OPTICAL_BASICITY_TIO2	0.610000000000	1	ISIJ-53-761-EQ10-TABLE2-v1	Zhang, Chou and Uday, ISIJ International 53 (2013), Eq.10 and Table 2	https://doi.org/10.2355/isijinternational.53.761	1773.0000	1923.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "oxide mole amount weighted by oxygen stoichiometry; CaF2 uses oxygen-equivalent 1", "equilibrium_only": true, "supported_components": ["CaO", "MgO", "Al2O3", "SiO2", "FeO", "MnO", "TiO2", "CaF2"], "plant_control_approved": false}	{"component_formula": "TiO2", "oxygen_equivalent": 2}	t	2026-09-01 12:31:27.272612
22	DS_SLAG_S_CAPACITY_ISIJ_2013	D011	D011_ZHANG_MA_ISIJ_V1	OPTICAL_BASICITY_CAF2	0.880000000000	1	ISIJ-53-761-EQ10-TABLE2-v1	Zhang, Chou and Uday, ISIJ International 53 (2013), Eq.10 and Table 2	https://doi.org/10.2355/isijinternational.53.761	1773.0000	1923.0000	ENGINEERING_SCREENING_ONLY	{"formula_basis": "oxide mole amount weighted by oxygen stoichiometry; CaF2 uses oxygen-equivalent 1", "equilibrium_only": true, "supported_components": ["CaO", "MgO", "Al2O3", "SiO2", "FeO", "MnO", "TiO2", "CaF2"], "plant_control_approved": false}	{"component_formula": "CaF2", "oxygen_equivalent": 1}	t	2026-09-01 12:31:27.272612
23	DS_MN_EQUILIBRIUM_ISIJ_1963	D012	D012_GUNJI_MATOBA_LIQUID_V1	LOGK_A	6440.000000000000	K	TETSU-49-5-756-LIQUID-v1	Gunji and Matoba, Tetsu-to-Hagane 49 (1963), abstract result 4	https://doi.org/10.2355/tetsutohagane1955.49.5_756	1823.1500	1936.1500	REFERENCE_VALIDATION_ONLY	{"reaction": "(FeO)+[Mn]=(MnO)+[Fe]", "metal_standard_state": "1 mass percent Henry for Mn", "oxide_standard_state": "liquid", "fixed_slag_activities": true, "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
24	DS_MN_EQUILIBRIUM_ISIJ_1963	D012	D012_GUNJI_MATOBA_LIQUID_V1	LOGK_B	-2.830000000000	1	TETSU-49-5-756-LIQUID-v1	Gunji and Matoba, Tetsu-to-Hagane 49 (1963), abstract result 4	https://doi.org/10.2355/tetsutohagane1955.49.5_756	1823.1500	1936.1500	REFERENCE_VALIDATION_ONLY	{"reaction": "(FeO)+[Mn]=(MnO)+[Fe]", "metal_standard_state": "1 mass percent Henry for Mn", "oxide_standard_state": "liquid", "fixed_slag_activities": true, "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
25	DS_SI_EQUILIBRIUM_ISIJ_2017	D013	D013_DONG_ISIJ_2017_V1	LOGK_A	18100.000000000000	K	ISIJINT-2017-147-EQ5-v1	Dong et al., ISIJ International 57 (2017), Eq.2 and Eq.5	https://doi.org/10.2355/isijinternational.ISIJINT-2017-147	1700.0000	2000.0000	REFERENCE_VALIDATION_ONLY	{"reaction": "[Si]+2(FeO)=(SiO2)+2[Fe]", "source_process": "ESR reference; not a BOF plant calibration", "slag_activity_basis": "mass-action concentration or equivalent dimensionless activity", "metal_standard_state": "1 mass percent Henry for Si", "fixed_slag_activities": true, "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
26	DS_SI_EQUILIBRIUM_ISIJ_2017	D013	D013_DONG_ISIJ_2017_V1	LOGK_B	-6.372000000000	1	ISIJINT-2017-147-EQ5-v1	Dong et al., ISIJ International 57 (2017), Eq.2 and Eq.5	https://doi.org/10.2355/isijinternational.ISIJINT-2017-147	1700.0000	2000.0000	REFERENCE_VALIDATION_ONLY	{"reaction": "[Si]+2(FeO)=(SiO2)+2[Fe]", "source_process": "ESR reference; not a BOF plant calibration", "slag_activity_basis": "mass-action concentration or equivalent dimensionless activity", "metal_standard_state": "1 mass percent Henry for Si", "fixed_slag_activities": true, "plant_control_approved": false}	{}	t	2026-09-01 12:31:27.272612
\.


--
-- Data for Name: casting_boundary_profile; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.casting_boundary_profile (id, boundary_profile_id, dataset_id, property_set_id, profile_name, profile_type, independent_variable, profile_version, domain_min, domain_max, independent_unit, value_unit, profile_json, equipment_scope, source_kind, source_ref, source_url, license, usage_scope, metadata, is_approved, created_at) FROM stdin;
1	F005_BENCH_SURFACE_TEMP_300K_V1	DS_F005_ANALYTIC_BENCH_V1	F005_ANALYTIC_CONSTANT_V1	constant 300 K surface temperature	SURFACE_TEMPERATURE	TIME	2026.08-v1	0.00000000	10.00000000	s	K	{"value": 300.0, "equation_type": "CONSTANT"}	{}	MATHEMATICAL_BENCHMARK	Dirichlet boundary for semi-infinite heat-equation identity	\N	Project-generated mathematical identity	MATHEMATICAL_BENCHMARK_ONLY	{"not_enterprise_data": true}	t	2026-08-26 17:28:07.463143
2	F005_BENCH_ZERO_HEAT_FLUX_V1	DS_F005_ANALYTIC_BENCH_V1	F005_ANALYTIC_CONSTANT_V1	zero outward heat flux	SURFACE_HEAT_FLUX	TIME	2026.08-v1	0.00000000	10.00000000	s	W/m2	{"value": 0.0, "equation_type": "CONSTANT", "sign_convention": "outward_positive"}	{}	MATHEMATICAL_BENCHMARK	Energy-conservation boundary identity	\N	Project-generated mathematical identity	MATHEMATICAL_BENCHMARK_ONLY	{"not_enterprise_data": true}	t	2026-08-26 17:28:07.463143
3	F005_BENCH_HEAT_FLUX_100KW_M2_V1	DS_F005_ANALYTIC_BENCH_V1	F005_ANALYTIC_CONSTANT_V1	constant 100 kW/m2 outward heat flux	SURFACE_HEAT_FLUX	TIME	2026.08-v1	0.00000000	10.00000000	s	W/m2	{"value": 100000.0, "equation_type": "CONSTANT", "sign_convention": "outward_positive"}	{}	MATHEMATICAL_BENCHMARK	Neumann boundary for semi-infinite heat-equation identity	\N	Project-generated mathematical identity	MATHEMATICAL_BENCHMARK_ONLY	{"not_enterprise_data": true}	t	2026-08-26 17:28:07.463143
\.


--
-- Data for Name: casting_endpoint_benchmark_case; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.casting_endpoint_benchmark_case (id, benchmark_id, dataset_id, model_code, machine_configuration_id, reference_type, input_json, expected_json, tolerance_json, source_ref, source_url, within_domain, metadata, created_at) FROM stdin;
1	F006-LINEAR-INSIDE-V1	DS_F006_ENDPOINT_BENCH_V1	F006	F006_BENCH_LONG_020M_V1	LINEAR_INTERPOLATION_IDENTITY	{"casting_speed_m_s": 0.02, "center_solid_fraction_curve": [{"time_s": 0.0, "center_solid_fraction": 0.0}, {"time_s": 5.0, "center_solid_fraction": 0.5}, {"time_s": 10.0, "center_solid_fraction": 1.0}], "endpoint_solid_fraction_threshold": 0.8}	{"equipment_status": "inside_machine", "solidification_end_time_s": 8.0, "exit_center_solid_fraction": 1.0, "solidification_end_position_m": 0.16}	{"time_s": 0.000000000001, "position_m": 0.000000000001, "solid_fraction": 0.000000000001}	Hand-computable linear interpolation and z=v*t identity	\N	t	{"independent_reference": "manual arithmetic"}	2026-09-01 10:46:26.889449
2	F006-NONLINEAR-INSIDE-V1	DS_F006_ENDPOINT_BENCH_V1	F006	F006_BENCH_LONG_020M_V1	PIECEWISE_LINEAR_INTERPOLATION_IDENTITY	{"casting_speed_m_s": 0.02, "center_solid_fraction_curve": [{"time_s": 0.0, "center_solid_fraction": 0.1}, {"time_s": 2.0, "center_solid_fraction": 0.3}, {"time_s": 6.0, "center_solid_fraction": 0.8}, {"time_s": 10.0, "center_solid_fraction": 1.0}], "endpoint_solid_fraction_threshold": 0.9}	{"equipment_status": "inside_machine", "solidification_end_time_s": 8.0, "exit_center_solid_fraction": 1.0, "solidification_end_position_m": 0.16}	{"time_s": 0.000000000001, "position_m": 0.000000000001, "solid_fraction": 0.000000000001}	Hand-computable piecewise-linear threshold interpolation	\N	t	{"independent_reference": "manual arithmetic"}	2026-09-01 10:46:26.889449
3	F006-LINEAR-BEYOND-EXIT-V1	DS_F006_ENDPOINT_BENCH_V1	F006	F006_BENCH_SHORT_008M_V1	EQUIPMENT_BOUNDARY_IDENTITY	{"casting_speed_m_s": 0.02, "center_solid_fraction_curve": [{"time_s": 0.0, "center_solid_fraction": 0.0}, {"time_s": 5.0, "center_solid_fraction": 0.5}, {"time_s": 10.0, "center_solid_fraction": 1.0}], "endpoint_solid_fraction_threshold": 0.8}	{"equipment_status": "beyond_machine_exit", "solidification_end_time_s": 8.0, "exit_center_solid_fraction": 0.4, "solidification_end_position_m": 0.16}	{"time_s": 0.000000000001, "position_m": 0.000000000001, "solid_fraction": 0.000000000001}	Hand-computable equipment-exit interpolation and boundary comparison	\N	t	{"independent_reference": "manual arithmetic"}	2026-09-01 10:46:26.889449
\.


--
-- Data for Name: casting_machine_configuration; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.casting_machine_configuration (id, machine_configuration_id, dataset_id, equipment_id, configuration_name, configuration_version, section_shape, section_width_m, section_thickness_m, mold_length_m, effective_metallurgical_length_m, casting_speed_min_m_s, casting_speed_max_m_s, unit_system, usage_scope, source_kind, source_ref, source_url, license, uncertainty_json, metadata, is_approved, created_at) FROM stdin;
1	F006_BENCH_LONG_020M_V1	DS_F006_ENDPOINT_BENCH_V1	SYNTHETIC_VALIDATION_MACHINE_LONG	Synthetic 0.20 m effective-length validation machine	2026.09-v1	RECTANGULAR	0.01000000	0.01000000	0.02000000	0.20000000	0.00500000	0.05000000	SI	MATHEMATICAL_BENCHMARK_ONLY	PROJECT_GENERATED_IDENTITY	Synthetic geometry for F006 threshold-event and equipment-boundary verification	\N	Project-generated mathematical identities; no third-party or plant data	{"exact_constants": true}	{"prohibited_use": "engineering design, production control, or plant alarm", "is_real_equipment": false}	t	2026-09-01 10:46:26.889449
2	F006_BENCH_SHORT_008M_V1	DS_F006_ENDPOINT_BENCH_V1	SYNTHETIC_VALIDATION_MACHINE_SHORT	Synthetic 0.08 m effective-length validation machine	2026.09-v1	RECTANGULAR	0.01000000	0.01000000	0.02000000	0.08000000	0.00500000	0.05000000	SI	MATHEMATICAL_BENCHMARK_ONLY	PROJECT_GENERATED_IDENTITY	Synthetic short machine for F006 beyond-exit status verification	\N	Project-generated mathematical identities; no third-party or plant data	{"exact_constants": true}	{"prohibited_use": "engineering design, production control, or plant alarm", "is_real_equipment": false}	t	2026-09-01 10:46:26.889449
\.


--
-- Data for Name: casting_material_property_correlation; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.casting_material_property_correlation (id, correlation_id, property_set_id, property_type, equation_type, phase, temperature_min_k, temperature_max_k, input_unit, output_unit, coefficients, uncertainty_json, source_kind, source_ref, source_url, source_record_key, priority, metadata, is_active, created_at) FROM stdin;
1	SRM1155A-DENSITY-SOLID-POLY-V1	NIST_SRM1155A_316L_2019_V1	DENSITY	POLYNOMIAL_T	solid	500.0000	1675.0000	K	kg/m3	{"a": 8052.0, "b": -0.564, "c": 0.0}	{"coverage_factor": 2, "relative_percent": 2.5}	MEASURED_FIT	Pichler et al. (2019), Table 3, D(T), solid OPA fit	https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=928362	TABLE3:DENSITY:SOLID	10	{}	t	2026-08-26 17:28:07.463143
2	SRM1155A-DENSITY-MUSHY-LINEAR-V1	NIST_SRM1155A_316L_2019_V1	DENSITY	LINEAR_ENDPOINTS	mushy	1675.0000	1708.0000	K	kg/m3	{"x0": 1675.0, "x1": 1708.0, "y0": 7107.3, "y1": 6935.012}	{"method": "derived bridge; uncertainty not established"}	DERIVED_INTERPOLATION	Linear bridge between Table 3 solid and liquid density fits at reported phase endpoints	https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=928362	DERIVED:DENSITY:MUSHY	20	{}	t	2026-08-26 17:28:07.463143
3	SRM1155A-DENSITY-LIQUID-POLY-V1	NIST_SRM1155A_316L_2019_V1	DENSITY	POLYNOMIAL_T	liquid	1708.0000	2900.0000	K	kg/m3	{"a": 8065.0, "b": -0.661, "c": 0.0}	{"coverage_factor": 2, "relative_percent": 3.0}	MEASURED_FIT	Pichler et al. (2019), Table 3, D(T), liquid OPA fit	https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=928362	TABLE3:DENSITY:LIQUID	10	{}	t	2026-08-26 17:28:07.463143
4	SRM1155A-ENTHALPY-TABLE6-V1	NIST_SRM1155A_316L_2019_V1	ENTHALPY	PIECEWISE_LINEAR_TABLE	all	500.0000	2800.0000	K	J/kg	{"points": [[500, 109000], [600, 163000], [700, 218000], [800, 274000], [900, 333000], [1000, 393000], [1100, 454000], [1200, 515000], [1300, 554000], [1400, 626000], [1500, 697000], [1600, 769000], [1700, 1042000], [1800, 1190000], [1900, 1275000], [2000, 1360000], [2100, 1444000], [2200, 1529000], [2300, 1614000], [2400, 1699000], [2500, 1783000], [2600, 1868000], [2700, 1953000], [2800, 2037000]], "interpolation": "linear_no_extrapolation", "source_value_unit": "kJ/kg", "reference_temperature_k": 298.0}	{"coverage_factor": 2, "solid_relative_percent": 2.5, "liquid_relative_percent": 2.9}	MEASURED_TABLE	Pichler et al. (2019), Table 6, Hs(T), converted from kJ/kg	https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=928362	TABLE6:ENTHALPY	10	{}	t	2026-08-26 17:28:07.463143
5	SRM1155A-HEAT-CAPACITY-TABLE7-V1	NIST_SRM1155A_316L_2019_V1	HEAT_CAPACITY	PIECEWISE_LINEAR_TABLE	solid	473.0000	1253.0000	K	J/(kg*K)	{"points": [[473, 528], [493, 529], [513, 530], [533, 532], [553, 534], [573, 537], [593, 541], [613, 544], [633, 547], [653, 550], [673, 553], [693, 556], [713, 559], [733, 561], [753, 564], [773, 566], [793, 569], [813, 572], [833, 578], [853, 587], [873, 595], [893, 598], [913, 599], [933, 600], [953, 601], [973, 603], [993, 605], [1013, 606], [1033, 608], [1053, 610], [1073, 611], [1093, 613], [1113, 614], [1133, 615], [1153, 617], [1173, 619], [1193, 620], [1213, 621], [1233, 622], [1253, 624]], "interpolation": "linear_no_extrapolation", "source_value_unit": "kJ/(kg*K)"}	{"relative_percent_range": [1.8, 3.0], "reported_point_uncertainties_transcribed": false}	MEASURED_TABLE	Pichler et al. (2019), Table 7, cp(T), converted from kJ/(kg*K)	https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=928362	TABLE7:HEAT_CAPACITY	10	{}	t	2026-08-26 17:28:07.463143
6	SRM1155A-HEAT-CAPACITY-SOLID-HIGH-V1	NIST_SRM1155A_316L_2019_V1	HEAT_CAPACITY	CONSTANT	solid	1350.0000	1675.0000	K	J/(kg*K)	{"value": 714.0}	{"derived_from": "slope of Table 3 enthalpy fit"}	MEASURED_FIT_DERIVATIVE	Pichler et al. (2019), Table 3 and text below Table 4, solid cp=0.714 kJ/(kg*K)	https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=928362	TABLE3:CP:SOLID_HIGH	10	{}	t	2026-08-26 17:28:07.463143
7	SRM1155A-HEAT-CAPACITY-LIQUID-V1	NIST_SRM1155A_316L_2019_V1	HEAT_CAPACITY	CONSTANT	liquid	1708.0000	2900.0000	K	J/(kg*K)	{"value": 847.0}	{"derived_from": "slope of Table 3 enthalpy fit"}	MEASURED_FIT_DERIVATIVE	Pichler et al. (2019), Table 3 and text below Table 4, liquid cp=0.847 kJ/(kg*K)	https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=928362	TABLE3:CP:LIQUID	10	{}	t	2026-08-26 17:28:07.463143
8	SRM1155A-RESISTIVITY-CORRECTED-TABLE6-V1	NIST_SRM1155A_316L_2019_V1	ELECTRICAL_RESISTIVITY_CORRECTED	PIECEWISE_LINEAR_TABLE	all	500.0000	2800.0000	K	microohm*m	{"points": [[500, 0.97], [600, 1.033], [700, 1.089], [800, 1.138], [900, 1.183], [1000, 1.223], [1100, 1.259], [1200, 1.29], [1300, 1.316], [1400, 1.342], [1500, 1.368], [1600, 1.394], [1700, 1.464], [1800, 1.495], [1900, 1.514], [2000, 1.532], [2100, 1.551], [2200, 1.57], [2300, 1.589], [2400, 1.608], [2500, 1.627], [2600, 1.646], [2700, 1.665], [2800, 1.684]], "interpolation": "linear_no_extrapolation"}	{"solid_percent": [5.0, 5.5], "liquid_percent": 4.5, "coverage_factor": 2}	MEASURED_TABLE	Pichler et al. (2019), Table 6, volume-corrected electrical resistivity	https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=928362	TABLE6:RESISTIVITY_CORRECTED	10	{}	t	2026-08-26 17:28:07.463143
9	SRM1155A-THERMAL-CONDUCTIVITY-WF-V1	NIST_SRM1155A_316L_2019_V1	THERMAL_CONDUCTIVITY	WIEDEMANN_FRANZ_FROM_RESISTIVITY_TABLE	all	500.0000	2800.0000	K	W/(m*K)	{"interpolation": "linear_no_extrapolation", "lorenz_number_definition": "pi^2/3*(k_B/e)^2 using exact 2019 SI k_B and e", "lorenz_number_w_ohm_per_k2": 0.00000002443004509073667, "resistivity_points_microohm_m": [[500, 0.97], [600, 1.033], [700, 1.089], [800, 1.138], [900, 1.183], [1000, 1.223], [1100, 1.259], [1200, 1.29], [1300, 1.316], [1400, 1.342], [1500, 1.368], [1600, 1.394], [1700, 1.464], [1800, 1.495], [1900, 1.514], [2000, 1.532], [2100, 1.551], [2200, 1.57], [2300, 1.589], [2400, 1.608], [2500, 1.627], [2600, 1.646], [2700, 1.665], [2800, 1.684]]}	{"use_scope": "validation-only", "model_uncertainty": "not established"}	DERIVED_MODEL_ESTIMATE	Wiedemann-Franz estimate using Pichler et al. (2019) Table 6 corrected resistivity; not a direct conductivity measurement	https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=928362	DERIVED:WIEDEMANN_FRANZ:TABLE6	10	{}	t	2026-08-26 17:28:07.463143
10	SRM1155A-LATENT-HEAT-FUSION-V1	NIST_SRM1155A_316L_2019_V1	LATENT_HEAT	CONSTANT	mushy	1675.0000	1708.0000	K	J/kg	{"value": 290000.0}	{"reported_uncertainty": "not separately stated"}	MEASURED_ENTHALPY_DIFFERENCE	Pichler et al. (2019), H298,2-H298,1=1112-822=290 kJ/kg	https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=928362	TEXT:LATENT_HEAT:290KJ_KG	10	{}	t	2026-08-26 17:28:07.463143
11	SRM1155A-SOLID-FRACTION-LINEAR-V1	NIST_SRM1155A_316L_2019_V1	SOLID_FRACTION	LINEAR_SOLID_FRACTION	all	473.0000	2900.0000	K	1	{"solidus_k": 1675.0, "liquidus_k": 1708.0}	{"model": "linear phase-fraction approximation; not measured"}	DERIVED_PHASE_MODEL	Linear validation phase fraction between Pichler et al. (2019) reported solidus and liquidus	https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=928362	DERIVED:SOLID_FRACTION:LINEAR	10	{}	t	2026-08-26 17:28:07.463143
12	F005BENCH-DENSITY-CONSTANT-V1	F005_ANALYTIC_CONSTANT_V1	DENSITY	CONSTANT	all	300.0000	1200.0000	K	kg/m3	{"value": 1000.0}	{"exact": true}	MATHEMATICAL_BENCHMARK	Project-generated constant giving alpha=1e-4 m2/s with cp and k records	\N	BENCH:DENSITY:CONSTANT	10	{}	t	2026-08-26 17:28:07.463143
13	F005BENCH-CP-CONSTANT-V1	F005_ANALYTIC_CONSTANT_V1	HEAT_CAPACITY	CONSTANT	all	300.0000	1200.0000	K	J/(kg*K)	{"value": 1000.0}	{"exact": true}	MATHEMATICAL_BENCHMARK	Project-generated constant giving alpha=1e-4 m2/s with rho and k records	\N	BENCH:CP:CONSTANT	10	{}	t	2026-08-26 17:28:07.463143
14	F005BENCH-K-CONSTANT-V1	F005_ANALYTIC_CONSTANT_V1	THERMAL_CONDUCTIVITY	CONSTANT	all	300.0000	1200.0000	K	W/(m*K)	{"value": 100.0}	{"exact": true}	MATHEMATICAL_BENCHMARK	Project-generated constant giving alpha=1e-4 m2/s with rho and cp records	\N	BENCH:K:CONSTANT	10	{}	t	2026-08-26 17:28:07.463143
15	F005BENCH-ENTHALPY-LINEAR-V1	F005_ANALYTIC_CONSTANT_V1	ENTHALPY	POLYNOMIAL_T	all	300.0000	1200.0000	K	J/kg	{"a": -300000.0, "b": 1000.0, "c": 0.0}	{"exact": true, "reference_temperature_k": 300.0}	MATHEMATICAL_BENCHMARK	Integral of constant cp with zero enthalpy at 300 K	\N	BENCH:ENTHALPY:LINEAR	10	{}	t	2026-08-26 17:28:07.463143
\.


--
-- Data for Name: casting_material_property_set; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.casting_material_property_set (id, property_set_id, dataset_id, material_name, material_grade, reference_material_id, property_set_version, composition_basis, composition_json, temperature_min_k, temperature_max_k, solidus_temperature_k, liquidus_temperature_k, phase_model, unit_system, usage_scope, source_ref, source_url, license, uncertainty_json, metadata, is_approved, created_at) FROM stdin;
1	NIST_SRM1155A_316L_2019_V1	DS_NIST_SRM1155A_316L_2019	NIST SRM 1155a stainless steel	316L (Cr18-Ni12-Mo2)	NIST SRM 1155a	2019-paper-transcription-v1	mass_percent_with_iron_balance	{"C": 0.026, "Cr": 17.803, "Fe": "balance", "Mn": 1.593, "Mo": 2.188, "Ni": 12.471, "Si": 0.521}	473.0000	2900.0000	1675.0000	1708.0000	reported_endpoints_with_linear_mushy_fraction_for_validation	SI	REFERENCE_VALIDATION_ONLY	Pichler et al. (2019), Tables 2-7, DOI 10.1007/s10853-019-04261-6	https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=928362	CC BY 4.0	{"coverage": "k=2 unless Table 4 marks statistical", "density_solid_percent": 2.5, "solidus_temperature_k": 15.0, "density_liquid_percent": 3.0, "enthalpy_solid_percent": 2.5, "liquidus_temperature_k": 30.0, "enthalpy_liquid_percent": 2.9, "heat_capacity_solid_percent_range": [1.8, 3.0], "derived_conductivity_model_uncertainty": "not established; validation-only"}	{"source_tables": [2, 3, 4, 5, 6, 7], "prohibited_use": "plant control or extrapolation to other steel grades", "solver_formulation": "enthalpy_table_with_linear_interpolation", "thermal_conductivity_note": "Derived estimate, not directly measured in the source paper"}	t	2026-08-26 17:28:07.463143
2	F005_ANALYTIC_CONSTANT_V1	DS_F005_ANALYTIC_BENCH_V1	dimensionally consistent constant-property benchmark medium	MATHEMATICAL_BENCHMARK	\N	2026.08-v1	not_applicable	{}	300.0000	1200.0000	\N	\N	no_phase_change	SI	MATHEMATICAL_BENCHMARK_ONLY	Project-generated exact heat-equation benchmark	\N	Project-generated mathematical identities; no third-party data	{"exact_constants": true}	{"prohibited_use": "material prediction or plant control", "thermal_diffusivity_m2_s": 0.0001}	t	2026-08-26 17:28:07.463143
\.


--
-- Data for Name: casting_model_benchmark_case; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.casting_model_benchmark_case (id, benchmark_id, model_code, property_set_id, boundary_profile_id, reference_type, input_json, expected_json, tolerance_json, source_ref, source_url, within_domain, metadata, created_at) FROM stdin;
1	F005-ANALYTIC-DIRICHLET-SEMI-INFINITE-V1	F005	F005_ANALYTIC_CONSTANT_V1	F005_BENCH_SURFACE_TEMP_300K_V1	ANALYTIC_SEMI_INFINITE_DIRICHLET	{"duration_s": 1.0, "sample_depth_m": 0.01, "half_thickness_m": 0.1, "initial_temperature_k": 800.0}	{"similarity_variable": 0.5, "temperature_at_sample_k": 560.2499389065233, "thermal_diffusivity_m2_s": 0.0001}	{"temperature_absolute_k": 0.5}	T=Ts+(Ti-Ts) erf[x/(2 sqrt(alpha t))]	https://dlmf.nist.gov/7.2	t	{"purpose": "independent analytic solver verification"}	2026-08-26 17:28:07.463143
2	F005-ANALYTIC-ZERO-FLUX-UNIFORM-V1	F005	F005_ANALYTIC_CONSTANT_V1	F005_BENCH_ZERO_HEAT_FLUX_V1	CONSERVATION_IDENTITY	{"duration_s": 5.0, "half_thickness_m": 0.1, "initial_temperature_k": 800.0}	{"uniform_temperature_k": 800.0, "cumulative_removed_heat_j_m2": 0.0}	{"energy_absolute_j_m2": 0.000000001, "temperature_absolute_k": 0.000000001}	Uniform initial field with adiabatic boundaries is invariant	\N	t	{"purpose": "energy conservation and zero-flux boundary verification"}	2026-08-26 17:28:07.463143
3	F005-ANALYTIC-NEUMANN-SURFACE-V1	F005	F005_ANALYTIC_CONSTANT_V1	F005_BENCH_HEAT_FLUX_100KW_M2_V1	ANALYTIC_SEMI_INFINITE_NEUMANN	{"duration_s": 1.0, "sample_depth_m": 0.0, "half_thickness_m": 0.1, "initial_temperature_k": 800.0}	{"surface_temperature_k": 788.7162083290449, "thermal_diffusivity_m2_s": 0.0001}	{"temperature_absolute_k": 0.5}	Ts=Ti-2*q*sqrt(alpha*t)/(k*sqrt(pi)) for outward-positive constant heat flux	\N	t	{"purpose": "independent Neumann boundary verification"}	2026-08-26 17:28:07.463143
\.


--
-- Data for Name: dataset_import_issue; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.dataset_import_issue (id, run_id, severity, natural_key, issue_code, details, created_at) FROM stdin;
\.


--
-- Data for Name: dataset_import_run; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.dataset_import_run (run_id, dataset_id, source_version, source_checksum, dry_run, status, staged_count, inserted_count, unchanged_count, conflict_count, details, started_at, completed_at) FROM stdin;
3edabf3f-0888-48c3-a46d-fd6219e3fbd0	30TOOLS-D1	2026.08-v1	sha256:5f6ee92c4cba5349e2b4169871ab1a702908d545d0a37df8d1899c0a4c9ce558	f	committed	147	147	0	0	{"assets": {"bof": "sha256:5f6ee92c4cba5349e2b4169871ab1a702908d545d0a37df8d1899c0a4c9ce558", "nasa": "sha256:5ae89a7d6d1c2f5bcb25dcc78850b968d1b9f210ab49b56ca91405eeb23e3136", "atomic": "sha256:fa344df26d99c4a180144b53c610a835407a742502348aa569552d7996f236c3", "ellingham": "sha256:82928dde8e8bddb788fd660d5b9f66b0b884cee623a0cd9179d926f4acf41c1e"}, "backup": {"path": "D:\\\\a_workplace\\\\metallurgy(2)\\\\metallurgy_v2_20260520\\\\backups\\\\30tools_pre_d1_20260825_165653\\\\metallurgy_full.custom", "sha256": "e901c8cb3108d29290f2d173a26295ff394fcc3c0eddcd66aa438b3921f83876"}}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
1f8d6890-25d8-434c-87f1-84f13ed9f68a	DS_MATCALC_MC_FE_2059	mc_fe_v2.059	a8628b6e0cb117f31d8278d87545e2d29fea78c9573694d0c51f1c72e50ac5e3	f	committed	5	5	0	0	{"backup": {"path": "D:\\\\a_workplace\\\\metallurgy(2)\\\\metallurgy_v2_20260520\\\\backups\\\\p0_w4_20260826_145241\\\\metallurgy_pre_w4.dump", "sha256": "3691201003826b7d0baa94293fd552fc1367273fc875a6f39ac0f1c77474c6f9"}, "manifest": "D:\\\\a_workplace\\\\metallurgy(2)\\\\metallurgy_v2_20260520\\\\Tools\\\\models_core\\\\data\\\\calculation_assets\\\\mc_fe_v2.059.manifest.json", "asset_sha256": "a8628b6e0cb117f31d8278d87545e2d29fea78c9573694d0c51f1c72e50ac5e3"}	2026-08-26 14:59:53.070081	2026-08-26 14:59:53.070081
aa5b6f89-232f-4bea-9d10-1bff4f1bc94a	DS_MATCALC_MC_FE_2059	mc_fe_v2.059	a8628b6e0cb117f31d8278d87545e2d29fea78c9573694d0c51f1c72e50ac5e3	f	committed	6	1	5	0	{"backup": {"path": "D:\\\\a_workplace\\\\metallurgy(2)\\\\metallurgy_v2_20260520\\\\backups\\\\p0_w4_20260826_145241\\\\metallurgy_pre_w4.dump", "sha256": "3691201003826b7d0baa94293fd552fc1367273fc875a6f39ac0f1c77474c6f9"}, "manifest": "D:\\\\a_workplace\\\\metallurgy(2)\\\\metallurgy_v2_20260520\\\\Tools\\\\models_core\\\\data\\\\calculation_assets\\\\mc_fe_v2.059.manifest.json", "asset_sha256": "a8628b6e0cb117f31d8278d87545e2d29fea78c9573694d0c51f1c72e50ac5e3"}	2026-08-26 15:26:11.748086	2026-08-26 15:26:11.748086
9475bc36-a1a0-4e43-a022-a3abc0ae3f78	P1-W5B-CASTING-THERMAL-2026.08-v1	2026.08-v1	c478458b8cfff105f1469d403b2e2e3332c3afffa70b8142d868f8c20f3db116	f	committed	25	25	0	0	{"asset": "Tools/models_core/data/casting_thermal_reference_v1.json", "backup": {"path": "D:\\\\a_workplace\\\\metallurgy(2)\\\\metallurgy_v2_20260520\\\\backups\\\\p1_w5b_data_20260826_172721\\\\metallurgy_pre_w5b_data.dump", "sha256": "4e1eeec0e351654cba0a68853ead1736dd88c664e2196fe8a46d3aa7f0ebad8b"}, "asset_sha256": "c478458b8cfff105f1469d403b2e2e3332c3afffa70b8142d868f8c20f3db116", "restricted_ds042_imported": false}	2026-08-26 17:28:07.463143	2026-08-26 17:28:07.463143
9b4d916c-a22e-412e-9e91-cb7b0e85a679	P1-W5C-CASTING-ENDPOINT-2026.09-v1	2026.09-v1	bc9e820754739640ae55f16962e3819a7b0f815f6ed102cac5bb95c431e096d3	f	committed	6	6	0	0	{"asset": "Tools/models_core/data/casting_endpoint_reference_v1.json", "backup": {"path": "D:\\\\a_workplace\\\\metallurgy(2)\\\\metallurgy_v2_20260520\\\\backups\\\\p1_w5c_data_20260901_104548\\\\metallurgy_pre_f006.dump", "sha256": "f04bf0a620ed6b0488ee9fba4170056c0b03036fe9a2be833139ef6c1842c1ad"}, "asset_sha256": "bc9e820754739640ae55f16962e3819a7b0f815f6ed102cac5bb95c431e096d3", "real_equipment_imported": false, "restricted_ds042_imported": false}	2026-09-01 10:46:26.889449	2026-09-01 10:46:26.889449
4c9b53a6-caea-4cc2-b6a1-6c00a9eb4227	P1-W7-BOF-SLAG-MODELS-2026.09-v1	2026.09-v1	67e69829dedb77b65e1151cd5e2af88db9b0b381a7dfbad117de53dd0b500e20	f	committed	31	31	0	0	{"asset": "Tools/models_core/data/bof_slag_model_parameters_v1.json", "backup": {"path": "D:\\\\a_workplace\\\\metallurgy(2)\\\\metallurgy_v2_20260520\\\\backups\\\\P1-W7_preimport_20260901_01\\\\metallurgy_pre_w7.dump", "sha256": "de94262f67dd81956592500a8c0ef4cb5d22719a561cc2e3953e6c7fb8d03cb2"}, "asset_sha256": "67e69829dedb77b65e1151cd5e2af88db9b0b381a7dfbad117de53dd0b500e20", "ds042_unchanged": true, "plant_control_approved": false, "restricted_ds042_imported": false}	2026-09-01 12:31:27.272612	2026-09-01 12:31:27.272612
a0f357a7-81d5-4da6-b8be-ac9326e502fa	DS_BF_GHG_FACTORS_W15	2026.09-v1	sha256:e242f3b1a5d44bebba2864dd8c9f18d67a7a3d7d7891135649e3d03a6badc090	f	committed	17	17	0	0	{"backup": {"path": "D:\\\\a_workplace\\\\metallurgy(2)\\\\metallurgy_v2_20260520\\\\backups\\\\p1_w15_e020_preimport_20260902\\\\metallurgy_pre_e020.dump", "sha256": "f5ecca3d232a25f4253d66efabe6d5694ef4c91ecc2bee56e15f32d52592362e"}, "asset_id": "BF_GHG_FACTORS_W15_V1", "migration": "database/migrations/012_bf_emission_factors.sql", "asset_sha256": "sha256:e242f3b1a5d44bebba2864dd8c9f18d67a7a3d7d7891135649e3d03a6badc090"}	2026-09-02 10:27:03.586049	2026-09-02 10:27:03.586049
6d48c9e1-d223-4971-b06b-887481a64252	DS_NIST_JANAF_IRON_REDUCTION_W18	2026.09-w18-v1	f2458b5414fbe6ed0c3dd4d9cefdb25900cad4b2399087f0c29fc4de62c9a85d	f	committed	15	15	0	0	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "unchanged": 0, "conflict_count": 0, "mutation_policy": "INSERT_ONLY", "dataset_inserted": 1, "correlations_inserted": 14}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
10a755a2-5938-4128-b2ed-360ad3c8f1b0	DS_MELT_VISCOSITY_W13	2026.09-v1	sha256:c57bff170f8f16eccc18ace52d25c2acc62638af58315841e7e5533f798a7048	f	committed	3	3	0	0	{"backup": {"path": "D:\\\\a_workplace\\\\metallurgy(2)\\\\metallurgy_v2_20260520\\\\backups\\\\P1-W13_preimport_20260901_01\\\\metallurgy_pre_w13.dump", "sha256": "05bd3b9c930b3799d25b4dec2e04ab0e0d3e397737b54f3dc07cff815b7be5b5"}, "asset_id": "MELT-VISCOSITY-CORRELATIONS-W13-V1", "migration": "database/migrations/011_melt_viscosity_correlations.sql", "asset_sha256": "sha256:c57bff170f8f16eccc18ace52d25c2acc62638af58315841e7e5533f798a7048"}	2026-09-01 17:33:12.865022	2026-09-01 17:33:12.865022
\.


--
-- Data for Name: dataset_registry; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.dataset_registry (dataset_id, name, category, provider, license, access_url, ingestion_mode, version, retrieved_at, checksum, owner, security_level, quality_grade, lineage_json, created_at, updated_at) FROM stdin;
DS001	NIST Chemistry WebBook	热化学/物性	NIST	公开；按页面许可与引用要求使用	https://webbook.nist.gov/chemistry/	网页/批量下载	1.0	2026-07-21 11:51:29.847617	\N	数据组	公开	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS002	NIST-JANAF Thermochemical Tables	热化学/物性	NIST	公开；需规范引用	https://janaf.nist.gov/	网页/表格	1.0	2026-07-21 11:51:29.847617	\N	数据组	公开	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS003	Materials Project	材料计算	LBNL	API访问；遵守使用条款与引用规范	https://docs.materialsproject.org/open-apis/the-materials-api/	REST API	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS004	Open Quantum Materials Database (OQMD)	材料计算	Northwestern University	开放访问；遵守许可与引用	https://oqmd.org/api/	REST API/下载	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS005	AFLOW	材料计算	AFLOW Consortium	开放接口；需引用	https://aflow.org/documentation/	API/下载	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS006	NOMAD	材料计算	FAIR-DI e.V.	开放平台；各条目许可可能不同	https://nomad-lab.eu/	API/下载	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS007	NIST-JARVIS	材料计算	NIST	公开；遵守引用与许可	https://jarvis.nist.gov/	API/下载	1.0	2026-07-21 11:51:29.847617	\N	数据组	公开	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS008	Crystallography Open Database (COD)	晶体结构	COD Advisory Board	CC0数据；文献本身另受版权保护	https://www.crystallography.net/cod/	批量下载/API	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS009	Materials Cloud	材料计算	EPFL/PSI/ETHZ等	各数据集许可不同	https://www.materialscloud.org/	网页/API/归档	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS010	NIMS MatNavi	材料实验	NIMS	部分开放，部分需注册或受条款限制	https://mits.nims.go.jp/en/	网页/注册	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS011	NIMS Thermophysical Property Database	材料实验	NIMS	按站点条款使用	https://thermophys.nims.go.jp/en/	网页/下载	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS012	Matbench	材料机器学习	Materials Project/社区	开放；按各数据集许可引用	https://docs.materialsproject.org/collaborations/matbench	Python/下载	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS013	matminer datasets	材料机器学习	LBNL/社区	开放；各数据集许可不同	https://hackingmaterials.lbl.gov/matminer/dataset_summary.html	Python/下载	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS014	UCI Steel Plates Faults	质量检测	UCI Machine Learning Repository	按UCI数据集许可与引用要求	https://archive.ics.uci.edu/ml/datasets/steel+plates+faults	下载	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS015	OpenAlex	文献元数据	OurResearch	开放数据；遵守API礼貌策略	https://developers.openalex.org/	REST API/快照	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS016	Crossref REST API	文献元数据	Crossref	开放API；需遵守礼貌池规范	https://www.crossref.org/documentation/retrieve-metadata/rest-api/	REST API	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS017	CORE API	开放论文	CORE	需注册；遵守许可和速率限制	https://core.ac.uk/documentation/api	REST API	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS018	DataCite API	数据集元数据	DataCite	开放元数据；遵守使用规范	https://support.datacite.org/docs/api	REST API	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS019	Zenodo API	开放科研数据	CERN/OpenAIRE	各记录许可不同	https://developers.zenodo.org/	REST API	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS020	国家标准全文公开系统	标准法规	国家市场监督管理总局/国家标准委	公开范围内使用；标准版权与下载限制需遵守	https://openstd.samr.gov.cn/	网页检索	1.0	2026-07-21 11:51:29.847617	\N	数据组	公开	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS021	全国标准信息公共服务平台	标准法规	国家标准委	公开元数据	https://std.samr.gov.cn/	网页检索	1.0	2026-07-21 11:51:29.847617	\N	数据组	公开	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS022	WIPO PATENTSCOPE	专利	WIPO	公开检索；全文和批量使用受条款约束	https://www.wipo.int/en/web/patentscope	网页/API视权限	1.0	2026-07-21 11:51:29.847617	\N	数据组	公开	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS023	Espacenet	专利	European Patent Office	公开检索；遵守EPO条款	https://www.epo.org/en/searching-for-patents/technical/espacenet	网页/API视权限	1.0	2026-07-21 11:51:29.847617	\N	数据组	公开	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS024	steeluniversity	教学与工艺知识	World Steel Association	课程内容受版权保护	https://steeluniversity.org/	网页/课程	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS025	worldsteel Steelmaking Process	流程知识	World Steel Association	公开网页；需引用	https://worldsteel.org/about-steel/steelmaking-process/	网页	1.0	2026-07-21 11:51:29.847617	\N	数据组	公开	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS035	OpenFOAM	CFD软件	OpenFOAM Foundation	GPL开源	https://openfoam.org/	软件/源码	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS026	worldsteel LCI Data and Eco-profiles	碳排与生命周期	World Steel Association	数据访问与再分发受条款约束	https://worldsteel.org/wider-sustainability/life-cycle-thinking/life-cycle-inventory-data-and-eco-profiles/	网页/申请数据	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS027	IEA Iron and Steel	能源与减排	International Energy Agency	部分开放；报告版权受保护	https://www.iea.org/energy-system/industry/iron-and-steel	网页/报告	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS028	EPA GHGRP Data Sets	企业排放	US EPA	美国政府开放数据	https://www.epa.gov/ghgreporting/data-sets	CSV/网页	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS029	EU Industrial Emissions Portal	企业排放	European Environment Agency	开放数据，按许可引用	https://industry.eea.europa.eu/	下载/网页	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS030	USGS Iron and Steel Statistics	原料与产量	U.S. Geological Survey	美国政府公开数据	https://www.usgs.gov/centers/national-minerals-information-center/iron-and-steel-statistics-and-information	网页/下载	1.0	2026-07-21 11:51:29.847617	\N	数据组	公开	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS031	pycalphad	热力学软件	开源社区	开源软件；数据库许可独立	https://pycalphad.org/docs	Python库	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS032	OpenCalphad	热力学软件	OpenCalphad Project	按项目许可使用；数据库许可独立	https://www.opencalphad.com/	软件/源码	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS033	Cantera	化学反应软件	Cantera Community	开源	https://cantera.org/	Python/C++	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS034	Thermochimica	热化学软件	ORNL	开源；数据库许可另核对	https://github.com/ORNL-CEES/thermochimica	源码/库	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS036	FiPy	PDE求解	NIST	开源	https://www.ctcms.nist.gov/fipy/	Python库	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS037	FEniCSx	有限元	FEniCS Project	开源	https://fenicsproject.org/	Python/C++	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS038	Pyomo	优化软件	Pyomo Project	开源；求解器许可独立	https://pyomo.readthedocs.io/	Python库	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS039	OPTIMADE	材料数据接口	OPTIMADE Consortium	开放标准	https://www.optimade.org/	REST API标准	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS040	SciPy	科学计算	SciPy Community	开源	https://docs.scipy.org/doc/scipy/	Python库	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS041	scikit-learn	机器学习	scikit-learn Community	开源	https://scikit-learn.org/stable/	Python库	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS042	实验室/企业历史数据与专家规则	内部数据	项目团队/合作企业	受限；需授权、脱敏与分级权限		数据库/文件/访谈	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS043	Thermo-Calc Databases	商业热力学数据库	Thermo-Calc Software	商业许可	https://thermocalc.com/products/databases/	商业软件/数据库	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS044	FactSage Databases	商业热化学数据库	Thermfact/CRCT & GTT-Technologies	商业许可	https://factsage.com/introduction/	商业软件/数据库	1.0	2026-07-21 11:51:29.847617	\N	数据组	内部	A	\N	2026-07-21 11:51:29.886544	2026-07-21 11:51:29.886544
DS_IUPAC_AW_2021	IUPAC standard atomic weights 2021 snapshot	基础化学与计量	IUPAC/CIAAW	reference-data snapshot; preserve upstream attribution	\N	versioned repository asset	2021-snapshot-v1	2026-08-25 00:00:00	sha256:fa344df26d99c4a180144b53c610a835407a742502348aa569552d7996f236c3	metallurgy-tools	公开	B	{"import_source": "models_core.chemical_data:ELEMENT_ATOMIC_WEIGHTS"}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
DS_NASA7_GRI30	GRI-Mech 3.0 NASA7 thermodynamic subset	热力学性质	GRI-Mech	reference-data snapshot; preserve upstream attribution	\N	versioned repository asset	NASA7-GRI30-SUBSET-V1	2026-08-25 00:00:00	sha256:5ae89a7d6d1c2f5bcb25dcc78850b968d1b9f210ab49b56ca91405eeb23e3136	metallurgy-tools	公开	B	{"import_source": "Tools\\\\models_core\\\\data\\\\nasa7_gri30_v1.json"}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
DS_BOF_PROCESS_PARAMETERS	BOF transparent static-balance engineering parameters	冶金工艺	metallurgy-tools	reference-data snapshot; preserve upstream attribution	\N	versioned repository asset	BOF-ENGINEERING-BASELINE-2026.08-v1	2026-08-25 00:00:00	sha256:5f6ee92c4cba5349e2b4169871ab1a702908d545d0a37df8d1899c0a4c9ce558	metallurgy-tools	公开	B	{"import_source": "Tools\\\\models_core\\\\data\\\\bof_process_parameters_v1.json", "plant_control_approved": false}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
DS_ELLINGHAM_BARIN_V1	Barin Ellingham parameter snapshot	热力学性质	Barin compilation	reference-data snapshot; preserve upstream attribution	\N	versioned repository asset	ELLINGHAM-BARIN-V1	2026-08-25 00:00:00	sha256:82928dde8e8bddb788fd660d5b9f66b0b884cee623a0cd9179d926f4acf41c1e	metallurgy-tools	公开	B	{"import_source": "models_core.thermo_assets:ELLINGHAM_DATA"}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
DS_MATCALC_MC_FE_2059	MatCalc mc_fe steel thermodynamic database v2.059	相平衡与凝固	MatCalc / pyroll-project snapshot	ODbL-1.0 database; DBCL-1.0 individual contents	\N	versioned repository asset	mc_fe_v2.059	2026-08-26 00:00:00	sha256:a8628b6e0cb117f31d8278d87545e2d29fea78c9573694d0c51f1c72e50ac5e3	metallurgy-tools	公开	B	{"source_url": "https://github.com/pyroll-project/pyroll-examples/blob/0a8dd09136e3c9c1e73afee054bb55a8f6cd84b0/mc_fe_v2.059.pycalphad.tdb", "source_commit": "0a8dd09136e3c9c1e73afee054bb55a8f6cd84b0", "manifest": "Tools/models_core/data/calculation_assets/mc_fe_v2.059.manifest.json"}	2026-08-26 14:59:53.070081	2026-08-26 14:59:53.070081
DS_NIST_SRM1155A_316L_2019	NIST SRM 1155a 316L thermophysical properties	连铸热物性	Pichler, Simonds, Sowards and Pottlacher	CC BY 4.0	https://tsapps.nist.gov/publication/get_pdf.cfm?pub_id=928362	versioned transcription of published tables and equations	2019-12-09	2026-08-26 00:00:00	sha256:ae90ec5c55b1e4145ad8f70f3b77d3656ec6cbcc83c0684bc33e4cfef57266ff	metallurgy-tools	公开	A	{"doi": "10.1007/s10853-019-04261-6", "title": "Measurements of thermophysical properties of solid and liquid NIST SRM 316L stainless steel", "source_pdf_sha256": "ae90ec5c55b1e4145ad8f70f3b77d3656ec6cbcc83c0684bc33e4cfef57266ff", "license_url": "https://creativecommons.org/licenses/by/4.0/", "transformations": ["Transcribed Tables 2, 3, 4, 5, 6 and 7", "Converted kJ/kg and kJ/(kg*K) to SI J/kg and J/(kg*K)", "Thermal conductivity is a separately labelled Wiedemann-Franz estimate derived from reported corrected resistivity"], "import_asset": "Tools/models_core/data/casting_thermal_reference_v1.json", "import_asset_sha256": "c478458b8cfff105f1469d403b2e2e3332c3afffa70b8142d868f8c20f3db116"}	2026-08-26 17:28:07.463143	2026-08-26 17:28:07.463143
DS_F005_ANALYTIC_BENCH_V1	F005 one-dimensional heat-equation analytic benchmarks	数值模型验证	metallurgy-tools verification suite	Project-generated mathematical identities; no third-party data	\N	versioned project-generated benchmark asset	2026.08-v1	2026-08-26 00:00:00	sha256:c478458b8cfff105f1469d403b2e2e3332c3afffa70b8142d868f8c20f3db116	metallurgy-tools	公开	A	{"method": "Closed-form semi-infinite heat-equation and conservation identities", "purpose": "Numerical verification only; not a steel property dataset", "import_asset": "Tools/models_core/data/casting_thermal_reference_v1.json", "import_asset_sha256": "c478458b8cfff105f1469d403b2e2e3332c3afffa70b8142d868f8c20f3db116"}	2026-08-26 17:28:07.463143	2026-08-26 17:28:07.463143
DS_F006_ENDPOINT_BENCH_V1	F006 solidification-end event-location benchmarks	数值模型验证	metallurgy-tools verification suite	Project-generated mathematical identities; no third-party or plant data	\N	versioned project-generated benchmark asset	2026.09-v1	2026-09-01 00:00:00	sha256:bc9e820754739640ae55f16962e3819a7b0f815f6ed102cac5bb95c431e096d3	metallurgy-tools	公开	A	{"method": "Hand-computable monotone solid-fraction curves and synthetic equipment bounds", "purpose": "Numerical verification only; not a production machine or DS042 casting-run dataset", "restricted_ds042_imported": false, "import_asset": "Tools/models_core/data/casting_endpoint_reference_v1.json", "import_asset_sha256": "bc9e820754739640ae55f16962e3819a7b0f815f6ed102cac5bb95c431e096d3"}	2026-09-01 10:46:26.889449	2026-09-01 10:46:26.889449
DS_BOF_P_PARTITION_ISIJ_2016	BOF phosphorus partition correlation reported by Spooner et al.	冶金公开实验关联	ISIJ International / J-STAGE	CC BY-NC-ND 4.0; factual coefficients stored with attribution for non-commercial research validation	https://doi.org/10.2355/isijinternational.ISIJINT-2016-361	reviewed equation-parameter transcription	ISIJINT-2016-361 Eq.6 snapshot	2026-09-01 00:00:00	sha256:67e69829dedb77b65e1151cd5e2af88db9b0b381a7dfbad117de53dd0b500e20	metallurgy-tools	公开	B	{"source_location": "Eq.6", "purpose": "reference validation and engineering screening only", "plant_control_approved": false, "restricted_ds042_imported": false, "import_asset": "Tools/models_core/data/bof_slag_model_parameters_v1.json", "import_asset_sha256": "67e69829dedb77b65e1151cd5e2af88db9b0b381a7dfbad117de53dd0b500e20"}	2026-09-01 12:31:27.272612	2026-09-01 12:31:27.272612
DS_SLAG_S_CAPACITY_ISIJ_2013	Multicomponent slag sulfide-capacity optical-basicity model	冶金公开实验关联	ISIJ International / J-STAGE	CC BY-NC-ND 4.0; factual coefficients stored with attribution for non-commercial research validation	https://doi.org/10.2355/isijinternational.53.761	reviewed equation-parameter transcription	ISIJ International 53 (2013) 761 Eq.10/Table 2 snapshot	2026-09-01 00:00:00	sha256:67e69829dedb77b65e1151cd5e2af88db9b0b381a7dfbad117de53dd0b500e20	metallurgy-tools	公开	B	{"source_location": "Eq.10 and Table 2", "purpose": "reference validation and engineering screening only", "plant_control_approved": false, "restricted_ds042_imported": false, "import_asset": "Tools/models_core/data/bof_slag_model_parameters_v1.json", "import_asset_sha256": "67e69829dedb77b65e1151cd5e2af88db9b0b381a7dfbad117de53dd0b500e20"}	2026-09-01 12:31:27.272612	2026-09-01 12:31:27.272612
DS_S_DISTRIBUTION_ISIJ_2016	Sulfur partition relation from sulfide capacity	冶金公开实验关联	ISIJ International / J-STAGE	CC BY-NC-ND 4.0; factual coefficients stored with attribution for non-commercial research validation	https://doi.org/10.2355/isijinternational.ISIJINT-2016-274	reviewed equation-parameter transcription	ISIJINT-2016-274 Eq.7-8 snapshot	2026-09-01 00:00:00	sha256:67e69829dedb77b65e1151cd5e2af88db9b0b381a7dfbad117de53dd0b500e20	metallurgy-tools	公开	B	{"source_location": "Eq.7 and Eq.8", "purpose": "reference validation and engineering screening only", "plant_control_approved": false, "restricted_ds042_imported": false, "import_asset": "Tools/models_core/data/bof_slag_model_parameters_v1.json", "import_asset_sha256": "67e69829dedb77b65e1151cd5e2af88db9b0b381a7dfbad117de53dd0b500e20"}	2026-09-01 12:31:27.272612	2026-09-01 12:31:27.272612
DS_MN_EQUILIBRIUM_ISIJ_1963	FeO-MnO/liquid-iron manganese equilibrium	冶金公开实验关联	Tetsu-to-Hagane / J-STAGE	CC BY-NC-ND 4.0; factual coefficients stored with attribution for non-commercial research validation	https://doi.org/10.2355/tetsutohagane1955.49.5_756	reviewed equation-parameter transcription	Tetsu-to-Hagane 49 (1963) 756 liquid-standard-state v1	2026-09-01 00:00:00	sha256:67e69829dedb77b65e1151cd5e2af88db9b0b381a7dfbad117de53dd0b500e20	metallurgy-tools	公开	B	{"source_location": "abstract result 4, log K_Mn(l)", "purpose": "reference validation and engineering screening only", "plant_control_approved": false, "restricted_ds042_imported": false, "import_asset": "Tools/models_core/data/bof_slag_model_parameters_v1.json", "import_asset_sha256": "67e69829dedb77b65e1151cd5e2af88db9b0b381a7dfbad117de53dd0b500e20"}	2026-09-01 12:31:27.272612	2026-09-01 12:31:27.272612
DS_SI_EQUILIBRIUM_ISIJ_2017	Si-SiO2-FeO slag-metal equilibrium constant	冶金公开实验关联	ISIJ International / J-STAGE	CC BY-NC-ND 4.0; factual coefficients stored with attribution for non-commercial research validation	https://doi.org/10.2355/isijinternational.ISIJINT-2017-147	reviewed equation-parameter transcription	ISIJINT-2017-147 Eq.5 snapshot	2026-09-01 00:00:00	sha256:67e69829dedb77b65e1151cd5e2af88db9b0b381a7dfbad117de53dd0b500e20	metallurgy-tools	公开	B	{"source_location": "Eq.2 and Eq.5", "purpose": "reference validation and engineering screening only", "source_process": "electroslag remelting; not a BOF plant calibration", "plant_control_approved": false, "restricted_ds042_imported": false, "import_asset": "Tools/models_core/data/bof_slag_model_parameters_v1.json", "import_asset_sha256": "67e69829dedb77b65e1151cd5e2af88db9b0b381a7dfbad117de53dd0b500e20"}	2026-09-01 12:31:27.272612	2026-09-01 12:31:27.272612
DS_MELT_VISCOSITY_W13	Public melt-viscosity correlation definitions for C008	动力学与传递	Urbain/Vargas and Hirai literature transcription	bibliographic equation data; preserve source attribution	https://doi.org/10.1002/srin.198701513	versioned repository asset	2026.09-v1	2026-09-01 00:00:00	sha256:c57bff170f8f16eccc18ace52d25c2acc62638af58315841e7e5533f798a7048	metallurgy-tools	公开	B	{"asset_id": "MELT-VISCOSITY-CORRELATIONS-W13-V1", "import_source": "Tools/models_core/data/melt_viscosity_correlations_w13_v1.json", "model_ids": ["URBAIN_SLAG_1981", "HIRAI_LIQUID_ALLOY_1993"], "plant_control_approved": false}	2026-09-01 17:33:12.865022	2026-09-01 17:33:12.865022
DS_BF_GHG_FACTORS_W15	P1-W15 public blast-furnace activity emission factors	高炉低碳	IPCC; Ministry of Ecology and Environment of China	Public official methodology and factor publications; retain source attribution	https://www.ipcc-nggip.iges.or.jp/public/2006gl/vol2.html	versioned repository asset	2026.09-v1	2026-09-02 00:00:00	sha256:e242f3b1a5d44bebba2864dd8c9f18d67a7a3d7d7891135649e3d03a6badc090	metallurgy-tools	公开	A	{"asset_id": "BF_GHG_FACTORS_W15_V1", "import_source": "Tools/models_core/data/bf_emission_factors_w15_v1.json", "factor_set_id": "BF_GHG_FACTORS_W15_V1", "factor_count": 16, "plant_control_approved": false}	2026-09-02 10:27:03.586049	2026-09-02 10:27:03.586049
DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-JANAF iron-oxide reduction Shomate segments	热化学/铁氧化物还原平衡	NIST Chemistry WebBook SRD 69 / NIST-JANAF	NIST Standard Reference Data terms; attribution required	https://webbook.nist.gov/chemistry/	versioned-json-transactional	2026.09-w18-v1	2026-09-02 00:00:00	f2458b5414fbe6ed0c3dd4d9cefdb25900cad4b2399087f0c29fc4de62c9a85d	metallurgy-tools	公开	A	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_urls": ["https://webbook.nist.gov/cgi/cbook.cgi?ID=C124389&Mask=1&Table=on&Type=JANAFG", "https://webbook.nist.gov/cgi/cbook.cgi?ID=C1317608&Mask=2", "https://webbook.nist.gov/cgi/cbook.cgi?ID=C1333740&Mask=1", "https://webbook.nist.gov/cgi/cbook.cgi?ID=C1345251&Plot=on&Type=JANAFS", "https://webbook.nist.gov/cgi/cbook.cgi?ID=C630080&Mask=1&Plot=on&Type=JANAFG", "https://webbook.nist.gov/cgi/cbook.cgi?ID=C7439896&Table=on&Type=JANAFS", "https://webbook.nist.gov/cgi/cbook.cgi?ID=C7732185&Mask=1&Plot=on&Type=JANAFG", "https://webbook.nist.gov/cgi/formula?ID=C1309382&Table=on&Type=JANAFS"], "additive_only": true, "reserved_for": "E022"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
\.


--
-- Data for Name: element_reference; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.element_reference (id, dataset_id, symbol, atomic_weight_g_mol, unit, source_version, source_ref, source_record_key, is_active, metadata, created_at) FROM stdin;
1	DS_IUPAC_AW_2021	Ac	227.000000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ac	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
2	DS_IUPAC_AW_2021	Ag	107.870000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ag	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
3	DS_IUPAC_AW_2021	Al	26.982000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Al	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
4	DS_IUPAC_AW_2021	Am	243.000000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Am	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
5	DS_IUPAC_AW_2021	Ar	39.948000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ar	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
6	DS_IUPAC_AW_2021	As	74.922000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:As	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
7	DS_IUPAC_AW_2021	At	210.000000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:At	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
8	DS_IUPAC_AW_2021	Au	196.970000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Au	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
9	DS_IUPAC_AW_2021	B	10.810000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:B	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
10	DS_IUPAC_AW_2021	Ba	137.330000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ba	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
11	DS_IUPAC_AW_2021	Be	9.012200000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Be	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
12	DS_IUPAC_AW_2021	Bi	208.980000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Bi	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
13	DS_IUPAC_AW_2021	Br	79.904000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Br	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
14	DS_IUPAC_AW_2021	C	12.011000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:C	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
15	DS_IUPAC_AW_2021	Ca	40.078000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ca	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
16	DS_IUPAC_AW_2021	Cd	112.410000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Cd	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
17	DS_IUPAC_AW_2021	Ce	140.120000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ce	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
18	DS_IUPAC_AW_2021	Cl	35.450000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Cl	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
19	DS_IUPAC_AW_2021	Cm	247.000000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Cm	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
20	DS_IUPAC_AW_2021	Co	58.933000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Co	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
21	DS_IUPAC_AW_2021	Cr	51.996000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Cr	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
22	DS_IUPAC_AW_2021	Cs	132.910000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Cs	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
23	DS_IUPAC_AW_2021	Cu	63.546000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Cu	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
24	DS_IUPAC_AW_2021	Dy	162.500000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Dy	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
25	DS_IUPAC_AW_2021	Er	167.260000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Er	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
26	DS_IUPAC_AW_2021	Eu	151.960000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Eu	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
27	DS_IUPAC_AW_2021	F	18.998000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:F	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
28	DS_IUPAC_AW_2021	Fe	55.845000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Fe	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
29	DS_IUPAC_AW_2021	Fr	223.000000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Fr	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
30	DS_IUPAC_AW_2021	Ga	69.723000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ga	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
31	DS_IUPAC_AW_2021	Gd	157.250000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Gd	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
32	DS_IUPAC_AW_2021	Ge	72.630000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ge	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
33	DS_IUPAC_AW_2021	H	1.008000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:H	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
34	DS_IUPAC_AW_2021	He	4.002600000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:He	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
35	DS_IUPAC_AW_2021	Hf	178.490000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Hf	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
36	DS_IUPAC_AW_2021	Hg	200.590000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Hg	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
37	DS_IUPAC_AW_2021	Ho	164.930000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ho	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
38	DS_IUPAC_AW_2021	I	126.900000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:I	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
39	DS_IUPAC_AW_2021	In	114.820000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:In	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
40	DS_IUPAC_AW_2021	Ir	192.220000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ir	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
41	DS_IUPAC_AW_2021	K	39.098000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:K	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
42	DS_IUPAC_AW_2021	Kr	83.798000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Kr	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
43	DS_IUPAC_AW_2021	La	138.910000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:La	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
44	DS_IUPAC_AW_2021	Li	6.940000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Li	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
45	DS_IUPAC_AW_2021	Lu	174.970000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Lu	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
46	DS_IUPAC_AW_2021	Mg	24.305000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Mg	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
47	DS_IUPAC_AW_2021	Mn	54.938000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Mn	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
48	DS_IUPAC_AW_2021	Mo	95.950000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Mo	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
49	DS_IUPAC_AW_2021	N	14.007000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:N	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
50	DS_IUPAC_AW_2021	Na	22.990000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Na	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
51	DS_IUPAC_AW_2021	Nb	92.906000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Nb	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
52	DS_IUPAC_AW_2021	Nd	144.240000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Nd	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
53	DS_IUPAC_AW_2021	Ne	20.180000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ne	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
54	DS_IUPAC_AW_2021	Ni	58.693000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ni	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
55	DS_IUPAC_AW_2021	Np	237.000000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Np	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
56	DS_IUPAC_AW_2021	O	15.999000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:O	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
57	DS_IUPAC_AW_2021	Os	190.230000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Os	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
58	DS_IUPAC_AW_2021	P	30.974000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:P	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
59	DS_IUPAC_AW_2021	Pa	231.040000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Pa	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
60	DS_IUPAC_AW_2021	Pb	207.200000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Pb	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
61	DS_IUPAC_AW_2021	Pd	106.420000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Pd	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
62	DS_IUPAC_AW_2021	Po	209.000000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Po	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
63	DS_IUPAC_AW_2021	Pr	140.910000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Pr	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
64	DS_IUPAC_AW_2021	Pt	195.080000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Pt	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
65	DS_IUPAC_AW_2021	Pu	244.000000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Pu	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
66	DS_IUPAC_AW_2021	Ra	226.000000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ra	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
67	DS_IUPAC_AW_2021	Rb	85.468000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Rb	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
68	DS_IUPAC_AW_2021	Re	186.210000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Re	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
69	DS_IUPAC_AW_2021	Rh	102.910000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Rh	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
70	DS_IUPAC_AW_2021	Rn	222.000000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Rn	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
71	DS_IUPAC_AW_2021	Ru	101.070000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ru	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
72	DS_IUPAC_AW_2021	S	32.060000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:S	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
73	DS_IUPAC_AW_2021	Sb	121.760000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Sb	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
74	DS_IUPAC_AW_2021	Sc	44.956000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Sc	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
75	DS_IUPAC_AW_2021	Se	78.971000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Se	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
76	DS_IUPAC_AW_2021	Si	28.085000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Si	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
77	DS_IUPAC_AW_2021	Sm	150.360000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Sm	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
78	DS_IUPAC_AW_2021	Sn	118.710000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Sn	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
79	DS_IUPAC_AW_2021	Sr	87.620000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Sr	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
80	DS_IUPAC_AW_2021	Ta	180.950000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ta	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
81	DS_IUPAC_AW_2021	Tb	158.930000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Tb	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
82	DS_IUPAC_AW_2021	Tc	98.000000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Tc	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
83	DS_IUPAC_AW_2021	Te	127.600000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Te	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
84	DS_IUPAC_AW_2021	Th	232.040000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Th	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
85	DS_IUPAC_AW_2021	Ti	47.867000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Ti	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
86	DS_IUPAC_AW_2021	Tl	204.380000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Tl	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
87	DS_IUPAC_AW_2021	Tm	168.930000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Tm	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
88	DS_IUPAC_AW_2021	U	238.030000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:U	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
89	DS_IUPAC_AW_2021	V	50.942000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:V	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
90	DS_IUPAC_AW_2021	W	183.840000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:W	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
91	DS_IUPAC_AW_2021	Xe	131.290000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Xe	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
92	DS_IUPAC_AW_2021	Y	88.906000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Y	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
93	DS_IUPAC_AW_2021	Yb	173.050000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Yb	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
94	DS_IUPAC_AW_2021	Zn	65.380000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Zn	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
95	DS_IUPAC_AW_2021	Zr	91.224000000	g/mol	2021-snapshot-v1	IUPAC/CIAAW standard atomic weights 2021 snapshot	IUPAC-AW-2021:Zr	t	{"natural_isotopic_composition": true}	2026-08-25 17:10:00.585156
\.


--
-- Data for Name: emission_factor; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.emission_factor (id, dataset_id, factor_set_id, factor_code, activity_name, activity_unit, scope, co2_kg_per_unit, ch4_kg_per_unit, n2o_kg_per_unit, co2e_kg_per_unit, gwp_ch4, gwp_n2o, methodology, applicability, source_version, source_ref, source_url, is_approved, created_at) FROM stdin;
1	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	FUEL_COKING_COAL_COMBUSTION_TJ_NCV	Coking coal combusted on NCV basis	TJ_NCV	scope1	94600.0000000000	10.0000000000	1.5000000000	\N	27.000000	273.000000	IPCC stationary combustion default factors; AR6 GWP100 for combustion CH4 and N2O	{"sector": "manufacturing industries and construction", "not_for": "total burden charged without a combustion split", "energy_basis": "net calorific value", "activity_basis": "fuel actually combusted"}	IPCC-2006-V2-C2-T2.3; IPCC-AR6-WGIII-Annex-II	2006 IPCC Guidelines Vol.2 Ch.2 Table 2.3; AR6 WGIII Annex II	https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/2_Volume2/V2_2_Ch2_Stationary_Combustion.pdf	t	2026-09-02 10:27:03.586049
2	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	FUEL_COKE_OVEN_COKE_COMBUSTION_TJ_NCV	Coke oven coke combusted on NCV basis	TJ_NCV	scope1	107000.0000000000	10.0000000000	1.5000000000	\N	27.000000	273.000000	IPCC stationary combustion default factors; AR6 GWP100 for combustion CH4 and N2O	{"sector": "manufacturing industries and construction", "not_for": "total coke burden charged without a combustion split", "energy_basis": "net calorific value", "activity_basis": "fuel actually combusted"}	IPCC-2006-V2-C2-T2.3; IPCC-AR6-WGIII-Annex-II	2006 IPCC Guidelines Vol.2 Ch.2 Table 2.3; AR6 WGIII Annex II	https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/2_Volume2/V2_2_Ch2_Stationary_Combustion.pdf	t	2026-09-02 10:27:03.586049
3	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	FUEL_COKE_OVEN_GAS_COMBUSTION_TJ_NCV	Coke oven gas combusted on NCV basis	TJ_NCV	scope1	44400.0000000000	1.0000000000	0.1000000000	\N	27.000000	273.000000	IPCC stationary combustion default factors; AR6 GWP100 for combustion CH4 and N2O	{"sector": "manufacturing industries and construction", "not_for": "exported gas or internal recycle not combusted inside the declared boundary", "energy_basis": "net calorific value", "activity_basis": "gas actually combusted"}	IPCC-2006-V2-C2-T2.3; IPCC-AR6-WGIII-Annex-II	2006 IPCC Guidelines Vol.2 Ch.2 Table 2.3; AR6 WGIII Annex II	https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/2_Volume2/V2_2_Ch2_Stationary_Combustion.pdf	t	2026-09-02 10:27:03.586049
4	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	FUEL_BLAST_FURNACE_GAS_COMBUSTION_TJ_NCV	Blast furnace gas combusted on NCV basis	TJ_NCV	scope1	260000.0000000000	1.0000000000	0.1000000000	\N	27.000000	273.000000	IPCC stationary combustion default factors; AR6 GWP100 for combustion CH4 and N2O	{"sector": "manufacturing industries and construction", "not_for": "exported gas or carbon already counted as direct process carbon", "energy_basis": "net calorific value", "activity_basis": "gas actually combusted"}	IPCC-2006-V2-C2-T2.3; IPCC-AR6-WGIII-Annex-II	2006 IPCC Guidelines Vol.2 Ch.2 Table 2.3; AR6 WGIII Annex II	https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/2_Volume2/V2_2_Ch2_Stationary_Combustion.pdf	t	2026-09-02 10:27:03.586049
5	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	FUEL_NATURAL_GAS_COMBUSTION_TJ_NCV	Natural gas combusted on NCV basis	TJ_NCV	scope1	56100.0000000000	1.0000000000	0.1000000000	\N	27.000000	273.000000	IPCC stationary combustion default factors; AR6 GWP100 for combustion CH4 and N2O	{"sector": "manufacturing industries and construction", "not_for": "upstream fugitive emissions", "energy_basis": "net calorific value", "activity_basis": "fuel actually combusted"}	IPCC-2006-V2-C2-T2.3; IPCC-AR6-WGIII-Annex-II	2006 IPCC Guidelines Vol.2 Ch.2 Table 2.3; AR6 WGIII Annex II	https://www.ipcc-nggip.iges.or.jp/public/2006gl/pdf/2_Volume2/V2_2_Ch2_Stationary_Combustion.pdf	t	2026-09-02 10:27:03.586049
6	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	ELECTRICITY_CN_NATIONAL_2024_KWH	China national electricity consumption	kWh	scope2	\N	\N	\N	0.5777000000	\N	\N	2024 national electricity carbon-footprint factor	{"year": 2024, "not_for": "supplier-specific contractual electricity", "boundary": "electricity carbon footprint", "geography": "China national average"}	MEE-CN-ELECTRICITY-CF-2024	生态环境部2024年全国电力碳足迹因子	https://www.mee.gov.cn/xxgk2018/xxgk/xxgk01/202510/W020251024569470952545.pdf	t	2026-09-02 10:27:03.586049
7	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	ELECTRICITY_CN_COAL_2024_KWH	China coal-fired electricity	kWh	scope2	\N	\N	\N	0.9240000000	\N	\N	2024 electricity carbon-footprint factor by technology	{"year": 2024, "geography": "China", "technology": "coal power"}	MEE-CN-ELECTRICITY-CF-2024	生态环境部2024年全国电力碳足迹因子	https://www.mee.gov.cn/xxgk2018/xxgk/xxgk01/202510/W020251024569470952545.pdf	t	2026-09-02 10:27:03.586049
8	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	ELECTRICITY_CN_GAS_2024_KWH	China gas-fired electricity	kWh	scope2	\N	\N	\N	0.4503000000	\N	\N	2024 electricity carbon-footprint factor by technology	{"year": 2024, "geography": "China", "technology": "gas power"}	MEE-CN-ELECTRICITY-CF-2024	生态环境部2024年全国电力碳足迹因子	https://www.mee.gov.cn/xxgk2018/xxgk/xxgk01/202510/W020251024569470952545.pdf	t	2026-09-02 10:27:03.586049
9	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	ELECTRICITY_CN_HYDRO_2024_KWH	China hydropower electricity	kWh	scope2	\N	\N	\N	0.0141000000	\N	\N	2024 electricity carbon-footprint factor by technology	{"year": 2024, "geography": "China", "technology": "hydropower"}	MEE-CN-ELECTRICITY-CF-2024	生态环境部2024年全国电力碳足迹因子	https://www.mee.gov.cn/xxgk2018/xxgk/xxgk01/202510/W020251024569470952545.pdf	t	2026-09-02 10:27:03.586049
10	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	ELECTRICITY_CN_NUCLEAR_2024_KWH	China nuclear electricity	kWh	scope2	\N	\N	\N	0.0065000000	\N	\N	2024 electricity carbon-footprint factor by technology	{"year": 2024, "geography": "China", "technology": "nuclear power"}	MEE-CN-ELECTRICITY-CF-2024	生态环境部2024年全国电力碳足迹因子	https://www.mee.gov.cn/xxgk2018/xxgk/xxgk01/202510/W020251024569470952545.pdf	t	2026-09-02 10:27:03.586049
11	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	ELECTRICITY_CN_WIND_2024_KWH	China wind electricity	kWh	scope2	\N	\N	\N	0.0324000000	\N	\N	2024 electricity carbon-footprint factor by technology	{"year": 2024, "geography": "China", "technology": "wind power"}	MEE-CN-ELECTRICITY-CF-2024	生态环境部2024年全国电力碳足迹因子	https://www.mee.gov.cn/xxgk2018/xxgk/xxgk01/202510/W020251024569470952545.pdf	t	2026-09-02 10:27:03.586049
12	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	ELECTRICITY_CN_PV_2024_KWH	China photovoltaic electricity	kWh	scope2	\N	\N	\N	0.0520000000	\N	\N	2024 electricity carbon-footprint factor by technology	{"year": 2024, "geography": "China", "technology": "photovoltaic power"}	MEE-CN-ELECTRICITY-CF-2024	生态环境部2024年全国电力碳足迹因子	https://www.mee.gov.cn/xxgk2018/xxgk/xxgk01/202510/W020251024569470952545.pdf	t	2026-09-02 10:27:03.586049
13	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	ELECTRICITY_CN_CSP_2024_KWH	China concentrated solar electricity	kWh	scope2	\N	\N	\N	0.0312000000	\N	\N	2024 electricity carbon-footprint factor by technology	{"year": 2024, "geography": "China", "technology": "concentrated solar power"}	MEE-CN-ELECTRICITY-CF-2024	生态环境部2024年全国电力碳足迹因子	https://www.mee.gov.cn/xxgk2018/xxgk/xxgk01/202510/W020251024569470952545.pdf	t	2026-09-02 10:27:03.586049
14	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	ELECTRICITY_CN_BIOMASS_2024_KWH	China biomass electricity	kWh	scope2	\N	\N	\N	0.0404000000	\N	\N	2024 electricity carbon-footprint factor by technology	{"year": 2024, "geography": "China", "technology": "biomass power"}	MEE-CN-ELECTRICITY-CF-2024	生态环境部2024年全国电力碳足迹因子	https://www.mee.gov.cn/xxgk2018/xxgk/xxgk01/202510/W020251024569470952545.pdf	t	2026-09-02 10:27:03.586049
15	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	ELECTRICITY_CN_TD_EXCL_LOSS_2024_KWH	China electricity transmission and distribution excluding loss	kWh	scope3	\N	\N	\N	0.0046000000	\N	\N	2024 transmission and distribution carbon-footprint factor excluding line loss	{"year": 2024, "geography": "China", "line_loss_included": false}	MEE-CN-ELECTRICITY-CF-2024	生态环境部2024年全国电力碳足迹因子	https://www.mee.gov.cn/xxgk2018/xxgk/xxgk01/202510/W020251024569470952545.pdf	t	2026-09-02 10:27:03.586049
16	DS_BF_GHG_FACTORS_W15	BF_GHG_FACTORS_W15_V1	ELECTRICITY_CN_TD_INCL_LOSS_2024_KWH	China electricity transmission and distribution including loss	kWh	scope3	\N	\N	\N	0.0327000000	\N	\N	2024 transmission and distribution carbon-footprint factor including line loss	{"year": 2024, "geography": "China", "line_loss_included": true}	MEE-CN-ELECTRICITY-CF-2024	生态环境部2024年全国电力碳足迹因子	https://www.mee.gov.cn/xxgk2018/xxgk/xxgk01/202510/W020251024569470952545.pdf	t	2026-09-02 10:27:03.586049
\.


--
-- Data for Name: kinetic_parameter; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.kinetic_parameter (id, dataset_id, material_system, diffusing_element, matrix_phase, parameter_type, parameter_value, unit, temperature_min, temperature_max, method, source_ref, quality_grade, created_at) FROM stdin;
\.


--
-- Data for Name: knowledge_docs; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.knowledge_docs (doc_id, dataset_id, title, doc_type, doi_or_standard_no, publication_date, license, content_uri, source_url, language, chunk_policy_version, embedding_model, citation_text, created_at) FROM stdin;
\.


--
-- Data for Name: melt_viscosity_model_definition; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.melt_viscosity_model_definition (id, dataset_id, model_id, material_kind, equation_type, temperature_min_k, temperature_max_k, parameters, component_groups, applicability, source_version, source_ref, source_url, is_approved, created_at) FROM stdin;
1	DS_MELT_VISCOSITY_W13	URBAIN_SLAG_1981	slag	URBAIN_WEYMANN	1400.0000	2000.0000	{"b0": [13.8, 39.9355, -44.049], "b1": [30.481, -117.1505, 129.9978], "b2": [-40.9429, 234.0486, -300.04], "b3": [60.7619, -153.9276, 211.1616], "ln_a_b_slope": -0.29, "ln_a_intercept": -11.57, "activation_scale_k": 1000.0}	{"modifier": {"CaO": 1.0, "MgO": 1.0}, "amphoteric": {"Al2O3": 1.0}, "glass_former": {"SiO2": 1.0}}	{"warning": "Do not apply below liquidus or to solid-bearing slag.", "composition_basis": "normalized oxide mole fraction converted from wt%", "phase_requirement": "fully liquid homogeneous silicate slag", "allowed_components": ["SiO2", "Al2O3", "CaO", "MgO"], "required_components": ["SiO2", "Al2O3", "CaO", "MgO"], "composition_sum_tolerance_wt_pct": 0.001}	URBAIN-1981-VARGAS-2001-TRANSCRIPTION-V1	Urbain et al., Trans. J. Br. Ceram. Soc. 80 (1981) 139-141; equations transcribed in Vargas et al., Prog. Energy Combust. Sci. 27 (2001) 237-429	https://doi.org/10.1002/srin.198701513	t	2026-09-01 17:33:12.865022
2	DS_MELT_VISCOSITY_W13	HIRAI_LIQUID_ALLOY_1993	liquid_metal	HIRAI_ARRHENIUS	300.0000	5000.0000	{"activation_factor": 2.65, "liquidus_exponent": 1.27, "universal_prefactor": 0.00000017, "gas_constant_j_mol_k": 8.3144}	{}	{"warning": "Density, liquidus temperature and mean molar mass must describe the same alloy basis.", "density_max_kg_m3": 20000.0, "density_min_kg_m3": 1000.0, "phase_requirement": "fully liquid metal or alloy", "molar_mass_max_kg_mol": 0.25, "molar_mass_min_kg_mol": 0.01, "temperature_to_liquidus_ratio_max": 1.5, "temperature_to_liquidus_ratio_min": 1.0}	HIRAI-ISIJ-1993-TRANSCRIPTION-V1	M. Hirai, Estimation of Viscosities of Liquid Alloys, ISIJ International 33 (1993) 251-258	https://doi.org/10.2355/isijinternational.33.251	t	2026-09-01 17:33:12.865022
\.


--
-- Data for Name: model_metrics; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.model_metrics (id, evaluation_id, model_id, model_version, dataset_snapshot_id, metric_name, metric_value, slice_json, passed, evaluated_at) FROM stdin;
\.


--
-- Data for Name: model_registry; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.model_registry (model_id, name, scenario, model_type, api_name, input_schema_json, output_schema_json, applicable_boundary, validation_rules, priority, owner, status, created_at, updated_at) FROM stdin;
A001	单位换算	通用数据与校验	确定性公式/规则	model_a001	{"type": "object", "properties": {"value": {"name": "value", "label": "\\u6570\\u503c", "type": "number", "required": true, "description": "\\u5f85\\u6362\\u7b97\\u7684\\u6570\\u503c"}, "source_unit": {"name": "source_unit", "label": "\\u6e90\\u5355\\u4f4d", "type": "string", "required": true, "description": "", "placeholder": "\\u5982 \\u00b0C, kg, MPa"}, "target_unit": {"name": "target_unit", "label": "\\u76ee\\u6807\\u5355\\u4f4d", "type": "string", "required": true, "description": "", "placeholder": "\\u5982 K, g, psi"}}, "required": ["value", "source_unit", "target_unit"]}	{"type": "object", "properties": {"value": {"name": "value", "label": "\\u6362\\u7b97\\u503c", "type": "number", "description": ""}, "source_unit": {"name": "source_unit", "label": "\\u6e90\\u5355\\u4f4d", "type": "string", "description": ""}, "target_unit": {"name": "target_unit", "label": "\\u76ee\\u6807\\u5355\\u4f4d", "type": "string", "description": ""}, "conversion_factor": {"name": "conversion_factor", "label": "\\u6362\\u7b97\\u56e0\\u5b50", "type": "number", "description": ""}, "category": {"name": "category", "label": "\\u5355\\u4f4d\\u7c7b\\u522b", "type": "string", "description": ""}}}	支持线性换算和温度偏移换算；超界返回警告	[]	P0	开发组	deployed	2026-07-21 11:52:15.034375	2026-07-21 11:52:15.034375
A002	化学式解析	通用数据与校验	确定性公式/规则	model_a002	{"type": "object", "properties": {"formula": {"name": "formula", "label": "\\u5316\\u5b66\\u5f0f", "type": "string", "required": true, "description": "", "placeholder": "\\u5982 Fe2(SO4)3, CaCO3, Mg(OH)2"}}, "required": ["formula"]}	{"type": "object", "properties": {"elements": {"name": "elements", "label": "\\u5143\\u7d20\\u7ec4\\u6210", "type": "object", "description": ""}, "molar_mass": {"name": "molar_mass", "label": "\\u6469\\u5c14\\u8d28\\u91cf (g/mol)", "type": "number", "description": ""}, "formula_display": {"name": "formula_display", "label": "\\u663e\\u793a\\u683c\\u5f0f", "type": "string", "description": ""}}}	支持含括号的化学式；不支持同位素标记	[]	P0	开发组	deployed	2026-07-21 11:52:15.034375	2026-07-21 11:52:15.034375
A003	摩尔质量计算	通用数据与校验	确定性公式/规则	model_a003	{"type": "object", "properties": {"formula": {"name": "formula", "label": "\\u5316\\u5b66\\u5f0f", "type": "string", "required": true, "description": "", "placeholder": "\\u5982 Fe2O3, H2SO4, CaCO3"}}, "required": ["formula"]}	{"type": "object", "properties": {"molar_mass": {"name": "molar_mass", "label": "\\u6469\\u5c14\\u8d28\\u91cf (g/mol)", "type": "number", "description": ""}, "formula": {"name": "formula", "label": "\\u5316\\u5b66\\u5f0f", "type": "string", "description": ""}}}	基于 IUPAC 2021 原子量	[]	P0	开发组	deployed	2026-07-21 11:52:15.034375	2026-07-21 11:52:15.034375
A004	成分归一化	通用数据与校验	确定性公式/规则	model_a004	{"type": "object", "properties": {"compositions": {"name": "compositions", "label": "\\u7ec4\\u6210", "type": "object", "required": true, "description": "\\u5982 {\\"Fe\\": 0.94, \\"C\\": 0.005, \\"Si\\": 0.003}"}, "tolerance": {"name": "tolerance", "label": "\\u5bb9\\u5dee", "type": "number", "required": false, "description": "\\u5f52\\u4e00\\u5316\\u504f\\u5dee\\u5bb9\\u5dee", "default": 0.001}}, "required": ["compositions"]}	{"type": "object", "properties": {"normalized": {"name": "normalized", "label": "\\u5f52\\u4e00\\u5316\\u7ec4\\u6210", "type": "object", "description": ""}, "sum_before": {"name": "sum_before", "label": "\\u5f52\\u4e00\\u5316\\u524d\\u603b\\u548c", "type": "number", "description": ""}, "deviation": {"name": "deviation", "label": "\\u504f\\u5dee", "type": "number", "description": ""}, "passed": {"name": "passed", "label": "\\u662f\\u5426\\u901a\\u8fc7", "type": "boolean", "description": ""}}}	输入各组分分数（质量或摩尔），总和可不等于1	[]	P0	开发组	deployed	2026-07-21 11:52:15.034375	2026-07-21 11:52:15.034375
A005	元素质量守恒校验	通用数据与校验	确定性公式/规则	model_a005	{"type": "object", "properties": {"input_streams": {"name": "input_streams", "label": "\\u8f93\\u5165\\u7269\\u6d41", "type": "object", "required": true, "description": "[{\\"name\\":\\"\\u94c1\\u6c34\\",\\"mass\\":100,\\"elements\\":{\\"Fe\\":0.94,\\"C\\":0.04}}, ...]"}, "output_streams": {"name": "output_streams", "label": "\\u8f93\\u51fa\\u7269\\u6d41", "type": "object", "required": true, "description": "[{\\"name\\":\\"\\u94a2\\u6c34\\",\\"mass\\":92,\\"elements\\":{\\"Fe\\":0.98,\\"C\\":0.001}}, ...]"}, "tolerance": {"name": "tolerance", "label": "\\u5bb9\\u5dee", "type": "number", "required": false, "description": "", "default": 0.001}}, "required": ["input_streams", "output_streams"]}	{"type": "object", "properties": {"element_balances": {"name": "element_balances", "label": "\\u5143\\u7d20\\u5e73\\u8861", "type": "object", "description": ""}, "closure_rate": {"name": "closure_rate", "label": "\\u95ed\\u5408\\u7387", "type": "number", "description": ""}, "passed": {"name": "passed", "label": "\\u662f\\u5426\\u901a\\u8fc7", "type": "boolean", "description": ""}}}	输入输出物料流中各元素质量分数	[]	P0	开发组	deployed	2026-07-21 11:52:15.034375	2026-07-21 11:52:15.034375
B003	显热与焓积分	热力学与相平衡	确定性公式/规则	model_b003	{"type": "object", "properties": {"species": {"name": "species", "label": "\\u7269\\u79cd", "type": "string", "required": true, "description": "", "placeholder": "\\u5982 Fe(s), O2(g), CO2(g)"}, "temperature_start": {"name": "temperature_start", "label": "\\u8d77\\u59cb\\u6e29\\u5ea6 (K)", "type": "number", "required": true, "description": "", "default": 298.15}, "temperature_end": {"name": "temperature_end", "label": "\\u7ec8\\u6b62\\u6e29\\u5ea6 (K)", "type": "number", "required": true, "description": "", "default": 1873}, "mass": {"name": "mass", "label": "\\u8d28\\u91cf (g)", "type": "number", "required": false, "description": "\\u5982\\u679c\\u4e0d\\u4e3a1\\uff0c\\u7ed3\\u679c\\u4e58\\u4ee5\\u8be5\\u8d28\\u91cf", "default": 1}}, "required": ["species", "temperature_start", "temperature_end"]}	{"type": "object", "properties": {"delta_H": {"name": "delta_H", "label": "\\u7113\\u53d8 (kJ)", "type": "number", "description": ""}, "temperature_start": {"name": "temperature_start", "label": "\\u8d77\\u59cb\\u6e29\\u5ea6 (K)", "type": "number", "description": ""}, "temperature_end": {"name": "temperature_end", "label": "\\u7ec8\\u6b62\\u6e29\\u5ea6 (K)", "type": "number", "description": ""}, "species": {"name": "species", "label": "\\u7269\\u79cd", "type": "string", "description": ""}}}	温度范围受 Shomate 参数有效区间限制；不支持相变潜热	[]	P0	开发组	deployed	2026-07-21 11:52:15.034375	2026-07-21 11:52:15.034375
B006	反应焓计算	热力学与相平衡	确定性公式/规则	model_b006	{"type": "object", "properties": {"reaction": {"name": "reaction", "label": "\\u53cd\\u5e94\\u5f0f", "type": "string", "required": true, "description": "", "placeholder": "\\u5982 FeO + C \\u2192 Fe + CO"}, "temperature": {"name": "temperature", "label": "\\u6e29\\u5ea6 (K)", "type": "number", "required": false, "description": "", "default": 298.15}}, "required": ["reaction"]}	{"type": "object", "properties": {"delta_H": {"name": "delta_H", "label": "\\u53cd\\u5e94\\u7113 \\u0394H (kJ/mol)", "type": "number", "description": ""}, "reaction": {"name": "reaction", "label": "\\u53cd\\u5e94\\u5f0f", "type": "string", "description": ""}, "reaction_type": {"name": "reaction_type", "label": "\\u53cd\\u5e94\\u7c7b\\u578b", "type": "string", "description": ""}}}	使用标准生成焓数据；默认温度 298.15K	[]	P0	开发组	deployed	2026-07-21 11:52:15.034375	2026-07-21 11:52:15.034375
B008	反应 Gibbs 自由能计算	热力学与相平衡	确定性公式/规则	model_b008	{"type": "object", "properties": {"reaction": {"name": "reaction", "label": "\\u53cd\\u5e94\\u5f0f", "type": "string", "required": true, "description": "", "placeholder": "\\u5982 2Fe + O2 \\u2192 2FeO"}, "temperature": {"name": "temperature", "label": "\\u6e29\\u5ea6 (K)", "type": "number", "required": false, "description": "", "default": 1873}, "pressure": {"name": "pressure", "label": "\\u538b\\u529b (Pa)", "type": "number", "required": false, "description": "", "default": 101325}}, "required": ["reaction"]}	{"type": "object", "properties": {"delta_G": {"name": "delta_G", "label": "Gibbs\\u81ea\\u7531\\u80fd (kJ/mol)", "type": "number", "description": ""}, "direction": {"name": "direction", "label": "\\u53cd\\u5e94\\u65b9\\u5411", "type": "string", "description": ""}, "reaction": {"name": "reaction", "label": "\\u53cd\\u5e94\\u5f0f", "type": "string", "description": ""}}}	使用标准生成焓/熵数据；ΔG = ΔH - TΔS	[]	P0	开发组	deployed	2026-07-21 11:52:15.034375	2026-07-21 11:52:15.034375
B009	平衡常数计算	热力学与相平衡	确定性公式/规则	model_b009	{"type": "object", "properties": {"reaction": {"name": "reaction", "label": "\\u53cd\\u5e94\\u5f0f", "type": "string", "required": true, "description": "", "placeholder": "\\u5982 FeO + C \\u2192 Fe + CO"}, "temperature": {"name": "temperature", "label": "\\u6e29\\u5ea6 (K)", "type": "number", "required": false, "description": "", "default": 1600}}, "required": ["reaction"]}	{"type": "object", "properties": {"K": {"name": "K", "label": "\\u5e73\\u8861\\u5e38\\u6570", "type": "number", "description": ""}, "delta_G": {"name": "delta_G", "label": "Gibbs\\u81ea\\u7531\\u80fd (kJ/mol)", "type": "number", "description": ""}, "direction": {"name": "direction", "label": "\\u53cd\\u5e94\\u65b9\\u5411", "type": "string", "description": ""}}}	K = exp(-ΔG°/RT)；ΔG° 基于内置热化学数据库	[]	P0	开发组	deployed	2026-07-21 11:52:15.034375	2026-07-21 11:52:15.034375
B001	Shomate 热容计算	热力学与相平衡	确定性公式/规则	model_b001	{"type": "object", "properties": {"species": {"name": "species", "label": "\\u7269\\u79cd", "type": "string", "required": true, "description": "", "placeholder": "\\u5982 Fe(s), O2(g), CO2(g)"}, "temperature": {"name": "temperature", "label": "\\u6e29\\u5ea6 (K)", "type": "number", "required": true, "description": "", "default": 298.15}}, "required": ["species", "temperature"]}	{"type": "object", "properties": {"Cp": {"name": "Cp", "label": "\\u70ed\\u5bb9 Cp", "type": "number", "description": "", "unit": "J/(mol\\u00b7K)"}, "H_minus_H298": {"name": "H_minus_H298", "label": "H\\u00b0-H\\u00b0298", "type": "number", "description": "", "unit": "kJ/mol"}, "S": {"name": "S", "label": "\\u71b5 S\\u00b0", "type": "number", "description": "", "unit": "J/(mol\\u00b7K)"}}}	Cp = A + B·t + C·t² + D·t³ + E/t² (t=T/1000)；温度受 Shomate 参数有效区间限制	[]	P0	开发组	deployed	2026-07-21 14:05:24.024842	2026-07-21 14:05:24.024842
B002	NASA 多项式热物性计算	热力学与相平衡	确定性公式/规则	model_b002	{"type": "object", "properties": {"species": {"name": "species", "label": "\\u7269\\u79cd", "type": "string", "required": true, "description": "", "placeholder": "\\u5982 Fe(s), O2(g)"}, "temperature": {"name": "temperature", "label": "\\u6e29\\u5ea6 (K)", "type": "number", "required": true, "description": "", "default": 298.15}}, "required": ["species", "temperature"]}	{"type": "object", "properties": {"Cp": {"name": "Cp", "label": "\\u5b9a\\u538b\\u70ed\\u5bb9 Cp", "type": "number", "description": "", "unit": "J/(mol\\u00b7K)"}, "H_minus_H298": {"name": "H_minus_H298", "label": "H\\u00b0-H\\u00b0298", "type": "number", "description": "", "unit": "kJ/mol"}, "S": {"name": "S", "label": "\\u71b5 S\\u00b0", "type": "number", "description": "", "unit": "J/(mol\\u00b7K)"}}}	Cp/R = a₁ + a₂·T + a₃·T² + a₄·T³ + a₅·T⁴；当前使用 Shomate 参数近似	[]	P0	开发组	deployed	2026-07-21 14:05:24.024842	2026-07-21 14:05:24.024842
B004	熵积分	热力学与相平衡	确定性公式/规则	model_b004	{"type": "object", "properties": {"species": {"name": "species", "label": "\\u7269\\u79cd", "type": "string", "required": true, "description": "", "placeholder": "\\u5982 Fe(s)"}, "temperature_start": {"name": "temperature_start", "label": "\\u8d77\\u59cb\\u6e29\\u5ea6 (K)", "type": "number", "required": true, "description": "", "default": 298.15}, "temperature_end": {"name": "temperature_end", "label": "\\u7ec8\\u6b62\\u6e29\\u5ea6 (K)", "type": "number", "required": true, "description": "", "default": 1873}}, "required": ["species", "temperature_start", "temperature_end"]}	{"type": "object", "properties": {"delta_S": {"name": "delta_S", "label": "\\u71b5\\u53d8 \\u0394S", "type": "number", "description": "", "unit": "J/(mol\\u00b7K)"}, "S_start": {"name": "S_start", "label": "\\u8d77\\u59cb\\u71b5", "type": "number", "description": "", "unit": "J/(mol\\u00b7K)"}, "S_end": {"name": "S_end", "label": "\\u7ec8\\u6b62\\u71b5", "type": "number", "description": "", "unit": "J/(mol\\u00b7K)"}}}	ΔS = ∫(Cp/T)dT；使用 Shomate 热容数值积分	[]	P0	开发组	deployed	2026-07-21 14:05:24.024842	2026-07-21 14:05:24.024842
B005	物种 Gibbs 自由能计算	热力学与相平衡	确定性公式/规则	model_b005	{"type": "object", "properties": {"species": {"name": "species", "label": "\\u7269\\u79cd", "type": "string", "required": true, "description": "", "placeholder": "\\u5982 Fe(s), O2(g)"}, "temperature": {"name": "temperature", "label": "\\u6e29\\u5ea6 (K)", "type": "number", "required": true, "description": "", "default": 1873}}, "required": ["species", "temperature"]}	{"type": "object", "properties": {"G": {"name": "G", "label": "Gibbs\\u81ea\\u7531\\u80fd G", "type": "number", "description": "", "unit": "kJ/mol"}, "H": {"name": "H", "label": "\\u7113 H", "type": "number", "description": "", "unit": "kJ/mol"}, "S": {"name": "S", "label": "\\u71b5 S", "type": "number", "description": "", "unit": "J/(mol\\u00b7K)"}}}	G = H - T·S；使用 Shomate 参数计算单物种热力学性质	[]	P0	开发组	deployed	2026-07-21 14:05:24.024842	2026-07-21 14:05:24.024842
B007	反应熵计算	热力学与相平衡	确定性公式/规则	model_b007	{"type": "object", "properties": {"reaction": {"name": "reaction", "label": "\\u53cd\\u5e94\\u5f0f", "type": "string", "required": true, "description": "", "placeholder": "\\u5982 FeO + C \\u2192 Fe + CO"}, "temperature": {"name": "temperature", "label": "\\u6e29\\u5ea6 (K)", "type": "number", "required": false, "description": "", "default": 298.15}}, "required": ["reaction"]}	{"type": "object", "properties": {"delta_S": {"name": "delta_S", "label": "\\u53cd\\u5e94\\u71b5 \\u0394S", "type": "number", "description": "", "unit": "J/(mol\\u00b7K)"}, "delta_H": {"name": "delta_H", "label": "\\u53cd\\u5e94\\u7113 \\u0394H", "type": "number", "description": "", "unit": "kJ/mol"}, "reaction": {"name": "reaction", "label": "\\u53cd\\u5e94\\u5f0f", "type": "string", "description": ""}}}	ΔS = ΣS°(产物) − ΣS°(反应物)；基于内置热化学数据库	[]	P0	开发组	deployed	2026-07-21 14:05:24.024842	2026-07-21 14:05:24.024842
B019	杠杆规则计算	热力学与相平衡	确定性公式/规则	model_b019	{"type": "object", "properties": {"overall_composition": {"name": "overall_composition", "label": "\\u603b\\u4f53\\u6210\\u5206", "type": "number", "required": true, "description": "\\u603b\\u4f53\\u6210\\u5206 (\\u8d28\\u91cf/\\u6469\\u5c14\\u5206\\u6570)"}, "phase1_composition": {"name": "phase1_composition", "label": "\\u76f81\\u6210\\u5206", "type": "number", "required": true, "description": "\\u76f81\\u8fb9\\u754c\\u6210\\u5206"}, "phase2_composition": {"name": "phase2_composition", "label": "\\u76f82\\u6210\\u5206", "type": "number", "required": true, "description": "\\u76f82\\u8fb9\\u754c\\u6210\\u5206"}, "component": {"name": "component", "label": "\\u7ec4\\u5143", "type": "string", "required": false, "description": "\\u7ec4\\u5143\\u540d\\u79f0", "default": "B"}}, "required": ["overall_composition", "phase1_composition", "phase2_composition"]}	{"type": "object", "properties": {"phase1_fraction": {"name": "phase1_fraction", "label": "\\u76f81\\u5206\\u6570", "type": "number", "description": ""}, "phase2_fraction": {"name": "phase2_fraction", "label": "\\u76f82\\u5206\\u6570", "type": "number", "description": ""}, "conservation_residual": {"name": "conservation_residual", "label": "\\u5b88\\u6052\\u6b8b\\u5dee", "type": "number", "description": ""}}}	仅适用于二元系两相区	[]	P2	开发组	deployed	2026-07-21 11:52:15.034375	2026-07-21 11:52:15.034375
C001	Arrhenius 速率常数	动力学与传递	确定性公式/规则	model_c001	{"type": "object", "properties": {"A": {"name": "A", "label": "\\u6307\\u524d\\u56e0\\u5b50 A", "type": "number", "required": true, "description": "\\u6307\\u524d\\u56e0\\u5b50\\uff0c\\u5355\\u4f4d\\u4e0e k \\u4e00\\u81f4"}, "Ea": {"name": "Ea", "label": "\\u6d3b\\u5316\\u80fd Ea", "type": "number", "required": true, "description": "\\u6d3b\\u5316\\u80fd (J/mol \\u6216 kJ/mol)"}, "temperature": {"name": "temperature", "label": "\\u6e29\\u5ea6 T", "type": "number", "required": true, "description": "\\u53cd\\u5e94\\u6e29\\u5ea6 (K)"}, "Ea_unit": {"name": "Ea_unit", "label": "\\u6d3b\\u5316\\u80fd\\u5355\\u4f4d", "type": "select", "required": false, "description": "", "default": "J/mol", "enum": ["J/mol", "kJ/mol"]}, "R": {"name": "R", "label": "\\u6c14\\u4f53\\u5e38\\u6570", "type": "number", "required": false, "description": "\\u6c14\\u4f53\\u5e38\\u6570 (J/(mol\\u00b7K))", "default": 8.314}}, "required": ["A", "Ea", "temperature"]}	{"type": "object", "properties": {"k": {"name": "k", "label": "\\u901f\\u7387\\u5e38\\u6570", "type": "number", "description": ""}, "ln_k": {"name": "ln_k", "label": "ln(k)", "type": "number", "description": ""}, "temperature": {"name": "temperature", "label": "\\u6e29\\u5ea6 (K)", "type": "number", "description": ""}}}	k = A·exp(-Ea/RT)；适用 Arrhenius 行为反应	[]	P0	开发组	deployed	2026-07-21 11:52:15.034375	2026-07-21 11:52:15.034375
C002	扩散系数计算	动力学与传递	确定性公式/规则	model_c002	{"type": "object", "properties": {"D0": {"name": "D0", "label": "\\u6307\\u524d\\u56e0\\u5b50 D\\u2080", "type": "number", "required": true, "description": "\\u6269\\u6563\\u5e38\\u6570 (m\\u00b2/s)"}, "Q": {"name": "Q", "label": "\\u6fc0\\u6d3b\\u80fd Q", "type": "number", "required": true, "description": "\\u6269\\u6563\\u6fc0\\u6d3b\\u80fd"}, "temperature": {"name": "temperature", "label": "\\u6e29\\u5ea6 T", "type": "number", "required": true, "description": "\\u6e29\\u5ea6 (K)"}, "Q_unit": {"name": "Q_unit", "label": "\\u6fc0\\u6d3b\\u80fd\\u5355\\u4f4d", "type": "select", "required": false, "description": "", "default": "J/mol", "enum": ["J/mol", "kJ/mol", "eV"]}}, "required": ["D0", "Q", "temperature"]}	{"type": "object", "properties": {"D": {"name": "D", "label": "\\u6269\\u6563\\u7cfb\\u6570 D", "type": "number", "description": "", "unit": "m\\u00b2/s"}, "ln_D": {"name": "ln_D", "label": "ln(D)", "type": "number", "description": ""}, "sqrt_Dt_1h": {"name": "sqrt_Dt_1h", "label": "1h \\u6269\\u6563\\u8ddd\\u79bb \\u221a(Dt)", "type": "number", "description": "", "unit": "m"}}}	D = D₀·exp(-Q/RT)；支持 Arrhenius 扩散行为	[]	P0	开发组	deployed	2026-07-21 14:05:24.024842	2026-07-21 14:05:24.024842
\.


--
-- Data for Name: model_versions; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.model_versions (id, model_id, version, artifact_uri, git_commit, data_snapshot_id, parameter_json, dependency_lock, created_at, approved_by, release_notes) FROM stdin;
\.


--
-- Data for Name: phase_equilibrium_record; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.phase_equilibrium_record (id, dataset_id, system_name, temperature, pressure, composition_json, phases_present, calculation_method, software_version, created_at) FROM stdin;
\.


--
-- Data for Name: process_parameter_set; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.process_parameter_set (id, dataset_id, parameter_set_id, process, parameter_code, parameter_value, unit, source_version, source_ref, applicability, is_active, metadata, created_at) FROM stdin;
1	DS_BOF_PROCESS_PARAMETERS	BOF_ENGINEERING_BASELINE_V1	BOF_STATIC_BALANCE	normal_molar_volume	22.414000000000	Nm3/kmol	BOF-ENGINEERING-BASELINE-2026.08-v1	Ideal-gas molar volume at 273.15 K and 101.325 kPa	{"model_scope": "zero-dimensional static estimate", "review_status": "engineering baseline; metallurgical review required before plant-control use"}	t	{"asset_id": "BOF-ENGINEERING-BASELINE-2026.08-v1"}	2026-08-25 17:10:00.585156
2	DS_BOF_PROCESS_PARAMETERS	BOF_ENGINEERING_BASELINE_V1	BOF_STATIC_BALANCE	oxygen_molar_mass	31.998000000000	kg/kmol	BOF-ENGINEERING-BASELINE-2026.08-v1	Twice the IUPAC 2021 oxygen atomic weight	{"model_scope": "zero-dimensional static estimate", "review_status": "engineering baseline; metallurgical review required before plant-control use"}	t	{"asset_id": "BOF-ENGINEERING-BASELINE-2026.08-v1"}	2026-08-25 17:10:00.585156
3	DS_BOF_PROCESS_PARAMETERS	BOF_ENGINEERING_BASELINE_V1	BOF_STATIC_BALANCE	reference_temperature	298.150000000000	K	BOF-ENGINEERING-BASELINE-2026.08-v1	Standard thermodynamic reference temperature	{"model_scope": "zero-dimensional static estimate", "review_status": "engineering baseline; metallurgical review required before plant-control use"}	t	{"asset_id": "BOF-ENGINEERING-BASELINE-2026.08-v1"}	2026-08-25 17:10:00.585156
4	DS_BOF_PROCESS_PARAMETERS	BOF_ENGINEERING_BASELINE_V1	BOF_STATIC_BALANCE	scrap_melting_temperature	1809.000000000000	K	BOF-ENGINEERING-BASELINE-2026.08-v1	Pure iron melting-point engineering approximation	{"model_scope": "zero-dimensional static estimate", "review_status": "engineering baseline; metallurgical review required before plant-control use"}	t	{"asset_id": "BOF-ENGINEERING-BASELINE-2026.08-v1"}	2026-08-25 17:10:00.585156
5	DS_BOF_PROCESS_PARAMETERS	BOF_ENGINEERING_BASELINE_V1	BOF_STATIC_BALANCE	cp_hot_metal	0.820000000000	kJ/(kg*K)	BOF-ENGINEERING-BASELINE-2026.08-v1	Constant-property BOF engineering baseline	{"model_scope": "zero-dimensional static estimate", "review_status": "engineering baseline; metallurgical review required before plant-control use"}	t	{"asset_id": "BOF-ENGINEERING-BASELINE-2026.08-v1"}	2026-08-25 17:10:00.585156
6	DS_BOF_PROCESS_PARAMETERS	BOF_ENGINEERING_BASELINE_V1	BOF_STATIC_BALANCE	cp_scrap_solid	0.700000000000	kJ/(kg*K)	BOF-ENGINEERING-BASELINE-2026.08-v1	Constant-property BOF engineering baseline	{"model_scope": "zero-dimensional static estimate", "review_status": "engineering baseline; metallurgical review required before plant-control use"}	t	{"asset_id": "BOF-ENGINEERING-BASELINE-2026.08-v1"}	2026-08-25 17:10:00.585156
7	DS_BOF_PROCESS_PARAMETERS	BOF_ENGINEERING_BASELINE_V1	BOF_STATIC_BALANCE	latent_heat_scrap	272.000000000000	kJ/kg	BOF-ENGINEERING-BASELINE-2026.08-v1	Iron fusion enthalpy engineering approximation	{"model_scope": "zero-dimensional static estimate", "review_status": "engineering baseline; metallurgical review required before plant-control use"}	t	{"asset_id": "BOF-ENGINEERING-BASELINE-2026.08-v1"}	2026-08-25 17:10:00.585156
8	DS_BOF_PROCESS_PARAMETERS	BOF_ENGINEERING_BASELINE_V1	BOF_STATIC_BALANCE	cp_scrap_liquid	0.820000000000	kJ/(kg*K)	BOF-ENGINEERING-BASELINE-2026.08-v1	Constant-property BOF engineering baseline	{"model_scope": "zero-dimensional static estimate", "review_status": "engineering baseline; metallurgical review required before plant-control use"}	t	{"asset_id": "BOF-ENGINEERING-BASELINE-2026.08-v1"}	2026-08-25 17:10:00.585156
\.


--
-- Data for Name: reaction_definition; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.reaction_definition (id, reaction_id, reaction_equation, name, category, reactants, products, created_at) FROM stdin;
1	R001	C + O₂ → CO₂	碳完全燃烧	氧化	[{"species":"C","coeff":1,"phase":"s"},{"species":"O2","coeff":1,"phase":"g"}]	[{"species":"CO2","coeff":1,"phase":"g"}]	2026-07-21 11:52:02.037555
2	R002	2C + O₂ → 2CO	碳不完全燃烧	氧化	[{"species":"C","coeff":2,"phase":"s"},{"species":"O2","coeff":1,"phase":"g"}]	[{"species":"CO","coeff":2,"phase":"g"}]	2026-07-21 11:52:02.037555
3	R003	FeO + C → Fe + CO	氧化亚铁碳还原	还原	[{"species":"FeO","coeff":1,"phase":"s"},{"species":"C","coeff":1,"phase":"s"}]	[{"species":"Fe","coeff":1,"phase":"s"},{"species":"CO","coeff":1,"phase":"g"}]	2026-07-21 11:52:02.037555
4	R004	Fe₂O₃ + 3CO → 2Fe + 3CO₂	赤铁矿间接还原	还原	[{"species":"Fe2O3","coeff":1,"phase":"s"},{"species":"CO","coeff":3,"phase":"g"}]	[{"species":"Fe","coeff":2,"phase":"s"},{"species":"CO2","coeff":3,"phase":"g"}]	2026-07-21 11:52:02.037555
5	R005	Fe₃O₄ + 4CO → 3Fe + 4CO₂	磁铁矿间接还原	还原	[{"species":"Fe3O4","coeff":1,"phase":"s"},{"species":"CO","coeff":4,"phase":"g"}]	[{"species":"Fe","coeff":3,"phase":"s"},{"species":"CO2","coeff":4,"phase":"g"}]	2026-07-21 11:52:02.037555
6	R006	CaCO₃ → CaO + CO₂	碳酸钙分解	分解	[{"species":"CaCO3","coeff":1,"phase":"s"}]	[{"species":"CaO","coeff":1,"phase":"s"},{"species":"CO2","coeff":1,"phase":"g"}]	2026-07-21 11:52:02.037555
7	R007	SiO₂ + 2C → Si + 2CO	二氧化硅碳还原	还原	[{"species":"SiO2","coeff":1,"phase":"s"},{"species":"C","coeff":2,"phase":"s"}]	[{"species":"Si","coeff":1,"phase":"s"},{"species":"CO","coeff":2,"phase":"g"}]	2026-07-21 11:52:02.037555
8	R008	2FeO + Si → 2Fe + SiO₂	硅还原氧化亚铁	还原	[{"species":"FeO","coeff":2,"phase":"s"},{"species":"Si","coeff":1,"phase":"s"}]	[{"species":"Fe","coeff":2,"phase":"s"},{"species":"SiO2","coeff":1,"phase":"s"}]	2026-07-21 11:52:02.037555
9	R009	MnO + C → Mn + CO	氧化锰碳还原	还原	[{"species":"MnO","coeff":1,"phase":"s"},{"species":"C","coeff":1,"phase":"s"}]	[{"species":"Mn","coeff":1,"phase":"s"},{"species":"CO","coeff":1,"phase":"g"}]	2026-07-21 11:52:02.037555
10	R010	Fe₂O₃ + 2Al → 2Fe + Al₂O₃	铝热反应	置换	[{"species":"Fe2O3","coeff":1,"phase":"s"},{"species":"Al","coeff":2,"phase":"s"}]	[{"species":"Fe","coeff":2,"phase":"s"},{"species":"Al2O3","coeff":1,"phase":"s"}]	2026-07-21 11:52:02.037555
15	R011	2Fe + O2 -> 2FeO	铁氧化生成氧化亚铁	氧化	[{"species": "Fe", "coeff": 2, "phase": "s"}, {"species": "O2", "coeff": 1, "phase": "g"}]	[{"species": "FeO", "coeff": 2, "phase": "s"}]	2026-08-25 17:10:00.585156
16	R012	4Al + 3O2 -> 2Al2O3	铝氧化生成氧化铝	氧化	[{"species": "Al", "coeff": 4, "phase": "s"}, {"species": "O2", "coeff": 3, "phase": "g"}]	[{"species": "Al2O3", "coeff": 2, "phase": "s"}]	2026-08-25 17:10:00.585156
\.


--
-- Data for Name: reaction_property; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.reaction_property (id, reaction_id, dataset_id, property_type, temperature, value, unit, uncertainty, data_type, source_ref, quality_grade, created_at, source_version, source_record_key, temperature_min_k, temperature_max_k, metadata) FROM stdin;
53	R001	DS002	DELTA_H_STD	298.15	-393.50000000	kJ/mol-reaction	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R001:DELTA_H_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "C + O₂ → CO₂"}
54	R001	DS002	DELTA_S_STD	298.15	2.90000000	J/(mol-reaction*K)	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R001:DELTA_S_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "C + O₂ → CO₂"}
55	R002	DS002	DELTA_H_STD	298.15	-221.00000000	kJ/mol-reaction	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R002:DELTA_H_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "2C + O₂ → 2CO"}
56	R002	DS002	DELTA_S_STD	298.15	179.20000000	J/(mol-reaction*K)	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R002:DELTA_S_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "2C + O₂ → 2CO"}
57	R003	DS002	DELTA_H_STD	298.15	158.00000000	kJ/mol-reaction	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R003:DELTA_H_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "FeO + C → Fe + CO"}
58	R003	DS002	DELTA_S_STD	298.15	150.00000000	J/(mol-reaction*K)	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R003:DELTA_S_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "FeO + C → Fe + CO"}
59	R004	DS002	DELTA_H_STD	298.15	-24.70000000	kJ/mol-reaction	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R004:DELTA_H_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "Fe₂O₃ + 3CO → 2Fe + 3CO₂"}
60	R004	DS002	DELTA_S_STD	298.15	15.60000000	J/(mol-reaction*K)	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R004:DELTA_S_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "Fe₂O₃ + 3CO → 2Fe + 3CO₂"}
61	R005	DS002	DELTA_H_STD	298.15	-14.50000000	kJ/mol-reaction	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R005:DELTA_H_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "Fe₃O₄ + 4CO → 3Fe + 4CO₂"}
62	R005	DS002	DELTA_S_STD	298.15	10.20000000	J/(mol-reaction*K)	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R005:DELTA_S_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "Fe₃O₄ + 4CO → 3Fe + 4CO₂"}
63	R006	DS002	DELTA_H_STD	298.15	178.30000000	kJ/mol-reaction	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R006:DELTA_H_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "CaCO₃ → CaO + CO₂"}
64	R006	DS002	DELTA_S_STD	298.15	160.60000000	J/(mol-reaction*K)	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R006:DELTA_S_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "CaCO₃ → CaO + CO₂"}
65	R007	DS002	DELTA_H_STD	298.15	689.60000000	kJ/mol-reaction	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R007:DELTA_H_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "SiO₂ + 2C → Si + 2CO"}
66	R007	DS002	DELTA_S_STD	298.15	359.30000000	J/(mol-reaction*K)	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R007:DELTA_S_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "SiO₂ + 2C → Si + 2CO"}
67	R008	DS002	DELTA_H_STD	298.15	-527.40000000	kJ/mol-reaction	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R008:DELTA_H_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "2FeO + Si → 2Fe + SiO₂"}
68	R008	DS002	DELTA_S_STD	298.15	-52.80000000	J/(mol-reaction*K)	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R008:DELTA_S_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "2FeO + Si → 2Fe + SiO₂"}
69	R009	DS002	DELTA_H_STD	298.15	276.10000000	kJ/mol-reaction	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R009:DELTA_H_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "MnO + C → Mn + CO"}
70	R009	DS002	DELTA_S_STD	298.15	151.60000000	J/(mol-reaction*K)	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R009:DELTA_S_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "MnO + C → Mn + CO"}
71	R010	DS002	DELTA_H_STD	298.15	-851.50000000	kJ/mol-reaction	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R010:DELTA_H_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "Fe₂O₃ + 2Al → 2Fe + Al₂O₃"}
72	R010	DS002	DELTA_S_STD	298.15	-38.00000000	J/(mol-reaction*K)	\N	compiled	NIST-JANAF / Barin compiled reaction snapshot	B	2026-08-25 17:10:00.585156	REACTION-THERMO-2026.08-v1	REACTION-THERMO-2026.08-v1:R010:DELTA_S_STD	1.0000	3500.0000	{"approximation": "temperature-independent delta H / delta S", "asset_reaction": "Fe₂O₃ + 2Al → 2Fe + Al₂O₃"}
73	R011	DS_ELLINGHAM_BARIN_V1	DELTA_H_STD	298.15	-544.00000000	kJ/mol-reaction	\N	compiled	Barin thermochemical compilation snapshot	B	2026-08-25 17:10:00.585156	ELLINGHAM-BARIN-V1	ELLINGHAM-BARIN-V1:R011:DELTA_H_STD	298.1500	1650.0000	{"approximation": "Ellingham straight line"}
74	R011	DS_ELLINGHAM_BARIN_V1	DELTA_S_STD	298.15	-133.60000000	J/(mol-reaction*K)	\N	compiled	Barin thermochemical compilation snapshot	B	2026-08-25 17:10:00.585156	ELLINGHAM-BARIN-V1	ELLINGHAM-BARIN-V1:R011:DELTA_S_STD	298.1500	1650.0000	{"approximation": "Ellingham straight line"}
75	R011	DS_ELLINGHAM_BARIN_V1	OXYGEN_COEFFICIENT	298.15	1.00000000	mol O2/mol-reaction	\N	compiled	Barin thermochemical compilation snapshot	B	2026-08-25 17:10:00.585156	ELLINGHAM-BARIN-V1	ELLINGHAM-BARIN-V1:R011:OXYGEN_COEFFICIENT	298.1500	1650.0000	{"approximation": "Ellingham straight line"}
76	R012	DS_ELLINGHAM_BARIN_V1	DELTA_H_STD	298.15	-3351.40000000	kJ/mol-reaction	\N	compiled	Barin thermochemical compilation snapshot	B	2026-08-25 17:10:00.585156	ELLINGHAM-BARIN-V1	ELLINGHAM-BARIN-V1:R012:DELTA_H_STD	298.1500	2300.0000	{"approximation": "Ellingham straight line"}
77	R012	DS_ELLINGHAM_BARIN_V1	DELTA_S_STD	298.15	-625.10000000	J/(mol-reaction*K)	\N	compiled	Barin thermochemical compilation snapshot	B	2026-08-25 17:10:00.585156	ELLINGHAM-BARIN-V1	ELLINGHAM-BARIN-V1:R012:DELTA_S_STD	298.1500	2300.0000	{"approximation": "Ellingham straight line"}
78	R012	DS_ELLINGHAM_BARIN_V1	OXYGEN_COEFFICIENT	298.15	3.00000000	mol O2/mol-reaction	\N	compiled	Barin thermochemical compilation snapshot	B	2026-08-25 17:10:00.585156	ELLINGHAM-BARIN-V1	ELLINGHAM-BARIN-V1:R012:OXYGEN_COEFFICIENT	298.1500	2300.0000	{"approximation": "Ellingham straight line"}
\.


--
-- Data for Name: solidification_benchmark_case; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.solidification_benchmark_case (id, benchmark_id, model_asset_id, composition_json, reference_type, expected_json, tolerance_json, source_ref, source_url, within_domain, metadata, created_at) FROM stdin;
1	MCFE2059-PURE-FE-MELTING	MATCALC-MC_FE-2.059-PYCALPHAD	{}	fixed_point_interval	{"solidus_k": [1809, 1813], "liquidus_k": [1809, 1813]}	{"grid_resolution_k": 2}	Accepted pure-iron melting point consistency check; CALPHAD asset self-consistency	https://physics.nist.gov/cgi-bin/cuu/Value?tk	t	{"purpose": "independent fixed-point range; not a fitted benchmark"}	2026-08-26 14:59:53.070081
2	MCFE2059-FEC-LIQUID-MONOTONIC	MATCALC-MC_FE-2.059-PYCALPHAD	{"C": 0.1}	mathematical_property	{"property": "fraction_liquid nondecreasing with temperature"}	{"absolute": 0.00000001}	Equilibrium phase-fraction monotonicity across the Fe-0.1 wt% C solidification interval	https://github.com/pyroll-project/pyroll-examples/blob/0a8dd09136e3c9c1e73afee054bb55a8f6cd84b0/mc_fe_v2.059.pycalphad.tdb	t	{"validation": "property-based"}	2026-08-26 14:59:53.070081
3	MCFE2059-SCHEIL-CLOSURE	MATCALC-MC_FE-2.059-PYCALPHAD	{"C": 0.1}	mathematical_property	{"property": "fraction_liquid + fraction_solid = 1"}	{"absolute": 0.00000001}	Scheil-Gulliver phase-fraction closure	https://github.com/pycalphad/scheil	t	{"validation": "conservation property"}	2026-08-26 14:59:53.070081
5	MCFE2059-PURE-FE-NIST-1809K	MATCALC-MC_FE-2.059-PYCALPHAD	{}	external_fixed_point_interval	{"solidus_k": [1807, 1811], "liquidus_k": [1807, 1811]}	{"grid_resolution_k": 2}	NIST Chemistry WebBook iron condensed-phase ranges meet at 1809 K (Chase, 1998)	https://webbook.nist.gov/cgi/cbook.cgi?ID=C7439896&Mask=24A	t	{"purpose": "external fixed-point verification; not fitted by this project"}	2026-08-26 15:26:11.748086
\.


--
-- Data for Name: solidification_model_definition; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.solidification_model_definition (id, model_asset_id, dataset_id, model_family, model_version, solver_name, solver_version, solidification_solver_name, solidification_solver_version, asset_uri, asset_sha256, license, source_url, source_commit, temperature_min_k, temperature_max_k, composition_basis, domain_json, supported_components, phase_set, metadata, is_approved, created_at) FROM stdin;
1	MATCALC-MC_FE-2.059-PYCALPHAD	DS_MATCALC_MC_FE_2059	CALPHAD steel solidification	mc_fe_v2.059	pycalphad	0.11.2	scheil	0.3.0	Tools/models_core/data/calculation_assets/mc_fe_v2.059.pycalphad.tdb	a8628b6e0cb117f31d8278d87545e2d29fea78c9573694d0c51f1c72e50ac5e3	ODbL-1.0 database; DBCL-1.0 individual contents	https://github.com/pyroll-project/pyroll-examples/blob/0a8dd09136e3c9c1e73afee054bb55a8f6cd84b0/mc_fe_v2.059.pycalphad.tdb	0a8dd09136e3c9c1e73afee054bb55a8f6cd84b0	673.0000	2000.0000	weight_percent_solute_with_iron_balance	{"component_max_wt_percent": {"C": 0.5, "AL": 3.0, "CR": 25.0, "CU": 1.0, "MN": 25.0, "MO": 5.0, "NI": 26.0, "SI": 3.5}}	["C", "SI", "MN", "CR", "NI", "MO", "CU", "AL"]	["LIQUID", "FCC_A1", "BCC_A2", "CEMENTITE", "M23C6", "M7C3"]	{"scope_note": "First qualified scope intentionally excludes P, S, N and other solutes; the database contains more components, but those paths have not passed this tool version's admission tests.", "pressure_pa": 101325}	t	2026-08-26 14:59:53.070081
\.


--
-- Data for Name: thermo_property_definition; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.thermo_property_definition (id, property_code, name_zh, name_en, symbol, default_unit, description) FROM stdin;
1	CP_STD	标准摩尔定压热容	Standard molar heat capacity	Cp°	J/(mol·K)	标准压力下摩尔定压热容
2	S_STD	标准摩尔熵	Standard molar entropy	S°	J/(mol·K)	标准熵
3	H_INCREMENT_298	相对于298.15K的焓增量	Enthalpy increment	H°-H°298	kJ/mol	H(T)-H(298.15)
4	G_STD	标准Gibbs自由能	Standard Gibbs free energy	G°	kJ/mol	G = H - TS
5	HF_STD	标准生成焓	Standard enthalpy of formation	ΔfH°	kJ/mol	标准生成焓
6	GF_STD	标准生成Gibbs自由能	Standard Gibbs free energy of formation	ΔfG°	kJ/mol	标准生成Gibbs自由能
\.


--
-- Data for Name: thermodynamic_correlation; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.thermodynamic_correlation (id, species_id, phase, equation_type, temperature_min_k, temperature_max_k, reference_temperature_k, reference_pressure_pa, coefficients, coefficient_units, source_id, source_record_key, reference_text, priority, quality_level, is_active, metadata, created_at, updated_at) FROM stdin;
1	Fe	solid	SHOMATE	298.0000	1812.0000	298.1500	101325.0000	{"A": 17.49168, "B": 24.76975, "C": -6.94624, "D": 0.13806, "E": 0.01961, "F": -4.95456, "G": 41.31052, "H": -4.74308}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-Fe	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
2	Fe	liquid	SHOMATE	1812.0000	3500.0000	298.1500	101325.0000	{"A": 46.064, "B": 0.0, "C": 0.0, "D": 0.0, "E": 0.0, "F": 42.05447, "G": 53.2591, "H": -4.74308}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-Fe	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
3	C	solid	SHOMATE	298.0000	1200.0000	298.1500	101325.0000	{"A": 0.10925, "B": 38.87326, "C": -36.30512, "D": 11.48794, "E": -0.0838, "F": -4.32953, "G": 24.0827, "H": 0.0}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-C	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
4	O2	gas	SHOMATE	298.0000	6000.0000	298.1500	101325.0000	{"A": 30.03235, "B": 8.772972, "C": -3.988133, "D": 0.788313, "E": -0.741599, "F": -11.32468, "G": 236.1662, "H": 0.0}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-O2	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
5	CO2	gas	SHOMATE	298.0000	1200.0000	298.1500	101325.0000	{"A": 24.99735, "B": 55.18696, "C": -33.69137, "D": 7.948387, "E": -0.136638, "F": -403.6075, "G": 228.2431, "H": -393.5224}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-CO2	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
6	CO	gas	SHOMATE	298.0000	1300.0000	298.1500	101325.0000	{"A": 25.56759, "B": 6.09613, "C": 4.054656, "D": -2.671301, "E": 0.131021, "F": -118.0089, "G": 227.3665, "H": -110.5271}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-CO	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
7	H2O	gas	SHOMATE	298.0000	2000.0000	298.1500	101325.0000	{"A": 30.092, "B": 6.832514, "C": 6.793435, "D": -2.53448, "E": 0.082139, "F": -250.881, "G": 223.3967, "H": -241.8264}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-H2O	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
8	FeO	solid	SHOMATE	298.0000	1650.0000	298.1500	101325.0000	{"A": 47.24276, "B": 10.02214, "C": 0.80007, "D": -1.5534, "E": -0.85219, "F": -276.68, "G": 266.8643, "H": -272.044}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-FeO	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
9	SiO2	solid	SHOMATE	298.0000	847.0000	298.1500	101325.0000	{"A": 75.93152, "B": 7.80867, "C": -1.66017, "D": 0.13135, "E": -1.18477, "F": -920.8755, "G": 263.881, "H": -910.7}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-SiO2	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
10	Al2O3	solid	SHOMATE	298.0000	2345.0000	298.1500	101325.0000	{"A": 102.429, "B": 38.7498, "C": -15.9109, "D": 2.628181, "E": -3.007551, "F": -1687.225, "G": 357.532, "H": -1675.7}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-Al2O3	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
11	Fe2O3	solid	SHOMATE	298.0000	1735.0000	298.1500	101325.0000	{"A": 119.144, "B": 18.174, "C": -2.0742, "D": 0.08924, "E": -5.1731, "F": -846.6513, "G": 327.7675, "H": -824.2}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-Fe2O3	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
12	Fe3O4	solid	SHOMATE	298.0000	1800.0000	298.1500	101325.0000	{"A": 192.003, "B": 49.322, "C": -11.9244, "D": 0.74424, "E": -8.9154, "F": -1137.946, "G": 506.3882, "H": -1118.4}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-Fe3O4	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
13	CaO	solid	SHOMATE	298.0000	3200.0000	298.1500	101325.0000	{"A": 49.9469, "B": 4.70788, "C": -0.66722, "D": 0.0385, "E": -1.09855, "F": -641.4345, "G": 93.0889, "H": -634.9}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-CaO	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
14	CaCO3	solid	SHOMATE	298.0000	1200.0000	298.1500	101325.0000	{"A": 114.277, "B": 43.5913, "C": -24.2467, "D": 4.0219, "E": -1.8776, "F": -1235.455, "G": 288.0198, "H": -1207.6}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-CaCO3	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
15	MgO	solid	SHOMATE	298.0000	3100.0000	298.1500	101325.0000	{"A": 61.2775, "B": -4.8234, "C": 2.49861, "D": -0.44295, "E": -1.09283, "F": -624.0971, "G": 56.5068, "H": -601.6}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-MgO	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
16	MnO	solid	SHOMATE	298.0000	2000.0000	298.1500	101325.0000	{"A": 55.5215, "B": 6.5968, "C": 0.06625, "D": -0.14407, "E": -0.9969, "F": -394.2485, "G": 130.3913, "H": -385.2}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-MnO	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
17	H2	gas	SHOMATE	298.0000	2000.0000	298.1500	101325.0000	{"A": 33.06618, "B": -11.36342, "C": 11.43282, "D": -2.77287, "E": -0.15856, "F": -9.9808, "G": 172.7077, "H": 0.0}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-H2	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
18	N2	gas	SHOMATE	298.0000	6000.0000	298.1500	101325.0000	{"A": 26.092, "B": 8.2188, "C": -1.97619, "D": 0.15929, "E": 0.04444, "F": -7.1762, "G": 216.354, "H": 0.0}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-N2	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
19	Cu	solid	SHOMATE	298.0000	1358.0000	298.1500	101325.0000	{"A": 22.6371, "B": 6.6952, "C": 0.0, "D": 0.0, "E": -0.08979, "F": -5.89196, "G": 62.5276, "H": 0.0}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-Cu	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
20	Ni	solid	SHOMATE	298.0000	1728.0000	298.1500	101325.0000	{"A": 17.353, "B": 25.8266, "C": -8.24832, "D": 0.79569, "E": 0.28984, "F": -7.16041, "G": 64.382, "H": 0.0}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-Ni	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
21	Cr	solid	SHOMATE	298.0000	2180.0000	298.1500	101325.0000	{"A": 18.443, "B": 19.3338, "C": -6.7101, "D": 0.77285, "E": -0.75546, "F": -3.0613, "G": 56.6944, "H": 0.0}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-Cr	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
22	Si	solid	SHOMATE	298.0000	1687.0000	298.1500	101325.0000	{"A": 22.8172, "B": 4.2072, "C": -0.82349, "D": 0.05735, "E": -0.2567, "F": -2.37548, "G": 44.1452, "H": 0.0}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-Si	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
23	CH4	gas	SHOMATE	298.0000	1300.0000	298.1500	101325.0000	{"A": -0.703029, "B": 108.4773, "C": -42.52157, "D": 5.862788, "E": 0.678565, "F": -76.84376, "G": 158.7163, "H": -74.8731}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-CH4	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
24	SO2	gas	SHOMATE	298.0000	1200.0000	298.1500	101325.0000	{"A": 21.43049, "B": 74.35094, "C": -57.75217, "D": 16.35534, "E": 0.086731, "F": -305.7688, "G": 254.8872, "H": -296.8422}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-SO2	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
25	H2S	gas	SHOMATE	298.0000	1400.0000	298.1500	101325.0000	{"A": 26.88412, "B": 18.67809, "C": 3.434203, "D": -3.378702, "E": 0.135882, "F": -28.91211, "G": 233.3747, "H": -20.50202}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-H2S	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
26	Cl2	gas	SHOMATE	298.0000	1000.0000	298.1500	101325.0000	{"A": 33.0506, "B": 12.2294, "C": -12.0651, "D": 4.38533, "E": -0.159494, "F": -10.8348, "G": 259.029, "H": 0.0}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-Cl2	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
27	CuO	solid	SHOMATE	298.0000	1200.0000	298.1500	101325.0000	{"A": 35.36354, "B": 5.412422, "C": -4.335837, "D": 1.355291, "E": -0.083269, "F": 295.2414, "G": 275.511, "H": 306.2692}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-CuO	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
28	Cu2O	solid	SHOMATE	298.0000	1517.0000	298.1500	101325.0000	{"A": 95.3998, "B": 4.89249, "C": -1.982781, "D": 0.284974, "E": 1.522601, "F": -155.927, "G": 213.927, "H": -111.995}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-Cu2O	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
29	TiO2	solid	SHOMATE	298.0000	2000.0000	298.1500	101325.0000	{"A": 67.2983, "B": 18.7094, "C": -11.579, "D": 2.449561, "E": -1.485471, "F": -964.514, "G": 117.863, "H": -938.722}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-TiO2	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
30	Cr2O3	solid	SHOMATE	298.0000	2603.0000	298.1500	101325.0000	{"A": 156.9, "B": 0.000169, "C": -0.000035, "D": 0.000003, "E": 0.000369, "F": -1111.58, "G": 252.717, "H": -1018.38}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-Cr2O3	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
31	V2O5	solid	SHOMATE	943.0000	3000.0000	298.1500	101325.0000	{"A": 190.7904, "B": 0.0, "C": 0.0, "D": 0.0, "E": 0.0, "F": -1559.055, "G": 395.9378, "H": -1491.211}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-V2O5	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
32	AlN	solid	SHOMATE	298.0000	6000.0000	298.1500	101325.0000	{"A": 36.21495, "B": 1.462133, "C": -0.283742, "D": 0.033794, "E": -0.397324, "F": 510.8078, "G": 269.6701, "H": 523.0}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-AlN	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
33	SiC	solid	SHOMATE	298.0000	1000.0000	298.1500	101325.0000	{"A": 60.3218, "B": 4.42394, "C": -61.7947, "D": 39.0614, "E": -1.675991, "F": 696.307, "G": 277.67, "H": 719.648}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-SiC	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
34	Si3N4	solid	SHOMATE	298.0000	3000.0000	298.1500	101325.0000	{"A": 55.63214, "B": 157.7037, "C": -63.61395, "D": 8.610924, "E": 0.21344, "F": -767.0653, "G": 137.29, "H": -744.752}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-Si3N4	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
35	CaS	solid	SHOMATE	298.0000	1400.0000	298.1500	101325.0000	{"A": 33.08887, "B": 15.89464, "C": -21.61998, "D": 10.84635, "E": -0.12382, "F": 112.7768, "G": 268.0601, "H": 123.5949}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-CaS	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
36	CaF2	solid	SHOMATE	298.0000	1690.0000	298.1500	101325.0000	{"A": 68.4524, "B": 9.4947, "C": -1.39566, "D": -0.11673, "E": -1.350913, "F": -815.6713, "G": 106.7184, "H": -784.5}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-CaF2	Chase, 1998, NIST-JANAF Thermochemical Tables	100	A	t	{}	2026-07-21 14:30:43.350444	2026-07-21 14:30:43.350444
37	CO	gas	SHOMATE	1300.0000	6000.0000	298.1500	101325.0000	{"A": 35.1507, "B": 1.300095, "C": -0.205931, "D": 0.01355, "E": -3.28278, "F": -127.8375, "G": 231.712, "H": -110.5271}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-CO-HIGH	Chase,1998	90	A	t	{}	2026-07-21 15:01:30.3113	2026-07-21 15:01:30.3113
38	CO2	gas	SHOMATE	1200.0000	6000.0000	298.1500	101325.0000	{"A": 58.16639, "B": 2.720074, "C": -0.492289, "D": 0.038844, "E": -6.447293, "F": -425.9186, "G": 263.6125, "H": -393.5224}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-CO2-HIGH	Chase,1998	90	A	t	{}	2026-07-21 15:01:30.3113	2026-07-21 15:01:30.3113
39	H2O	gas	SHOMATE	1700.0000	6000.0000	298.1500	101325.0000	{"A": 41.96426, "B": 8.622053, "C": -1.49978, "D": 0.098119, "E": -11.15764, "F": -272.1797, "G": 219.7809, "H": -241.8264}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-H2O-HIGH	Chase,1998	90	A	t	{}	2026-07-21 15:01:30.3113	2026-07-21 15:01:30.3113
40	O2	gas	SHOMATE	700.0000	2000.0000	298.1500	101325.0000	{"A": 30.03235, "B": 8.772972, "C": -3.988133, "D": 0.788313, "E": -0.741599, "F": -11.32468, "G": 236.1663, "H": 0.0}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-O2-MID	Chase,1998	90	A	t	{}	2026-07-21 15:01:30.3113	2026-07-21 15:01:30.3113
41	O2	gas	SHOMATE	2000.0000	6000.0000	298.1500	101325.0000	{"A": 20.91111, "B": 4.009112, "C": -0.873152, "D": 0.154396, "E": -0.164482, "F": -6.451826, "G": 238.598, "H": 0.0}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-O2-HIGH	Chase,1998	90	A	t	{}	2026-07-21 15:01:30.3113	2026-07-21 15:01:30.3113
42	N2	gas	SHOMATE	500.0000	2000.0000	298.1500	101325.0000	{"A": 19.5058, "B": 19.88705, "C": -8.598535, "D": 1.369784, "E": 0.52761, "F": -4.935202, "G": 212.39, "H": 0.0}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-N2-MID	Chase,1998	90	A	t	{}	2026-07-21 15:01:30.3113	2026-07-21 15:01:30.3113
43	N2	gas	SHOMATE	2000.0000	6000.0000	298.1500	101325.0000	{"A": 35.51872, "B": 1.128728, "C": -0.196103, "D": 0.014662, "E": -4.55376, "F": -18.97091, "G": 224.981, "H": 0.0}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-N2-HIGH	Chase,1998	90	A	t	{}	2026-07-21 15:01:30.3113	2026-07-21 15:01:30.3113
44	FeO	liquid	SHOMATE	1650.0000	5000.0000	298.1500	101325.0000	{"A": 68.1992, "B": -0.0000000004501232, "C": 0.0000000001195227, "D": -0.00000000001064302, "E": -0.000000000309268, "F": -281.4326, "G": 137.8377, "H": -249.5321}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-FeO-L	Chase,1998	100	A	t	{}	2026-07-21 15:16:40.542399	2026-07-21 15:16:40.542399
45	SiO2	solid	SHOMATE	847.0000	1996.0000	298.1500	101325.0000	{"A": 58.7534, "B": 10.27925, "C": -0.131384, "D": 0.02521, "E": 0.025601, "F": -929.3292, "G": 105.8092, "H": -910.8568}	{"A": "J/(mol·K)", "B": "J/(mol·K²)", "C": "J/(mol·K³)", "D": "J/(mol·K⁴)", "E": "J·K/mol", "F": "kJ/mol", "G": "J/(mol·K)", "H": "kJ/mol"}	DS002	NIST-JANAF-SiO2-BETA	Chase,1998	100	A	t	{}	2026-07-21 15:16:40.542399	2026-07-21 15:16:40.542399
70	O2(g)	gas	NASA7	200.0000	1000.0000	298.1500	101325.0000	{"a": [3.78245636, -0.00299673416, 0.00000984730201, -0.00000000968129509, 0.00000000000324372837, -1063.94356, 3.65767573], "region": "low", "asset_id": "NASA7-GRI30-SUBSET-V1"}	{"h": "kJ/mol", "s": "J/(mol*K)", "cp": "J/(mol*K)", "temperature": "K"}	DS_NASA7_GRI30	NASA7-GRI30-SUBSET-V1:O2(g):low	GRI-Mech 3.0 thermodynamic data subset	10	B	t	{"coefficient_order": ["a1", "a2", "a3", "a4", "a5", "a6", "a7"]}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
71	O2(g)	gas	NASA7	1000.0000	3500.0000	298.1500	101325.0000	{"a": [3.28253784, 0.00148308754, -0.000000757966669, 0.000000000209470555, -0.0000000000000216717794, -1088.45772, 5.45323129], "region": "high", "asset_id": "NASA7-GRI30-SUBSET-V1"}	{"h": "kJ/mol", "s": "J/(mol*K)", "cp": "J/(mol*K)", "temperature": "K"}	DS_NASA7_GRI30	NASA7-GRI30-SUBSET-V1:O2(g):high	GRI-Mech 3.0 thermodynamic data subset	10	B	t	{"coefficient_order": ["a1", "a2", "a3", "a4", "a5", "a6", "a7"]}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
72	N2(g)	gas	NASA7	200.0000	1000.0000	298.1500	101325.0000	{"a": [3.53100528, -0.000123660987, -0.000000502999433, 0.00000000243530612, -0.00000000000140881235, -1046.97628, 2.96747468], "region": "low", "asset_id": "NASA7-GRI30-SUBSET-V1"}	{"h": "kJ/mol", "s": "J/(mol*K)", "cp": "J/(mol*K)", "temperature": "K"}	DS_NASA7_GRI30	NASA7-GRI30-SUBSET-V1:N2(g):low	GRI-Mech 3.0 thermodynamic data subset	10	B	t	{"coefficient_order": ["a1", "a2", "a3", "a4", "a5", "a6", "a7"]}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
73	N2(g)	gas	NASA7	1000.0000	3500.0000	298.1500	101325.0000	{"a": [2.95257626, 0.0013969004, -0.000000492631603, 0.0000000000786010367, -0.00000000000000460755321, -923.948645, 5.87188762], "region": "high", "asset_id": "NASA7-GRI30-SUBSET-V1"}	{"h": "kJ/mol", "s": "J/(mol*K)", "cp": "J/(mol*K)", "temperature": "K"}	DS_NASA7_GRI30	NASA7-GRI30-SUBSET-V1:N2(g):high	GRI-Mech 3.0 thermodynamic data subset	10	B	t	{"coefficient_order": ["a1", "a2", "a3", "a4", "a5", "a6", "a7"]}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
74	CO(g)	gas	NASA7	200.0000	1000.0000	298.1500	101325.0000	{"a": [3.57953347, -0.00061035368, 0.00000101681433, 0.000000000907005884, -0.000000000000904424499, -14344.086, 3.50840928], "region": "low", "asset_id": "NASA7-GRI30-SUBSET-V1"}	{"h": "kJ/mol", "s": "J/(mol*K)", "cp": "J/(mol*K)", "temperature": "K"}	DS_NASA7_GRI30	NASA7-GRI30-SUBSET-V1:CO(g):low	GRI-Mech 3.0 thermodynamic data subset	10	B	t	{"coefficient_order": ["a1", "a2", "a3", "a4", "a5", "a6", "a7"]}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
75	CO(g)	gas	NASA7	1000.0000	3500.0000	298.1500	101325.0000	{"a": [2.71518561, 0.00206252743, -0.000000998825771, 0.000000000230053008, -0.0000000000000203647716, -14151.8724, 7.81868772], "region": "high", "asset_id": "NASA7-GRI30-SUBSET-V1"}	{"h": "kJ/mol", "s": "J/(mol*K)", "cp": "J/(mol*K)", "temperature": "K"}	DS_NASA7_GRI30	NASA7-GRI30-SUBSET-V1:CO(g):high	GRI-Mech 3.0 thermodynamic data subset	10	B	t	{"coefficient_order": ["a1", "a2", "a3", "a4", "a5", "a6", "a7"]}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
76	CO2(g)	gas	NASA7	200.0000	1000.0000	298.1500	101325.0000	{"a": [2.35677352, 0.00898459677, -0.00000712356269, 0.00000000245919022, -0.000000000000143699548, -48371.9697, 9.90105222], "region": "low", "asset_id": "NASA7-GRI30-SUBSET-V1"}	{"h": "kJ/mol", "s": "J/(mol*K)", "cp": "J/(mol*K)", "temperature": "K"}	DS_NASA7_GRI30	NASA7-GRI30-SUBSET-V1:CO2(g):low	GRI-Mech 3.0 thermodynamic data subset	10	B	t	{"coefficient_order": ["a1", "a2", "a3", "a4", "a5", "a6", "a7"]}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
77	CO2(g)	gas	NASA7	1000.0000	3500.0000	298.1500	101325.0000	{"a": [3.85796028, 0.00441437026, -0.00000221481404, 0.000000000523490188, -0.0000000000000472084164, -48759.166, 2.27163806], "region": "high", "asset_id": "NASA7-GRI30-SUBSET-V1"}	{"h": "kJ/mol", "s": "J/(mol*K)", "cp": "J/(mol*K)", "temperature": "K"}	DS_NASA7_GRI30	NASA7-GRI30-SUBSET-V1:CO2(g):high	GRI-Mech 3.0 thermodynamic data subset	10	B	t	{"coefficient_order": ["a1", "a2", "a3", "a4", "a5", "a6", "a7"]}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
78	H2(g)	gas	NASA7	200.0000	1000.0000	298.1500	101325.0000	{"a": [2.34433112, 0.00798052075, -0.000019478151, 0.0000000201572094, -0.00000000000737611761, -917.935173, 0.683010238], "region": "low", "asset_id": "NASA7-GRI30-SUBSET-V1"}	{"h": "kJ/mol", "s": "J/(mol*K)", "cp": "J/(mol*K)", "temperature": "K"}	DS_NASA7_GRI30	NASA7-GRI30-SUBSET-V1:H2(g):low	GRI-Mech 3.0 thermodynamic data subset	10	B	t	{"coefficient_order": ["a1", "a2", "a3", "a4", "a5", "a6", "a7"]}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
79	H2(g)	gas	NASA7	1000.0000	3500.0000	298.1500	101325.0000	{"a": [3.3372792, -0.0000494024731, 0.000000499456778, -0.000000000179566394, 0.0000000000000200255376, -950.158922, -3.20502331], "region": "high", "asset_id": "NASA7-GRI30-SUBSET-V1"}	{"h": "kJ/mol", "s": "J/(mol*K)", "cp": "J/(mol*K)", "temperature": "K"}	DS_NASA7_GRI30	NASA7-GRI30-SUBSET-V1:H2(g):high	GRI-Mech 3.0 thermodynamic data subset	10	B	t	{"coefficient_order": ["a1", "a2", "a3", "a4", "a5", "a6", "a7"]}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
80	H2O(g)	gas	NASA7	200.0000	1000.0000	298.1500	101325.0000	{"a": [4.19864056, -0.0020364341, 0.00000652040211, -0.00000000548797062, 0.00000000000177197817, -30293.7267, -0.849032208], "region": "low", "asset_id": "NASA7-GRI30-SUBSET-V1"}	{"h": "kJ/mol", "s": "J/(mol*K)", "cp": "J/(mol*K)", "temperature": "K"}	DS_NASA7_GRI30	NASA7-GRI30-SUBSET-V1:H2O(g):low	GRI-Mech 3.0 thermodynamic data subset	10	B	t	{"coefficient_order": ["a1", "a2", "a3", "a4", "a5", "a6", "a7"]}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
81	H2O(g)	gas	NASA7	1000.0000	3500.0000	298.1500	101325.0000	{"a": [3.03399249, 0.00217691804, -0.000000164072518, -0.000000000097041987, 0.0000000000000168200992, -30004.2971, 4.9667701], "region": "high", "asset_id": "NASA7-GRI30-SUBSET-V1"}	{"h": "kJ/mol", "s": "J/(mol*K)", "cp": "J/(mol*K)", "temperature": "K"}	DS_NASA7_GRI30	NASA7-GRI30-SUBSET-V1:H2O(g):high	GRI-Mech 3.0 thermodynamic data subset	10	B	t	{"coefficient_order": ["a1", "a2", "a3", "a4", "a5", "a6", "a7"]}	2026-08-25 17:10:00.585156	2026-08-25 17:10:00.585156
110	Fe	solid_alpha_delta	SHOMATE	298.0000	700.0000	298.1500	100000.0000	{"A": 18.42868, "B": 24.64301, "C": -8.91372, "D": 9.664706, "E": -0.012643, "F": -6.573022, "G": 42.51488, "H": 0.0}	{"cp": "J/(mol*K)", "entropy": "J/(mol*K)", "enthalpy": "kJ/mol", "temperature": "K"}	DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-C7439896-FE-ALPHA-298-700	Chase, 1998; alpha-delta iron; NIST Chemistry WebBook SRD 69	250	A	t	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_url": "https://webbook.nist.gov/cgi/cbook.cgi?ID=C7439896&Table=on&Type=JANAFS", "reserved_for": "E022", "retrieved_at": "2026-09-02"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
111	Fe	solid_alpha_delta	SHOMATE	700.0000	1042.0000	298.1500	100000.0000	{"A": -57767.65, "B": 137919.7, "C": -122773.2, "D": 38682.42, "E": 3993.08, "F": 24078.67, "G": -87364.01, "H": 0.0}	{"cp": "J/(mol*K)", "entropy": "J/(mol*K)", "enthalpy": "kJ/mol", "temperature": "K"}	DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-C7439896-FE-ALPHA-700-1042	Chase, 1998; alpha-delta iron; NIST Chemistry WebBook SRD 69	250	A	t	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_url": "https://webbook.nist.gov/cgi/cbook.cgi?ID=C7439896&Table=on&Type=JANAFS", "reserved_for": "E022", "retrieved_at": "2026-09-02"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
112	Fe	solid_alpha_delta	SHOMATE	1042.0000	1100.0000	298.1500	100000.0000	{"A": -325.8859, "B": 28.92876, "C": 0.0, "D": 0.0, "E": 411.9629, "F": 745.8231, "G": 241.8766, "H": 0.0}	{"cp": "J/(mol*K)", "entropy": "J/(mol*K)", "enthalpy": "kJ/mol", "temperature": "K"}	DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-C7439896-FE-ALPHA-1042-1100	Chase, 1998; alpha-delta iron; NIST Chemistry WebBook SRD 69	250	A	t	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_url": "https://webbook.nist.gov/cgi/cbook.cgi?ID=C7439896&Table=on&Type=JANAFS", "reserved_for": "E022", "retrieved_at": "2026-09-02"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
113	FeO	solid	SHOMATE	298.0000	1650.0000	298.1500	100000.0000	{"A": 45.7512, "B": 18.78553, "C": -5.952201, "D": 0.852779, "E": -0.081265, "F": -286.7429, "G": 110.312, "H": -272.0441}	{"cp": "J/(mol*K)", "entropy": "J/(mol*K)", "enthalpy": "kJ/mol", "temperature": "K"}	DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-C1345251-FEO-SOLID-298-1650	Chase, 1998; iron monoxide; NIST Chemistry WebBook SRD 69	250	A	t	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_url": "https://webbook.nist.gov/cgi/cbook.cgi?ID=C1345251&Plot=on&Type=JANAFS", "reserved_for": "E022", "retrieved_at": "2026-09-02"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
114	Fe2O3	solid	SHOMATE	298.0000	950.0000	298.1500	100000.0000	{"A": 93.43834, "B": 108.3577, "C": -50.86447, "D": 25.58683, "E": -1.61133, "F": -863.2094, "G": 161.0719, "H": -825.5032}	{"cp": "J/(mol*K)", "entropy": "J/(mol*K)", "enthalpy": "kJ/mol", "temperature": "K"}	DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-C1317608-FE2O3-298-950	Chase, 1998; hematite; NIST Chemistry WebBook SRD 69	250	A	t	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_url": "https://webbook.nist.gov/cgi/cbook.cgi?ID=C1317608&Mask=2", "reserved_for": "E022", "retrieved_at": "2026-09-02"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
115	Fe2O3	solid	SHOMATE	950.0000	1050.0000	298.1500	100000.0000	{"A": 150.624, "B": 0.0, "C": 0.0, "D": 0.0, "E": 0.0, "F": -875.6066, "G": 252.8814, "H": -825.5032}	{"cp": "J/(mol*K)", "entropy": "J/(mol*K)", "enthalpy": "kJ/mol", "temperature": "K"}	DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-C1317608-FE2O3-950-1050	Chase, 1998; hematite; NIST Chemistry WebBook SRD 69	250	A	t	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_url": "https://webbook.nist.gov/cgi/cbook.cgi?ID=C1317608&Mask=2", "reserved_for": "E022", "retrieved_at": "2026-09-02"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
116	Fe2O3	solid	SHOMATE	1050.0000	2500.0000	298.1500	100000.0000	{"A": 110.9362, "B": 32.04714, "C": -9.192333, "D": 0.901506, "E": 5.433677, "F": -843.1471, "G": 228.3548, "H": -825.5032}	{"cp": "J/(mol*K)", "entropy": "J/(mol*K)", "enthalpy": "kJ/mol", "temperature": "K"}	DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-C1317608-FE2O3-1050-2500	Chase, 1998; hematite; NIST Chemistry WebBook SRD 69	250	A	t	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_url": "https://webbook.nist.gov/cgi/cbook.cgi?ID=C1317608&Mask=2", "reserved_for": "E022", "retrieved_at": "2026-09-02"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
117	Fe3O4	solid	SHOMATE	298.0000	900.0000	298.1500	100000.0000	{"A": 104.2096, "B": 178.5108, "C": 10.6151, "D": 1.132534, "E": -0.994202, "F": -1163.336, "G": 212.0585, "H": -1120.894}	{"cp": "J/(mol*K)", "entropy": "J/(mol*K)", "enthalpy": "kJ/mol", "temperature": "K"}	DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-C1309382-FE3O4-298-900	Chase, 1998; magnetite; NIST Chemistry WebBook SRD 69	250	A	t	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_url": "https://webbook.nist.gov/cgi/formula?ID=C1309382&Table=on&Type=JANAFS", "reserved_for": "E022", "retrieved_at": "2026-09-02"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
118	Fe3O4	solid	SHOMATE	900.0000	3000.0000	298.1500	100000.0000	{"A": 200.832, "B": 0.0000001586435, "C": -0.00000006661682, "D": 0.000000009452452, "E": 0.0000000318602, "F": -1174.135, "G": 388.079, "H": -1120.894}	{"cp": "J/(mol*K)", "entropy": "J/(mol*K)", "enthalpy": "kJ/mol", "temperature": "K"}	DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-C1309382-FE3O4-900-3000	Chase, 1998; magnetite; NIST Chemistry WebBook SRD 69	250	A	t	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_url": "https://webbook.nist.gov/cgi/formula?ID=C1309382&Table=on&Type=JANAFS", "reserved_for": "E022", "retrieved_at": "2026-09-02"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
119	CO	gas	SHOMATE	298.0000	1300.0000	298.1500	100000.0000	{"A": 25.56759, "B": 6.09613, "C": 4.054656, "D": -2.671301, "E": 0.131021, "F": -118.0089, "G": 227.3665, "H": -110.5271}	{"cp": "J/(mol*K)", "entropy": "J/(mol*K)", "enthalpy": "kJ/mol", "temperature": "K"}	DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-C630080-CO-GAS-298-1300	Chase, 1998; carbon monoxide; NIST Chemistry WebBook SRD 69	250	A	t	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_url": "https://webbook.nist.gov/cgi/cbook.cgi?ID=C630080&Mask=1&Plot=on&Type=JANAFG", "reserved_for": "E022", "retrieved_at": "2026-09-02"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
120	CO2	gas	SHOMATE	298.0000	1200.0000	298.1500	100000.0000	{"A": 24.99735, "B": 55.18696, "C": -33.69137, "D": 7.948387, "E": -0.136638, "F": -403.6075, "G": 228.2431, "H": -393.5224}	{"cp": "J/(mol*K)", "entropy": "J/(mol*K)", "enthalpy": "kJ/mol", "temperature": "K"}	DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-C124389-CO2-GAS-298-1200	Chase, 1998; carbon dioxide; NIST Chemistry WebBook SRD 69	250	A	t	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_url": "https://webbook.nist.gov/cgi/cbook.cgi?ID=C124389&Mask=1&Table=on&Type=JANAFG", "reserved_for": "E022", "retrieved_at": "2026-09-02"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
121	H2	gas	SHOMATE	298.0000	1000.0000	298.1500	100000.0000	{"A": 33.066178, "B": -11.363417, "C": 11.432816, "D": -2.772874, "E": -0.158558, "F": -9.980797, "G": 172.707974, "H": 0.0}	{"cp": "J/(mol*K)", "entropy": "J/(mol*K)", "enthalpy": "kJ/mol", "temperature": "K"}	DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-C1333740-H2-GAS-298-1000	Chase, 1998; hydrogen; NIST Chemistry WebBook SRD 69	250	A	t	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_url": "https://webbook.nist.gov/cgi/cbook.cgi?ID=C1333740&Mask=1", "reserved_for": "E022", "retrieved_at": "2026-09-02"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
122	H2	gas	SHOMATE	1000.0000	2500.0000	298.1500	100000.0000	{"A": 18.563083, "B": 12.257357, "C": -2.859786, "D": 0.268238, "E": 1.97799, "F": -1.147438, "G": 156.288133, "H": 0.0}	{"cp": "J/(mol*K)", "entropy": "J/(mol*K)", "enthalpy": "kJ/mol", "temperature": "K"}	DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-C1333740-H2-GAS-1000-2500	Chase, 1998; hydrogen; NIST Chemistry WebBook SRD 69	250	A	t	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_url": "https://webbook.nist.gov/cgi/cbook.cgi?ID=C1333740&Mask=1", "reserved_for": "E022", "retrieved_at": "2026-09-02"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
123	H2O	gas	SHOMATE	500.0000	1700.0000	298.1500	100000.0000	{"A": 30.092, "B": 6.832514, "C": 6.793435, "D": -2.53448, "E": 0.082139, "F": -250.881, "G": 223.3967, "H": -241.8264}	{"cp": "J/(mol*K)", "entropy": "J/(mol*K)", "enthalpy": "kJ/mol", "temperature": "K"}	DS_NIST_JANAF_IRON_REDUCTION_W18	NIST-C7732185-H2O-GAS-500-1700	Chase, 1998; water vapor; NIST Chemistry WebBook SRD 69	250	A	t	{"asset_id": "NIST-JANAF-IRON-REDUCTION-W18-V1", "source_url": "https://webbook.nist.gov/cgi/cbook.cgi?ID=C7732185&Mask=1&Plot=on&Type=JANAFG", "reserved_for": "E022", "retrieved_at": "2026-09-02"}	2026-09-02 16:02:21.025672	2026-09-02 16:02:21.025672
\.


--
-- Data for Name: thermodynamic_property; Type: TABLE DATA; Schema: metallurgy_v2; Owner: -
--

COPY metallurgy_v2.thermodynamic_property (id, dataset_id, species, chemical_formula, phase, property_type, temperature, temperature_min, temperature_max, value, unit, uncertainty, data_type, source_ref, quality_grade, created_at, property_code, pressure_pa, data_origin, correlation_id, source_id, metadata) FROM stdin;
1835	DS002	Fe(s)	\N	\N	标准熵	298.15	\N	\N	27.11010000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	1	\N	{}
1836	DS002	Fe(l)	\N	\N	标准熵	298.15	\N	\N	-2.48560000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	2	\N	{}
1837	DS002	C(s)	\N	\N	标准生成焓	298.15	\N	\N	0.00000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1838	DS002	C(s)	\N	\N	标准熵	298.15	\N	\N	34.49980000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	3	\N	{}
1839	DS002	O2(g)	\N	\N	标准生成焓	298.15	\N	\N	0.00000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1840	DS002	O2(g)	\N	\N	标准熵	298.15	\N	\N	206.43890000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	4	\N	{}
1841	DS002	CO2(g)	\N	\N	标准生成焓	298.15	\N	\N	-393.52240000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1842	DS002	CO2(g)	\N	\N	标准熵	298.15	\N	\N	213.78760000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	5	\N	{}
1843	DS002	CO(g)	\N	\N	标准生成焓	298.15	\N	\N	-110.52710000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1844	DS002	CO(g)	\N	\N	标准熵	298.15	\N	\N	197.66290000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	6	\N	{}
1845	DS002	H2O(g)	\N	\N	标准生成焓	298.15	\N	\N	-241.82640000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1846	DS002	H2O(g)	\N	\N	标准熵	298.15	\N	\N	188.83530000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	7	\N	{}
1847	DS002	FeO(s)	\N	\N	标准生成焓	298.15	\N	\N	-272.04400000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1848	DS002	FeO(s)	\N	\N	标准熵	298.15	\N	\N	217.49630000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	8	\N	{}
1849	DS002	Fe2O3(s)	\N	\N	标准生成焓	298.15	\N	\N	-824.20000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1850	DS002	Fe2O3(s)	\N	\N	标准熵	298.15	\N	\N	218.00870000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	11	\N	{}
1851	DS002	Fe3O4(s)	\N	\N	标准生成焓	298.15	\N	\N	-1118.40000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1852	DS002	Fe3O4(s)	\N	\N	标准熵	298.15	\N	\N	338.36260000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	12	\N	{}
1853	DS002	CaO(s)	\N	\N	标准生成焓	298.15	\N	\N	-634.90000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1854	DS002	CaO(s)	\N	\N	标准熵	298.15	\N	\N	40.19860000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	13	\N	{}
1855	DS002	CaCO3(s)	\N	\N	标准生成焓	298.15	\N	\N	-1207.60000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1856	DS002	CaCO3(s)	\N	\N	标准熵	298.15	\N	\N	172.24210000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	14	\N	{}
1857	DS002	MgO(s)	\N	\N	标准生成焓	298.15	\N	\N	-601.60000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1858	DS002	MgO(s)	\N	\N	标准熵	298.15	\N	\N	-12.83280000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	15	\N	{}
1859	DS002	MnO(s)	\N	\N	标准生成焓	298.15	\N	\N	-385.20000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1860	DS002	MnO(s)	\N	\N	标准熵	298.15	\N	\N	70.77730000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	16	\N	{}
1861	DS002	H2(g)	\N	\N	标准生成焓	298.15	\N	\N	0.00000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1862	DS002	H2(g)	\N	\N	标准熵	298.15	\N	\N	130.67990000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	17	\N	{}
1863	DS002	N2(g)	\N	\N	标准生成焓	298.15	\N	\N	0.00000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1864	DS002	N2(g)	\N	\N	标准熵	298.15	\N	\N	186.89260000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	18	\N	{}
1865	DS002	Cu(s)	\N	\N	标准生成焓	298.15	\N	\N	0.00000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1866	DS002	Cu(s)	\N	\N	标准熵	298.15	\N	\N	37.63430000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	19	\N	{}
1867	DS002	Ni(s)	\N	\N	标准生成焓	298.15	\N	\N	0.00000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1868	DS002	Ni(s)	\N	\N	标准熵	298.15	\N	\N	49.09250000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	20	\N	{}
1869	DS002	Cr(s)	\N	\N	标准生成焓	298.15	\N	\N	0.00000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1870	DS002	Cr(s)	\N	\N	标准熵	298.15	\N	\N	44.09760000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	21	\N	{}
1871	DS002	Si(s)	\N	\N	标准生成焓	298.15	\N	\N	0.00000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1872	DS002	Si(s)	\N	\N	标准熵	298.15	\N	\N	19.19490000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	22	\N	{}
1873	DS002	CH4(g)	\N	\N	标准生成焓	298.15	\N	\N	-74.87310000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1874	DS002	CH4(g)	\N	\N	标准熵	298.15	\N	\N	186.25470000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	23	\N	{}
1875	DS002	SO2(g)	\N	\N	标准生成焓	298.15	\N	\N	-296.84220000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1876	DS002	SO2(g)	\N	\N	标准熵	298.15	\N	\N	248.21040000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	24	\N	{}
1877	DS002	H2S(g)	\N	\N	标准生成焓	298.15	\N	\N	-20.50202000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1878	DS002	H2S(g)	\N	\N	标准熵	298.15	\N	\N	205.76800000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	25	\N	{}
1879	DS002	Cl2(g)	\N	\N	标准生成焓	298.15	\N	\N	0.00000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1880	DS002	Cl2(g)	\N	\N	标准熵	298.15	\N	\N	223.07830000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	26	\N	{}
1881	DS002	CuO(s)	\N	\N	标准生成焓	298.15	\N	\N	306.26920000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1882	DS002	CuO(s)	\N	\N	标准熵	298.15	\N	\N	234.61680000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	27	\N	{}
1883	DS002	Cu2O(s)	\N	\N	标准生成焓	298.15	\N	\N	-111.99500000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1884	DS002	Cu2O(s)	\N	\N	标准熵	298.15	\N	\N	91.28700000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	28	\N	{}
1885	DS002	TiO2(s)	\N	\N	标准生成焓	298.15	\N	\N	-938.72200000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1886	DS002	TiO2(s)	\N	\N	标准熵	298.15	\N	\N	49.86190000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	29	\N	{}
1887	DS002	Cr2O3(s)	\N	\N	标准生成焓	298.15	\N	\N	-1018.38000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1888	DS002	Cr2O3(s)	\N	\N	标准熵	298.15	\N	\N	62.84110000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	30	\N	{}
1889	DS002	V2O5(s)	\N	\N	标准熵	298.15	\N	\N	165.05120000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	31	\N	{}
1890	DS002	AlN(s)	\N	\N	标准生成焓	298.15	\N	\N	523.00000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1891	DS002	AlN(s)	\N	\N	标准熵	298.15	\N	\N	228.50270000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	32	\N	{}
1892	DS002	SiC(s)	\N	\N	标准生成焓	298.15	\N	\N	719.64800000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1893	DS002	SiC(s)	\N	\N	标准熵	298.15	\N	\N	213.01550000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	33	\N	{}
1894	DS002	Si3N4(s)	\N	\N	标准生成焓	298.15	\N	\N	-744.75200000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1895	DS002	Si3N4(s)	\N	\N	标准熵	298.15	\N	\N	113.03380000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	34	\N	{}
1896	DS002	CaS(s)	\N	\N	标准生成焓	298.15	\N	\N	123.59490000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1897	DS002	CaS(s)	\N	\N	标准熵	298.15	\N	\N	232.58760000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	35	\N	{}
1898	DS002	CaF2(s)	\N	\N	标准生成焓	298.15	\N	\N	-784.50000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
1899	DS002	CaF2(s)	\N	\N	标准熵	298.15	\N	\N	34.24640000	J/(mol·K)	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	S_STD	\N	unknown	36	\N	{}
1834	DS002	Fe(s)	\N	\N	标准生成焓	298.15	\N	\N	0.00000000	kJ/mol	\N	compiled	NIST-JANAF	A	2026-07-21 14:54:26.171117	HF_STD	\N	unknown	\N	\N	{}
218	DS002	O2(g)	\N	gas	S	2698.00	\N	\N	280.33950000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	4	\N	{}
31	DS002	Fe(s)	\N	solid	H-H298	798.00	\N	\N	20.44640000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
32	DS002	Fe(s)	\N	solid	S	798.00	\N	\N	54.92610000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
33	DS002	Fe(s)	\N	solid	Cp	898.00	\N	\N	34.25773400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
34	DS002	Fe(s)	\N	solid	H-H298	898.00	\N	\N	23.80720000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
35	DS002	Fe(s)	\N	solid	S	898.00	\N	\N	58.89230000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
36	DS002	Fe(s)	\N	solid	Cp	998.00	\N	\N	35.45033000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
1	DS002	CO2(g)	\N	gas	生成焓_ΔHf°	298.00	\N	\N	-393.50000000	kJ/mol	\N	experimental	NIST-JANAF	A	2026-07-21 11:52:02.039128	HF_STD	\N	compiled	\N	\N	{}
2	DS002	CO2(g)	\N	gas	生成焓_ΔHf°	500.00	\N	\N	-393.50000000	kJ/mol	\N	experimental	NIST-JANAF	A	2026-07-21 11:52:02.039128	HF_STD	\N	compiled	\N	\N	{}
3	DS002	CO(g)	\N	gas	生成焓_ΔHf°	298.00	\N	\N	-110.50000000	kJ/mol	\N	experimental	NIST-JANAF	A	2026-07-21 11:52:02.039128	HF_STD	\N	compiled	\N	\N	{}
4	DS002	FeO(s)	\N	solid	生成焓_ΔHf°	298.00	\N	\N	-272.00000000	kJ/mol	\N	experimental	NIST-JANAF	A	2026-07-21 11:52:02.039128	HF_STD	\N	compiled	\N	\N	{}
5	DS002	Fe(s)	\N	solid	生成焓_ΔHf°	298.00	\N	\N	0.00000000	kJ/mol	\N	experimental	NIST-JANAF	A	2026-07-21 11:52:02.039128	HF_STD	\N	compiled	\N	\N	{}
6	DS002	Fe2O3(s)	\N	solid	生成焓_ΔHf°	298.00	\N	\N	-824.20000000	kJ/mol	\N	experimental	NIST-JANAF	A	2026-07-21 11:52:02.039128	HF_STD	\N	compiled	\N	\N	{}
7	DS002	Fe3O4(s)	\N	solid	生成焓_ΔHf°	298.00	\N	\N	-1118.40000000	kJ/mol	\N	experimental	NIST-JANAF	A	2026-07-21 11:52:02.039128	HF_STD	\N	compiled	\N	\N	{}
8	DS002	CaCO3(s)	\N	solid	生成焓_ΔHf°	298.00	\N	\N	-1207.60000000	kJ/mol	\N	experimental	NIST-JANAF	A	2026-07-21 11:52:02.039128	HF_STD	\N	compiled	\N	\N	{}
9	DS002	CaO(s)	\N	solid	生成焓_ΔHf°	298.00	\N	\N	-634.90000000	kJ/mol	\N	experimental	NIST-JANAF	A	2026-07-21 11:52:02.039128	HF_STD	\N	compiled	\N	\N	{}
10	DS002	SiO2(s)	\N	solid	生成焓_ΔHf°	298.00	\N	\N	-910.70000000	kJ/mol	\N	experimental	NIST-JANAF	A	2026-07-21 11:52:02.039128	HF_STD	\N	compiled	\N	\N	{}
11	DS002	Si(s)	\N	solid	生成焓_ΔHf°	298.00	\N	\N	0.00000000	kJ/mol	\N	experimental	NIST-JANAF	A	2026-07-21 11:52:02.039128	HF_STD	\N	compiled	\N	\N	{}
12	DS002	MnO(s)	\N	solid	生成焓_ΔHf°	298.00	\N	\N	-385.20000000	kJ/mol	\N	experimental	NIST-JANAF	A	2026-07-21 11:52:02.039128	HF_STD	\N	compiled	\N	\N	{}
13	DS002	Al2O3(s)	\N	solid	生成焓_ΔHf°	298.00	\N	\N	-1675.70000000	kJ/mol	\N	experimental	NIST-JANAF	A	2026-07-21 11:52:02.039128	HF_STD	\N	compiled	\N	\N	{}
14	DS002	Al(s)	\N	solid	生成焓_ΔHf°	298.00	\N	\N	0.00000000	kJ/mol	\N	experimental	NIST-JANAF	A	2026-07-21 11:52:02.039128	HF_STD	\N	compiled	\N	\N	{}
37	DS002	Fe(s)	\N	solid	H-H298	998.00	\N	\N	27.29360000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
38	DS002	Fe(s)	\N	solid	S	998.00	\N	\N	62.57240000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
39	DS002	Fe(s)	\N	solid	Cp	1098.00	\N	\N	36.51347400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
40	DS002	Fe(s)	\N	solid	H-H298	1098.00	\N	\N	30.89290000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
41	DS002	Fe(s)	\N	solid	S	1098.00	\N	\N	66.00860000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
42	DS002	Fe(s)	\N	solid	Cp	1198.00	\N	\N	37.44760900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
43	DS002	Fe(s)	\N	solid	H-H298	1198.00	\N	\N	34.59200000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
44	DS002	Fe(s)	\N	solid	S	1198.00	\N	\N	69.23230000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
45	DS002	Fe(s)	\N	solid	Cp	1298.00	\N	\N	38.25332200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
46	DS002	Fe(s)	\N	solid	H-H298	1298.00	\N	\N	38.37820000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
47	DS002	Fe(s)	\N	solid	S	1298.00	\N	\N	72.26720000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
48	DS002	Fe(s)	\N	solid	Cp	1398.00	\N	\N	38.93128000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
49	DS002	Fe(s)	\N	solid	H-H298	1398.00	\N	\N	42.23840000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
50	DS002	Fe(s)	\N	solid	S	1398.00	\N	\N	75.13190000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
51	DS002	Fe(s)	\N	solid	Cp	1498.00	\N	\N	39.48220500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
52	DS002	Fe(s)	\N	solid	H-H298	1498.00	\N	\N	46.16020000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
53	DS002	Fe(s)	\N	solid	S	1498.00	\N	\N	77.84120000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
54	DS002	Fe(s)	\N	solid	Cp	1598.00	\N	\N	39.90684900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
55	DS002	Fe(s)	\N	solid	H-H298	1598.00	\N	\N	50.13070000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
56	DS002	Fe(s)	\N	solid	S	1598.00	\N	\N	80.40680000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
57	DS002	Fe(s)	\N	solid	Cp	1698.00	\N	\N	40.20598800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
58	DS002	Fe(s)	\N	solid	H-H298	1698.00	\N	\N	54.13740000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
59	DS002	Fe(s)	\N	solid	S	1698.00	\N	\N	82.83870000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
60	DS002	Fe(s)	\N	solid	Cp	1798.00	\N	\N	40.38040900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
61	DS002	Fe(s)	\N	solid	H-H298	1798.00	\N	\N	58.16770000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
62	DS002	Fe(s)	\N	solid	S	1798.00	\N	\N	85.14500000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
63	DS002	Fe(l)	\N	liquid	Cp	1812.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
64	DS002	Fe(l)	\N	liquid	H-H298	1812.00	\N	\N	130.26550000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
65	DS002	Fe(l)	\N	liquid	S	1812.00	\N	\N	80.64100000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
66	DS002	Fe(l)	\N	liquid	Cp	1912.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
67	DS002	Fe(l)	\N	liquid	H-H298	1912.00	\N	\N	134.87190000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
68	DS002	Fe(l)	\N	liquid	S	1912.00	\N	\N	83.11550000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
69	DS002	Fe(l)	\N	liquid	Cp	2012.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
70	DS002	Fe(l)	\N	liquid	H-H298	2012.00	\N	\N	139.47830000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
71	DS002	Fe(l)	\N	liquid	S	2012.00	\N	\N	85.46380000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
72	DS002	Fe(l)	\N	liquid	Cp	2112.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
73	DS002	Fe(l)	\N	liquid	H-H298	2112.00	\N	\N	144.08470000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
74	DS002	Fe(l)	\N	liquid	S	2112.00	\N	\N	87.69820000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
75	DS002	Fe(l)	\N	liquid	Cp	2212.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
76	DS002	Fe(l)	\N	liquid	H-H298	2212.00	\N	\N	148.69110000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
77	DS002	Fe(l)	\N	liquid	S	2212.00	\N	\N	89.82920000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
78	DS002	Fe(l)	\N	liquid	Cp	2312.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
79	DS002	Fe(l)	\N	liquid	H-H298	2312.00	\N	\N	153.29750000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
80	DS002	Fe(l)	\N	liquid	S	2312.00	\N	\N	91.86590000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
81	DS002	Fe(l)	\N	liquid	Cp	2412.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
82	DS002	Fe(l)	\N	liquid	H-H298	2412.00	\N	\N	157.90390000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
83	DS002	Fe(l)	\N	liquid	S	2412.00	\N	\N	93.81640000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
84	DS002	Fe(l)	\N	liquid	Cp	2512.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
85	DS002	Fe(l)	\N	liquid	H-H298	2512.00	\N	\N	162.51030000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
86	DS002	Fe(l)	\N	liquid	S	2512.00	\N	\N	95.68770000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
87	DS002	Fe(l)	\N	liquid	Cp	2612.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
88	DS002	Fe(l)	\N	liquid	H-H298	2612.00	\N	\N	167.11670000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
89	DS002	Fe(l)	\N	liquid	S	2612.00	\N	\N	97.48590000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
90	DS002	Fe(l)	\N	liquid	Cp	2712.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
91	DS002	Fe(l)	\N	liquid	H-H298	2712.00	\N	\N	171.72310000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
92	DS002	Fe(l)	\N	liquid	S	2712.00	\N	\N	99.21650000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
93	DS002	Fe(l)	\N	liquid	Cp	2812.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
94	DS002	Fe(l)	\N	liquid	H-H298	2812.00	\N	\N	176.32950000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
95	DS002	Fe(l)	\N	liquid	S	2812.00	\N	\N	100.88450000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
96	DS002	Fe(l)	\N	liquid	Cp	2912.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
97	DS002	Fe(l)	\N	liquid	H-H298	2912.00	\N	\N	180.93590000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
98	DS002	Fe(l)	\N	liquid	S	2912.00	\N	\N	102.49420000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
99	DS002	Fe(l)	\N	liquid	Cp	3012.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
100	DS002	Fe(l)	\N	liquid	H-H298	3012.00	\N	\N	185.54230000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
101	DS002	Fe(l)	\N	liquid	S	3012.00	\N	\N	104.04950000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
102	DS002	Fe(l)	\N	liquid	Cp	3112.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
103	DS002	Fe(l)	\N	liquid	H-H298	3112.00	\N	\N	190.14870000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
104	DS002	Fe(l)	\N	liquid	S	3112.00	\N	\N	105.55400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
105	DS002	Fe(l)	\N	liquid	Cp	3212.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
106	DS002	Fe(l)	\N	liquid	H-H298	3212.00	\N	\N	194.75510000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
107	DS002	Fe(l)	\N	liquid	S	3212.00	\N	\N	107.01090000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
108	DS002	Fe(l)	\N	liquid	Cp	3312.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
109	DS002	Fe(l)	\N	liquid	H-H298	3312.00	\N	\N	199.36150000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
110	DS002	Fe(l)	\N	liquid	S	3312.00	\N	\N	108.42310000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
111	DS002	Fe(l)	\N	liquid	Cp	3412.00	\N	\N	46.06400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	2	\N	{}
112	DS002	Fe(l)	\N	liquid	H-H298	3412.00	\N	\N	203.96790000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	2	\N	{}
113	DS002	Fe(l)	\N	liquid	S	3412.00	\N	\N	109.79340000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	2	\N	{}
114	DS002	C(s,graphite)	\N	solid	Cp	298.00	\N	\N	7.82980300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	3	\N	{}
115	DS002	C(s,graphite)	\N	solid	H-H298	298.00	\N	\N	-2.58730000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	3	\N	{}
116	DS002	C(s,graphite)	\N	solid	S	298.00	\N	\N	34.49580000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	3	\N	{}
117	DS002	C(s,graphite)	\N	solid	Cp	398.00	\N	\N	10.02515900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	3	\N	{}
118	DS002	C(s,graphite)	\N	solid	H-H298	398.00	\N	\N	-1.68750000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	3	\N	{}
119	DS002	C(s,graphite)	\N	solid	S	398.00	\N	\N	37.08410000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	3	\N	{}
120	DS002	C(s,graphite)	\N	solid	Cp	498.00	\N	\N	11.54525000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	3	\N	{}
121	DS002	C(s,graphite)	\N	solid	H-H298	498.00	\N	\N	-0.60450000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	3	\N	{}
122	DS002	C(s,graphite)	\N	solid	S	498.00	\N	\N	39.50540000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	3	\N	{}
123	DS002	C(s,graphite)	\N	solid	Cp	598.00	\N	\N	12.59493000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	3	\N	{}
124	DS002	C(s,graphite)	\N	solid	H-H298	598.00	\N	\N	0.60590000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	3	\N	{}
125	DS002	C(s,graphite)	\N	solid	S	598.00	\N	\N	41.71740000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	3	\N	{}
126	DS002	C(s,graphite)	\N	solid	Cp	698.00	\N	\N	13.28946900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	3	\N	{}
127	DS002	C(s,graphite)	\N	solid	H-H298	698.00	\N	\N	1.90270000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	3	\N	{}
128	DS002	C(s,graphite)	\N	solid	S	698.00	\N	\N	43.72120000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	3	\N	{}
129	DS002	C(s,graphite)	\N	solid	Cp	798.00	\N	\N	13.71709300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	3	\N	{}
130	DS002	C(s,graphite)	\N	solid	H-H298	798.00	\N	\N	3.25490000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	3	\N	{}
131	DS002	C(s,graphite)	\N	solid	S	798.00	\N	\N	45.53100000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	3	\N	{}
132	DS002	C(s,graphite)	\N	solid	Cp	898.00	\N	\N	13.95592600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	3	\N	{}
133	DS002	C(s,graphite)	\N	solid	H-H298	898.00	\N	\N	4.63980000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	3	\N	{}
134	DS002	C(s,graphite)	\N	solid	S	898.00	\N	\N	47.16580000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	3	\N	{}
135	DS002	C(s,graphite)	\N	solid	Cp	998.00	\N	\N	14.07973300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	3	\N	{}
136	DS002	C(s,graphite)	\N	solid	H-H298	998.00	\N	\N	6.04230000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	3	\N	{}
137	DS002	C(s,graphite)	\N	solid	S	998.00	\N	\N	48.64640000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	3	\N	{}
138	DS002	C(s,graphite)	\N	solid	Cp	1098.00	\N	\N	14.16018000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	3	\N	{}
139	DS002	C(s,graphite)	\N	solid	H-H298	1098.00	\N	\N	7.45430000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	3	\N	{}
140	DS002	C(s,graphite)	\N	solid	S	1098.00	\N	\N	49.99480000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	3	\N	{}
141	DS002	C(s,graphite)	\N	solid	Cp	1198.00	\N	\N	14.26784300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	3	\N	{}
142	DS002	C(s,graphite)	\N	solid	H-H298	1198.00	\N	\N	8.87520000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	3	\N	{}
143	DS002	C(s,graphite)	\N	solid	S	1198.00	\N	\N	51.23320000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	3	\N	{}
144	DS002	O2(g)	\N	gas	Cp	298.00	\N	\N	23.96243100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
145	DS002	O2(g)	\N	gas	H-H298	298.00	\N	\N	0.46950000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
146	DS002	O2(g)	\N	gas	S	298.00	\N	\N	206.42690000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
147	DS002	O2(g)	\N	gas	Cp	398.00	\N	\N	28.26026200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
148	DS002	O2(g)	\N	gas	H-H298	398.00	\N	\N	3.10750000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
149	DS002	O2(g)	\N	gas	S	398.00	\N	\N	214.03050000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
150	DS002	O2(g)	\N	gas	Cp	498.00	\N	\N	30.51930800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
151	DS002	O2(g)	\N	gas	H-H298	498.00	\N	\N	6.05640000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
152	DS002	O2(g)	\N	gas	S	498.00	\N	\N	220.63100000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
153	DS002	O2(g)	\N	gas	Cp	598.00	\N	\N	31.94719400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
154	DS002	O2(g)	\N	gas	H-H298	598.00	\N	\N	9.18430000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
155	DS002	O2(g)	\N	gas	S	598.00	\N	\N	226.35090000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
156	DS002	O2(g)	\N	gas	Cp	698.00	\N	\N	32.95877800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
157	DS002	O2(g)	\N	gas	H-H298	698.00	\N	\N	12.43220000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
158	DS002	O2(g)	\N	gas	S	698.00	\N	\N	231.37090000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
159	DS002	O2(g)	\N	gas	Cp	798.00	\N	\N	33.72955500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
160	DS002	O2(g)	\N	gas	H-H298	798.00	\N	\N	15.76820000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
161	DS002	O2(g)	\N	gas	S	798.00	\N	\N	235.83630000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
162	DS002	O2(g)	\N	gas	Cp	898.00	\N	\N	34.34565300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
163	DS002	O2(g)	\N	gas	H-H298	898.00	\N	\N	19.17300000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
164	DS002	O2(g)	\N	gas	S	898.00	\N	\N	239.85540000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
165	DS002	O2(g)	\N	gas	Cp	998.00	\N	\N	34.85459800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
166	DS002	O2(g)	\N	gas	H-H298	998.00	\N	\N	22.63370000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
167	DS002	O2(g)	\N	gas	S	998.00	\N	\N	243.50890000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
168	DS002	O2(g)	\N	gas	Cp	1098.00	\N	\N	35.28536900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
169	DS002	O2(g)	\N	gas	H-H298	1098.00	\N	\N	26.14130000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
170	DS002	O2(g)	\N	gas	S	1098.00	\N	\N	246.85800000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
171	DS002	O2(g)	\N	gas	Cp	1198.00	\N	\N	35.65727100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
172	DS002	O2(g)	\N	gas	H-H298	1198.00	\N	\N	29.68890000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
173	DS002	O2(g)	\N	gas	S	1198.00	\N	\N	249.94990000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
174	DS002	O2(g)	\N	gas	Cp	1298.00	\N	\N	35.98421800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
175	DS002	O2(g)	\N	gas	H-H298	1298.00	\N	\N	33.27130000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
176	DS002	O2(g)	\N	gas	S	1298.00	\N	\N	252.82180000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
177	DS002	O2(g)	\N	gas	Cp	1398.00	\N	\N	36.27696500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
178	DS002	O2(g)	\N	gas	H-H298	1398.00	\N	\N	36.88460000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
179	DS002	O2(g)	\N	gas	S	1398.00	\N	\N	255.50340000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
180	DS002	O2(g)	\N	gas	Cp	1498.00	\N	\N	36.54432400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
181	DS002	O2(g)	\N	gas	H-H298	1498.00	\N	\N	40.52580000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
182	DS002	O2(g)	\N	gas	S	1498.00	\N	\N	258.01900000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
183	DS002	O2(g)	\N	gas	Cp	1598.00	\N	\N	36.79387100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
184	DS002	O2(g)	\N	gas	H-H298	1598.00	\N	\N	44.19280000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
185	DS002	O2(g)	\N	gas	S	1598.00	\N	\N	260.38860000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
186	DS002	O2(g)	\N	gas	Cp	1698.00	\N	\N	37.03237000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
187	DS002	O2(g)	\N	gas	H-H298	1698.00	\N	\N	47.88420000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
188	DS002	O2(g)	\N	gas	S	1698.00	\N	\N	262.62910000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
189	DS002	O2(g)	\N	gas	Cp	1798.00	\N	\N	37.26603700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
190	DS002	O2(g)	\N	gas	H-H298	1798.00	\N	\N	51.59910000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
191	DS002	O2(g)	\N	gas	S	1798.00	\N	\N	264.75490000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
192	DS002	O2(g)	\N	gas	Cp	1898.00	\N	\N	37.50070400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
193	DS002	O2(g)	\N	gas	H-H298	1898.00	\N	\N	55.33750000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
194	DS002	O2(g)	\N	gas	S	1898.00	\N	\N	266.77820000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
195	DS002	O2(g)	\N	gas	Cp	1998.00	\N	\N	37.74193700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
196	DS002	O2(g)	\N	gas	H-H298	1998.00	\N	\N	59.09950000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
197	DS002	O2(g)	\N	gas	S	1998.00	\N	\N	268.70980000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
198	DS002	O2(g)	\N	gas	Cp	2098.00	\N	\N	37.99510700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
199	DS002	O2(g)	\N	gas	H-H298	2098.00	\N	\N	62.88620000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
200	DS002	O2(g)	\N	gas	S	2098.00	\N	\N	270.55910000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
201	DS002	O2(g)	\N	gas	Cp	2198.00	\N	\N	38.26544100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
202	DS002	O2(g)	\N	gas	H-H298	2198.00	\N	\N	66.69910000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
203	DS002	O2(g)	\N	gas	S	2198.00	\N	\N	272.33450000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
204	DS002	O2(g)	\N	gas	Cp	2298.00	\N	\N	38.55806300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
205	DS002	O2(g)	\N	gas	H-H298	2298.00	\N	\N	70.54010000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
206	DS002	O2(g)	\N	gas	S	2298.00	\N	\N	274.04330000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
207	DS002	O2(g)	\N	gas	Cp	2398.00	\N	\N	38.87801400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
208	DS002	O2(g)	\N	gas	H-H298	2398.00	\N	\N	74.41160000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
209	DS002	O2(g)	\N	gas	S	2398.00	\N	\N	275.69240000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
210	DS002	O2(g)	\N	gas	Cp	2498.00	\N	\N	39.23027500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
211	DS002	O2(g)	\N	gas	H-H298	2498.00	\N	\N	78.31670000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
212	DS002	O2(g)	\N	gas	S	2498.00	\N	\N	277.28780000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	S_STD	\N	calculated	4	\N	{}
213	DS002	O2(g)	\N	gas	Cp	2598.00	\N	\N	39.61978000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	CP_STD	\N	calculated	4	\N	{}
214	DS002	O2(g)	\N	gas	H-H298	2598.00	\N	\N	82.25890000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.837582	H_INCREMENT_298	\N	calculated	4	\N	{}
215	DS002	O2(g)	\N	gas	S	2598.00	\N	\N	278.83510000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	4	\N	{}
216	DS002	O2(g)	\N	gas	Cp	2698.00	\N	\N	40.05142500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	4	\N	{}
217	DS002	O2(g)	\N	gas	H-H298	2698.00	\N	\N	86.24210000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	4	\N	{}
219	DS002	O2(g)	\N	gas	Cp	2798.00	\N	\N	40.53007800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	4	\N	{}
220	DS002	O2(g)	\N	gas	H-H298	2798.00	\N	\N	90.27080000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	4	\N	{}
221	DS002	O2(g)	\N	gas	S	2798.00	\N	\N	281.80560000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	4	\N	{}
222	DS002	O2(g)	\N	gas	Cp	2898.00	\N	\N	41.06058300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	4	\N	{}
223	DS002	O2(g)	\N	gas	H-H298	2898.00	\N	\N	94.34990000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	4	\N	{}
224	DS002	O2(g)	\N	gas	S	2898.00	\N	\N	283.23800000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	4	\N	{}
225	DS002	O2(g)	\N	gas	Cp	2998.00	\N	\N	41.64776500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	4	\N	{}
226	DS002	O2(g)	\N	gas	H-H298	2998.00	\N	\N	98.48480000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	4	\N	{}
227	DS002	O2(g)	\N	gas	S	2998.00	\N	\N	284.64070000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	4	\N	{}
228	DS002	O2(g)	\N	gas	Cp	3098.00	\N	\N	42.29643500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	4	\N	{}
229	DS002	O2(g)	\N	gas	H-H298	3098.00	\N	\N	102.68150000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	4	\N	{}
230	DS002	O2(g)	\N	gas	S	3098.00	\N	\N	286.01760000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	4	\N	{}
231	DS002	O2(g)	\N	gas	Cp	3198.00	\N	\N	43.01138900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	4	\N	{}
232	DS002	O2(g)	\N	gas	H-H298	3198.00	\N	\N	106.94630000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	4	\N	{}
233	DS002	O2(g)	\N	gas	S	3198.00	\N	\N	287.37240000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	4	\N	{}
234	DS002	O2(g)	\N	gas	Cp	3298.00	\N	\N	43.79741600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	4	\N	{}
235	DS002	O2(g)	\N	gas	H-H298	3298.00	\N	\N	111.28610000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	4	\N	{}
236	DS002	O2(g)	\N	gas	S	3298.00	\N	\N	288.70860000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	4	\N	{}
237	DS002	O2(g)	\N	gas	Cp	3398.00	\N	\N	44.65929500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	4	\N	{}
238	DS002	O2(g)	\N	gas	H-H298	3398.00	\N	\N	115.70830000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	4	\N	{}
239	DS002	O2(g)	\N	gas	S	3398.00	\N	\N	290.02950000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	4	\N	{}
240	DS002	O2(g)	\N	gas	Cp	3498.00	\N	\N	45.60179900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	4	\N	{}
241	DS002	O2(g)	\N	gas	H-H298	3498.00	\N	\N	120.22060000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	4	\N	{}
242	DS002	O2(g)	\N	gas	S	3498.00	\N	\N	291.33820000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	4	\N	{}
243	DS002	CO2(g)	\N	gas	Cp	298.00	\N	\N	37.12283200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	5	\N	{}
244	DS002	CO2(g)	\N	gas	H-H298	298.00	\N	\N	-0.00850000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	5	\N	{}
245	DS002	CO2(g)	\N	gas	S	298.00	\N	\N	213.76900000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	5	\N	{}
246	DS002	CO2(g)	\N	gas	Cp	398.00	\N	\N	41.26342500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	5	\N	{}
247	DS002	CO2(g)	\N	gas	H-H298	398.00	\N	\N	3.91990000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	5	\N	{}
248	DS002	CO2(g)	\N	gas	S	398.00	\N	\N	225.10730000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	5	\N	{}
249	DS002	CO2(g)	\N	gas	Cp	498.00	\N	\N	44.55558400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	5	\N	{}
250	DS002	CO2(g)	\N	gas	H-H298	498.00	\N	\N	8.21640000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	5	\N	{}
251	DS002	CO2(g)	\N	gas	S	498.00	\N	\N	234.72410000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	5	\N	{}
252	DS002	CO2(g)	\N	gas	Cp	598.00	\N	\N	47.26863100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	5	\N	{}
253	DS002	CO2(g)	\N	gas	H-H298	598.00	\N	\N	12.81190000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	5	\N	{}
254	DS002	CO2(g)	\N	gas	S	598.00	\N	\N	243.12570000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	5	\N	{}
255	DS002	CO2(g)	\N	gas	Cp	698.00	\N	\N	49.52582000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	5	\N	{}
256	DS002	CO2(g)	\N	gas	H-H298	698.00	\N	\N	17.65500000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	5	\N	{}
257	DS002	CO2(g)	\N	gas	S	698.00	\N	\N	250.61010000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	5	\N	{}
258	DS002	CO2(g)	\N	gas	Cp	798.00	\N	\N	51.40630500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	5	\N	{}
259	DS002	CO2(g)	\N	gas	H-H298	798.00	\N	\N	22.70450000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	5	\N	{}
260	DS002	CO2(g)	\N	gas	S	798.00	\N	\N	257.36800000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	5	\N	{}
261	DS002	CO2(g)	\N	gas	Cp	898.00	\N	\N	52.97277400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	5	\N	{}
262	DS002	CO2(g)	\N	gas	H-H298	898.00	\N	\N	27.92580000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	5	\N	{}
263	DS002	CO2(g)	\N	gas	S	898.00	\N	\N	263.53050000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	5	\N	{}
264	DS002	CO2(g)	\N	gas	Cp	998.00	\N	\N	54.28080300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	5	\N	{}
265	DS002	CO2(g)	\N	gas	H-H298	998.00	\N	\N	33.29040000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	5	\N	{}
266	DS002	CO2(g)	\N	gas	S	998.00	\N	\N	269.19350000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	5	\N	{}
267	DS002	CO2(g)	\N	gas	Cp	1098.00	\N	\N	55.38254900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	5	\N	{}
268	DS002	CO2(g)	\N	gas	H-H298	1098.00	\N	\N	38.77510000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	5	\N	{}
269	DS002	CO2(g)	\N	gas	S	1098.00	\N	\N	274.43010000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	5	\N	{}
270	DS002	CO2(g)	\N	gas	Cp	1198.00	\N	\N	56.32838800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	5	\N	{}
271	DS002	CO2(g)	\N	gas	H-H298	1198.00	\N	\N	44.36170000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	5	\N	{}
272	DS002	CO2(g)	\N	gas	S	1198.00	\N	\N	279.29900000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	5	\N	{}
273	DS002	CO(g)	\N	gas	Cp	298.00	\N	\N	29.14900900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	6	\N	{}
274	DS002	CO(g)	\N	gas	H-H298	298.00	\N	\N	-0.00110000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	6	\N	{}
275	DS002	CO(g)	\N	gas	S	298.00	\N	\N	197.64820000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	6	\N	{}
276	DS002	CO(g)	\N	gas	Cp	398.00	\N	\N	29.29484400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	6	\N	{}
277	DS002	CO(g)	\N	gas	H-H298	398.00	\N	\N	2.91620000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	6	\N	{}
278	DS002	CO(g)	\N	gas	S	398.00	\N	\N	206.08870000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	6	\N	{}
279	DS002	CO(g)	\N	gas	Cp	498.00	\N	\N	29.80741400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	6	\N	{}
280	DS002	CO(g)	\N	gas	H-H298	498.00	\N	\N	5.86950000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	6	\N	{}
281	DS002	CO(g)	\N	gas	S	498.00	\N	\N	212.70650000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	6	\N	{}
282	DS002	CO(g)	\N	gas	Cp	598.00	\N	\N	30.45817200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	6	\N	{}
283	DS002	CO(g)	\N	gas	H-H298	598.00	\N	\N	8.88210000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	6	\N	{}
284	DS002	CO(g)	\N	gas	S	598.00	\N	\N	218.21740000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	6	\N	{}
285	DS002	CO(g)	\N	gas	Cp	698.00	\N	\N	31.15863300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	6	\N	{}
286	DS002	CO(g)	\N	gas	H-H298	698.00	\N	\N	11.96280000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	6	\N	{}
287	DS002	CO(g)	\N	gas	S	698.00	\N	\N	222.97960000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	6	\N	{}
288	DS002	CO(g)	\N	gas	Cp	798.00	\N	\N	31.86259700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	6	\N	{}
289	DS002	CO(g)	\N	gas	H-H298	798.00	\N	\N	15.11400000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	6	\N	{}
290	DS002	CO(g)	\N	gas	S	798.00	\N	\N	227.19760000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	6	\N	{}
291	DS002	CO(g)	\N	gas	Cp	898.00	\N	\N	32.53965600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	6	\N	{}
292	DS002	CO(g)	\N	gas	H-H298	898.00	\N	\N	18.33440000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	6	\N	{}
293	DS002	CO(g)	\N	gas	S	898.00	\N	\N	230.99890000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	6	\N	{}
294	DS002	CO(g)	\N	gas	Cp	998.00	\N	\N	33.16622300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	6	\N	{}
295	DS002	CO(g)	\N	gas	H-H298	998.00	\N	\N	21.62020000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	6	\N	{}
296	DS002	CO(g)	\N	gas	S	998.00	\N	\N	234.46760000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	6	\N	{}
297	DS002	CO(g)	\N	gas	Cp	1098.00	\N	\N	33.72198400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	6	\N	{}
298	DS002	CO(g)	\N	gas	H-H298	1098.00	\N	\N	24.96530000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	6	\N	{}
299	DS002	CO(g)	\N	gas	S	1098.00	\N	\N	237.66150000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	6	\N	{}
300	DS002	CO(g)	\N	gas	Cp	1198.00	\N	\N	34.18833700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	6	\N	{}
301	DS002	CO(g)	\N	gas	H-H298	1198.00	\N	\N	28.36160000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	6	\N	{}
302	DS002	CO(g)	\N	gas	S	1198.00	\N	\N	240.62150000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	6	\N	{}
303	DS002	CO(g)	\N	gas	Cp	1298.00	\N	\N	34.54763100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	6	\N	{}
304	DS002	CO(g)	\N	gas	H-H298	1298.00	\N	\N	31.79940000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	6	\N	{}
305	DS002	CO(g)	\N	gas	S	1298.00	\N	\N	243.37740000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	6	\N	{}
306	DS002	H2O(g)	\N	gas	Cp	298.00	\N	\N	33.58924900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	7	\N	{}
307	DS002	H2O(g)	\N	gas	H-H298	298.00	\N	\N	-0.00450000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	7	\N	{}
308	DS002	H2O(g)	\N	gas	S	298.00	\N	\N	188.81840000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	7	\N	{}
309	DS002	H2O(g)	\N	gas	Cp	398.00	\N	\N	34.24620300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	7	\N	{}
310	DS002	H2O(g)	\N	gas	H-H298	398.00	\N	\N	3.38370000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	7	\N	{}
311	DS002	H2O(g)	\N	gas	S	398.00	\N	\N	198.61770000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	7	\N	{}
312	DS002	H2O(g)	\N	gas	Cp	498.00	\N	\N	35.19756800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	CP_STD	\N	calculated	7	\N	{}
313	DS002	H2O(g)	\N	gas	H-H298	498.00	\N	\N	6.85420000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	H_INCREMENT_298	\N	calculated	7	\N	{}
314	DS002	H2O(g)	\N	gas	S	498.00	\N	\N	206.39300000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.839634	S_STD	\N	calculated	7	\N	{}
315	DS002	H2O(g)	\N	gas	Cp	598.00	\N	\N	36.29490400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
316	DS002	H2O(g)	\N	gas	H-H298	598.00	\N	\N	10.42800000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
317	DS002	H2O(g)	\N	gas	S	598.00	\N	\N	212.92950000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
318	DS002	H2O(g)	\N	gas	Cp	698.00	\N	\N	37.47758000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
319	DS002	H2O(g)	\N	gas	H-H298	698.00	\N	\N	14.11600000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
320	DS002	H2O(g)	\N	gas	S	698.00	\N	\N	218.62990000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
321	DS002	H2O(g)	\N	gas	Cp	798.00	\N	\N	38.71147300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
322	DS002	H2O(g)	\N	gas	H-H298	798.00	\N	\N	17.92520000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
323	DS002	H2O(g)	\N	gas	S	798.00	\N	\N	223.72810000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
324	DS002	H2O(g)	\N	gas	Cp	898.00	\N	\N	39.97236300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
325	DS002	H2O(g)	\N	gas	H-H298	898.00	\N	\N	21.85920000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
326	DS002	H2O(g)	\N	gas	S	898.00	\N	\N	228.37130000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
327	DS002	H2O(g)	\N	gas	Cp	998.00	\N	\N	41.24030200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
328	DS002	H2O(g)	\N	gas	H-H298	998.00	\N	\N	25.91990000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
329	DS002	H2O(g)	\N	gas	S	998.00	\N	\N	232.65740000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
330	DS002	H2O(g)	\N	gas	Cp	1098.00	\N	\N	42.49739800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
331	DS002	H2O(g)	\N	gas	H-H298	1098.00	\N	\N	30.10690000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
332	DS002	H2O(g)	\N	gas	S	1098.00	\N	\N	236.65480000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
333	DS002	H2O(g)	\N	gas	Cp	1198.00	\N	\N	43.72682800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
334	DS002	H2O(g)	\N	gas	H-H298	1198.00	\N	\N	34.41840000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
335	DS002	H2O(g)	\N	gas	S	1198.00	\N	\N	240.41210000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
336	DS002	H2O(g)	\N	gas	Cp	1298.00	\N	\N	44.91237000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
337	DS002	H2O(g)	\N	gas	H-H298	1298.00	\N	\N	38.85080000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
338	DS002	H2O(g)	\N	gas	S	1298.00	\N	\N	243.96490000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
339	DS002	H2O(g)	\N	gas	Cp	1398.00	\N	\N	46.03814900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
340	DS002	H2O(g)	\N	gas	H-H298	1398.00	\N	\N	43.39890000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
341	DS002	H2O(g)	\N	gas	S	1398.00	\N	\N	247.33990000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
342	DS002	H2O(g)	\N	gas	Cp	1498.00	\N	\N	47.08850500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
343	DS002	H2O(g)	\N	gas	H-H298	1498.00	\N	\N	48.05590000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
344	DS002	H2O(g)	\N	gas	S	1498.00	\N	\N	250.55700000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
345	DS002	H2O(g)	\N	gas	Cp	1598.00	\N	\N	48.04791700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
346	DS002	H2O(g)	\N	gas	H-H298	1598.00	\N	\N	52.81360000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
347	DS002	H2O(g)	\N	gas	S	1598.00	\N	\N	253.63110000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
348	DS002	H2O(g)	\N	gas	Cp	1698.00	\N	\N	48.90095200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
349	DS002	H2O(g)	\N	gas	H-H298	1698.00	\N	\N	57.66200000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
350	DS002	H2O(g)	\N	gas	S	1698.00	\N	\N	256.57370000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
351	DS002	H2O(g)	\N	gas	Cp	1798.00	\N	\N	49.63224000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
352	DS002	H2O(g)	\N	gas	H-H298	1798.00	\N	\N	62.58970000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
353	DS002	H2O(g)	\N	gas	S	1798.00	\N	\N	259.39340000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
354	DS002	H2O(g)	\N	gas	Cp	1898.00	\N	\N	50.22645100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
355	DS002	H2O(g)	\N	gas	H-H298	1898.00	\N	\N	67.58390000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
356	DS002	H2O(g)	\N	gas	S	1898.00	\N	\N	262.09630000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
357	DS002	H2O(g)	\N	gas	Cp	1998.00	\N	\N	50.66828500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	7	\N	{}
358	DS002	H2O(g)	\N	gas	H-H298	1998.00	\N	\N	72.62990000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	7	\N	{}
359	DS002	H2O(g)	\N	gas	S	1998.00	\N	\N	264.68720000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	7	\N	{}
360	DS002	FeO(s)	\N	solid	Cp	298.00	\N	\N	40.66299700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	8	\N	{}
361	DS002	FeO(s)	\N	solid	H-H298	298.00	\N	\N	12.75100000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	8	\N	{}
362	DS002	FeO(s)	\N	solid	S	298.00	\N	\N	217.47590000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	8	\N	{}
363	DS002	FeO(s)	\N	solid	Cp	398.00	\N	\N	45.88052100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	8	\N	{}
364	DS002	FeO(s)	\N	solid	H-H298	398.00	\N	\N	17.10860000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	8	\N	{}
365	DS002	FeO(s)	\N	solid	S	398.00	\N	\N	230.04890000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	8	\N	{}
366	DS002	FeO(s)	\N	solid	Cp	498.00	\N	\N	48.80415700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	8	\N	{}
367	DS002	FeO(s)	\N	solid	H-H298	498.00	\N	\N	21.85390000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	8	\N	{}
368	DS002	FeO(s)	\N	solid	S	498.00	\N	\N	240.67310000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	8	\N	{}
369	DS002	FeO(s)	\N	solid	Cp	598.00	\N	\N	50.80686300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	8	\N	{}
370	DS002	FeO(s)	\N	solid	H-H298	598.00	\N	\N	26.83960000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	8	\N	{}
371	DS002	FeO(s)	\N	solid	S	598.00	\N	\N	249.79080000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	8	\N	{}
372	DS002	FeO(s)	\N	solid	Cp	698.00	\N	\N	52.35060500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	8	\N	{}
373	DS002	FeO(s)	\N	solid	H-H298	698.00	\N	\N	32.00030000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	8	\N	{}
374	DS002	FeO(s)	\N	solid	S	698.00	\N	\N	257.76770000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	8	\N	{}
375	DS002	FeO(s)	\N	solid	Cp	798.00	\N	\N	53.62229500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	8	\N	{}
376	DS002	FeO(s)	\N	solid	H-H298	798.00	\N	\N	37.30070000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	8	\N	{}
377	DS002	FeO(s)	\N	solid	S	798.00	\N	\N	264.86250000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	8	\N	{}
378	DS002	FeO(s)	\N	solid	Cp	898.00	\N	\N	54.70614800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	8	\N	{}
379	DS002	FeO(s)	\N	solid	H-H298	898.00	\N	\N	42.71850000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	8	\N	{}
380	DS002	FeO(s)	\N	solid	S	898.00	\N	\N	271.25760000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	8	\N	{}
381	DS002	FeO(s)	\N	solid	Cp	998.00	\N	\N	55.64202100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	8	\N	{}
382	DS002	FeO(s)	\N	solid	H-H298	998.00	\N	\N	48.23710000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	8	\N	{}
383	DS002	FeO(s)	\N	solid	S	998.00	\N	\N	277.08340000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	8	\N	{}
384	DS002	FeO(s)	\N	solid	Cp	1098.00	\N	\N	56.44846200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	8	\N	{}
385	DS002	FeO(s)	\N	solid	H-H298	1098.00	\N	\N	53.84260000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	8	\N	{}
386	DS002	FeO(s)	\N	solid	S	1098.00	\N	\N	282.43560000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	8	\N	{}
387	DS002	FeO(s)	\N	solid	Cp	1198.00	\N	\N	57.13289500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	8	\N	{}
388	DS002	FeO(s)	\N	solid	H-H298	1198.00	\N	\N	59.52270000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	8	\N	{}
389	DS002	FeO(s)	\N	solid	S	1198.00	\N	\N	287.38610000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	8	\N	{}
390	DS002	FeO(s)	\N	solid	Cp	1298.00	\N	\N	57.69655700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	8	\N	{}
391	DS002	FeO(s)	\N	solid	H-H298	1298.00	\N	\N	65.26520000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	8	\N	{}
392	DS002	FeO(s)	\N	solid	S	1298.00	\N	\N	291.98960000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	8	\N	{}
393	DS002	FeO(s)	\N	solid	Cp	1398.00	\N	\N	58.13704800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	8	\N	{}
394	DS002	FeO(s)	\N	solid	H-H298	1398.00	\N	\N	71.05790000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	8	\N	{}
395	DS002	FeO(s)	\N	solid	S	1398.00	\N	\N	296.28870000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	8	\N	{}
396	DS002	FeO(s)	\N	solid	Cp	1498.00	\N	\N	58.44974100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	8	\N	{}
397	DS002	FeO(s)	\N	solid	H-H298	1498.00	\N	\N	76.88830000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	8	\N	{}
398	DS002	FeO(s)	\N	solid	S	1498.00	\N	\N	300.31670000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	8	\N	{}
399	DS002	FeO(s)	\N	solid	Cp	1598.00	\N	\N	58.62858500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	8	\N	{}
400	DS002	FeO(s)	\N	solid	H-H298	1598.00	\N	\N	82.74340000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	8	\N	{}
401	DS002	FeO(s)	\N	solid	S	1598.00	\N	\N	304.10030000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	8	\N	{}
402	DS002	SiO2(s,alpha)	\N	solid	Cp	298.00	\N	\N	64.77314600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	9	\N	{}
403	DS002	SiO2(s,alpha)	\N	solid	H-H298	298.00	\N	\N	16.76020000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	9	\N	{}
404	DS002	SiO2(s,alpha)	\N	solid	S	298.00	\N	\N	180.87870000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	9	\N	{}
405	DS002	SiO2(s,alpha)	\N	solid	Cp	398.00	\N	\N	71.30525400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	9	\N	{}
406	DS002	SiO2(s,alpha)	\N	solid	H-H298	398.00	\N	\N	23.60650000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	9	\N	{}
407	DS002	SiO2(s,alpha)	\N	solid	S	398.00	\N	\N	200.64390000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	9	\N	{}
408	DS002	SiO2(s,alpha)	\N	solid	Cp	498.00	\N	\N	74.64751000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	9	\N	{}
409	DS002	SiO2(s,alpha)	\N	solid	H-H298	498.00	\N	\N	30.91940000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	9	\N	{}
410	DS002	SiO2(s,alpha)	\N	solid	S	498.00	\N	\N	217.02180000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	9	\N	{}
411	DS002	SiO2(s,alpha)	\N	solid	Cp	598.00	\N	\N	76.72243200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	9	\N	{}
412	DS002	SiO2(s,alpha)	\N	solid	H-H298	598.00	\N	\N	38.49480000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	H_INCREMENT_298	\N	calculated	9	\N	{}
413	DS002	SiO2(s,alpha)	\N	solid	S	598.00	\N	\N	230.87840000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	S_STD	\N	calculated	9	\N	{}
414	DS002	SiO2(s,alpha)	\N	solid	Cp	698.00	\N	\N	78.18602400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.842349	CP_STD	\N	calculated	9	\N	{}
415	DS002	SiO2(s,alpha)	\N	solid	H-H298	698.00	\N	\N	46.24390000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	9	\N	{}
416	DS002	SiO2(s,alpha)	\N	solid	S	698.00	\N	\N	242.85770000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	9	\N	{}
417	DS002	SiO2(s,alpha)	\N	solid	Cp	798.00	\N	\N	79.31189000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	9	\N	{}
418	DS002	SiO2(s,alpha)	\N	solid	H-H298	798.00	\N	\N	54.12090000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	9	\N	{}
419	DS002	SiO2(s,alpha)	\N	solid	S	798.00	\N	\N	253.40250000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	9	\N	{}
420	DS002	Al2O3(s,alpha)	\N	solid	Cp	298.00	\N	\N	78.76574800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
421	DS002	Al2O3(s,alpha)	\N	solid	H-H298	298.00	\N	\N	30.67670000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
422	DS002	Al2O3(s,alpha)	\N	solid	S	298.00	\N	\N	261.32290000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
423	DS002	Al2O3(s,alpha)	\N	solid	Cp	398.00	\N	\N	96.51017800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
424	DS002	Al2O3(s,alpha)	\N	solid	H-H298	398.00	\N	\N	39.54960000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
425	DS002	Al2O3(s,alpha)	\N	solid	S	398.00	\N	\N	286.87460000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
426	DS002	Al2O3(s,alpha)	\N	solid	Cp	498.00	\N	\N	105.97800300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
427	DS002	Al2O3(s,alpha)	\N	solid	H-H298	498.00	\N	\N	49.71430000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
428	DS002	Al2O3(s,alpha)	\N	solid	S	498.00	\N	\N	309.61920000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
429	DS002	Al2O3(s,alpha)	\N	solid	Cp	598.00	\N	\N	112.06332500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
430	DS002	Al2O3(s,alpha)	\N	solid	H-H298	598.00	\N	\N	60.63530000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
431	DS002	Al2O3(s,alpha)	\N	solid	S	598.00	\N	\N	329.58660000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
432	DS002	Al2O3(s,alpha)	\N	solid	Cp	698.00	\N	\N	116.44518400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
433	DS002	Al2O3(s,alpha)	\N	solid	H-H298	698.00	\N	\N	72.07110000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
434	DS002	Al2O3(s,alpha)	\N	solid	S	698.00	\N	\N	347.26100000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
435	DS002	Al2O3(s,alpha)	\N	solid	Cp	798.00	\N	\N	119.83189400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
436	DS002	Al2O3(s,alpha)	\N	solid	H-H298	798.00	\N	\N	83.89150000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
437	DS002	Al2O3(s,alpha)	\N	solid	S	798.00	\N	\N	363.08210000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
438	DS002	Al2O3(s,alpha)	\N	solid	Cp	898.00	\N	\N	122.56932300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
439	DS002	Al2O3(s,alpha)	\N	solid	H-H298	898.00	\N	\N	96.01600000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
440	DS002	Al2O3(s,alpha)	\N	solid	S	898.00	\N	\N	377.39340000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
441	DS002	Al2O3(s,alpha)	\N	solid	Cp	998.00	\N	\N	124.84680600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
442	DS002	Al2O3(s,alpha)	\N	solid	H-H298	998.00	\N	\N	108.39010000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
443	DS002	Al2O3(s,alpha)	\N	solid	S	998.00	\N	\N	390.45620000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
444	DS002	Al2O3(s,alpha)	\N	solid	Cp	1098.00	\N	\N	126.77845600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
445	DS002	Al2O3(s,alpha)	\N	solid	H-H298	1098.00	\N	\N	120.97390000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
446	DS002	Al2O3(s,alpha)	\N	solid	S	1098.00	\N	\N	402.47130000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
447	DS002	Al2O3(s,alpha)	\N	solid	Cp	1198.00	\N	\N	128.43914400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
448	DS002	Al2O3(s,alpha)	\N	solid	H-H298	1198.00	\N	\N	133.73680000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
449	DS002	Al2O3(s,alpha)	\N	solid	S	1198.00	\N	\N	413.59480000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
450	DS002	Al2O3(s,alpha)	\N	solid	Cp	1298.00	\N	\N	129.88189300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
451	DS002	Al2O3(s,alpha)	\N	solid	H-H298	1298.00	\N	\N	146.65450000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
452	DS002	Al2O3(s,alpha)	\N	solid	S	1298.00	\N	\N	423.95030000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
453	DS002	Al2O3(s,alpha)	\N	solid	Cp	1398.00	\N	\N	131.14690100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
454	DS002	Al2O3(s,alpha)	\N	solid	H-H298	1398.00	\N	\N	159.70730000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
455	DS002	Al2O3(s,alpha)	\N	solid	S	1398.00	\N	\N	433.63720000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
456	DS002	Al2O3(s,alpha)	\N	solid	Cp	1498.00	\N	\N	132.26649400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
457	DS002	Al2O3(s,alpha)	\N	solid	H-H298	1498.00	\N	\N	172.87900000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
458	DS002	Al2O3(s,alpha)	\N	solid	S	1498.00	\N	\N	442.73690000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
459	DS002	Al2O3(s,alpha)	\N	solid	Cp	1598.00	\N	\N	133.26798600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
460	DS002	Al2O3(s,alpha)	\N	solid	H-H298	1598.00	\N	\N	186.15660000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
461	DS002	Al2O3(s,alpha)	\N	solid	S	1598.00	\N	\N	451.31680000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
462	DS002	Al2O3(s,alpha)	\N	solid	Cp	1698.00	\N	\N	134.17539600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
463	DS002	Al2O3(s,alpha)	\N	solid	H-H298	1698.00	\N	\N	199.52950000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
464	DS002	Al2O3(s,alpha)	\N	solid	S	1698.00	\N	\N	459.43360000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
465	DS002	Al2O3(s,alpha)	\N	solid	Cp	1798.00	\N	\N	135.01051300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
466	DS002	Al2O3(s,alpha)	\N	solid	H-H298	1798.00	\N	\N	212.98930000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
467	DS002	Al2O3(s,alpha)	\N	solid	S	1798.00	\N	\N	467.13560000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
468	DS002	Al2O3(s,alpha)	\N	solid	Cp	1898.00	\N	\N	135.79358400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
469	DS002	Al2O3(s,alpha)	\N	solid	H-H298	1898.00	\N	\N	226.52990000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
470	DS002	Al2O3(s,alpha)	\N	solid	S	1898.00	\N	\N	474.46430000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
471	DS002	Al2O3(s,alpha)	\N	solid	Cp	1998.00	\N	\N	136.54376500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
472	DS002	Al2O3(s,alpha)	\N	solid	H-H298	1998.00	\N	\N	240.14690000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
473	DS002	Al2O3(s,alpha)	\N	solid	S	1998.00	\N	\N	481.45600000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
474	DS002	Al2O3(s,alpha)	\N	solid	Cp	2098.00	\N	\N	137.27942300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
475	DS002	Al2O3(s,alpha)	\N	solid	H-H298	2098.00	\N	\N	253.83810000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
476	DS002	Al2O3(s,alpha)	\N	solid	S	2098.00	\N	\N	488.14230000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
477	DS002	Al2O3(s,alpha)	\N	solid	Cp	2198.00	\N	\N	138.01834900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
478	DS002	Al2O3(s,alpha)	\N	solid	H-H298	2198.00	\N	\N	267.60290000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
479	DS002	Al2O3(s,alpha)	\N	solid	S	2198.00	\N	\N	494.55150000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
480	DS002	Al2O3(s,alpha)	\N	solid	Cp	2298.00	\N	\N	138.77790300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	10	\N	{}
481	DS002	Al2O3(s,alpha)	\N	solid	H-H298	2298.00	\N	\N	281.44250000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	10	\N	{}
482	DS002	Al2O3(s,alpha)	\N	solid	S	2298.00	\N	\N	500.70880000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	10	\N	{}
483	DS002	Fe2O3(s)	\N	solid	Cp	298.00	\N	\N	66.12501000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	11	\N	{}
484	DS002	Fe2O3(s)	\N	solid	H-H298	298.00	\N	\N	31.20180000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	11	\N	{}
485	DS002	Fe2O3(s)	\N	solid	S	298.00	\N	\N	217.97550000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	11	\N	{}
486	DS002	Fe2O3(s)	\N	solid	Cp	398.00	\N	\N	93.39668200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	11	\N	{}
487	DS002	Fe2O3(s)	\N	solid	H-H298	398.00	\N	\N	39.36210000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	11	\N	{}
488	DS002	Fe2O3(s)	\N	solid	S	398.00	\N	\N	241.39940000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	11	\N	{}
489	DS002	Fe2O3(s)	\N	solid	Cp	498.00	\N	\N	106.83232600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	11	\N	{}
490	DS002	Fe2O3(s)	\N	solid	H-H298	498.00	\N	\N	49.43980000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	11	\N	{}
491	DS002	Fe2O3(s)	\N	solid	S	498.00	\N	\N	263.93220000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	11	\N	{}
492	DS002	Fe2O3(s)	\N	solid	Cp	598.00	\N	\N	114.82339200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	11	\N	{}
493	DS002	Fe2O3(s)	\N	solid	H-H298	598.00	\N	\N	60.55200000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	11	\N	{}
494	DS002	Fe2O3(s)	\N	solid	S	598.00	\N	\N	284.24440000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	11	\N	{}
495	DS002	Fe2O3(s)	\N	solid	Cp	698.00	\N	\N	120.23130700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	11	\N	{}
496	DS002	Fe2O3(s)	\N	solid	H-H298	698.00	\N	\N	72.31990000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	11	\N	{}
497	DS002	Fe2O3(s)	\N	solid	S	698.00	\N	\N	302.43020000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	11	\N	{}
498	DS002	Fe2O3(s)	\N	solid	Cp	798.00	\N	\N	124.24780700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	11	\N	{}
499	DS002	Fe2O3(s)	\N	solid	H-H298	798.00	\N	\N	84.55250000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	11	\N	{}
500	DS002	Fe2O3(s)	\N	solid	S	798.00	\N	\N	318.80240000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	11	\N	{}
501	DS002	Fe2O3(s)	\N	solid	Cp	898.00	\N	\N	127.44120900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	11	\N	{}
502	DS002	Fe2O3(s)	\N	solid	H-H298	898.00	\N	\N	97.14230000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	11	\N	{}
503	DS002	Fe2O3(s)	\N	solid	S	898.00	\N	\N	333.66240000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	11	\N	{}
504	DS002	Fe2O3(s)	\N	solid	Cp	998.00	\N	\N	130.11059100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	11	\N	{}
505	DS002	Fe2O3(s)	\N	solid	H-H298	998.00	\N	\N	110.02340000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	11	\N	{}
506	DS002	Fe2O3(s)	\N	solid	S	998.00	\N	\N	347.26020000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	11	\N	{}
507	DS002	Fe2O3(s)	\N	solid	Cp	1098.00	\N	\N	132.42564200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	11	\N	{}
508	DS002	Fe2O3(s)	\N	solid	H-H298	1098.00	\N	\N	123.15270000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	11	\N	{}
509	DS002	Fe2O3(s)	\N	solid	S	1098.00	\N	\N	359.79580000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	11	\N	{}
510	DS002	Fe2O3(s)	\N	solid	Cp	1198.00	\N	\N	134.48855400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	11	\N	{}
511	DS002	Fe2O3(s)	\N	solid	H-H298	1198.00	\N	\N	136.50020000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	11	\N	{}
512	DS002	Fe2O3(s)	\N	solid	S	1198.00	\N	\N	371.42860000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	S_STD	\N	calculated	11	\N	{}
513	DS002	Fe2O3(s)	\N	solid	Cp	1298.00	\N	\N	136.36394200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	CP_STD	\N	calculated	11	\N	{}
514	DS002	Fe2O3(s)	\N	solid	H-H298	1298.00	\N	\N	150.04420000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.845058	H_INCREMENT_298	\N	calculated	11	\N	{}
515	DS002	Fe2O3(s)	\N	solid	S	1298.00	\N	\N	382.28600000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	11	\N	{}
516	DS002	Fe2O3(s)	\N	solid	Cp	1398.00	\N	\N	138.09436000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	11	\N	{}
517	DS002	Fe2O3(s)	\N	solid	H-H298	1398.00	\N	\N	163.76820000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	11	\N	{}
518	DS002	Fe2O3(s)	\N	solid	S	1398.00	\N	\N	392.47090000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	11	\N	{}
519	DS002	Fe2O3(s)	\N	solid	Cp	1498.00	\N	\N	139.70882200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	11	\N	{}
520	DS002	Fe2O3(s)	\N	solid	H-H298	1498.00	\N	\N	177.65920000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	11	\N	{}
521	DS002	Fe2O3(s)	\N	solid	S	1498.00	\N	\N	402.06730000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	11	\N	{}
522	DS002	Fe2O3(s)	\N	solid	Cp	1598.00	\N	\N	141.22772100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	11	\N	{}
523	DS002	Fe2O3(s)	\N	solid	H-H298	1598.00	\N	\N	191.70680000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	11	\N	{}
524	DS002	Fe2O3(s)	\N	solid	S	1598.00	\N	\N	411.14460000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	11	\N	{}
525	DS002	Fe2O3(s)	\N	solid	Cp	1698.00	\N	\N	142.66578200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	11	\N	{}
526	DS002	Fe2O3(s)	\N	solid	H-H298	1698.00	\N	\N	205.90210000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	11	\N	{}
527	DS002	Fe2O3(s)	\N	solid	S	1698.00	\N	\N	419.76040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	11	\N	{}
528	DS002	Fe3O4(s)	\N	solid	Cp	298.00	\N	\N	105.26759000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
529	DS002	Fe3O4(s)	\N	solid	H-H298	298.00	\N	\N	69.67460000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
530	DS002	Fe3O4(s)	\N	solid	S	298.00	\N	\N	338.30960000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
531	DS002	Fe3O4(s)	\N	solid	Cp	398.00	\N	\N	153.50853400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
532	DS002	Fe3O4(s)	\N	solid	H-H298	398.00	\N	\N	82.93220000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
533	DS002	Fe3O4(s)	\N	solid	S	398.00	\N	\N	376.33790000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
534	DS002	Fe3O4(s)	\N	solid	Cp	498.00	\N	\N	177.75136100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
535	DS002	Fe3O4(s)	\N	solid	H-H298	498.00	\N	\N	99.61050000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
536	DS002	Fe3O4(s)	\N	solid	S	498.00	\N	\N	413.62100000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
537	DS002	Fe3O4(s)	\N	solid	Cp	598.00	\N	\N	192.46156700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
538	DS002	Fe3O4(s)	\N	solid	H-H298	598.00	\N	\N	118.17320000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
539	DS002	Fe3O4(s)	\N	solid	S	598.00	\N	\N	447.54800000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
540	DS002	Fe3O4(s)	\N	solid	Cp	698.00	\N	\N	202.57412200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
541	DS002	Fe3O4(s)	\N	solid	H-H298	698.00	\N	\N	137.95230000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
542	DS002	Fe3O4(s)	\N	solid	S	698.00	\N	\N	478.11200000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
543	DS002	Fe3O4(s)	\N	solid	Cp	798.00	\N	\N	210.14642400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
544	DS002	Fe3O4(s)	\N	solid	H-H298	798.00	\N	\N	158.60440000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
545	DS002	Fe3O4(s)	\N	solid	S	798.00	\N	\N	505.75170000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
546	DS002	Fe3O4(s)	\N	solid	Cp	898.00	\N	\N	216.16146500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
547	DS002	Fe3O4(s)	\N	solid	H-H298	898.00	\N	\N	179.93010000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
548	DS002	Fe3O4(s)	\N	solid	S	898.00	\N	\N	530.92230000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
549	DS002	Fe3O4(s)	\N	solid	Cp	998.00	\N	\N	221.13822100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
550	DS002	Fe3O4(s)	\N	solid	H-H298	998.00	\N	\N	201.80230000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
551	DS002	Fe3O4(s)	\N	solid	S	998.00	\N	\N	554.01100000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
552	DS002	Fe3O4(s)	\N	solid	Cp	1098.00	\N	\N	225.37267600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
553	DS002	Fe3O4(s)	\N	solid	H-H298	1098.00	\N	\N	224.13310000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
554	DS002	Fe3O4(s)	\N	solid	S	1098.00	\N	\N	575.33200000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
555	DS002	Fe3O4(s)	\N	solid	Cp	1198.00	\N	\N	229.04449700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
556	DS002	Fe3O4(s)	\N	solid	H-H298	1198.00	\N	\N	246.85810000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
557	DS002	Fe3O4(s)	\N	solid	S	1198.00	\N	\N	595.13750000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
558	DS002	Fe3O4(s)	\N	solid	Cp	1298.00	\N	\N	232.26858500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
559	DS002	Fe3O4(s)	\N	solid	H-H298	1298.00	\N	\N	269.92720000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
560	DS002	Fe3O4(s)	\N	solid	S	1298.00	\N	\N	613.63050000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
561	DS002	Fe3O4(s)	\N	solid	Cp	1398.00	\N	\N	235.12181800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
562	DS002	Fe3O4(s)	\N	solid	H-H298	1398.00	\N	\N	293.29950000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
563	DS002	Fe3O4(s)	\N	solid	S	1398.00	\N	\N	630.97570000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
564	DS002	Fe3O4(s)	\N	solid	Cp	1498.00	\N	\N	237.65774300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
565	DS002	Fe3O4(s)	\N	solid	H-H298	1498.00	\N	\N	316.94100000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
566	DS002	Fe3O4(s)	\N	solid	S	1498.00	\N	\N	647.30810000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
567	DS002	Fe3O4(s)	\N	solid	Cp	1598.00	\N	\N	239.91504900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
568	DS002	Fe3O4(s)	\N	solid	H-H298	1598.00	\N	\N	340.82180000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
569	DS002	Fe3O4(s)	\N	solid	S	1598.00	\N	\N	662.73960000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
570	DS002	Fe3O4(s)	\N	solid	Cp	1698.00	\N	\N	241.92265400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
571	DS002	Fe3O4(s)	\N	solid	H-H298	1698.00	\N	\N	364.91570000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
572	DS002	Fe3O4(s)	\N	solid	S	1698.00	\N	\N	677.36350000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
573	DS002	Fe3O4(s)	\N	solid	Cp	1798.00	\N	\N	243.70287200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	12	\N	{}
574	DS002	Fe3O4(s)	\N	solid	H-H298	1798.00	\N	\N	389.19880000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	12	\N	{}
575	DS002	Fe3O4(s)	\N	solid	S	1798.00	\N	\N	691.25880000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	12	\N	{}
576	DS002	CaO(s)	\N	solid	Cp	298.00	\N	\N	38.92111400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	13	\N	{}
577	DS002	CaO(s)	\N	solid	H-H298	298.00	\N	\N	12.23930000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	13	\N	{}
578	DS002	CaO(s)	\N	solid	S	298.00	\N	\N	40.17900000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	13	\N	{}
579	DS002	CaO(s)	\N	solid	Cp	398.00	\N	\N	44.78225800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	13	\N	{}
580	DS002	CaO(s)	\N	solid	H-H298	398.00	\N	\N	16.46360000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	13	\N	{}
581	DS002	CaO(s)	\N	solid	S	398.00	\N	\N	52.36190000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	13	\N	{}
582	DS002	CaO(s)	\N	solid	Cp	498.00	\N	\N	47.70114000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	13	\N	{}
583	DS002	CaO(s)	\N	solid	H-H298	498.00	\N	\N	21.10190000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	13	\N	{}
584	DS002	CaO(s)	\N	solid	S	498.00	\N	\N	62.74630000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	13	\N	{}
585	DS002	CaO(s)	\N	solid	Cp	598.00	\N	\N	49.45987100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	13	\N	{}
586	DS002	CaO(s)	\N	solid	H-H298	598.00	\N	\N	25.96620000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	13	\N	{}
587	DS002	CaO(s)	\N	solid	S	598.00	\N	\N	71.64270000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	13	\N	{}
588	DS002	CaO(s)	\N	solid	Cp	698.00	\N	\N	50.66621600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	13	\N	{}
589	DS002	CaO(s)	\N	solid	H-H298	698.00	\N	\N	30.97580000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	13	\N	{}
590	DS002	CaO(s)	\N	solid	S	698.00	\N	\N	79.38650000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	13	\N	{}
591	DS002	CaO(s)	\N	solid	Cp	798.00	\N	\N	51.57336500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	13	\N	{}
592	DS002	CaO(s)	\N	solid	H-H298	798.00	\N	\N	36.08960000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	13	\N	{}
593	DS002	CaO(s)	\N	solid	S	798.00	\N	\N	86.23210000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	13	\N	{}
594	DS002	CaO(s)	\N	solid	Cp	898.00	\N	\N	52.30212500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	13	\N	{}
595	DS002	CaO(s)	\N	solid	H-H298	898.00	\N	\N	41.28460000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	13	\N	{}
596	DS002	CaO(s)	\N	solid	S	898.00	\N	\N	92.36440000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	13	\N	{}
597	DS002	CaO(s)	\N	solid	Cp	998.00	\N	\N	52.91612200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	13	\N	{}
598	DS002	CaO(s)	\N	solid	H-H298	998.00	\N	\N	46.54630000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	13	\N	{}
599	DS002	CaO(s)	\N	solid	S	998.00	\N	\N	97.91930000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	13	\N	{}
600	DS002	CaO(s)	\N	solid	Cp	1098.00	\N	\N	53.45151100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	13	\N	{}
601	DS002	CaO(s)	\N	solid	H-H298	1098.00	\N	\N	51.86520000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	13	\N	{}
602	DS002	CaO(s)	\N	solid	S	1098.00	\N	\N	102.99810000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	13	\N	{}
603	DS002	CaO(s)	\N	solid	Cp	1198.00	\N	\N	53.93010800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	13	\N	{}
604	DS002	CaO(s)	\N	solid	H-H298	1198.00	\N	\N	57.23470000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	13	\N	{}
605	DS002	CaO(s)	\N	solid	S	1198.00	\N	\N	107.67800000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	13	\N	{}
606	DS002	CaO(s)	\N	solid	Cp	1298.00	\N	\N	54.36575400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	13	\N	{}
607	DS002	CaO(s)	\N	solid	H-H298	1298.00	\N	\N	62.64980000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	13	\N	{}
608	DS002	CaO(s)	\N	solid	S	1298.00	\N	\N	112.01910000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	13	\N	{}
609	DS002	CaO(s)	\N	solid	Cp	1398.00	\N	\N	54.76760100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	13	\N	{}
610	DS002	CaO(s)	\N	solid	H-H298	1398.00	\N	\N	68.10670000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	13	\N	{}
611	DS002	CaO(s)	\N	solid	S	1398.00	\N	\N	116.06900000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	13	\N	{}
612	DS002	CaO(s)	\N	solid	Cp	1498.00	\N	\N	55.14192900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	CP_STD	\N	calculated	13	\N	{}
613	DS002	CaO(s)	\N	solid	H-H298	1498.00	\N	\N	73.60240000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	H_INCREMENT_298	\N	calculated	13	\N	{}
614	DS002	CaO(s)	\N	solid	S	1498.00	\N	\N	119.86570000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.848036	S_STD	\N	calculated	13	\N	{}
615	DS002	CaO(s)	\N	solid	Cp	1598.00	\N	\N	55.49318600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
616	DS002	CaO(s)	\N	solid	H-H298	1598.00	\N	\N	79.13430000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
617	DS002	CaO(s)	\N	solid	S	1598.00	\N	\N	123.44040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
618	DS002	CaO(s)	\N	solid	Cp	1698.00	\N	\N	55.82461500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
619	DS002	CaO(s)	\N	solid	H-H298	1698.00	\N	\N	84.70040000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
620	DS002	CaO(s)	\N	solid	S	1698.00	\N	\N	126.81880000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
621	DS002	CaO(s)	\N	solid	Cp	1798.00	\N	\N	56.13864800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
622	DS002	CaO(s)	\N	solid	H-H298	1798.00	\N	\N	90.29870000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
623	DS002	CaO(s)	\N	solid	S	1798.00	\N	\N	130.02230000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
624	DS002	CaO(s)	\N	solid	Cp	1898.00	\N	\N	56.43715000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
625	DS002	CaO(s)	\N	solid	H-H298	1898.00	\N	\N	95.92760000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
626	DS002	CaO(s)	\N	solid	S	1898.00	\N	\N	133.06890000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
627	DS002	CaO(s)	\N	solid	Cp	1998.00	\N	\N	56.72158900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
628	DS002	CaO(s)	\N	solid	H-H298	1998.00	\N	\N	101.58560000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
629	DS002	CaO(s)	\N	solid	S	1998.00	\N	\N	135.97400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
630	DS002	CaO(s)	\N	solid	Cp	2098.00	\N	\N	56.99314500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
631	DS002	CaO(s)	\N	solid	H-H298	2098.00	\N	\N	107.27150000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
632	DS002	CaO(s)	\N	solid	S	2098.00	\N	\N	138.75080000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
633	DS002	CaO(s)	\N	solid	Cp	2198.00	\N	\N	57.25278900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
634	DS002	CaO(s)	\N	solid	H-H298	2198.00	\N	\N	112.98390000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
635	DS002	CaO(s)	\N	solid	S	2198.00	\N	\N	141.41060000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
636	DS002	CaO(s)	\N	solid	Cp	2298.00	\N	\N	57.50133200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
637	DS002	CaO(s)	\N	solid	H-H298	2298.00	\N	\N	118.72170000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
638	DS002	CaO(s)	\N	solid	S	2298.00	\N	\N	143.96340000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
639	DS002	CaO(s)	\N	solid	Cp	2398.00	\N	\N	57.73946700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
640	DS002	CaO(s)	\N	solid	H-H298	2398.00	\N	\N	124.48380000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
641	DS002	CaO(s)	\N	solid	S	2398.00	\N	\N	146.41780000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
642	DS002	CaO(s)	\N	solid	Cp	2498.00	\N	\N	57.96779900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
643	DS002	CaO(s)	\N	solid	H-H298	2498.00	\N	\N	130.26920000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
644	DS002	CaO(s)	\N	solid	S	2498.00	\N	\N	148.78140000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
645	DS002	CaO(s)	\N	solid	Cp	2598.00	\N	\N	58.18685900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
646	DS002	CaO(s)	\N	solid	H-H298	2598.00	\N	\N	136.07700000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
647	DS002	CaO(s)	\N	solid	S	2598.00	\N	\N	151.06110000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
648	DS002	CaO(s)	\N	solid	Cp	2698.00	\N	\N	58.39712600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
649	DS002	CaO(s)	\N	solid	H-H298	2698.00	\N	\N	141.90630000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
650	DS002	CaO(s)	\N	solid	S	2698.00	\N	\N	153.26270000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
651	DS002	CaO(s)	\N	solid	Cp	2798.00	\N	\N	58.59903400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
652	DS002	CaO(s)	\N	solid	H-H298	2798.00	\N	\N	147.75620000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
653	DS002	CaO(s)	\N	solid	S	2798.00	\N	\N	155.39170000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
654	DS002	CaO(s)	\N	solid	Cp	2898.00	\N	\N	58.79298400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
655	DS002	CaO(s)	\N	solid	H-H298	2898.00	\N	\N	153.62580000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
656	DS002	CaO(s)	\N	solid	S	2898.00	\N	\N	157.45280000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
657	DS002	CaO(s)	\N	solid	Cp	2998.00	\N	\N	58.97934700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
658	DS002	CaO(s)	\N	solid	H-H298	2998.00	\N	\N	159.51450000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
659	DS002	CaO(s)	\N	solid	S	2998.00	\N	\N	159.45050000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
660	DS002	CaO(s)	\N	solid	Cp	3098.00	\N	\N	59.15847300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
661	DS002	CaO(s)	\N	solid	H-H298	3098.00	\N	\N	165.42150000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
662	DS002	CaO(s)	\N	solid	S	3098.00	\N	\N	161.38870000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
663	DS002	CaO(s)	\N	solid	Cp	3198.00	\N	\N	59.33069500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	13	\N	{}
664	DS002	CaO(s)	\N	solid	H-H298	3198.00	\N	\N	171.34600000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	13	\N	{}
665	DS002	CaO(s)	\N	solid	S	3198.00	\N	\N	163.27080000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	13	\N	{}
666	DS002	CaCO3(s)	\N	solid	Cp	298.00	\N	\N	104.07724600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	14	\N	{}
667	DS002	CaCO3(s)	\N	solid	H-H298	298.00	\N	\N	14.22980000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	14	\N	{}
668	DS002	CaCO3(s)	\N	solid	S	298.00	\N	\N	172.18970000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	14	\N	{}
669	DS002	CaCO3(s)	\N	solid	Cp	398.00	\N	\N	116.18588700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	14	\N	{}
670	DS002	CaCO3(s)	\N	solid	H-H298	398.00	\N	\N	25.31300000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	14	\N	{}
671	DS002	CaCO3(s)	\N	solid	S	398.00	\N	\N	204.17610000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	14	\N	{}
672	DS002	CaCO3(s)	\N	solid	Cp	498.00	\N	\N	122.89807200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	14	\N	{}
673	DS002	CaCO3(s)	\N	solid	H-H298	498.00	\N	\N	37.29430000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	14	\N	{}
674	DS002	CaCO3(s)	\N	solid	S	498.00	\N	\N	231.00380000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	14	\N	{}
675	DS002	CaCO3(s)	\N	solid	Cp	598.00	\N	\N	127.28345200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	14	\N	{}
676	DS002	CaCO3(s)	\N	solid	H-H298	598.00	\N	\N	49.81690000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	14	\N	{}
677	DS002	CaCO3(s)	\N	solid	S	598.00	\N	\N	253.90680000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	14	\N	{}
678	DS002	CaCO3(s)	\N	solid	Cp	698.00	\N	\N	130.40453200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	14	\N	{}
679	DS002	CaCO3(s)	\N	solid	H-H298	698.00	\N	\N	62.70940000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	14	\N	{}
680	DS002	CaCO3(s)	\N	solid	S	698.00	\N	\N	273.83610000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	14	\N	{}
681	DS002	CaCO3(s)	\N	solid	Cp	798.00	\N	\N	132.71779500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	14	\N	{}
682	DS002	CaCO3(s)	\N	solid	H-H298	798.00	\N	\N	75.87110000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	14	\N	{}
683	DS002	CaCO3(s)	\N	solid	S	798.00	\N	\N	291.45470000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	14	\N	{}
684	DS002	CaCO3(s)	\N	solid	Cp	898.00	\N	\N	134.45345200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	14	\N	{}
685	DS002	CaCO3(s)	\N	solid	H-H298	898.00	\N	\N	89.23380000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	14	\N	{}
686	DS002	CaCO3(s)	\N	solid	S	898.00	\N	\N	307.22900000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	14	\N	{}
687	DS002	CaCO3(s)	\N	solid	Cp	998.00	\N	\N	135.74399100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	14	\N	{}
688	DS002	CaCO3(s)	\N	solid	H-H298	998.00	\N	\N	102.74700000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	14	\N	{}
689	DS002	CaCO3(s)	\N	solid	S	998.00	\N	\N	321.49540000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	14	\N	{}
690	DS002	CaCO3(s)	\N	solid	Cp	1098.00	\N	\N	136.67493800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	14	\N	{}
691	DS002	CaCO3(s)	\N	solid	H-H298	1098.00	\N	\N	116.37060000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	14	\N	{}
692	DS002	CaCO3(s)	\N	solid	S	1098.00	\N	\N	334.50420000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	14	\N	{}
693	DS002	CaCO3(s)	\N	solid	Cp	1198.00	\N	\N	137.30732200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	14	\N	{}
694	DS002	CaCO3(s)	\N	solid	H-H298	1198.00	\N	\N	130.07200000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	14	\N	{}
695	DS002	CaCO3(s)	\N	solid	S	1198.00	\N	\N	346.44640000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	14	\N	{}
696	DS002	MgO(s)	\N	solid	Cp	298.00	\N	\N	47.74420100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	15	\N	{}
697	DS002	MgO(s)	\N	solid	H-H298	298.00	\N	\N	-0.76220000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	15	\N	{}
698	DS002	MgO(s)	\N	solid	S	298.00	\N	\N	-12.85680000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	15	\N	{}
699	DS002	MgO(s)	\N	solid	Cp	398.00	\N	\N	52.82664600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	15	\N	{}
700	DS002	MgO(s)	\N	solid	H-H298	398.00	\N	\N	4.30490000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	15	\N	{}
701	DS002	MgO(s)	\N	solid	S	398.00	\N	\N	1.77000000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	15	\N	{}
702	DS002	MgO(s)	\N	solid	Cp	498.00	\N	\N	55.03390400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	15	\N	{}
703	DS002	MgO(s)	\N	solid	H-H298	498.00	\N	\N	9.71150000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	15	\N	{}
704	DS002	MgO(s)	\N	solid	S	498.00	\N	\N	13.87970000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	15	\N	{}
705	DS002	MgO(s)	\N	solid	Cp	598.00	\N	\N	56.13591800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	15	\N	{}
706	DS002	MgO(s)	\N	solid	H-H298	598.00	\N	\N	15.27580000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	15	\N	{}
707	DS002	MgO(s)	\N	solid	S	598.00	\N	\N	24.05890000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	15	\N	{}
708	DS002	MgO(s)	\N	solid	Cp	698.00	\N	\N	56.73440200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	15	\N	{}
709	DS002	MgO(s)	\N	solid	H-H298	698.00	\N	\N	20.92220000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	15	\N	{}
710	DS002	MgO(s)	\N	solid	S	698.00	\N	\N	32.78860000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	15	\N	{}
711	DS002	MgO(s)	\N	solid	Cp	798.00	\N	\N	57.07834100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	15	\N	{}
712	DS002	MgO(s)	\N	solid	H-H298	798.00	\N	\N	26.61440000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	H_INCREMENT_298	\N	calculated	15	\N	{}
713	DS002	MgO(s)	\N	solid	S	798.00	\N	\N	40.40930000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	S_STD	\N	calculated	15	\N	{}
714	DS002	MgO(s)	\N	solid	Cp	898.00	\N	\N	57.28502400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.850217	CP_STD	\N	calculated	15	\N	{}
715	DS002	MgO(s)	\N	solid	H-H298	898.00	\N	\N	32.33340000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
716	DS002	MgO(s)	\N	solid	S	898.00	\N	\N	47.16100000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
717	DS002	MgO(s)	\N	solid	Cp	998.00	\N	\N	57.41486000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
718	DS002	MgO(s)	\N	solid	H-H298	998.00	\N	\N	38.06880000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
719	DS002	MgO(s)	\N	solid	S	998.00	\N	\N	53.21650000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
720	DS002	MgO(s)	\N	solid	Cp	1098.00	\N	\N	57.50092600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
721	DS002	MgO(s)	\N	solid	H-H298	1098.00	\N	\N	43.81490000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
722	DS002	MgO(s)	\N	solid	S	1098.00	\N	\N	58.70350000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
723	DS002	MgO(s)	\N	solid	Cp	1198.00	\N	\N	57.56203900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
724	DS002	MgO(s)	\N	solid	H-H298	1198.00	\N	\N	49.56820000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
725	DS002	MgO(s)	\N	solid	S	1198.00	\N	\N	63.71820000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
726	DS002	MgO(s)	\N	solid	Cp	1298.00	\N	\N	57.60907900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
727	DS002	MgO(s)	\N	solid	H-H298	1298.00	\N	\N	55.32680000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
728	DS002	MgO(s)	\N	solid	S	1298.00	\N	\N	68.33500000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
729	DS002	MgO(s)	\N	solid	Cp	1398.00	\N	\N	57.64826400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
730	DS002	MgO(s)	\N	solid	H-H298	1398.00	\N	\N	61.08970000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
731	DS002	MgO(s)	\N	solid	S	1398.00	\N	\N	72.61210000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
732	DS002	MgO(s)	\N	solid	Cp	1498.00	\N	\N	57.68295300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
733	DS002	MgO(s)	\N	solid	H-H298	1498.00	\N	\N	66.85630000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
734	DS002	MgO(s)	\N	solid	S	1498.00	\N	\N	76.59610000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
735	DS002	MgO(s)	\N	solid	Cp	1598.00	\N	\N	57.71468300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
736	DS002	MgO(s)	\N	solid	H-H298	1598.00	\N	\N	72.62620000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
737	DS002	MgO(s)	\N	solid	S	1598.00	\N	\N	80.32470000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
738	DS002	MgO(s)	\N	solid	Cp	1698.00	\N	\N	57.74379400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
739	DS002	MgO(s)	\N	solid	H-H298	1698.00	\N	\N	78.39920000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
740	DS002	MgO(s)	\N	solid	S	1698.00	\N	\N	83.82880000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
741	DS002	MgO(s)	\N	solid	Cp	1798.00	\N	\N	57.76981600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
742	DS002	MgO(s)	\N	solid	H-H298	1798.00	\N	\N	84.17490000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
743	DS002	MgO(s)	\N	solid	S	1798.00	\N	\N	87.13390000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
744	DS002	MgO(s)	\N	solid	Cp	1898.00	\N	\N	57.79171800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
745	DS002	MgO(s)	\N	solid	H-H298	1898.00	\N	\N	89.95300000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
746	DS002	MgO(s)	\N	solid	S	1898.00	\N	\N	90.26130000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
747	DS002	MgO(s)	\N	solid	Cp	1998.00	\N	\N	57.80807300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
748	DS002	MgO(s)	\N	solid	H-H298	1998.00	\N	\N	95.73310000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
749	DS002	MgO(s)	\N	solid	S	1998.00	\N	\N	93.22910000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
750	DS002	MgO(s)	\N	solid	Cp	2098.00	\N	\N	57.81716800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
751	DS002	MgO(s)	\N	solid	H-H298	2098.00	\N	\N	101.51440000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
752	DS002	MgO(s)	\N	solid	S	2098.00	\N	\N	96.05260000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
753	DS002	MgO(s)	\N	solid	Cp	2198.00	\N	\N	57.81707900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
754	DS002	MgO(s)	\N	solid	H-H298	2198.00	\N	\N	107.29620000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
755	DS002	MgO(s)	\N	solid	S	2198.00	\N	\N	98.74480000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
756	DS002	MgO(s)	\N	solid	Cp	2298.00	\N	\N	57.80572700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
757	DS002	MgO(s)	\N	solid	H-H298	2298.00	\N	\N	113.07740000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
758	DS002	MgO(s)	\N	solid	S	2298.00	\N	\N	101.31690000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
759	DS002	MgO(s)	\N	solid	Cp	2398.00	\N	\N	57.78091400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
760	DS002	MgO(s)	\N	solid	H-H298	2398.00	\N	\N	118.85690000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
761	DS002	MgO(s)	\N	solid	S	2398.00	\N	\N	103.77880000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
762	DS002	MgO(s)	\N	solid	Cp	2498.00	\N	\N	57.74035400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
763	DS002	MgO(s)	\N	solid	H-H298	2498.00	\N	\N	124.63310000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
764	DS002	MgO(s)	\N	solid	S	2498.00	\N	\N	106.13860000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
765	DS002	MgO(s)	\N	solid	Cp	2598.00	\N	\N	57.68168800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
766	DS002	MgO(s)	\N	solid	H-H298	2598.00	\N	\N	130.40440000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
767	DS002	MgO(s)	\N	solid	S	2598.00	\N	\N	108.40400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
768	DS002	MgO(s)	\N	solid	Cp	2698.00	\N	\N	57.60250400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
769	DS002	MgO(s)	\N	solid	H-H298	2698.00	\N	\N	136.16870000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
770	DS002	MgO(s)	\N	solid	S	2698.00	\N	\N	110.58110000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
771	DS002	MgO(s)	\N	solid	Cp	2798.00	\N	\N	57.50034700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
772	DS002	MgO(s)	\N	solid	H-H298	2798.00	\N	\N	141.92410000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
773	DS002	MgO(s)	\N	solid	S	2798.00	\N	\N	112.67570000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
774	DS002	MgO(s)	\N	solid	Cp	2898.00	\N	\N	57.37272800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
775	DS002	MgO(s)	\N	solid	H-H298	2898.00	\N	\N	147.66800000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
776	DS002	MgO(s)	\N	solid	S	2898.00	\N	\N	114.69280000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
777	DS002	MgO(s)	\N	solid	Cp	2998.00	\N	\N	57.21712900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
778	DS002	MgO(s)	\N	solid	H-H298	2998.00	\N	\N	153.39770000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
779	DS002	MgO(s)	\N	solid	S	2998.00	\N	\N	116.63660000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
780	DS002	MgO(s)	\N	solid	Cp	3098.00	\N	\N	57.03101200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	15	\N	{}
781	DS002	MgO(s)	\N	solid	H-H298	3098.00	\N	\N	159.11040000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	15	\N	{}
782	DS002	MgO(s)	\N	solid	S	3098.00	\N	\N	118.51100000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	15	\N	{}
783	DS002	MnO(s)	\N	solid	Cp	298.00	\N	\N	46.26357100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	16	\N	{}
784	DS002	MnO(s)	\N	solid	H-H298	298.00	\N	\N	11.13540000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	16	\N	{}
785	DS002	MnO(s)	\N	solid	S	298.00	\N	\N	70.75400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	16	\N	{}
786	DS002	MnO(s)	\N	solid	Cp	398.00	\N	\N	51.85503600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	16	\N	{}
787	DS002	MnO(s)	\N	solid	H-H298	398.00	\N	\N	16.07680000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	16	\N	{}
788	DS002	MnO(s)	\N	solid	S	398.00	\N	\N	85.01360000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	16	\N	{}
789	DS002	MnO(s)	\N	solid	Cp	498.00	\N	\N	54.78565000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	16	\N	{}
790	DS002	MnO(s)	\N	solid	H-H298	498.00	\N	\N	21.42150000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	16	\N	{}
791	DS002	MnO(s)	\N	solid	S	498.00	\N	\N	96.98150000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	16	\N	{}
792	DS002	MnO(s)	\N	solid	Cp	598.00	\N	\N	56.67154800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	16	\N	{}
793	DS002	MnO(s)	\N	solid	H-H298	598.00	\N	\N	27.00010000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	16	\N	{}
794	DS002	MnO(s)	\N	solid	S	598.00	\N	\N	107.18440000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	16	\N	{}
795	DS002	MnO(s)	\N	solid	Cp	698.00	\N	\N	58.06318500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	16	\N	{}
796	DS002	MnO(s)	\N	solid	H-H298	698.00	\N	\N	32.73970000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	16	\N	{}
797	DS002	MnO(s)	\N	solid	S	698.00	\N	\N	116.05680000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	16	\N	{}
798	DS002	MnO(s)	\N	solid	Cp	798.00	\N	\N	59.18924900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	16	\N	{}
799	DS002	MnO(s)	\N	solid	H-H298	798.00	\N	\N	38.60400000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	16	\N	{}
800	DS002	MnO(s)	\N	solid	S	798.00	\N	\N	123.90670000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	16	\N	{}
801	DS002	MnO(s)	\N	solid	Cp	898.00	\N	\N	60.15829300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	16	\N	{}
802	DS002	MnO(s)	\N	solid	H-H298	898.00	\N	\N	44.57240000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	16	\N	{}
803	DS002	MnO(s)	\N	solid	S	898.00	\N	\N	130.95200000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	16	\N	{}
804	DS002	MnO(s)	\N	solid	Cp	998.00	\N	\N	61.02698500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	16	\N	{}
805	DS002	MnO(s)	\N	solid	H-H298	998.00	\N	\N	50.63230000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	16	\N	{}
806	DS002	MnO(s)	\N	solid	S	998.00	\N	\N	137.34950000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	16	\N	{}
807	DS002	MnO(s)	\N	solid	Cp	1098.00	\N	\N	61.82705600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	16	\N	{}
808	DS002	MnO(s)	\N	solid	H-H298	1098.00	\N	\N	56.77550000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	16	\N	{}
809	DS002	MnO(s)	\N	solid	S	1098.00	\N	\N	143.21510000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	16	\N	{}
810	DS002	MnO(s)	\N	solid	Cp	1198.00	\N	\N	62.57723300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	16	\N	{}
811	DS002	MnO(s)	\N	solid	H-H298	1198.00	\N	\N	62.99610000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	16	\N	{}
812	DS002	MnO(s)	\N	solid	S	1198.00	\N	\N	148.63670000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	S_STD	\N	calculated	16	\N	{}
813	DS002	MnO(s)	\N	solid	Cp	1298.00	\N	\N	63.28900100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	CP_STD	\N	calculated	16	\N	{}
814	DS002	MnO(s)	\N	solid	H-H298	1298.00	\N	\N	69.28960000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85238	H_INCREMENT_298	\N	calculated	16	\N	{}
815	DS002	MnO(s)	\N	solid	S	1298.00	\N	\N	153.68200000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	16	\N	{}
816	DS002	MnO(s)	\N	solid	Cp	1398.00	\N	\N	63.96959100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	16	\N	{}
817	DS002	MnO(s)	\N	solid	H-H298	1398.00	\N	\N	75.65280000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	16	\N	{}
818	DS002	MnO(s)	\N	solid	S	1398.00	\N	\N	158.40430000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	16	\N	{}
819	DS002	MnO(s)	\N	solid	Cp	1498.00	\N	\N	64.62362700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	16	\N	{}
820	DS002	MnO(s)	\N	solid	H-H298	1498.00	\N	\N	82.08270000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	16	\N	{}
821	DS002	MnO(s)	\N	solid	S	1498.00	\N	\N	162.84630000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	16	\N	{}
822	DS002	MnO(s)	\N	solid	Cp	1598.00	\N	\N	65.25407300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	16	\N	{}
823	DS002	MnO(s)	\N	solid	H-H298	1598.00	\N	\N	88.57680000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	16	\N	{}
824	DS002	MnO(s)	\N	solid	S	1598.00	\N	\N	167.04270000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	16	\N	{}
825	DS002	MnO(s)	\N	solid	Cp	1698.00	\N	\N	65.86279700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	16	\N	{}
826	DS002	MnO(s)	\N	solid	H-H298	1698.00	\N	\N	95.13280000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	16	\N	{}
827	DS002	MnO(s)	\N	solid	S	1698.00	\N	\N	171.02190000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	16	\N	{}
828	DS002	MnO(s)	\N	solid	Cp	1798.00	\N	\N	66.45093100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	16	\N	{}
829	DS002	MnO(s)	\N	solid	H-H298	1798.00	\N	\N	101.74860000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	16	\N	{}
830	DS002	MnO(s)	\N	solid	S	1798.00	\N	\N	174.80760000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	16	\N	{}
831	DS002	MnO(s)	\N	solid	Cp	1898.00	\N	\N	67.01909500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	16	\N	{}
832	DS002	MnO(s)	\N	solid	H-H298	1898.00	\N	\N	108.42230000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	16	\N	{}
833	DS002	MnO(s)	\N	solid	S	1898.00	\N	\N	178.41960000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	16	\N	{}
834	DS002	MnO(s)	\N	solid	Cp	1998.00	\N	\N	67.56754700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	16	\N	{}
835	DS002	MnO(s)	\N	solid	H-H298	1998.00	\N	\N	115.15180000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	16	\N	{}
836	DS002	MnO(s)	\N	solid	S	1998.00	\N	\N	181.87480000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	16	\N	{}
837	DS002	H2(g)	\N	gas	Cp	298.00	\N	\N	28.83627600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
838	DS002	H2(g)	\N	gas	H-H298	298.00	\N	\N	-0.00420000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
839	DS002	H2(g)	\N	gas	S	298.00	\N	\N	130.66540000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
840	DS002	H2(g)	\N	gas	Cp	398.00	\N	\N	29.17874300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
841	DS002	H2(g)	\N	gas	H-H298	398.00	\N	\N	2.90080000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
842	DS002	H2(g)	\N	gas	S	398.00	\N	\N	139.06880000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
843	DS002	H2(g)	\N	gas	Cp	498.00	\N	\N	29.26077100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
844	DS002	H2(g)	\N	gas	H-H298	498.00	\N	\N	5.82350000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
845	DS002	H2(g)	\N	gas	S	498.00	\N	\N	145.61970000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
846	DS002	H2(g)	\N	gas	Cp	598.00	\N	\N	29.32291100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
847	DS002	H2(g)	\N	gas	H-H298	598.00	\N	\N	8.75240000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
848	DS002	H2(g)	\N	gas	S	598.00	\N	\N	150.97920000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
849	DS002	H2(g)	\N	gas	Cp	698.00	\N	\N	29.43621400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
850	DS002	H2(g)	\N	gas	H-H298	698.00	\N	\N	11.68980000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
851	DS002	H2(g)	\N	gas	S	698.00	\N	\N	155.52100000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
852	DS002	H2(g)	\N	gas	Cp	798.00	\N	\N	29.62055500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
853	DS002	H2(g)	\N	gas	H-H298	798.00	\N	\N	14.64210000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
854	DS002	H2(g)	\N	gas	S	798.00	\N	\N	159.47350000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
855	DS002	H2(g)	\N	gas	Cp	898.00	\N	\N	29.87669900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
856	DS002	H2(g)	\N	gas	H-H298	898.00	\N	\N	17.61640000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
857	DS002	H2(g)	\N	gas	S	898.00	\N	\N	162.98460000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
858	DS002	H2(g)	\N	gas	Cp	998.00	\N	\N	30.19715900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
859	DS002	H2(g)	\N	gas	H-H298	998.00	\N	\N	20.61960000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
860	DS002	H2(g)	\N	gas	S	998.00	\N	\N	166.15520000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
861	DS002	H2(g)	\N	gas	Cp	1098.00	\N	\N	30.57048400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
862	DS002	H2(g)	\N	gas	H-H298	1098.00	\N	\N	23.65750000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
863	DS002	H2(g)	\N	gas	S	1098.00	\N	\N	169.05600000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
864	DS002	H2(g)	\N	gas	Cp	1198.00	\N	\N	30.98315100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
865	DS002	H2(g)	\N	gas	H-H298	1198.00	\N	\N	26.73500000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
866	DS002	H2(g)	\N	gas	S	1198.00	\N	\N	171.73810000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
867	DS002	H2(g)	\N	gas	Cp	1298.00	\N	\N	31.42048800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
868	DS002	H2(g)	\N	gas	H-H298	1298.00	\N	\N	29.85500000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
869	DS002	H2(g)	\N	gas	S	1298.00	\N	\N	174.23920000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
870	DS002	H2(g)	\N	gas	Cp	1398.00	\N	\N	31.86714500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
871	DS002	H2(g)	\N	gas	H-H298	1398.00	\N	\N	33.01940000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
872	DS002	H2(g)	\N	gas	S	1398.00	\N	\N	176.58760000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
873	DS002	H2(g)	\N	gas	Cp	1498.00	\N	\N	32.30735900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
874	DS002	H2(g)	\N	gas	H-H298	1498.00	\N	\N	36.22820000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
875	DS002	H2(g)	\N	gas	S	1498.00	\N	\N	178.80430000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
876	DS002	H2(g)	\N	gas	Cp	1598.00	\N	\N	32.72510000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
877	DS002	H2(g)	\N	gas	H-H298	1598.00	\N	\N	39.48010000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
878	DS002	H2(g)	\N	gas	S	1598.00	\N	\N	180.90560000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
879	DS002	H2(g)	\N	gas	Cp	1698.00	\N	\N	33.10416600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
880	DS002	H2(g)	\N	gas	H-H298	1698.00	\N	\N	42.77190000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
881	DS002	H2(g)	\N	gas	S	1698.00	\N	\N	182.90360000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
882	DS002	H2(g)	\N	gas	Cp	1798.00	\N	\N	33.42823700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
883	DS002	H2(g)	\N	gas	H-H298	1798.00	\N	\N	46.09910000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
884	DS002	H2(g)	\N	gas	S	1798.00	\N	\N	184.80740000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
885	DS002	H2(g)	\N	gas	Cp	1898.00	\N	\N	33.68091200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
886	DS002	H2(g)	\N	gas	H-H298	1898.00	\N	\N	49.45520000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
887	DS002	H2(g)	\N	gas	S	1898.00	\N	\N	186.62390000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
888	DS002	H2(g)	\N	gas	Cp	1998.00	\N	\N	33.84573300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	17	\N	{}
889	DS002	H2(g)	\N	gas	H-H298	1998.00	\N	\N	52.83230000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	17	\N	{}
890	DS002	H2(g)	\N	gas	S	1998.00	\N	\N	188.35790000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	17	\N	{}
891	DS002	N2(g)	\N	gas	Cp	298.00	\N	\N	28.87035200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	18	\N	{}
892	DS002	N2(g)	\N	gas	H-H298	298.00	\N	\N	0.79790000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	18	\N	{}
893	DS002	N2(g)	\N	gas	S	298.00	\N	\N	186.87810000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	18	\N	{}
894	DS002	N2(g)	\N	gas	Cp	398.00	\N	\N	29.34063700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	18	\N	{}
895	DS002	N2(g)	\N	gas	H-H298	398.00	\N	\N	3.70720000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	18	\N	{}
896	DS002	N2(g)	\N	gas	S	398.00	\N	\N	195.29300000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	18	\N	{}
897	DS002	N2(g)	\N	gas	Cp	498.00	\N	\N	29.89372300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	18	\N	{}
898	DS002	N2(g)	\N	gas	H-H298	498.00	\N	\N	6.66860000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	18	\N	{}
899	DS002	N2(g)	\N	gas	S	498.00	\N	\N	201.92870000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	18	\N	{}
900	DS002	N2(g)	\N	gas	Cp	598.00	\N	\N	30.45848400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	18	\N	{}
901	DS002	N2(g)	\N	gas	H-H298	598.00	\N	\N	9.68630000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	18	\N	{}
902	DS002	N2(g)	\N	gas	S	598.00	\N	\N	207.44910000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	18	\N	{}
903	DS002	N2(g)	\N	gas	Cp	698.00	\N	\N	31.01129900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	18	\N	{}
904	DS002	N2(g)	\N	gas	H-H298	698.00	\N	\N	12.75990000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	18	\N	{}
905	DS002	N2(g)	\N	gas	S	698.00	\N	\N	212.20070000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	18	\N	{}
906	DS002	N2(g)	\N	gas	Cp	798.00	\N	\N	31.54288900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	18	\N	{}
907	DS002	N2(g)	\N	gas	H-H298	798.00	\N	\N	15.88780000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	18	\N	{}
908	DS002	N2(g)	\N	gas	S	798.00	\N	\N	216.38790000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	18	\N	{}
909	DS002	N2(g)	\N	gas	Cp	898.00	\N	\N	32.04933400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	18	\N	{}
910	DS002	N2(g)	\N	gas	H-H298	898.00	\N	\N	19.06760000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	18	\N	{}
911	DS002	N2(g)	\N	gas	S	898.00	\N	\N	220.14150000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	18	\N	{}
912	DS002	N2(g)	\N	gas	Cp	998.00	\N	\N	32.52902400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	CP_STD	\N	calculated	18	\N	{}
913	DS002	N2(g)	\N	gas	H-H298	998.00	\N	\N	22.29680000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	H_INCREMENT_298	\N	calculated	18	\N	{}
914	DS002	N2(g)	\N	gas	S	998.00	\N	\N	223.55040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.854628	S_STD	\N	calculated	18	\N	{}
915	DS002	N2(g)	\N	gas	Cp	1098.00	\N	\N	32.98146200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
916	DS002	N2(g)	\N	gas	H-H298	1098.00	\N	\N	25.57250000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
917	DS002	N2(g)	\N	gas	S	1098.00	\N	\N	226.67820000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
918	DS002	N2(g)	\N	gas	Cp	1198.00	\N	\N	33.40673000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
919	DS002	N2(g)	\N	gas	H-H298	1198.00	\N	\N	28.89220000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
920	DS002	N2(g)	\N	gas	S	1198.00	\N	\N	229.57140000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
921	DS002	N2(g)	\N	gas	Cp	1298.00	\N	\N	33.80523400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
922	DS002	N2(g)	\N	gas	H-H298	1298.00	\N	\N	32.25300000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
923	DS002	N2(g)	\N	gas	S	1298.00	\N	\N	232.26560000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
924	DS002	N2(g)	\N	gas	Cp	1398.00	\N	\N	34.17756800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
925	DS002	N2(g)	\N	gas	H-H298	1398.00	\N	\N	35.65230000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
926	DS002	N2(g)	\N	gas	S	1398.00	\N	\N	234.78840000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
927	DS002	N2(g)	\N	gas	Cp	1498.00	\N	\N	34.52444400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
928	DS002	N2(g)	\N	gas	H-H298	1498.00	\N	\N	39.08770000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
929	DS002	N2(g)	\N	gas	S	1498.00	\N	\N	237.16160000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
930	DS002	N2(g)	\N	gas	Cp	1598.00	\N	\N	34.84664700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
931	DS002	N2(g)	\N	gas	H-H298	1598.00	\N	\N	42.55640000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
932	DS002	N2(g)	\N	gas	S	1598.00	\N	\N	239.40310000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
933	DS002	N2(g)	\N	gas	Cp	1698.00	\N	\N	35.14501000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
934	DS002	N2(g)	\N	gas	H-H298	1698.00	\N	\N	46.05620000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
935	DS002	N2(g)	\N	gas	S	1698.00	\N	\N	241.52730000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
936	DS002	N2(g)	\N	gas	Cp	1798.00	\N	\N	35.42040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
937	DS002	N2(g)	\N	gas	H-H298	1798.00	\N	\N	49.58460000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
938	DS002	N2(g)	\N	gas	S	1798.00	\N	\N	243.54640000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
939	DS002	N2(g)	\N	gas	Cp	1898.00	\N	\N	35.67370700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
940	DS002	N2(g)	\N	gas	H-H298	1898.00	\N	\N	53.13950000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
941	DS002	N2(g)	\N	gas	S	1898.00	\N	\N	245.47040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
942	DS002	N2(g)	\N	gas	Cp	1998.00	\N	\N	35.90583700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
943	DS002	N2(g)	\N	gas	H-H298	1998.00	\N	\N	56.71870000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
944	DS002	N2(g)	\N	gas	S	1998.00	\N	\N	247.30810000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
945	DS002	N2(g)	\N	gas	Cp	2098.00	\N	\N	36.11770700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
946	DS002	N2(g)	\N	gas	H-H298	2098.00	\N	\N	60.32000000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
947	DS002	N2(g)	\N	gas	S	2098.00	\N	\N	249.06690000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
948	DS002	N2(g)	\N	gas	Cp	2198.00	\N	\N	36.31024200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
949	DS002	N2(g)	\N	gas	H-H298	2198.00	\N	\N	63.94160000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
950	DS002	N2(g)	\N	gas	S	2198.00	\N	\N	250.75320000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
951	DS002	N2(g)	\N	gas	Cp	2298.00	\N	\N	36.48437600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
952	DS002	N2(g)	\N	gas	H-H298	2298.00	\N	\N	67.58150000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
953	DS002	N2(g)	\N	gas	S	2298.00	\N	\N	252.37260000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
954	DS002	N2(g)	\N	gas	Cp	2398.00	\N	\N	36.64104400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
955	DS002	N2(g)	\N	gas	H-H298	2398.00	\N	\N	71.23790000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
956	DS002	N2(g)	\N	gas	S	2398.00	\N	\N	253.93000000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
957	DS002	N2(g)	\N	gas	Cp	2498.00	\N	\N	36.78118800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
958	DS002	N2(g)	\N	gas	H-H298	2498.00	\N	\N	74.90910000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
959	DS002	N2(g)	\N	gas	S	2498.00	\N	\N	255.42990000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
960	DS002	N2(g)	\N	gas	Cp	2598.00	\N	\N	36.90575200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
961	DS002	N2(g)	\N	gas	H-H298	2598.00	\N	\N	78.59360000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
962	DS002	N2(g)	\N	gas	S	2598.00	\N	\N	256.87610000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
963	DS002	N2(g)	\N	gas	Cp	2698.00	\N	\N	37.01568000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
964	DS002	N2(g)	\N	gas	H-H298	2698.00	\N	\N	82.28980000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
965	DS002	N2(g)	\N	gas	S	2698.00	\N	\N	258.27210000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
966	DS002	N2(g)	\N	gas	Cp	2798.00	\N	\N	37.11192100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
967	DS002	N2(g)	\N	gas	H-H298	2798.00	\N	\N	85.99630000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
968	DS002	N2(g)	\N	gas	S	2798.00	\N	\N	259.62100000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
969	DS002	N2(g)	\N	gas	Cp	2898.00	\N	\N	37.19542300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
970	DS002	N2(g)	\N	gas	H-H298	2898.00	\N	\N	89.71170000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
971	DS002	N2(g)	\N	gas	S	2898.00	\N	\N	260.92570000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
972	DS002	N2(g)	\N	gas	Cp	2998.00	\N	\N	37.26713700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
973	DS002	N2(g)	\N	gas	H-H298	2998.00	\N	\N	93.43500000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
974	DS002	N2(g)	\N	gas	S	2998.00	\N	\N	262.18880000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
975	DS002	N2(g)	\N	gas	Cp	3098.00	\N	\N	37.32801300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
976	DS002	N2(g)	\N	gas	H-H298	3098.00	\N	\N	97.16480000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
977	DS002	N2(g)	\N	gas	S	3098.00	\N	\N	263.41260000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
978	DS002	N2(g)	\N	gas	Cp	3198.00	\N	\N	37.37900300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
979	DS002	N2(g)	\N	gas	H-H298	3198.00	\N	\N	100.90020000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
980	DS002	N2(g)	\N	gas	S	3198.00	\N	\N	264.59930000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
981	DS002	N2(g)	\N	gas	Cp	3298.00	\N	\N	37.42106000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
982	DS002	N2(g)	\N	gas	H-H298	3298.00	\N	\N	104.64030000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
983	DS002	N2(g)	\N	gas	S	3298.00	\N	\N	265.75090000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
984	DS002	N2(g)	\N	gas	Cp	3398.00	\N	\N	37.45513500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
985	DS002	N2(g)	\N	gas	H-H298	3398.00	\N	\N	108.38420000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
986	DS002	N2(g)	\N	gas	S	3398.00	\N	\N	266.86920000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
987	DS002	N2(g)	\N	gas	Cp	3498.00	\N	\N	37.48218300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	18	\N	{}
988	DS002	N2(g)	\N	gas	H-H298	3498.00	\N	\N	112.13110000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	18	\N	{}
989	DS002	N2(g)	\N	gas	S	3498.00	\N	\N	267.95600000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	18	\N	{}
990	DS002	Cu(s)	\N	solid	Cp	298.00	\N	\N	23.62116600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	19	\N	{}
991	DS002	Cu(s)	\N	solid	H-H298	298.00	\N	\N	1.45250000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	19	\N	{}
992	DS002	Cu(s)	\N	solid	S	298.00	\N	\N	37.62240000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	19	\N	{}
993	DS002	Cu(s)	\N	solid	Cp	398.00	\N	\N	24.73494800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	19	\N	{}
994	DS002	Cu(s)	\N	solid	H-H298	398.00	\N	\N	3.87350000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	19	\N	{}
995	DS002	Cu(s)	\N	solid	S	398.00	\N	\N	44.62010000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	19	\N	{}
996	DS002	Cu(s)	\N	solid	Cp	498.00	\N	\N	25.60925900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	19	\N	{}
997	DS002	Cu(s)	\N	solid	H-H298	498.00	\N	\N	6.39180000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	19	\N	{}
998	DS002	Cu(s)	\N	solid	S	498.00	\N	\N	50.26130000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	19	\N	{}
999	DS002	Cu(s)	\N	solid	Cp	598.00	\N	\N	26.38974200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	19	\N	{}
1000	DS002	Cu(s)	\N	solid	H-H298	598.00	\N	\N	8.99230000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	19	\N	{}
1001	DS002	Cu(s)	\N	solid	S	598.00	\N	\N	55.01770000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	19	\N	{}
1002	DS002	Cu(s)	\N	solid	Cp	698.00	\N	\N	27.12605300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	19	\N	{}
1003	DS002	Cu(s)	\N	solid	H-H298	698.00	\N	\N	11.66830000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	19	\N	{}
1004	DS002	Cu(s)	\N	solid	S	698.00	\N	\N	59.15410000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	19	\N	{}
1005	DS002	Cu(s)	\N	solid	Cp	798.00	\N	\N	27.83886900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	19	\N	{}
1006	DS002	Cu(s)	\N	solid	H-H298	798.00	\N	\N	14.41670000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	19	\N	{}
1007	DS002	Cu(s)	\N	solid	S	798.00	\N	\N	62.83290000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	19	\N	{}
1008	DS002	Cu(s)	\N	solid	Cp	898.00	\N	\N	28.53804300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	19	\N	{}
1009	DS002	Cu(s)	\N	solid	H-H298	898.00	\N	\N	17.23570000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	19	\N	{}
1010	DS002	Cu(s)	\N	solid	S	898.00	\N	\N	66.16010000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	19	\N	{}
1011	DS002	Cu(s)	\N	solid	Cp	998.00	\N	\N	29.22875900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	19	\N	{}
1012	DS002	Cu(s)	\N	solid	H-H298	998.00	\N	\N	20.12410000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	H_INCREMENT_298	\N	calculated	19	\N	{}
1013	DS002	Cu(s)	\N	solid	S	998.00	\N	\N	69.20920000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	S_STD	\N	calculated	19	\N	{}
1014	DS002	Cu(s)	\N	solid	Cp	1098.00	\N	\N	29.91395200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.856815	CP_STD	\N	calculated	19	\N	{}
1015	DS002	Cu(s)	\N	solid	H-H298	1098.00	\N	\N	23.08120000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	19	\N	{}
1016	DS002	Cu(s)	\N	solid	S	1098.00	\N	\N	72.03250000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	19	\N	{}
1017	DS002	Cu(s)	\N	solid	Cp	1198.00	\N	\N	30.59538700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	19	\N	{}
1018	DS002	Cu(s)	\N	solid	H-H298	1198.00	\N	\N	26.10670000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	19	\N	{}
1019	DS002	Cu(s)	\N	solid	S	1198.00	\N	\N	74.66920000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	19	\N	{}
1020	DS002	Cu(s)	\N	solid	Cp	1298.00	\N	\N	31.27417600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	19	\N	{}
1021	DS002	Cu(s)	\N	solid	H-H298	1298.00	\N	\N	29.20020000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	19	\N	{}
1022	DS002	Cu(s)	\N	solid	S	1298.00	\N	\N	77.14890000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	19	\N	{}
1023	DS002	Ni(s)	\N	solid	Cp	298.00	\N	\N	27.60171700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1024	DS002	Ni(s)	\N	solid	H-H298	298.00	\N	\N	-1.88630000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1025	DS002	Ni(s)	\N	solid	S	298.00	\N	\N	49.07860000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1026	DS002	Ni(s)	\N	solid	Cp	398.00	\N	\N	28.20533600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1027	DS002	Ni(s)	\N	solid	H-H298	398.00	\N	\N	0.89500000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1028	DS002	Ni(s)	\N	solid	S	398.00	\N	\N	57.12220000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1029	DS002	Ni(s)	\N	solid	Cp	498.00	\N	\N	29.43599400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1030	DS002	Ni(s)	\N	solid	H-H298	498.00	\N	\N	3.77460000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1031	DS002	Ni(s)	\N	solid	S	498.00	\N	\N	63.57150000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1032	DS002	Ni(s)	\N	solid	Cp	598.00	\N	\N	30.82833600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1033	DS002	Ni(s)	\N	solid	H-H298	598.00	\N	\N	6.78730000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1034	DS002	Ni(s)	\N	solid	S	598.00	\N	\N	69.08070000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1035	DS002	Ni(s)	\N	solid	Cp	698.00	\N	\N	32.22684600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1036	DS002	Ni(s)	\N	solid	H-H298	698.00	\N	\N	9.94040000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1037	DS002	Ni(s)	\N	solid	S	698.00	\N	\N	73.95340000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1038	DS002	Ni(s)	\N	solid	Cp	798.00	\N	\N	33.56955700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1039	DS002	Ni(s)	\N	solid	H-H298	798.00	\N	\N	13.23080000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1040	DS002	Ni(s)	\N	solid	S	798.00	\N	\N	78.35690000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1041	DS002	Ni(s)	\N	solid	Cp	898.00	\N	\N	34.82943100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1042	DS002	Ni(s)	\N	solid	H-H298	898.00	\N	\N	16.65150000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1043	DS002	Ni(s)	\N	solid	S	898.00	\N	\N	82.39400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1044	DS002	Ni(s)	\N	solid	Cp	998.00	\N	\N	35.99451500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1045	DS002	Ni(s)	\N	solid	H-H298	998.00	\N	\N	20.19350000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1046	DS002	Ni(s)	\N	solid	S	998.00	\N	\N	86.13270000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1047	DS002	Ni(s)	\N	solid	Cp	1098.00	\N	\N	37.06010700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1048	DS002	Ni(s)	\N	solid	H-H298	1098.00	\N	\N	23.84710000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1049	DS002	Ni(s)	\N	solid	S	1098.00	\N	\N	89.62070000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1050	DS002	Ni(s)	\N	solid	Cp	1198.00	\N	\N	38.02528400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1051	DS002	Ni(s)	\N	solid	H-H298	1198.00	\N	\N	27.60220000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1052	DS002	Ni(s)	\N	solid	S	1198.00	\N	\N	92.89320000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1053	DS002	Ni(s)	\N	solid	Cp	1298.00	\N	\N	38.89123100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1054	DS002	Ni(s)	\N	solid	H-H298	1298.00	\N	\N	31.44880000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1055	DS002	Ni(s)	\N	solid	S	1298.00	\N	\N	95.97660000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1056	DS002	Ni(s)	\N	solid	Cp	1398.00	\N	\N	39.66036800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1057	DS002	Ni(s)	\N	solid	H-H298	1398.00	\N	\N	35.37720000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1058	DS002	Ni(s)	\N	solid	S	1398.00	\N	\N	98.89180000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1059	DS002	Ni(s)	\N	solid	Cp	1498.00	\N	\N	40.33587200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1060	DS002	Ni(s)	\N	solid	H-H298	1498.00	\N	\N	39.37780000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1061	DS002	Ni(s)	\N	solid	S	1498.00	\N	\N	101.65550000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1062	DS002	Ni(s)	\N	solid	Cp	1598.00	\N	\N	40.92140600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1063	DS002	Ni(s)	\N	solid	H-H298	1598.00	\N	\N	43.44140000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1064	DS002	Ni(s)	\N	solid	S	1598.00	\N	\N	104.28130000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1065	DS002	Ni(s)	\N	solid	Cp	1698.00	\N	\N	41.42094900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	20	\N	{}
1066	DS002	Ni(s)	\N	solid	H-H298	1698.00	\N	\N	47.55920000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	20	\N	{}
1067	DS002	Ni(s)	\N	solid	S	1698.00	\N	\N	106.78060000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	20	\N	{}
1068	DS002	Cr(s)	\N	solid	Cp	298.00	\N	\N	15.12199200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1069	DS002	Cr(s)	\N	solid	H-H298	298.00	\N	\N	5.77060000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1070	DS002	Cr(s)	\N	solid	S	298.00	\N	\N	44.09000000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1071	DS002	Cr(s)	\N	solid	Cp	398.00	\N	\N	20.35447200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1072	DS002	Cr(s)	\N	solid	H-H298	398.00	\N	\N	7.57230000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1073	DS002	Cr(s)	\N	solid	S	398.00	\N	\N	49.26700000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1074	DS002	Cr(s)	\N	solid	Cp	498.00	\N	\N	23.45639200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1075	DS002	Cr(s)	\N	solid	H-H298	498.00	\N	\N	9.77340000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1076	DS002	Cr(s)	\N	solid	S	498.00	\N	\N	54.18780000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1077	DS002	Cr(s)	\N	solid	Cp	598.00	\N	\N	25.65776500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1078	DS002	Cr(s)	\N	solid	H-H298	598.00	\N	\N	12.23420000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1079	DS002	Cr(s)	\N	solid	S	598.00	\N	\N	58.68490000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1080	DS002	Cr(s)	\N	solid	Cp	698.00	\N	\N	27.38102400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1081	DS002	Cr(s)	\N	solid	H-H298	698.00	\N	\N	14.88920000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1082	DS002	Cr(s)	\N	solid	S	698.00	\N	\N	62.78680000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1083	DS002	Cr(s)	\N	solid	Cp	798.00	\N	\N	28.80476200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1084	DS002	Cr(s)	\N	solid	H-H298	798.00	\N	\N	17.70060000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1085	DS002	Cr(s)	\N	solid	S	798.00	\N	\N	66.54870000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1086	DS002	Cr(s)	\N	solid	Cp	898.00	\N	\N	30.01653500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1087	DS002	Cr(s)	\N	solid	H-H298	898.00	\N	\N	20.64310000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1088	DS002	Cr(s)	\N	solid	S	898.00	\N	\N	70.02140000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1089	DS002	Cr(s)	\N	solid	Cp	998.00	\N	\N	31.06457700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1090	DS002	Cr(s)	\N	solid	H-H298	998.00	\N	\N	23.69840000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1091	DS002	Cr(s)	\N	solid	S	998.00	\N	\N	73.24630000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1092	DS002	Cr(s)	\N	solid	Cp	1098.00	\N	\N	31.97822800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1093	DS002	Cr(s)	\N	solid	H-H298	1098.00	\N	\N	26.85160000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1094	DS002	Cr(s)	\N	solid	S	1098.00	\N	\N	76.25660000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1095	DS002	Cr(s)	\N	solid	Cp	1198.00	\N	\N	32.77697000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1096	DS002	Cr(s)	\N	solid	H-H298	1198.00	\N	\N	30.09020000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1097	DS002	Cr(s)	\N	solid	S	1198.00	\N	\N	79.07900000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1098	DS002	Cr(s)	\N	solid	Cp	1298.00	\N	\N	33.47480000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1099	DS002	Cr(s)	\N	solid	H-H298	1298.00	\N	\N	33.40360000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1100	DS002	Cr(s)	\N	solid	S	1298.00	\N	\N	81.73500000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1101	DS002	Cr(s)	\N	solid	Cp	1398.00	\N	\N	34.08248800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1102	DS002	Cr(s)	\N	solid	H-H298	1398.00	\N	\N	36.78220000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1103	DS002	Cr(s)	\N	solid	S	1398.00	\N	\N	84.24230000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1104	DS002	Cr(s)	\N	solid	Cp	1498.00	\N	\N	34.60883300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1105	DS002	Cr(s)	\N	solid	H-H298	1498.00	\N	\N	40.21740000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1106	DS002	Cr(s)	\N	solid	S	1498.00	\N	\N	86.61540000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1107	DS002	Cr(s)	\N	solid	Cp	1598.00	\N	\N	35.06137100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1108	DS002	Cr(s)	\N	solid	H-H298	1598.00	\N	\N	43.70150000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1109	DS002	Cr(s)	\N	solid	S	1598.00	\N	\N	88.86670000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1110	DS002	Cr(s)	\N	solid	Cp	1698.00	\N	\N	35.44681100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1111	DS002	Cr(s)	\N	solid	H-H298	1698.00	\N	\N	47.22750000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1112	DS002	Cr(s)	\N	solid	S	1698.00	\N	\N	91.00680000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	S_STD	\N	calculated	21	\N	{}
1113	DS002	Cr(s)	\N	solid	Cp	1798.00	\N	\N	35.77130200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	CP_STD	\N	calculated	21	\N	{}
1114	DS002	Cr(s)	\N	solid	H-H298	1798.00	\N	\N	50.78880000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.85895	H_INCREMENT_298	\N	calculated	21	\N	{}
1115	DS002	Cr(s)	\N	solid	S	1798.00	\N	\N	93.04470000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	21	\N	{}
1116	DS002	Cr(s)	\N	solid	Cp	1898.00	\N	\N	36.04060700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	21	\N	{}
1117	DS002	Cr(s)	\N	solid	H-H298	1898.00	\N	\N	54.37990000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	21	\N	{}
1118	DS002	Cr(s)	\N	solid	S	1898.00	\N	\N	94.98830000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	21	\N	{}
1119	DS002	Cr(s)	\N	solid	Cp	1998.00	\N	\N	36.26021300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	21	\N	{}
1120	DS002	Cr(s)	\N	solid	H-H298	1998.00	\N	\N	57.99530000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	21	\N	{}
1121	DS002	Cr(s)	\N	solid	S	1998.00	\N	\N	96.84460000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	21	\N	{}
1122	DS002	Cr(s)	\N	solid	Cp	2098.00	\N	\N	36.43541000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	21	\N	{}
1123	DS002	Cr(s)	\N	solid	H-H298	2098.00	\N	\N	61.63040000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	21	\N	{}
1124	DS002	Cr(s)	\N	solid	S	2098.00	\N	\N	98.61990000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	21	\N	{}
1125	DS002	Si(s)	\N	solid	Cp	298.00	\N	\N	21.10869900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	22	\N	{}
1126	DS002	Si(s)	\N	solid	H-H298	298.00	\N	\N	5.46510000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	22	\N	{}
1127	DS002	Si(s)	\N	solid	S	298.00	\N	\N	19.18430000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	22	\N	{}
1128	DS002	Si(s)	\N	solid	Cp	398.00	\N	\N	22.74429700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	22	\N	{}
1129	DS002	Si(s)	\N	solid	H-H298	398.00	\N	\N	7.66700000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	22	\N	{}
1130	DS002	Si(s)	\N	solid	S	398.00	\N	\N	25.54440000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	22	\N	{}
1131	DS002	Si(s)	\N	solid	Cp	498.00	\N	\N	23.68017600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	22	\N	{}
1132	DS002	Si(s)	\N	solid	H-H298	498.00	\N	\N	9.99160000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	22	\N	{}
1133	DS002	Si(s)	\N	solid	S	498.00	\N	\N	30.75100000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	22	\N	{}
1134	DS002	Si(s)	\N	solid	Cp	598.00	\N	\N	24.33305300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	22	\N	{}
1135	DS002	Si(s)	\N	solid	H-H298	598.00	\N	\N	12.39390000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	22	\N	{}
1136	DS002	Si(s)	\N	solid	S	598.00	\N	\N	35.14510000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	22	\N	{}
1137	DS002	Si(s)	\N	solid	Cp	698.00	\N	\N	24.84523700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	22	\N	{}
1138	DS002	Si(s)	\N	solid	H-H298	698.00	\N	\N	14.85360000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	22	\N	{}
1139	DS002	Si(s)	\N	solid	S	698.00	\N	\N	38.94760000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	22	\N	{}
1140	DS002	Si(s)	\N	solid	Cp	798.00	\N	\N	25.27618100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	22	\N	{}
1141	DS002	Si(s)	\N	solid	H-H298	798.00	\N	\N	17.36020000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	22	\N	{}
1142	DS002	Si(s)	\N	solid	S	798.00	\N	\N	42.30300000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	22	\N	{}
1143	DS002	Si(s)	\N	solid	Cp	898.00	\N	\N	25.65440300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	22	\N	{}
1144	DS002	Si(s)	\N	solid	H-H298	898.00	\N	\N	19.90710000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	22	\N	{}
1145	DS002	Si(s)	\N	solid	S	898.00	\N	\N	45.30940000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	22	\N	{}
1146	DS002	Si(s)	\N	solid	Cp	998.00	\N	\N	25.99506300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	22	\N	{}
1147	DS002	Si(s)	\N	solid	H-H298	998.00	\N	\N	22.48990000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	22	\N	{}
1148	DS002	Si(s)	\N	solid	S	998.00	\N	\N	48.03610000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	22	\N	{}
1149	DS002	Si(s)	\N	solid	Cp	1098.00	\N	\N	26.30689800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	22	\N	{}
1150	DS002	Si(s)	\N	solid	H-H298	1098.00	\N	\N	25.10520000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	22	\N	{}
1151	DS002	Si(s)	\N	solid	S	1098.00	\N	\N	50.53330000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	22	\N	{}
1152	DS002	Si(s)	\N	solid	Cp	1198.00	\N	\N	26.59529600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	22	\N	{}
1153	DS002	Si(s)	\N	solid	H-H298	1198.00	\N	\N	27.75050000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	22	\N	{}
1154	DS002	Si(s)	\N	solid	S	1198.00	\N	\N	52.83880000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	22	\N	{}
1155	DS002	Si(s)	\N	solid	Cp	1298.00	\N	\N	26.86378200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	22	\N	{}
1156	DS002	Si(s)	\N	solid	H-H298	1298.00	\N	\N	30.42360000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	22	\N	{}
1157	DS002	Si(s)	\N	solid	S	1298.00	\N	\N	54.98170000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	22	\N	{}
1158	DS002	Si(s)	\N	solid	Cp	1398.00	\N	\N	27.11478400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	22	\N	{}
1159	DS002	Si(s)	\N	solid	H-H298	1398.00	\N	\N	33.12260000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	22	\N	{}
1160	DS002	Si(s)	\N	solid	S	1398.00	\N	\N	56.98480000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	22	\N	{}
1161	DS002	Si(s)	\N	solid	Cp	1498.00	\N	\N	27.35006000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	22	\N	{}
1162	DS002	Si(s)	\N	solid	H-H298	1498.00	\N	\N	35.84600000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	22	\N	{}
1163	DS002	Si(s)	\N	solid	S	1498.00	\N	\N	58.86620000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	22	\N	{}
1164	DS002	Si(s)	\N	solid	Cp	1598.00	\N	\N	27.57093900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	22	\N	{}
1165	DS002	Si(s)	\N	solid	H-H298	1598.00	\N	\N	38.59220000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	22	\N	{}
1166	DS002	Si(s)	\N	solid	S	1598.00	\N	\N	60.64080000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	22	\N	{}
1167	DS002	CH4(g)	\N	gas	Cp	298.00	\N	\N	35.64342500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	23	\N	{}
1168	DS002	CH4(g)	\N	gas	H-H298	298.00	\N	\N	-0.00410000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	23	\N	{}
1169	DS002	CH4(g)	\N	gas	S	298.00	\N	\N	186.23680000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	23	\N	{}
1170	DS002	CH4(g)	\N	gas	Cp	398.00	\N	\N	40.38873000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	23	\N	{}
1171	DS002	CH4(g)	\N	gas	H-H298	398.00	\N	\N	3.77940000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	23	\N	{}
1172	DS002	CH4(g)	\N	gas	S	398.00	\N	\N	197.15150000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	23	\N	{}
1173	DS002	CH4(g)	\N	gas	Cp	498.00	\N	\N	46.23334100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	23	\N	{}
1174	DS002	CH4(g)	\N	gas	H-H298	498.00	\N	\N	8.10760000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	23	\N	{}
1175	DS002	CH4(g)	\N	gas	S	498.00	\N	\N	206.82870000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	23	\N	{}
1176	DS002	CH4(g)	\N	gas	Cp	598.00	\N	\N	52.11178600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	23	\N	{}
1177	DS002	CH4(g)	\N	gas	H-H298	598.00	\N	\N	13.02660000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	23	\N	{}
1178	DS002	CH4(g)	\N	gas	S	598.00	\N	\N	215.81340000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	23	\N	{}
1179	DS002	CH4(g)	\N	gas	Cp	698.00	\N	\N	57.68397000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	23	\N	{}
1180	DS002	CH4(g)	\N	gas	H-H298	698.00	\N	\N	18.51960000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	23	\N	{}
1181	DS002	CH4(g)	\N	gas	S	698.00	\N	\N	224.29610000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	23	\N	{}
1182	DS002	CH4(g)	\N	gas	Cp	798.00	\N	\N	62.82882000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	23	\N	{}
1183	DS002	CH4(g)	\N	gas	H-H298	798.00	\N	\N	24.54900000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	23	\N	{}
1184	DS002	CH4(g)	\N	gas	S	798.00	\N	\N	232.36120000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	23	\N	{}
1185	DS002	CH4(g)	\N	gas	Cp	898.00	\N	\N	67.50703500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	23	\N	{}
1186	DS002	CH4(g)	\N	gas	H-H298	898.00	\N	\N	31.06980000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	23	\N	{}
1187	DS002	CH4(g)	\N	gas	S	898.00	\N	\N	240.05420000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	23	\N	{}
1188	DS002	CH4(g)	\N	gas	Cp	998.00	\N	\N	71.71463200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	23	\N	{}
1189	DS002	CH4(g)	\N	gas	H-H298	998.00	\N	\N	38.03470000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	23	\N	{}
1190	DS002	CH4(g)	\N	gas	S	998.00	\N	\N	247.40410000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	23	\N	{}
1191	DS002	CH4(g)	\N	gas	Cp	1098.00	\N	\N	75.46459800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	23	\N	{}
1192	DS002	CH4(g)	\N	gas	H-H298	1098.00	\N	\N	45.39740000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	23	\N	{}
1193	DS002	CH4(g)	\N	gas	S	1098.00	\N	\N	254.43210000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	23	\N	{}
1194	DS002	CH4(g)	\N	gas	Cp	1198.00	\N	\N	78.77877700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	23	\N	{}
1195	DS002	CH4(g)	\N	gas	H-H298	1198.00	\N	\N	53.11310000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	23	\N	{}
1196	DS002	CH4(g)	\N	gas	S	1198.00	\N	\N	261.15520000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	23	\N	{}
1197	DS002	CH4(g)	\N	gas	Cp	1298.00	\N	\N	81.68393900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	23	\N	{}
1198	DS002	CH4(g)	\N	gas	H-H298	1298.00	\N	\N	61.13950000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	23	\N	{}
1199	DS002	CH4(g)	\N	gas	S	1298.00	\N	\N	267.58860000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	23	\N	{}
1200	DS002	SO2(g)	\N	gas	Cp	298.00	\N	\N	39.86792400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	24	\N	{}
1201	DS002	SO2(g)	\N	gas	H-H298	298.00	\N	\N	-0.00720000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	24	\N	{}
1202	DS002	SO2(g)	\N	gas	S	298.00	\N	\N	248.19030000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	24	\N	{}
1203	DS002	SO2(g)	\N	gas	Cp	398.00	\N	\N	43.45263900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	24	\N	{}
1204	DS002	SO2(g)	\N	gas	H-H298	398.00	\N	\N	4.16250000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	24	\N	{}
1205	DS002	SO2(g)	\N	gas	S	398.00	\N	\N	260.23070000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	24	\N	{}
1206	DS002	SO2(g)	\N	gas	Cp	498.00	\N	\N	46.50418800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	24	\N	{}
1207	DS002	SO2(g)	\N	gas	H-H298	498.00	\N	\N	8.66520000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	24	\N	{}
1208	DS002	SO2(g)	\N	gas	S	498.00	\N	\N	270.31070000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	24	\N	{}
1209	DS002	SO2(g)	\N	gas	Cp	598.00	\N	\N	48.98002200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	24	\N	{}
1210	DS002	SO2(g)	\N	gas	H-H298	598.00	\N	\N	13.44410000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	24	\N	{}
1211	DS002	SO2(g)	\N	gas	S	598.00	\N	\N	279.04860000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	24	\N	{}
1212	DS002	SO2(g)	\N	gas	Cp	698.00	\N	\N	50.93031000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	CP_STD	\N	calculated	24	\N	{}
1213	DS002	SO2(g)	\N	gas	H-H298	698.00	\N	\N	18.44370000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	H_INCREMENT_298	\N	calculated	24	\N	{}
1214	DS002	SO2(g)	\N	gas	S	698.00	\N	\N	286.77550000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.861059	S_STD	\N	calculated	24	\N	{}
1215	DS002	SO2(g)	\N	gas	Cp	798.00	\N	\N	52.43321100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	24	\N	{}
1216	DS002	SO2(g)	\N	gas	H-H298	798.00	\N	\N	23.61520000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	24	\N	{}
1217	DS002	SO2(g)	\N	gas	S	798.00	\N	\N	293.69750000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	24	\N	{}
1218	DS002	SO2(g)	\N	gas	Cp	898.00	\N	\N	53.57733800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	24	\N	{}
1219	DS002	SO2(g)	\N	gas	H-H298	898.00	\N	\N	28.91830000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	24	\N	{}
1220	DS002	SO2(g)	\N	gas	S	898.00	\N	\N	299.95710000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	24	\N	{}
1221	DS002	SO2(g)	\N	gas	Cp	998.00	\N	\N	54.45581900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	24	\N	{}
1222	DS002	SO2(g)	\N	gas	H-H298	998.00	\N	\N	34.32180000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	24	\N	{}
1223	DS002	SO2(g)	\N	gas	S	998.00	\N	\N	305.66140000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	24	\N	{}
1224	DS002	SO2(g)	\N	gas	Cp	1098.00	\N	\N	55.16394800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	24	\N	{}
1225	DS002	SO2(g)	\N	gas	H-H298	1098.00	\N	\N	39.80380000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	24	\N	{}
1226	DS002	SO2(g)	\N	gas	S	1098.00	\N	\N	310.89580000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	24	\N	{}
1227	DS002	SO2(g)	\N	gas	Cp	1198.00	\N	\N	55.79815500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	24	\N	{}
1228	DS002	SO2(g)	\N	gas	H-H298	1198.00	\N	\N	45.35210000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	24	\N	{}
1229	DS002	SO2(g)	\N	gas	S	1198.00	\N	\N	315.73150000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	24	\N	{}
1230	DS002	H2S(g)	\N	gas	Cp	298.00	\N	\N	34.19588300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	25	\N	{}
1231	DS002	H2S(g)	\N	gas	H-H298	298.00	\N	\N	-0.00160000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	25	\N	{}
1232	DS002	H2S(g)	\N	gas	S	298.00	\N	\N	205.75080000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	25	\N	{}
1233	DS002	H2S(g)	\N	gas	Cp	398.00	\N	\N	35.50680100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	25	\N	{}
1234	DS002	H2S(g)	\N	gas	H-H298	398.00	\N	\N	3.47870000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	25	\N	{}
1235	DS002	H2S(g)	\N	gas	S	398.00	\N	\N	215.81220000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	25	\N	{}
1236	DS002	H2S(g)	\N	gas	Cp	498.00	\N	\N	37.16811700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	25	\N	{}
1237	DS002	H2S(g)	\N	gas	H-H298	498.00	\N	\N	7.11090000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	25	\N	{}
1238	DS002	H2S(g)	\N	gas	S	498.00	\N	\N	223.94680000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	25	\N	{}
1239	DS002	H2S(g)	\N	gas	Cp	598.00	\N	\N	38.93915600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	25	\N	{}
1240	DS002	H2S(g)	\N	gas	H-H298	598.00	\N	\N	10.91580000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	25	\N	{}
1241	DS002	H2S(g)	\N	gas	S	598.00	\N	\N	230.90450000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	25	\N	{}
1242	DS002	H2S(g)	\N	gas	Cp	698.00	\N	\N	40.72449600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	25	\N	{}
1243	DS002	H2S(g)	\N	gas	H-H298	698.00	\N	\N	14.89920000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	25	\N	{}
1244	DS002	H2S(g)	\N	gas	S	698.00	\N	\N	237.06030000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	25	\N	{}
1245	DS002	H2S(g)	\N	gas	Cp	798.00	\N	\N	42.47257800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	25	\N	{}
1246	DS002	H2S(g)	\N	gas	H-H298	798.00	\N	\N	19.05950000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	25	\N	{}
1247	DS002	H2S(g)	\N	gas	S	798.00	\N	\N	242.62800000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	25	\N	{}
1248	DS002	H2S(g)	\N	gas	Cp	898.00	\N	\N	44.14821400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	25	\N	{}
1249	DS002	H2S(g)	\N	gas	H-H298	898.00	\N	\N	23.39130000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	25	\N	{}
1250	DS002	H2S(g)	\N	gas	S	898.00	\N	\N	247.74020000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	25	\N	{}
1251	DS002	H2S(g)	\N	gas	Cp	998.00	\N	\N	45.72329100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	25	\N	{}
1252	DS002	H2S(g)	\N	gas	H-H298	998.00	\N	\N	27.88580000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	25	\N	{}
1253	DS002	H2S(g)	\N	gas	S	998.00	\N	\N	252.48410000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	25	\N	{}
1254	DS002	H2S(g)	\N	gas	Cp	1098.00	\N	\N	47.17309300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	25	\N	{}
1255	DS002	H2S(g)	\N	gas	H-H298	1098.00	\N	\N	32.53170000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	25	\N	{}
1256	DS002	H2S(g)	\N	gas	S	1098.00	\N	\N	256.91960000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	25	\N	{}
1257	DS002	H2S(g)	\N	gas	Cp	1198.00	\N	\N	48.47467800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	25	\N	{}
1258	DS002	H2S(g)	\N	gas	H-H298	1198.00	\N	\N	37.31550000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	25	\N	{}
1259	DS002	H2S(g)	\N	gas	S	1198.00	\N	\N	261.08840000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	25	\N	{}
1260	DS002	H2S(g)	\N	gas	Cp	1298.00	\N	\N	49.60609000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	25	\N	{}
1261	DS002	H2S(g)	\N	gas	H-H298	1298.00	\N	\N	42.22100000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	25	\N	{}
1262	DS002	H2S(g)	\N	gas	S	1298.00	\N	\N	265.02060000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	25	\N	{}
1263	DS002	H2S(g)	\N	gas	Cp	1398.00	\N	\N	50.54595400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	25	\N	{}
1264	DS002	H2S(g)	\N	gas	H-H298	1398.00	\N	\N	47.23030000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	25	\N	{}
1265	DS002	H2S(g)	\N	gas	S	1398.00	\N	\N	268.73800000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	25	\N	{}
1266	DS002	Cl2(g)	\N	gas	Cp	298.00	\N	\N	33.94356100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	26	\N	{}
1267	DS002	Cl2(g)	\N	gas	H-H298	298.00	\N	\N	-0.00530000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	26	\N	{}
1268	DS002	Cl2(g)	\N	gas	S	298.00	\N	\N	223.06120000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	26	\N	{}
1269	DS002	Cl2(g)	\N	gas	Cp	398.00	\N	\N	35.27633200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	26	\N	{}
1270	DS002	Cl2(g)	\N	gas	H-H298	398.00	\N	\N	3.46260000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	26	\N	{}
1271	DS002	Cl2(g)	\N	gas	S	398.00	\N	\N	233.08670000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	26	\N	{}
1272	DS002	Cl2(g)	\N	gas	Cp	498.00	\N	\N	36.04715200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	26	\N	{}
1273	DS002	Cl2(g)	\N	gas	H-H298	498.00	\N	\N	7.03190000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	26	\N	{}
1274	DS002	Cl2(g)	\N	gas	S	498.00	\N	\N	241.08380000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	26	\N	{}
1275	DS002	Cl2(g)	\N	gas	Cp	598.00	\N	\N	36.54103600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	26	\N	{}
1276	DS002	Cl2(g)	\N	gas	H-H298	598.00	\N	\N	10.66300000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	26	\N	{}
1277	DS002	Cl2(g)	\N	gas	S	598.00	\N	\N	247.72710000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	26	\N	{}
1278	DS002	Cl2(g)	\N	gas	Cp	698.00	\N	\N	36.87250200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	26	\N	{}
1279	DS002	Cl2(g)	\N	gas	H-H298	698.00	\N	\N	14.33470000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	26	\N	{}
1280	DS002	Cl2(g)	\N	gas	S	698.00	\N	\N	253.40390000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	26	\N	{}
1281	DS002	Cl2(g)	\N	gas	Cp	798.00	\N	\N	37.10458900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	26	\N	{}
1282	DS002	Cl2(g)	\N	gas	H-H298	798.00	\N	\N	18.03420000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	26	\N	{}
1283	DS002	Cl2(g)	\N	gas	S	798.00	\N	\N	258.35680000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	26	\N	{}
1284	DS002	Cl2(g)	\N	gas	Cp	898.00	\N	\N	37.28111200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	26	\N	{}
1285	DS002	Cl2(g)	\N	gas	H-H298	898.00	\N	\N	21.75380000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	26	\N	{}
1286	DS002	Cl2(g)	\N	gas	S	898.00	\N	\N	262.74800000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	26	\N	{}
1287	DS002	Cl2(g)	\N	gas	Cp	998.00	\N	\N	37.43759000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	26	\N	{}
1288	DS002	Cl2(g)	\N	gas	H-H298	998.00	\N	\N	25.48970000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	26	\N	{}
1289	DS002	Cl2(g)	\N	gas	S	998.00	\N	\N	266.69240000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	26	\N	{}
1290	DS002	CuO(s)	\N	solid	Cp	298.00	\N	\N	35.68959600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	27	\N	{}
1291	DS002	CuO(s)	\N	solid	H-H298	298.00	\N	\N	-0.00530000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	27	\N	{}
1292	DS002	CuO(s)	\N	solid	S	298.00	\N	\N	234.59890000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	27	\N	{}
1293	DS002	CuO(s)	\N	solid	Cp	398.00	\N	\N	36.39063900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	27	\N	{}
1294	DS002	CuO(s)	\N	solid	H-H298	398.00	\N	\N	3.60220000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	27	\N	{}
1295	DS002	CuO(s)	\N	solid	S	398.00	\N	\N	245.03250000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	27	\N	{}
1296	DS002	CuO(s)	\N	solid	Cp	498.00	\N	\N	36.81525100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	27	\N	{}
1297	DS002	CuO(s)	\N	solid	H-H298	498.00	\N	\N	7.26390000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	27	\N	{}
1298	DS002	CuO(s)	\N	solid	S	498.00	\N	\N	253.23850000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	27	\N	{}
1299	DS002	CuO(s)	\N	solid	Cp	598.00	\N	\N	37.10662800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	27	\N	{}
1300	DS002	CuO(s)	\N	solid	H-H298	598.00	\N	\N	10.96090000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	27	\N	{}
1301	DS002	CuO(s)	\N	solid	S	598.00	\N	\N	260.00270000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	27	\N	{}
1302	DS002	CuO(s)	\N	solid	Cp	698.00	\N	\N	37.31895300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	27	\N	{}
1303	DS002	CuO(s)	\N	solid	H-H298	698.00	\N	\N	14.68270000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	27	\N	{}
1304	DS002	CuO(s)	\N	solid	S	698.00	\N	\N	265.75730000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	27	\N	{}
1305	DS002	CuO(s)	\N	solid	Cp	798.00	\N	\N	37.47953100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	27	\N	{}
1306	DS002	CuO(s)	\N	solid	H-H298	798.00	\N	\N	18.42290000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	27	\N	{}
1307	DS002	CuO(s)	\N	solid	S	798.00	\N	\N	270.76490000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	27	\N	{}
1308	DS002	CuO(s)	\N	solid	Cp	898.00	\N	\N	37.60563400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	27	\N	{}
1309	DS002	CuO(s)	\N	solid	H-H298	898.00	\N	\N	22.17740000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	27	\N	{}
1310	DS002	CuO(s)	\N	solid	S	898.00	\N	\N	275.19730000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	27	\N	{}
1311	DS002	CuO(s)	\N	solid	Cp	998.00	\N	\N	37.71019900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	27	\N	{}
1312	DS002	CuO(s)	\N	solid	H-H298	998.00	\N	\N	25.94330000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	H_INCREMENT_298	\N	calculated	27	\N	{}
1313	DS002	CuO(s)	\N	solid	S	998.00	\N	\N	279.17340000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	S_STD	\N	calculated	27	\N	{}
1314	DS002	CuO(s)	\N	solid	Cp	1098.00	\N	\N	37.80407900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.863297	CP_STD	\N	calculated	27	\N	{}
1315	DS002	CuO(s)	\N	solid	H-H298	1098.00	\N	\N	29.71910000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	27	\N	{}
1316	DS002	CuO(s)	\N	solid	S	1098.00	\N	\N	282.77890000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	27	\N	{}
1317	DS002	CuO(s)	\N	solid	Cp	1198.00	\N	\N	37.89704500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	27	\N	{}
1318	DS002	CuO(s)	\N	solid	H-H298	1198.00	\N	\N	33.50410000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	27	\N	{}
1319	DS002	CuO(s)	\N	solid	S	1198.00	\N	\N	286.07800000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	27	\N	{}
1320	DS002	Cu2O(s)	\N	solid	Cp	298.00	\N	\N	113.83486000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	28	\N	{}
1321	DS002	Cu2O(s)	\N	solid	H-H298	298.00	\N	\N	-20.41200000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	28	\N	{}
1322	DS002	Cu2O(s)	\N	solid	S	298.00	\N	\N	91.22970000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	28	\N	{}
1323	DS002	Cu2O(s)	\N	solid	Cp	398.00	\N	\N	106.66303400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	28	\N	{}
1324	DS002	Cu2O(s)	\N	solid	H-H298	398.00	\N	\N	-9.44090000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	28	\N	{}
1325	DS002	Cu2O(s)	\N	solid	S	398.00	\N	\N	123.02490000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	28	\N	{}
1326	DS002	Cu2O(s)	\N	solid	Cp	498.00	\N	\N	103.51914000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	28	\N	{}
1327	DS002	Cu2O(s)	\N	solid	H-H298	498.00	\N	\N	1.04910000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	28	\N	{}
1328	DS002	Cu2O(s)	\N	solid	S	498.00	\N	\N	146.55110000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	28	\N	{}
1329	DS002	Cu2O(s)	\N	solid	Cp	598.00	\N	\N	101.93518500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	28	\N	{}
1330	DS002	Cu2O(s)	\N	solid	H-H298	598.00	\N	\N	11.31350000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	28	\N	{}
15	DS002	Fe(s)	\N	solid	Cp	298.00	\N	\N	24.48068900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
16	DS002	Fe(s)	\N	solid	H-H298	298.00	\N	\N	5.97410000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
17	DS002	Fe(s)	\N	solid	S	298.00	\N	\N	27.09780000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
18	DS002	Fe(s)	\N	solid	Cp	398.00	\N	\N	26.38223000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
19	DS002	Fe(s)	\N	solid	H-H298	398.00	\N	\N	8.51760000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
20	DS002	Fe(s)	\N	solid	S	398.00	\N	\N	34.44460000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
21	DS002	Fe(s)	\N	solid	Cp	498.00	\N	\N	28.20044300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
22	DS002	Fe(s)	\N	solid	H-H298	498.00	\N	\N	11.24770000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
23	DS002	Fe(s)	\N	solid	S	498.00	\N	\N	40.55620000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
24	DS002	Fe(s)	\N	solid	Cp	598.00	\N	\N	29.90434800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
25	DS002	Fe(s)	\N	solid	H-H298	598.00	\N	\N	14.15390000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
26	DS002	Fe(s)	\N	solid	S	598.00	\N	\N	45.86970000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
27	DS002	Fe(s)	\N	solid	Cp	698.00	\N	\N	31.48393000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
28	DS002	Fe(s)	\N	solid	H-H298	698.00	\N	\N	17.22440000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	H_INCREMENT_298	\N	calculated	1	\N	{}
29	DS002	Fe(s)	\N	solid	S	698.00	\N	\N	50.61430000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	S_STD	\N	calculated	1	\N	{}
30	DS002	Fe(s)	\N	solid	Cp	798.00	\N	\N	32.93549900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.832542	CP_STD	\N	calculated	1	\N	{}
1335	DS002	Cu2O(s)	\N	solid	Cp	798.00	\N	\N	100.57718300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	28	\N	{}
1336	DS002	Cu2O(s)	\N	solid	H-H298	798.00	\N	\N	31.53980000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	28	\N	{}
1337	DS002	Cu2O(s)	\N	solid	S	798.00	\N	\N	194.52600000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	28	\N	{}
1338	DS002	Cu2O(s)	\N	solid	Cp	898.00	\N	\N	100.28883400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	28	\N	{}
1339	DS002	Cu2O(s)	\N	solid	H-H298	898.00	\N	\N	41.58190000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	28	\N	{}
1340	DS002	Cu2O(s)	\N	solid	S	898.00	\N	\N	206.38210000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	28	\N	{}
1341	DS002	Cu2O(s)	\N	solid	Cp	998.00	\N	\N	100.11962500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	28	\N	{}
1342	DS002	Cu2O(s)	\N	solid	H-H298	998.00	\N	\N	51.60150000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	28	\N	{}
1343	DS002	Cu2O(s)	\N	solid	S	998.00	\N	\N	216.96140000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	28	\N	{}
1344	DS002	Cu2O(s)	\N	solid	Cp	1098.00	\N	\N	100.02147700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	28	\N	{}
1345	DS002	Cu2O(s)	\N	solid	H-H298	1098.00	\N	\N	61.60810000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	28	\N	{}
1346	DS002	Cu2O(s)	\N	solid	S	1098.00	\N	\N	226.51700000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	28	\N	{}
1347	DS002	Cu2O(s)	\N	solid	Cp	1198.00	\N	\N	99.96618000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	28	\N	{}
1348	DS002	Cu2O(s)	\N	solid	H-H298	1198.00	\N	\N	71.60720000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	28	\N	{}
1349	DS002	Cu2O(s)	\N	solid	S	1198.00	\N	\N	235.23250000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	28	\N	{}
1350	DS002	Cu2O(s)	\N	solid	Cp	1298.00	\N	\N	99.93658300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	28	\N	{}
1351	DS002	Cu2O(s)	\N	solid	H-H298	1298.00	\N	\N	81.60220000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	28	\N	{}
1352	DS002	Cu2O(s)	\N	solid	S	1298.00	\N	\N	243.24560000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	28	\N	{}
1353	DS002	Cu2O(s)	\N	solid	Cp	1398.00	\N	\N	99.92203000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	28	\N	{}
1354	DS002	Cu2O(s)	\N	solid	H-H298	1398.00	\N	\N	91.59500000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	28	\N	{}
1355	DS002	Cu2O(s)	\N	solid	S	1398.00	\N	\N	250.66210000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	28	\N	{}
1356	DS002	Cu2O(s)	\N	solid	Cp	1498.00	\N	\N	99.91584600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	28	\N	{}
1357	DS002	Cu2O(s)	\N	solid	H-H298	1498.00	\N	\N	101.58690000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	28	\N	{}
1358	DS002	Cu2O(s)	\N	solid	S	1498.00	\N	\N	257.56530000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	28	\N	{}
1359	DS002	TiO2(s)	\N	solid	Cp	298.00	\N	\N	55.18274000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1360	DS002	TiO2(s)	\N	solid	H-H298	298.00	\N	\N	-0.01890000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1361	DS002	TiO2(s)	\N	solid	S	298.00	\N	\N	49.83420000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1362	DS002	TiO2(s)	\N	solid	Cp	398.00	\N	\N	63.68717700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1363	DS002	TiO2(s)	\N	solid	H-H298	398.00	\N	\N	5.97890000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1364	DS002	TiO2(s)	\N	solid	S	398.00	\N	\N	67.13050000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1365	DS002	TiO2(s)	\N	solid	Cp	498.00	\N	\N	68.05677300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1366	DS002	TiO2(s)	\N	solid	H-H298	498.00	\N	\N	12.58640000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1367	DS002	TiO2(s)	\N	solid	S	498.00	\N	\N	81.92280000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1368	DS002	TiO2(s)	\N	solid	Cp	598.00	\N	\N	70.71570100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1369	DS002	TiO2(s)	\N	solid	H-H298	598.00	\N	\N	19.53470000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1370	DS002	TiO2(s)	\N	solid	S	598.00	\N	\N	94.63010000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1371	DS002	TiO2(s)	\N	solid	Cp	698.00	\N	\N	72.50017300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1372	DS002	TiO2(s)	\N	solid	H-H298	698.00	\N	\N	26.70090000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1373	DS002	TiO2(s)	\N	solid	S	698.00	\N	\N	105.70750000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1374	DS002	TiO2(s)	\N	solid	Cp	798.00	\N	\N	73.76694300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1375	DS002	TiO2(s)	\N	solid	H-H298	798.00	\N	\N	34.01760000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1376	DS002	TiO2(s)	\N	solid	S	798.00	\N	\N	115.50200000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1377	DS002	TiO2(s)	\N	solid	Cp	898.00	\N	\N	74.69374800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1378	DS002	TiO2(s)	\N	solid	H-H298	898.00	\N	\N	41.44300000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1379	DS002	TiO2(s)	\N	solid	S	898.00	\N	\N	124.26740000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1380	DS002	TiO2(s)	\N	solid	Cp	998.00	\N	\N	75.38101300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1381	DS002	TiO2(s)	\N	solid	H-H298	998.00	\N	\N	48.94840000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1382	DS002	TiO2(s)	\N	solid	S	998.00	\N	\N	132.19120000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1383	DS002	TiO2(s)	\N	solid	Cp	1098.00	\N	\N	75.89200800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1384	DS002	TiO2(s)	\N	solid	H-H298	1098.00	\N	\N	56.51330000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1385	DS002	TiO2(s)	\N	solid	S	1098.00	\N	\N	139.41480000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1386	DS002	TiO2(s)	\N	solid	Cp	1198.00	\N	\N	76.27062200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1387	DS002	TiO2(s)	\N	solid	H-H298	1198.00	\N	\N	64.12240000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1388	DS002	TiO2(s)	\N	solid	S	1198.00	\N	\N	146.04680000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1389	DS002	TiO2(s)	\N	solid	Cp	1298.00	\N	\N	76.54995300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1390	DS002	TiO2(s)	\N	solid	H-H298	1298.00	\N	\N	71.76420000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1391	DS002	TiO2(s)	\N	solid	S	1298.00	\N	\N	152.17320000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1392	DS002	TiO2(s)	\N	solid	Cp	1398.00	\N	\N	76.75676400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1393	DS002	TiO2(s)	\N	solid	H-H298	1398.00	\N	\N	79.43000000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1394	DS002	TiO2(s)	\N	solid	S	1398.00	\N	\N	157.86250000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1395	DS002	TiO2(s)	\N	solid	Cp	1498.00	\N	\N	76.91392900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1396	DS002	TiO2(s)	\N	solid	H-H298	1498.00	\N	\N	87.11390000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1397	DS002	TiO2(s)	\N	solid	S	1498.00	\N	\N	163.17110000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1398	DS002	TiO2(s)	\N	solid	Cp	1598.00	\N	\N	77.04184900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1399	DS002	TiO2(s)	\N	solid	H-H298	1598.00	\N	\N	94.81180000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1400	DS002	TiO2(s)	\N	solid	S	1598.00	\N	\N	168.14560000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1401	DS002	TiO2(s)	\N	solid	Cp	1698.00	\N	\N	77.15929400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1402	DS002	TiO2(s)	\N	solid	H-H298	1698.00	\N	\N	102.52190000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1403	DS002	TiO2(s)	\N	solid	S	1698.00	\N	\N	172.82540000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1404	DS002	TiO2(s)	\N	solid	Cp	1798.00	\N	\N	77.28393800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1405	DS002	TiO2(s)	\N	solid	H-H298	1798.00	\N	\N	110.24390000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1406	DS002	TiO2(s)	\N	solid	S	1798.00	\N	\N	177.24420000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1407	DS002	TiO2(s)	\N	solid	Cp	1898.00	\N	\N	77.43268700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1408	DS002	TiO2(s)	\N	solid	H-H298	1898.00	\N	\N	117.97950000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1409	DS002	TiO2(s)	\N	solid	S	1898.00	\N	\N	181.43110000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1410	DS002	TiO2(s)	\N	solid	Cp	1998.00	\N	\N	77.62191300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	29	\N	{}
1411	DS002	TiO2(s)	\N	solid	H-H298	1998.00	\N	\N	125.73180000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	29	\N	{}
1412	DS002	TiO2(s)	\N	solid	S	1998.00	\N	\N	185.41160000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	29	\N	{}
1413	DS002	Cr2O3(s)	\N	solid	Cp	298.00	\N	\N	156.90420300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	30	\N	{}
1414	DS002	Cr2O3(s)	\N	solid	H-H298	298.00	\N	\N	-46.44500000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	30	\N	{}
1415	DS002	Cr2O3(s)	\N	solid	S	298.00	\N	\N	62.76210000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1416	DS002	Cr2O3(s)	\N	solid	Cp	398.00	\N	\N	156.90239100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1417	DS002	Cr2O3(s)	\N	solid	H-H298	398.00	\N	\N	-30.75470000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1418	DS002	Cr2O3(s)	\N	solid	S	398.00	\N	\N	108.16340000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1419	DS002	Cr2O3(s)	\N	solid	Cp	498.00	\N	\N	156.90156400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1420	DS002	Cr2O3(s)	\N	solid	H-H298	498.00	\N	\N	-15.06450000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1421	DS002	Cr2O3(s)	\N	solid	S	498.00	\N	\N	143.33270000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1422	DS002	Cr2O3(s)	\N	solid	Cp	598.00	\N	\N	156.90112100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1423	DS002	Cr2O3(s)	\N	solid	H-H298	598.00	\N	\N	0.62560000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1424	DS002	Cr2O3(s)	\N	solid	S	598.00	\N	\N	172.04420000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1425	DS002	Cr2O3(s)	\N	solid	Cp	698.00	\N	\N	156.90085900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1426	DS002	Cr2O3(s)	\N	solid	H-H298	698.00	\N	\N	16.31570000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1427	DS002	Cr2O3(s)	\N	solid	S	698.00	\N	\N	196.30550000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1428	DS002	Cr2O3(s)	\N	solid	Cp	798.00	\N	\N	156.90069400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1429	DS002	Cr2O3(s)	\N	solid	H-H298	798.00	\N	\N	32.00580000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1430	DS002	Cr2O3(s)	\N	solid	S	798.00	\N	\N	217.31290000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1431	DS002	Cr2O3(s)	\N	solid	Cp	898.00	\N	\N	156.90058300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1432	DS002	Cr2O3(s)	\N	solid	H-H298	898.00	\N	\N	47.69580000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1433	DS002	Cr2O3(s)	\N	solid	S	898.00	\N	\N	235.83680000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1434	DS002	Cr2O3(s)	\N	solid	Cp	998.00	\N	\N	156.90050700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1435	DS002	Cr2O3(s)	\N	solid	H-H298	998.00	\N	\N	63.38590000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1436	DS002	Cr2O3(s)	\N	solid	S	998.00	\N	\N	252.40290000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1437	DS002	Cr2O3(s)	\N	solid	Cp	1098.00	\N	\N	156.90045300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1438	DS002	Cr2O3(s)	\N	solid	H-H298	1098.00	\N	\N	79.07600000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1439	DS002	Cr2O3(s)	\N	solid	S	1098.00	\N	\N	267.38560000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1440	DS002	Cr2O3(s)	\N	solid	Cp	1198.00	\N	\N	156.90041400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1441	DS002	Cr2O3(s)	\N	solid	H-H298	1198.00	\N	\N	94.76600000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1442	DS002	Cr2O3(s)	\N	solid	S	1198.00	\N	\N	281.06160000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1443	DS002	Cr2O3(s)	\N	solid	Cp	1298.00	\N	\N	156.90038600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1444	DS002	Cr2O3(s)	\N	solid	H-H298	1298.00	\N	\N	110.45600000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1445	DS002	Cr2O3(s)	\N	solid	S	1298.00	\N	\N	293.64050000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1446	DS002	Cr2O3(s)	\N	solid	Cp	1398.00	\N	\N	156.90036500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1447	DS002	Cr2O3(s)	\N	solid	H-H298	1398.00	\N	\N	126.14610000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1448	DS002	Cr2O3(s)	\N	solid	S	1398.00	\N	\N	305.28530000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1449	DS002	Cr2O3(s)	\N	solid	Cp	1498.00	\N	\N	156.90034900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1450	DS002	Cr2O3(s)	\N	solid	H-H298	1498.00	\N	\N	141.83610000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1451	DS002	Cr2O3(s)	\N	solid	S	1498.00	\N	\N	316.12530000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1452	DS002	Cr2O3(s)	\N	solid	Cp	1598.00	\N	\N	156.90033700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1453	DS002	Cr2O3(s)	\N	solid	H-H298	1598.00	\N	\N	157.52610000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1454	DS002	Cr2O3(s)	\N	solid	S	1598.00	\N	\N	326.26450000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1455	DS002	Cr2O3(s)	\N	solid	Cp	1698.00	\N	\N	156.90032900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1456	DS002	Cr2O3(s)	\N	solid	H-H298	1698.00	\N	\N	173.21620000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1457	DS002	Cr2O3(s)	\N	solid	S	1698.00	\N	\N	335.78810000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1458	DS002	Cr2O3(s)	\N	solid	Cp	1798.00	\N	\N	156.90032200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1459	DS002	Cr2O3(s)	\N	solid	H-H298	1798.00	\N	\N	188.90620000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1460	DS002	Cr2O3(s)	\N	solid	S	1798.00	\N	\N	344.76650000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1461	DS002	Cr2O3(s)	\N	solid	Cp	1898.00	\N	\N	156.90031800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1462	DS002	Cr2O3(s)	\N	solid	H-H298	1898.00	\N	\N	204.59620000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1463	DS002	Cr2O3(s)	\N	solid	S	1898.00	\N	\N	353.25880000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1464	DS002	Cr2O3(s)	\N	solid	Cp	1998.00	\N	\N	156.90031400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1465	DS002	Cr2O3(s)	\N	solid	H-H298	1998.00	\N	\N	220.28630000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1466	DS002	Cr2O3(s)	\N	solid	S	1998.00	\N	\N	361.31500000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1467	DS002	Cr2O3(s)	\N	solid	Cp	2098.00	\N	\N	156.90031200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1468	DS002	Cr2O3(s)	\N	solid	H-H298	2098.00	\N	\N	235.97630000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1469	DS002	Cr2O3(s)	\N	solid	S	2098.00	\N	\N	368.97770000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1470	DS002	Cr2O3(s)	\N	solid	Cp	2198.00	\N	\N	156.90031100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1471	DS002	Cr2O3(s)	\N	solid	H-H298	2198.00	\N	\N	251.66630000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1472	DS002	Cr2O3(s)	\N	solid	S	2198.00	\N	\N	376.28350000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1473	DS002	Cr2O3(s)	\N	solid	Cp	2298.00	\N	\N	156.90031000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1474	DS002	Cr2O3(s)	\N	solid	H-H298	2298.00	\N	\N	267.35640000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1475	DS002	Cr2O3(s)	\N	solid	S	2298.00	\N	\N	383.26420000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1476	DS002	Cr2O3(s)	\N	solid	Cp	2398.00	\N	\N	156.90031000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1477	DS002	Cr2O3(s)	\N	solid	H-H298	2398.00	\N	\N	283.04640000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1478	DS002	Cr2O3(s)	\N	solid	S	2398.00	\N	\N	389.94750000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1479	DS002	Cr2O3(s)	\N	solid	Cp	2498.00	\N	\N	156.90031000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1480	DS002	Cr2O3(s)	\N	solid	H-H298	2498.00	\N	\N	298.73640000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1481	DS002	Cr2O3(s)	\N	solid	S	2498.00	\N	\N	396.35770000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1482	DS002	Cr2O3(s)	\N	solid	Cp	2598.00	\N	\N	156.90031000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	30	\N	{}
1483	DS002	Cr2O3(s)	\N	solid	H-H298	2598.00	\N	\N	314.42650000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	30	\N	{}
1484	DS002	Cr2O3(s)	\N	solid	S	2598.00	\N	\N	402.51630000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	30	\N	{}
1485	DS002	V2O5(s)	\N	solid	Cp	943.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	31	\N	{}
1486	DS002	V2O5(s)	\N	solid	H-H298	943.00	\N	\N	112.07130000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	31	\N	{}
1487	DS002	V2O5(s)	\N	solid	S	943.00	\N	\N	384.74050000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	31	\N	{}
1488	DS002	V2O5(s)	\N	solid	Cp	1043.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	31	\N	{}
1489	DS002	V2O5(s)	\N	solid	H-H298	1043.00	\N	\N	131.15040000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	31	\N	{}
1490	DS002	V2O5(s)	\N	solid	S	1043.00	\N	\N	403.97030000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	31	\N	{}
1491	DS002	V2O5(s)	\N	solid	Cp	1143.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	31	\N	{}
1492	DS002	V2O5(s)	\N	solid	H-H298	1143.00	\N	\N	150.22940000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	31	\N	{}
1493	DS002	V2O5(s)	\N	solid	S	1143.00	\N	\N	421.43820000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	31	\N	{}
1494	DS002	V2O5(s)	\N	solid	Cp	1243.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	31	\N	{}
1495	DS002	V2O5(s)	\N	solid	H-H298	1243.00	\N	\N	169.30850000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	31	\N	{}
1496	DS002	V2O5(s)	\N	solid	S	1243.00	\N	\N	437.44000000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	31	\N	{}
1497	DS002	V2O5(s)	\N	solid	Cp	1343.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	31	\N	{}
1498	DS002	V2O5(s)	\N	solid	H-H298	1343.00	\N	\N	188.38750000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	31	\N	{}
1499	DS002	V2O5(s)	\N	solid	S	1343.00	\N	\N	452.20300000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	31	\N	{}
1500	DS002	V2O5(s)	\N	solid	Cp	1443.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	31	\N	{}
1501	DS002	V2O5(s)	\N	solid	H-H298	1443.00	\N	\N	207.46650000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	31	\N	{}
1502	DS002	V2O5(s)	\N	solid	S	1443.00	\N	\N	465.90530000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	31	\N	{}
1503	DS002	V2O5(s)	\N	solid	Cp	1543.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	31	\N	{}
1504	DS002	V2O5(s)	\N	solid	H-H298	1543.00	\N	\N	226.54560000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	31	\N	{}
1505	DS002	V2O5(s)	\N	solid	S	1543.00	\N	\N	478.68900000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	31	\N	{}
1506	DS002	V2O5(s)	\N	solid	Cp	1643.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	31	\N	{}
1507	DS002	V2O5(s)	\N	solid	H-H298	1643.00	\N	\N	245.62460000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	31	\N	{}
1508	DS002	V2O5(s)	\N	solid	S	1643.00	\N	\N	490.66980000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	31	\N	{}
1509	DS002	V2O5(s)	\N	solid	Cp	1743.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	31	\N	{}
1510	DS002	V2O5(s)	\N	solid	H-H298	1743.00	\N	\N	264.70370000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	31	\N	{}
1511	DS002	V2O5(s)	\N	solid	S	1743.00	\N	\N	501.94240000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	31	\N	{}
1512	DS002	V2O5(s)	\N	solid	Cp	1843.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	CP_STD	\N	calculated	31	\N	{}
1513	DS002	V2O5(s)	\N	solid	H-H298	1843.00	\N	\N	283.78270000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	H_INCREMENT_298	\N	calculated	31	\N	{}
1514	DS002	V2O5(s)	\N	solid	S	1843.00	\N	\N	512.58600000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.868576	S_STD	\N	calculated	31	\N	{}
1515	DS002	V2O5(s)	\N	solid	Cp	1943.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	31	\N	{}
1516	DS002	V2O5(s)	\N	solid	H-H298	1943.00	\N	\N	302.86170000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	31	\N	{}
1517	DS002	V2O5(s)	\N	solid	S	1943.00	\N	\N	522.66710000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	31	\N	{}
1518	DS002	V2O5(s)	\N	solid	Cp	2043.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	31	\N	{}
1519	DS002	V2O5(s)	\N	solid	H-H298	2043.00	\N	\N	321.94080000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	31	\N	{}
1520	DS002	V2O5(s)	\N	solid	S	2043.00	\N	\N	532.24210000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	31	\N	{}
1521	DS002	V2O5(s)	\N	solid	Cp	2143.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	31	\N	{}
1522	DS002	V2O5(s)	\N	solid	H-H298	2143.00	\N	\N	341.01980000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	31	\N	{}
1523	DS002	V2O5(s)	\N	solid	S	2143.00	\N	\N	541.35950000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	31	\N	{}
1524	DS002	V2O5(s)	\N	solid	Cp	2243.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	31	\N	{}
1525	DS002	V2O5(s)	\N	solid	H-H298	2243.00	\N	\N	360.09890000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	31	\N	{}
1526	DS002	V2O5(s)	\N	solid	S	2243.00	\N	\N	550.06100000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	31	\N	{}
1527	DS002	V2O5(s)	\N	solid	Cp	2343.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	31	\N	{}
1528	DS002	V2O5(s)	\N	solid	H-H298	2343.00	\N	\N	379.17790000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	31	\N	{}
1529	DS002	V2O5(s)	\N	solid	S	2343.00	\N	\N	558.38290000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	31	\N	{}
1530	DS002	V2O5(s)	\N	solid	Cp	2443.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	31	\N	{}
1531	DS002	V2O5(s)	\N	solid	H-H298	2443.00	\N	\N	398.25690000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	31	\N	{}
1532	DS002	V2O5(s)	\N	solid	S	2443.00	\N	\N	566.35690000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	31	\N	{}
1533	DS002	V2O5(s)	\N	solid	Cp	2543.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	31	\N	{}
1534	DS002	V2O5(s)	\N	solid	H-H298	2543.00	\N	\N	417.33600000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	31	\N	{}
1535	DS002	V2O5(s)	\N	solid	S	2543.00	\N	\N	574.01100000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	31	\N	{}
1536	DS002	V2O5(s)	\N	solid	Cp	2643.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	31	\N	{}
1537	DS002	V2O5(s)	\N	solid	H-H298	2643.00	\N	\N	436.41500000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	31	\N	{}
1538	DS002	V2O5(s)	\N	solid	S	2643.00	\N	\N	581.36980000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	31	\N	{}
1539	DS002	V2O5(s)	\N	solid	Cp	2743.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	31	\N	{}
1540	DS002	V2O5(s)	\N	solid	H-H298	2743.00	\N	\N	455.49410000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	31	\N	{}
1541	DS002	V2O5(s)	\N	solid	S	2743.00	\N	\N	588.45530000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	31	\N	{}
1542	DS002	V2O5(s)	\N	solid	Cp	2843.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	31	\N	{}
1543	DS002	V2O5(s)	\N	solid	H-H298	2843.00	\N	\N	474.57310000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	31	\N	{}
1544	DS002	V2O5(s)	\N	solid	S	2843.00	\N	\N	595.28700000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	31	\N	{}
1545	DS002	V2O5(s)	\N	solid	Cp	2943.00	\N	\N	190.79040000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	31	\N	{}
1546	DS002	V2O5(s)	\N	solid	H-H298	2943.00	\N	\N	493.65210000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	31	\N	{}
1547	DS002	V2O5(s)	\N	solid	S	2943.00	\N	\N	601.88260000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	31	\N	{}
1548	DS002	AlN(s)	\N	solid	Cp	298.00	\N	\N	32.15219500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1549	DS002	AlN(s)	\N	solid	H-H298	298.00	\N	\N	-0.00440000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1550	DS002	AlN(s)	\N	solid	S	298.00	\N	\N	228.48650000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1551	DS002	AlN(s)	\N	solid	Cp	398.00	\N	\N	34.24576800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1552	DS002	AlN(s)	\N	solid	H-H298	398.00	\N	\N	3.32970000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1553	DS002	AlN(s)	\N	solid	S	398.00	\N	\N	238.11950000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1554	DS002	AlN(s)	\N	solid	Cp	498.00	\N	\N	35.27481000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1555	DS002	AlN(s)	\N	solid	H-H298	498.00	\N	\N	6.81080000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1556	DS002	AlN(s)	\N	solid	S	498.00	\N	\N	245.91810000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1557	DS002	AlN(s)	\N	solid	Cp	598.00	\N	\N	35.88399200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1558	DS002	AlN(s)	\N	solid	H-H298	598.00	\N	\N	10.37100000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1559	DS002	AlN(s)	\N	solid	S	598.00	\N	\N	252.43120000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1560	DS002	AlN(s)	\N	solid	Cp	698.00	\N	\N	36.29325200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1561	DS002	AlN(s)	\N	solid	H-H298	698.00	\N	\N	13.98110000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1562	DS002	AlN(s)	\N	solid	S	698.00	\N	\N	258.01260000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1563	DS002	AlN(s)	\N	solid	Cp	798.00	\N	\N	36.59428300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1564	DS002	AlN(s)	\N	solid	H-H298	798.00	\N	\N	17.62610000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1565	DS002	AlN(s)	\N	solid	S	798.00	\N	\N	262.89240000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1566	DS002	AlN(s)	\N	solid	Cp	898.00	\N	\N	36.83089600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1567	DS002	AlN(s)	\N	solid	H-H298	898.00	\N	\N	21.29780000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1568	DS002	AlN(s)	\N	solid	S	898.00	\N	\N	267.22700000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1569	DS002	AlN(s)	\N	solid	Cp	998.00	\N	\N	37.02622400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1570	DS002	AlN(s)	\N	solid	H-H298	998.00	\N	\N	24.99100000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1571	DS002	AlN(s)	\N	solid	S	998.00	\N	\N	271.12620000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1572	DS002	AlN(s)	\N	solid	Cp	1098.00	\N	\N	37.19346200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1573	DS002	AlN(s)	\N	solid	H-H298	1098.00	\N	\N	28.70210000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1574	DS002	AlN(s)	\N	solid	S	1098.00	\N	\N	274.66990000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1575	DS002	AlN(s)	\N	solid	Cp	1198.00	\N	\N	37.34062100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1576	DS002	AlN(s)	\N	solid	H-H298	1198.00	\N	\N	32.42900000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1577	DS002	AlN(s)	\N	solid	S	1198.00	\N	\N	277.91830000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1578	DS002	AlN(s)	\N	solid	Cp	1298.00	\N	\N	37.47282400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1579	DS002	AlN(s)	\N	solid	H-H298	1298.00	\N	\N	36.16980000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1580	DS002	AlN(s)	\N	solid	S	1298.00	\N	\N	280.91720000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1581	DS002	AlN(s)	\N	solid	Cp	1398.00	\N	\N	37.59350300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1582	DS002	AlN(s)	\N	solid	H-H298	1398.00	\N	\N	39.92320000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1583	DS002	AlN(s)	\N	solid	S	1398.00	\N	\N	283.70290000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1584	DS002	AlN(s)	\N	solid	Cp	1498.00	\N	\N	37.70504600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1585	DS002	AlN(s)	\N	solid	H-H298	1498.00	\N	\N	43.68820000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1586	DS002	AlN(s)	\N	solid	S	1498.00	\N	\N	286.30400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1587	DS002	AlN(s)	\N	solid	Cp	1598.00	\N	\N	37.80918200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1588	DS002	AlN(s)	\N	solid	H-H298	1598.00	\N	\N	47.46390000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1589	DS002	AlN(s)	\N	solid	S	1598.00	\N	\N	288.74390000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1590	DS002	AlN(s)	\N	solid	Cp	1698.00	\N	\N	37.90720400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1591	DS002	AlN(s)	\N	solid	H-H298	1698.00	\N	\N	51.24980000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1592	DS002	AlN(s)	\N	solid	S	1698.00	\N	\N	291.04190000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1593	DS002	AlN(s)	\N	solid	Cp	1798.00	\N	\N	38.00010900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1594	DS002	AlN(s)	\N	solid	H-H298	1798.00	\N	\N	55.04520000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1595	DS002	AlN(s)	\N	solid	S	1798.00	\N	\N	293.21370000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1596	DS002	AlN(s)	\N	solid	Cp	1898.00	\N	\N	38.08869300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1597	DS002	AlN(s)	\N	solid	H-H298	1898.00	\N	\N	58.84970000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1598	DS002	AlN(s)	\N	solid	S	1898.00	\N	\N	295.27290000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1599	DS002	AlN(s)	\N	solid	Cp	1998.00	\N	\N	38.17360400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1600	DS002	AlN(s)	\N	solid	H-H298	1998.00	\N	\N	62.66280000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1601	DS002	AlN(s)	\N	solid	S	1998.00	\N	\N	297.23080000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1602	DS002	AlN(s)	\N	solid	Cp	2098.00	\N	\N	38.25539000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1603	DS002	AlN(s)	\N	solid	H-H298	2098.00	\N	\N	66.48430000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1604	DS002	AlN(s)	\N	solid	S	2098.00	\N	\N	299.09710000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1605	DS002	AlN(s)	\N	solid	Cp	2198.00	\N	\N	38.33452000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1606	DS002	AlN(s)	\N	solid	H-H298	2198.00	\N	\N	70.31380000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1607	DS002	AlN(s)	\N	solid	S	2198.00	\N	\N	300.88020000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1608	DS002	AlN(s)	\N	solid	Cp	2298.00	\N	\N	38.41140600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1609	DS002	AlN(s)	\N	solid	H-H298	2298.00	\N	\N	74.15110000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1610	DS002	AlN(s)	\N	solid	S	2298.00	\N	\N	302.58750000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1611	DS002	AlN(s)	\N	solid	Cp	2398.00	\N	\N	38.48642000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1612	DS002	AlN(s)	\N	solid	H-H298	2398.00	\N	\N	77.99600000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	H_INCREMENT_298	\N	calculated	32	\N	{}
1613	DS002	AlN(s)	\N	solid	S	2398.00	\N	\N	304.22520000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	S_STD	\N	calculated	32	\N	{}
1614	DS002	AlN(s)	\N	solid	Cp	2498.00	\N	\N	38.55989800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.870894	CP_STD	\N	calculated	32	\N	{}
1615	DS002	AlN(s)	\N	solid	H-H298	2498.00	\N	\N	81.84830000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	32	\N	{}
1616	DS002	AlN(s)	\N	solid	S	2498.00	\N	\N	305.79910000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	32	\N	{}
1617	DS002	AlN(s)	\N	solid	Cp	2598.00	\N	\N	38.63215300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	32	\N	{}
1618	DS002	AlN(s)	\N	solid	H-H298	2598.00	\N	\N	85.70800000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	32	\N	{}
1619	DS002	AlN(s)	\N	solid	S	2598.00	\N	\N	307.31400000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	32	\N	{}
1620	DS002	AlN(s)	\N	solid	Cp	2698.00	\N	\N	38.70347600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	32	\N	{}
1621	DS002	AlN(s)	\N	solid	H-H298	2698.00	\N	\N	89.57470000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	32	\N	{}
1622	DS002	AlN(s)	\N	solid	S	2698.00	\N	\N	308.77450000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	32	\N	{}
1623	DS002	AlN(s)	\N	solid	Cp	2798.00	\N	\N	38.77414300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	32	\N	{}
1624	DS002	AlN(s)	\N	solid	H-H298	2798.00	\N	\N	93.44860000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	32	\N	{}
1625	DS002	AlN(s)	\N	solid	S	2798.00	\N	\N	310.18430000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	32	\N	{}
1626	DS002	AlN(s)	\N	solid	Cp	2898.00	\N	\N	38.84442000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	32	\N	{}
1627	DS002	AlN(s)	\N	solid	H-H298	2898.00	\N	\N	97.32960000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	32	\N	{}
1628	DS002	AlN(s)	\N	solid	S	2898.00	\N	\N	311.54720000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	32	\N	{}
1629	DS002	AlN(s)	\N	solid	Cp	2998.00	\N	\N	38.91455900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	32	\N	{}
1630	DS002	AlN(s)	\N	solid	H-H298	2998.00	\N	\N	101.21750000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	32	\N	{}
1631	DS002	AlN(s)	\N	solid	S	2998.00	\N	\N	312.86610000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	32	\N	{}
1632	DS002	AlN(s)	\N	solid	Cp	3098.00	\N	\N	38.98480600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	32	\N	{}
1633	DS002	AlN(s)	\N	solid	H-H298	3098.00	\N	\N	105.11250000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	32	\N	{}
1634	DS002	AlN(s)	\N	solid	S	3098.00	\N	\N	314.14410000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	32	\N	{}
1635	DS002	AlN(s)	\N	solid	Cp	3198.00	\N	\N	39.05540100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	32	\N	{}
1636	DS002	AlN(s)	\N	solid	H-H298	3198.00	\N	\N	109.01450000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	32	\N	{}
1637	DS002	AlN(s)	\N	solid	S	3198.00	\N	\N	315.38370000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	32	\N	{}
1638	DS002	AlN(s)	\N	solid	Cp	3298.00	\N	\N	39.12657700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	32	\N	{}
1639	DS002	AlN(s)	\N	solid	H-H298	3298.00	\N	\N	112.92360000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	32	\N	{}
1640	DS002	AlN(s)	\N	solid	S	3298.00	\N	\N	316.58730000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	32	\N	{}
1641	DS002	AlN(s)	\N	solid	Cp	3398.00	\N	\N	39.19856400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	32	\N	{}
1642	DS002	AlN(s)	\N	solid	H-H298	3398.00	\N	\N	116.83980000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	32	\N	{}
1643	DS002	AlN(s)	\N	solid	S	3398.00	\N	\N	317.75720000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	32	\N	{}
1644	DS002	AlN(s)	\N	solid	Cp	3498.00	\N	\N	39.27158700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	32	\N	{}
1645	DS002	AlN(s)	\N	solid	H-H298	3498.00	\N	\N	120.76330000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	32	\N	{}
1646	DS002	AlN(s)	\N	solid	S	3498.00	\N	\N	318.89510000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	32	\N	{}
1647	DS002	SiC(s)	\N	solid	Cp	298.00	\N	\N	38.31330000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	33	\N	{}
1648	DS002	SiC(s)	\N	solid	H-H298	298.00	\N	\N	-0.01260000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	33	\N	{}
1649	DS002	SiC(s)	\N	solid	S	298.00	\N	\N	212.99630000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	33	\N	{}
1650	DS002	SiC(s)	\N	solid	Cp	398.00	\N	\N	44.17613400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	33	\N	{}
1651	DS002	SiC(s)	\N	solid	H-H298	398.00	\N	\N	4.17490000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	33	\N	{}
1652	DS002	SiC(s)	\N	solid	S	398.00	\N	\N	225.07290000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	33	\N	{}
1653	DS002	SiC(s)	\N	solid	Cp	498.00	\N	\N	45.26598700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	33	\N	{}
1654	DS002	SiC(s)	\N	solid	H-H298	498.00	\N	\N	8.66990000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	33	\N	{}
1655	DS002	SiC(s)	\N	solid	S	498.00	\N	\N	235.14390000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	33	\N	{}
1656	DS002	SiC(s)	\N	solid	Cp	598.00	\N	\N	44.53573200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	33	\N	{}
1657	DS002	SiC(s)	\N	solid	H-H298	598.00	\N	\N	13.16900000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	33	\N	{}
1658	DS002	SiC(s)	\N	solid	S	598.00	\N	\N	243.37890000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	33	\N	{}
1659	DS002	SiC(s)	\N	solid	Cp	698.00	\N	\N	43.14661400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	33	\N	{}
1660	DS002	SiC(s)	\N	solid	H-H298	698.00	\N	\N	17.55560000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	33	\N	{}
1661	DS002	SiC(s)	\N	solid	S	698.00	\N	\N	250.16460000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	33	\N	{}
1662	DS002	SiC(s)	\N	solid	Cp	798.00	\N	\N	41.71892900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	33	\N	{}
1663	DS002	SiC(s)	\N	solid	H-H298	798.00	\N	\N	21.79730000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	33	\N	{}
1664	DS002	SiC(s)	\N	solid	S	798.00	\N	\N	255.84590000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	33	\N	{}
1665	DS002	SiC(s)	\N	solid	Cp	898.00	\N	\N	40.67099700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	33	\N	{}
1666	DS002	SiC(s)	\N	solid	H-H298	898.00	\N	\N	25.91210000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	33	\N	{}
1667	DS002	SiC(s)	\N	solid	S	898.00	\N	\N	260.70520000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	33	\N	{}
1668	DS002	SiC(s)	\N	solid	Cp	998.00	\N	\N	40.33390900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	33	\N	{}
1669	DS002	SiC(s)	\N	solid	H-H298	998.00	\N	\N	29.95520000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	33	\N	{}
1670	DS002	SiC(s)	\N	solid	S	998.00	\N	\N	264.97430000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	33	\N	{}
1671	DS002	Si3N4(s)	\N	solid	Cp	298.00	\N	\N	99.61004100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1672	DS002	Si3N4(s)	\N	solid	H-H298	298.00	\N	\N	0.00700000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1673	DS002	Si3N4(s)	\N	solid	S	298.00	\N	\N	112.98360000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	34	\N	{}
1674	DS002	Si3N4(s)	\N	solid	Cp	398.00	\N	\N	110.21182300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1675	DS002	Si3N4(s)	\N	solid	H-H298	398.00	\N	\N	10.49960000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1676	DS002	Si3N4(s)	\N	solid	S	398.00	\N	\N	143.27090000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	34	\N	{}
1677	DS002	Si3N4(s)	\N	solid	Cp	498.00	\N	\N	120.31620100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1678	DS002	Si3N4(s)	\N	solid	H-H298	498.00	\N	\N	22.03200000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1679	DS002	Si3N4(s)	\N	solid	S	498.00	\N	\N	169.07810000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	34	\N	{}
1680	DS002	Si3N4(s)	\N	solid	Cp	598.00	\N	\N	129.62863300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1681	DS002	Si3N4(s)	\N	solid	H-H298	598.00	\N	\N	34.53630000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1682	DS002	Si3N4(s)	\N	solid	S	598.00	\N	\N	191.93380000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	34	\N	{}
1683	DS002	Si3N4(s)	\N	solid	Cp	698.00	\N	\N	138.08274600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1684	DS002	Si3N4(s)	\N	solid	H-H298	698.00	\N	\N	47.92900000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1685	DS002	Si3N4(s)	\N	solid	S	698.00	\N	\N	212.62600000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	34	\N	{}
1331	DS002	Cu2O(s)	\N	solid	S	598.00	\N	\N	165.33840000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	28	\N	{}
1332	DS002	Cu2O(s)	\N	solid	Cp	698.00	\N	\N	101.07083100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	CP_STD	\N	calculated	28	\N	{}
1333	DS002	Cu2O(s)	\N	solid	H-H298	698.00	\N	\N	21.45970000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	H_INCREMENT_298	\N	calculated	28	\N	{}
1334	DS002	Cu2O(s)	\N	solid	S	698.00	\N	\N	181.02900000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.865831	S_STD	\N	calculated	28	\N	{}
1686	DS002	Si3N4(s)	\N	solid	Cp	798.00	\N	\N	145.68105800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1687	DS002	Si3N4(s)	\N	solid	H-H298	798.00	\N	\N	62.12430000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1688	DS002	Si3N4(s)	\N	solid	S	798.00	\N	\N	231.62060000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	34	\N	{}
1689	DS002	Si3N4(s)	\N	solid	Cp	898.00	\N	\N	152.45180800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1690	DS002	Si3N4(s)	\N	solid	H-H298	898.00	\N	\N	77.03770000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1691	DS002	Si3N4(s)	\N	solid	S	898.00	\N	\N	249.21970000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	34	\N	{}
1692	DS002	Si3N4(s)	\N	solid	Cp	998.00	\N	\N	158.43434200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1693	DS002	Si3N4(s)	\N	solid	H-H298	998.00	\N	\N	92.58840000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1694	DS002	Si3N4(s)	\N	solid	S	998.00	\N	\N	265.63300000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	34	\N	{}
1695	DS002	Si3N4(s)	\N	solid	Cp	1098.00	\N	\N	163.67334800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1696	DS002	Si3N4(s)	\N	solid	H-H298	1098.00	\N	\N	108.69970000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1697	DS002	Si3N4(s)	\N	solid	S	1098.00	\N	\N	281.01420000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	34	\N	{}
1698	DS002	Si3N4(s)	\N	solid	Cp	1198.00	\N	\N	168.21629700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1699	DS002	Si3N4(s)	\N	solid	H-H298	1198.00	\N	\N	125.29980000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1700	DS002	Si3N4(s)	\N	solid	S	1198.00	\N	\N	295.48050000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	34	\N	{}
1701	DS002	Si3N4(s)	\N	solid	Cp	1298.00	\N	\N	172.11221000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1702	DS002	Si3N4(s)	\N	solid	H-H298	1298.00	\N	\N	142.32140000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1703	DS002	Si3N4(s)	\N	solid	S	1298.00	\N	\N	309.12480000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	34	\N	{}
1704	DS002	Si3N4(s)	\N	solid	Cp	1398.00	\N	\N	175.41102000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1705	DS002	Si3N4(s)	\N	solid	H-H298	1398.00	\N	\N	159.70240000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1706	DS002	Si3N4(s)	\N	solid	S	1398.00	\N	\N	322.02300000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	34	\N	{}
1707	DS002	Si3N4(s)	\N	solid	Cp	1498.00	\N	\N	178.16321600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1708	DS002	Si3N4(s)	\N	solid	H-H298	1498.00	\N	\N	177.38540000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1709	DS002	Si3N4(s)	\N	solid	S	1498.00	\N	\N	334.23890000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	34	\N	{}
1710	DS002	Si3N4(s)	\N	solid	Cp	1598.00	\N	\N	180.41964500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1711	DS002	Si3N4(s)	\N	solid	H-H298	1598.00	\N	\N	195.31850000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1712	DS002	Si3N4(s)	\N	solid	S	1598.00	\N	\N	345.82680000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	S_STD	\N	calculated	34	\N	{}
1713	DS002	Si3N4(s)	\N	solid	Cp	1698.00	\N	\N	182.23138800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	CP_STD	\N	calculated	34	\N	{}
1714	DS002	Si3N4(s)	\N	solid	H-H298	1698.00	\N	\N	213.45450000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.8731	H_INCREMENT_298	\N	calculated	34	\N	{}
1715	DS002	Si3N4(s)	\N	solid	S	1698.00	\N	\N	356.83450000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	34	\N	{}
1716	DS002	Si3N4(s)	\N	solid	Cp	1798.00	\N	\N	183.64968200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	34	\N	{}
1717	DS002	Si3N4(s)	\N	solid	H-H298	1798.00	\N	\N	231.75160000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	34	\N	{}
1718	DS002	Si3N4(s)	\N	solid	S	1798.00	\N	\N	367.30440000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	34	\N	{}
1719	DS002	Si3N4(s)	\N	solid	Cp	1898.00	\N	\N	184.72587500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	34	\N	{}
1720	DS002	Si3N4(s)	\N	solid	H-H298	1898.00	\N	\N	250.17300000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	34	\N	{}
1721	DS002	Si3N4(s)	\N	solid	S	1898.00	\N	\N	377.27490000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	34	\N	{}
1722	DS002	Si3N4(s)	\N	solid	Cp	1998.00	\N	\N	185.51139300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	34	\N	{}
1723	DS002	Si3N4(s)	\N	solid	H-H298	1998.00	\N	\N	268.68710000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	34	\N	{}
1724	DS002	Si3N4(s)	\N	solid	S	1998.00	\N	\N	386.78090000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	34	\N	{}
1725	DS002	Si3N4(s)	\N	solid	Cp	2098.00	\N	\N	186.05771600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	34	\N	{}
1726	DS002	Si3N4(s)	\N	solid	H-H298	2098.00	\N	\N	287.26740000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	34	\N	{}
1727	DS002	Si3N4(s)	\N	solid	S	2098.00	\N	\N	395.85500000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	34	\N	{}
1728	DS002	Si3N4(s)	\N	solid	Cp	2198.00	\N	\N	186.41636700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	34	\N	{}
1729	DS002	Si3N4(s)	\N	solid	H-H298	2198.00	\N	\N	305.89240000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	34	\N	{}
1730	DS002	Si3N4(s)	\N	solid	S	2198.00	\N	\N	404.52740000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	34	\N	{}
1731	DS002	Si3N4(s)	\N	solid	Cp	2298.00	\N	\N	186.63889800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	34	\N	{}
1732	DS002	Si3N4(s)	\N	solid	H-H298	2298.00	\N	\N	324.54610000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	34	\N	{}
1733	DS002	Si3N4(s)	\N	solid	S	2298.00	\N	\N	412.82660000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	34	\N	{}
1734	DS002	Si3N4(s)	\N	solid	Cp	2398.00	\N	\N	186.77688500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	34	\N	{}
1735	DS002	Si3N4(s)	\N	solid	H-H298	2398.00	\N	\N	343.21740000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	34	\N	{}
1736	DS002	Si3N4(s)	\N	solid	S	2398.00	\N	\N	420.77980000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	34	\N	{}
1737	DS002	Si3N4(s)	\N	solid	Cp	2498.00	\N	\N	186.88192100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	34	\N	{}
1738	DS002	Si3N4(s)	\N	solid	H-H298	2498.00	\N	\N	361.90040000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	34	\N	{}
1739	DS002	Si3N4(s)	\N	solid	S	2498.00	\N	\N	428.41280000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	34	\N	{}
1740	DS002	Si3N4(s)	\N	solid	Cp	2598.00	\N	\N	187.00561400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	34	\N	{}
1741	DS002	Si3N4(s)	\N	solid	H-H298	2598.00	\N	\N	380.59440000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	34	\N	{}
1742	DS002	Si3N4(s)	\N	solid	S	2598.00	\N	\N	435.75050000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	34	\N	{}
1743	DS002	Si3N4(s)	\N	solid	Cp	2698.00	\N	\N	187.19957900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	34	\N	{}
1744	DS002	Si3N4(s)	\N	solid	H-H298	2698.00	\N	\N	399.30380000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	34	\N	{}
1745	DS002	Si3N4(s)	\N	solid	S	2698.00	\N	\N	442.81680000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	34	\N	{}
1746	DS002	Si3N4(s)	\N	solid	Cp	2798.00	\N	\N	187.51544500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	34	\N	{}
1747	DS002	Si3N4(s)	\N	solid	H-H298	2798.00	\N	\N	418.03840000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	34	\N	{}
1748	DS002	Si3N4(s)	\N	solid	S	2798.00	\N	\N	449.63500000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	34	\N	{}
1749	DS002	Si3N4(s)	\N	solid	Cp	2898.00	\N	\N	188.00484300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	34	\N	{}
1750	DS002	Si3N4(s)	\N	solid	H-H298	2898.00	\N	\N	436.81270000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	34	\N	{}
1751	DS002	Si3N4(s)	\N	solid	S	2898.00	\N	\N	456.22780000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	34	\N	{}
1752	DS002	Si3N4(s)	\N	solid	Cp	2998.00	\N	\N	188.71941100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	34	\N	{}
1753	DS002	Si3N4(s)	\N	solid	H-H298	2998.00	\N	\N	455.64680000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	34	\N	{}
1754	DS002	Si3N4(s)	\N	solid	S	2998.00	\N	\N	462.61710000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	34	\N	{}
1755	DS002	CaS(s)	\N	solid	Cp	298.00	\N	\N	34.79825900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	35	\N	{}
1756	DS002	CaS(s)	\N	solid	H-H298	298.00	\N	\N	-0.00570000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	35	\N	{}
1757	DS002	CaS(s)	\N	solid	S	298.00	\N	\N	232.57010000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	35	\N	{}
1758	DS002	CaS(s)	\N	solid	Cp	398.00	\N	\N	35.89237900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	35	\N	{}
1759	DS002	CaS(s)	\N	solid	H-H298	398.00	\N	\N	3.53500000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	35	\N	{}
1760	DS002	CaS(s)	\N	solid	S	398.00	\N	\N	242.80770000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	35	\N	{}
1761	DS002	CaS(s)	\N	solid	Cp	498.00	\N	\N	36.48288200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	35	\N	{}
1762	DS002	CaS(s)	\N	solid	H-H298	498.00	\N	\N	7.15650000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	35	\N	{}
1763	DS002	CaS(s)	\N	solid	S	498.00	\N	\N	250.92280000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	35	\N	{}
1764	DS002	CaS(s)	\N	solid	Cp	598.00	\N	\N	36.83568600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	35	\N	{}
1765	DS002	CaS(s)	\N	solid	H-H298	598.00	\N	\N	10.82370000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	35	\N	{}
1766	DS002	CaS(s)	\N	solid	S	598.00	\N	\N	257.63260000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	35	\N	{}
1767	DS002	CaS(s)	\N	solid	Cp	698.00	\N	\N	37.08434500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	35	\N	{}
1768	DS002	CaS(s)	\N	solid	H-H298	698.00	\N	\N	14.52020000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	35	\N	{}
1769	DS002	CaS(s)	\N	solid	S	698.00	\N	\N	263.34780000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	35	\N	{}
1770	DS002	CaS(s)	\N	solid	Cp	798.00	\N	\N	37.32244800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	35	\N	{}
1771	DS002	CaS(s)	\N	solid	H-H298	798.00	\N	\N	18.24030000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	35	\N	{}
1772	DS002	CaS(s)	\N	solid	S	798.00	\N	\N	268.32830000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	35	\N	{}
1773	DS002	CaS(s)	\N	solid	Cp	898.00	\N	\N	37.62866500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	35	\N	{}
1774	DS002	CaS(s)	\N	solid	H-H298	898.00	\N	\N	21.98690000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	35	\N	{}
1775	DS002	CaS(s)	\N	solid	S	898.00	\N	\N	272.75130000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	35	\N	{}
1776	DS002	CaS(s)	\N	solid	Cp	998.00	\N	\N	38.07521900	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	35	\N	{}
1777	DS002	CaS(s)	\N	solid	H-H298	998.00	\N	\N	25.77070000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	35	\N	{}
1778	DS002	CaS(s)	\N	solid	S	998.00	\N	\N	276.74590000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	35	\N	{}
1779	DS002	CaS(s)	\N	solid	Cp	1098.00	\N	\N	38.73123700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	35	\N	{}
1780	DS002	CaS(s)	\N	solid	H-H298	1098.00	\N	\N	29.60900000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	35	\N	{}
1781	DS002	CaS(s)	\N	solid	S	1098.00	\N	\N	280.41070000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	35	\N	{}
1782	DS002	CaS(s)	\N	solid	Cp	1198.00	\N	\N	39.66423000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	35	\N	{}
1783	DS002	CaS(s)	\N	solid	H-H298	1198.00	\N	\N	33.52620000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	35	\N	{}
1784	DS002	CaS(s)	\N	solid	S	1198.00	\N	\N	283.82440000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	35	\N	{}
1785	DS002	CaS(s)	\N	solid	Cp	1298.00	\N	\N	40.94081000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	35	\N	{}
1786	DS002	CaS(s)	\N	solid	H-H298	1298.00	\N	\N	37.55330000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	35	\N	{}
1787	DS002	CaS(s)	\N	solid	S	1298.00	\N	\N	287.05230000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	35	\N	{}
1788	DS002	CaS(s)	\N	solid	Cp	1398.00	\N	\N	42.62706000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	35	\N	{}
1789	DS002	CaS(s)	\N	solid	H-H298	1398.00	\N	\N	41.72800000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	35	\N	{}
1790	DS002	CaS(s)	\N	solid	S	1398.00	\N	\N	290.14990000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	35	\N	{}
1791	DS002	CaF2(s)	\N	solid	Cp	298.00	\N	\N	55.94249200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	36	\N	{}
1792	DS002	CaF2(s)	\N	solid	H-H298	298.00	\N	\N	-5.83020000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	36	\N	{}
1793	DS002	CaF2(s)	\N	solid	S	298.00	\N	\N	34.21830000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	36	\N	{}
1794	DS002	CaF2(s)	\N	solid	Cp	398.00	\N	\N	63.47457700	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	36	\N	{}
1795	DS002	CaF2(s)	\N	solid	H-H298	398.00	\N	\N	0.18890000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	36	\N	{}
1796	DS002	CaF2(s)	\N	solid	S	398.00	\N	\N	51.58300000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	36	\N	{}
1797	DS002	CaF2(s)	\N	solid	Cp	498.00	\N	\N	67.37307300	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	36	\N	{}
1798	DS002	CaF2(s)	\N	solid	H-H298	498.00	\N	\N	6.74880000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	36	\N	{}
1799	DS002	CaF2(s)	\N	solid	S	498.00	\N	\N	66.27050000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	36	\N	{}
1800	DS002	CaF2(s)	\N	solid	Cp	598.00	\N	\N	69.82849600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	36	\N	{}
1801	DS002	CaF2(s)	\N	solid	H-H298	598.00	\N	\N	13.61670000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	36	\N	{}
1802	DS002	CaF2(s)	\N	solid	S	598.00	\N	\N	78.83140000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	36	\N	{}
1803	DS002	CaF2(s)	\N	solid	Cp	698.00	\N	\N	71.58724600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	36	\N	{}
1804	DS002	CaF2(s)	\N	solid	H-H298	698.00	\N	\N	20.69170000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	36	\N	{}
1805	DS002	CaF2(s)	\N	solid	S	698.00	\N	\N	89.76780000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	36	\N	{}
1806	DS002	CaF2(s)	\N	solid	Cp	798.00	\N	\N	72.95969500	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	36	\N	{}
1807	DS002	CaF2(s)	\N	solid	H-H298	798.00	\N	\N	27.92150000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	36	\N	{}
1808	DS002	CaF2(s)	\N	solid	S	798.00	\N	\N	99.44570000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	36	\N	{}
1809	DS002	CaF2(s)	\N	solid	Cp	898.00	\N	\N	74.09341400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	36	\N	{}
1810	DS002	CaF2(s)	\N	solid	H-H298	898.00	\N	\N	35.27570000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	36	\N	{}
1811	DS002	CaF2(s)	\N	solid	S	898.00	\N	\N	108.12690000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	36	\N	{}
1812	DS002	CaF2(s)	\N	solid	Cp	998.00	\N	\N	75.06566400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	CP_STD	\N	calculated	36	\N	{}
1813	DS002	CaF2(s)	\N	solid	H-H298	998.00	\N	\N	42.73480000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	H_INCREMENT_298	\N	calculated	36	\N	{}
1814	DS002	CaF2(s)	\N	solid	S	998.00	\N	\N	116.00150000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.875219	S_STD	\N	calculated	36	\N	{}
1815	DS002	CaF2(s)	\N	solid	Cp	1098.00	\N	\N	75.91991800	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	CP_STD	\N	calculated	36	\N	{}
1816	DS002	CaF2(s)	\N	solid	H-H298	1098.00	\N	\N	50.28490000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	H_INCREMENT_298	\N	calculated	36	\N	{}
1817	DS002	CaF2(s)	\N	solid	S	1098.00	\N	\N	123.21070000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	S_STD	\N	calculated	36	\N	{}
1818	DS002	CaF2(s)	\N	solid	Cp	1198.00	\N	\N	76.68202200	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	CP_STD	\N	calculated	36	\N	{}
1819	DS002	CaF2(s)	\N	solid	H-H298	1198.00	\N	\N	57.91570000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	H_INCREMENT_298	\N	calculated	36	\N	{}
1820	DS002	CaF2(s)	\N	solid	S	1198.00	\N	\N	129.86140000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	S_STD	\N	calculated	36	\N	{}
1821	DS002	CaF2(s)	\N	solid	Cp	1298.00	\N	\N	77.36801100	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	CP_STD	\N	calculated	36	\N	{}
1822	DS002	CaF2(s)	\N	solid	H-H298	1298.00	\N	\N	65.61880000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	H_INCREMENT_298	\N	calculated	36	\N	{}
1823	DS002	CaF2(s)	\N	solid	S	1298.00	\N	\N	136.03670000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	S_STD	\N	calculated	36	\N	{}
1824	DS002	CaF2(s)	\N	solid	Cp	1398.00	\N	\N	77.98815600	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	CP_STD	\N	calculated	36	\N	{}
1825	DS002	CaF2(s)	\N	solid	H-H298	1398.00	\N	\N	73.38710000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	H_INCREMENT_298	\N	calculated	36	\N	{}
1826	DS002	CaF2(s)	\N	solid	S	1398.00	\N	\N	141.80190000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	S_STD	\N	calculated	36	\N	{}
1827	DS002	CaF2(s)	\N	solid	Cp	1498.00	\N	\N	78.54919400	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	CP_STD	\N	calculated	36	\N	{}
1828	DS002	CaF2(s)	\N	solid	H-H298	1498.00	\N	\N	81.21450000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	H_INCREMENT_298	\N	calculated	36	\N	{}
1829	DS002	CaF2(s)	\N	solid	S	1498.00	\N	\N	147.20950000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	S_STD	\N	calculated	36	\N	{}
1830	DS002	CaF2(s)	\N	solid	Cp	1598.00	\N	\N	79.05561000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	CP_STD	\N	calculated	36	\N	{}
1831	DS002	CaF2(s)	\N	solid	H-H298	1598.00	\N	\N	89.09520000	kJ/mol	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	H_INCREMENT_298	\N	calculated	36	\N	{}
1832	DS002	CaF2(s)	\N	solid	S	1598.00	\N	\N	152.30190000	J/(mol·K)	\N	calculated	NIST-JANAF Shomate	A	2026-07-21 14:20:52.877157	S_STD	\N	calculated	36	\N	{}
\.


--
-- Name: accounts_id_seq; Type: SEQUENCE SET; Schema: User; Owner: -
--

SELECT pg_catalog.setval('"User".accounts_id_seq', 1, true);


--
-- Name: bof_slag_model_parameter_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.bof_slag_model_parameter_id_seq', 26, true);


--
-- Name: casting_boundary_profile_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.casting_boundary_profile_id_seq', 3, true);


--
-- Name: casting_endpoint_benchmark_case_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.casting_endpoint_benchmark_case_id_seq', 3, true);


--
-- Name: casting_machine_configuration_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.casting_machine_configuration_id_seq', 2, true);


--
-- Name: casting_material_property_correlation_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.casting_material_property_correlation_id_seq', 15, true);


--
-- Name: casting_material_property_set_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.casting_material_property_set_id_seq', 2, true);


--
-- Name: casting_model_benchmark_case_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.casting_model_benchmark_case_id_seq', 3, true);


--
-- Name: dataset_import_issue_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.dataset_import_issue_id_seq', 1, false);


--
-- Name: element_reference_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.element_reference_id_seq', 95, true);


--
-- Name: emission_factor_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.emission_factor_id_seq', 16, true);


--
-- Name: invocation_logs_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.invocation_logs_id_seq', 3, true);


--
-- Name: kinetic_parameter_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.kinetic_parameter_id_seq', 1, false);


--
-- Name: melt_viscosity_model_definition_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.melt_viscosity_model_definition_id_seq', 2, true);


--
-- Name: model_metrics_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.model_metrics_id_seq', 1, false);


--
-- Name: model_versions_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.model_versions_id_seq', 1, false);


--
-- Name: phase_equilibrium_record_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.phase_equilibrium_record_id_seq', 1, false);


--
-- Name: process_parameter_set_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.process_parameter_set_id_seq', 8, true);


--
-- Name: reaction_definition_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.reaction_definition_id_seq', 16, true);


--
-- Name: reaction_property_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.reaction_property_id_seq', 78, true);


--
-- Name: solidification_benchmark_case_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.solidification_benchmark_case_id_seq', 5, true);


--
-- Name: solidification_model_definition_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.solidification_model_definition_id_seq', 1, true);


--
-- Name: thermo_property_definition_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.thermo_property_definition_id_seq', 6, true);


--
-- Name: thermodynamic_correlation_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.thermodynamic_correlation_id_seq', 123, true);


--
-- Name: thermodynamic_property_id_seq; Type: SEQUENCE SET; Schema: metallurgy_v2; Owner: -
--

SELECT pg_catalog.setval('metallurgy_v2.thermodynamic_property_id_seq', 1899, true);


--
-- Name: accounts accounts_email_key; Type: CONSTRAINT; Schema: User; Owner: -
--

ALTER TABLE ONLY "User".accounts
    ADD CONSTRAINT accounts_email_key UNIQUE (email);


--
-- Name: accounts accounts_pkey; Type: CONSTRAINT; Schema: User; Owner: -
--

ALTER TABLE ONLY "User".accounts
    ADD CONSTRAINT accounts_pkey PRIMARY KEY (id);


--
-- Name: accounts accounts_username_key; Type: CONSTRAINT; Schema: User; Owner: -
--

ALTER TABLE ONLY "User".accounts
    ADD CONSTRAINT accounts_username_key UNIQUE (username);


--
-- Name: benchmark_cases benchmark_cases_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.benchmark_cases
    ADD CONSTRAINT benchmark_cases_pkey PRIMARY KEY (case_id);


--
-- Name: bof_slag_model_parameter bof_slag_model_parameter_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.bof_slag_model_parameter
    ADD CONSTRAINT bof_slag_model_parameter_pkey PRIMARY KEY (id);


--
-- Name: casting_boundary_profile casting_boundary_profile_boundary_profile_id_key; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_boundary_profile
    ADD CONSTRAINT casting_boundary_profile_boundary_profile_id_key UNIQUE (boundary_profile_id);


--
-- Name: casting_boundary_profile casting_boundary_profile_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_boundary_profile
    ADD CONSTRAINT casting_boundary_profile_pkey PRIMARY KEY (id);


--
-- Name: casting_endpoint_benchmark_case casting_endpoint_benchmark_case_benchmark_id_key; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_endpoint_benchmark_case
    ADD CONSTRAINT casting_endpoint_benchmark_case_benchmark_id_key UNIQUE (benchmark_id);


--
-- Name: casting_endpoint_benchmark_case casting_endpoint_benchmark_case_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_endpoint_benchmark_case
    ADD CONSTRAINT casting_endpoint_benchmark_case_pkey PRIMARY KEY (id);


--
-- Name: casting_machine_configuration casting_machine_configuration_machine_configuration_id_key; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_machine_configuration
    ADD CONSTRAINT casting_machine_configuration_machine_configuration_id_key UNIQUE (machine_configuration_id);


--
-- Name: casting_machine_configuration casting_machine_configuration_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_machine_configuration
    ADD CONSTRAINT casting_machine_configuration_pkey PRIMARY KEY (id);


--
-- Name: casting_material_property_correlation casting_material_property_correlation_correlation_id_key; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_material_property_correlation
    ADD CONSTRAINT casting_material_property_correlation_correlation_id_key UNIQUE (correlation_id);


--
-- Name: casting_material_property_correlation casting_material_property_correlation_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_material_property_correlation
    ADD CONSTRAINT casting_material_property_correlation_pkey PRIMARY KEY (id);


--
-- Name: casting_material_property_set casting_material_property_set_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_material_property_set
    ADD CONSTRAINT casting_material_property_set_pkey PRIMARY KEY (id);


--
-- Name: casting_material_property_set casting_material_property_set_property_set_id_key; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_material_property_set
    ADD CONSTRAINT casting_material_property_set_property_set_id_key UNIQUE (property_set_id);


--
-- Name: casting_model_benchmark_case casting_model_benchmark_case_benchmark_id_key; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_model_benchmark_case
    ADD CONSTRAINT casting_model_benchmark_case_benchmark_id_key UNIQUE (benchmark_id);


--
-- Name: casting_model_benchmark_case casting_model_benchmark_case_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_model_benchmark_case
    ADD CONSTRAINT casting_model_benchmark_case_pkey PRIMARY KEY (id);


--
-- Name: dataset_import_issue dataset_import_issue_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.dataset_import_issue
    ADD CONSTRAINT dataset_import_issue_pkey PRIMARY KEY (id);


--
-- Name: dataset_import_run dataset_import_run_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.dataset_import_run
    ADD CONSTRAINT dataset_import_run_pkey PRIMARY KEY (run_id);


--
-- Name: dataset_registry dataset_registry_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.dataset_registry
    ADD CONSTRAINT dataset_registry_pkey PRIMARY KEY (dataset_id);


--
-- Name: element_reference element_reference_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.element_reference
    ADD CONSTRAINT element_reference_pkey PRIMARY KEY (id);


--
-- Name: emission_factor emission_factor_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.emission_factor
    ADD CONSTRAINT emission_factor_pkey PRIMARY KEY (id);


--
-- Name: experiment_run experiment_run_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.experiment_run
    ADD CONSTRAINT experiment_run_pkey PRIMARY KEY (experiment_id);


--
-- Name: invocation_logs invocation_logs_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.invocation_logs
    ADD CONSTRAINT invocation_logs_pkey PRIMARY KEY (id);


--
-- Name: kinetic_parameter kinetic_parameter_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.kinetic_parameter
    ADD CONSTRAINT kinetic_parameter_pkey PRIMARY KEY (id);


--
-- Name: knowledge_docs knowledge_docs_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.knowledge_docs
    ADD CONSTRAINT knowledge_docs_pkey PRIMARY KEY (doc_id);


--
-- Name: llm_tool_trace llm_tool_trace_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.llm_tool_trace
    ADD CONSTRAINT llm_tool_trace_pkey PRIMARY KEY (trace_id);


--
-- Name: melt_viscosity_model_definition melt_viscosity_model_definition_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.melt_viscosity_model_definition
    ADD CONSTRAINT melt_viscosity_model_definition_pkey PRIMARY KEY (id);


--
-- Name: model_execution_log model_execution_log_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.model_execution_log
    ADD CONSTRAINT model_execution_log_pkey PRIMARY KEY (execution_id);


--
-- Name: model_metrics model_metrics_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.model_metrics
    ADD CONSTRAINT model_metrics_pkey PRIMARY KEY (id);


--
-- Name: model_registry model_registry_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.model_registry
    ADD CONSTRAINT model_registry_pkey PRIMARY KEY (model_id);


--
-- Name: model_versions model_versions_model_id_version_key; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.model_versions
    ADD CONSTRAINT model_versions_model_id_version_key UNIQUE (model_id, version);


--
-- Name: model_versions model_versions_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.model_versions
    ADD CONSTRAINT model_versions_pkey PRIMARY KEY (id);


--
-- Name: phase_equilibrium_record phase_equilibrium_record_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.phase_equilibrium_record
    ADD CONSTRAINT phase_equilibrium_record_pkey PRIMARY KEY (id);


--
-- Name: process_parameter_set process_parameter_set_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.process_parameter_set
    ADD CONSTRAINT process_parameter_set_pkey PRIMARY KEY (id);


--
-- Name: reaction_definition reaction_definition_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.reaction_definition
    ADD CONSTRAINT reaction_definition_pkey PRIMARY KEY (id);


--
-- Name: reaction_definition reaction_definition_reaction_id_key; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.reaction_definition
    ADD CONSTRAINT reaction_definition_reaction_id_key UNIQUE (reaction_id);


--
-- Name: reaction_property reaction_property_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.reaction_property
    ADD CONSTRAINT reaction_property_pkey PRIMARY KEY (id);


--
-- Name: reaction_property reaction_property_reaction_id_property_type_temperature_key; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.reaction_property
    ADD CONSTRAINT reaction_property_reaction_id_property_type_temperature_key UNIQUE (reaction_id, property_type, temperature);


--
-- Name: solidification_benchmark_case solidification_benchmark_case_benchmark_id_key; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.solidification_benchmark_case
    ADD CONSTRAINT solidification_benchmark_case_benchmark_id_key UNIQUE (benchmark_id);


--
-- Name: solidification_benchmark_case solidification_benchmark_case_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.solidification_benchmark_case
    ADD CONSTRAINT solidification_benchmark_case_pkey PRIMARY KEY (id);


--
-- Name: solidification_model_definition solidification_model_definition_model_asset_id_key; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.solidification_model_definition
    ADD CONSTRAINT solidification_model_definition_model_asset_id_key UNIQUE (model_asset_id);


--
-- Name: solidification_model_definition solidification_model_definition_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.solidification_model_definition
    ADD CONSTRAINT solidification_model_definition_pkey PRIMARY KEY (id);


--
-- Name: thermo_property_definition thermo_property_definition_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.thermo_property_definition
    ADD CONSTRAINT thermo_property_definition_pkey PRIMARY KEY (id);


--
-- Name: thermo_property_definition thermo_property_definition_property_code_key; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.thermo_property_definition
    ADD CONSTRAINT thermo_property_definition_property_code_key UNIQUE (property_code);


--
-- Name: thermodynamic_correlation thermodynamic_correlation_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.thermodynamic_correlation
    ADD CONSTRAINT thermodynamic_correlation_pkey PRIMARY KEY (id);


--
-- Name: thermodynamic_property thermodynamic_property_pkey; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.thermodynamic_property
    ADD CONSTRAINT thermodynamic_property_pkey PRIMARY KEY (id);


--
-- Name: bof_slag_model_parameter uq_bof_slag_parameter; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.bof_slag_model_parameter
    ADD CONSTRAINT uq_bof_slag_parameter UNIQUE (model_code, parameter_set_id, parameter_code, source_version);


--
-- Name: casting_material_property_correlation uq_casting_correlation_source; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_material_property_correlation
    ADD CONSTRAINT uq_casting_correlation_source UNIQUE (property_set_id, source_record_key);


--
-- Name: element_reference uq_element_reference; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.element_reference
    ADD CONSTRAINT uq_element_reference UNIQUE (dataset_id, symbol, source_version);


--
-- Name: emission_factor uq_emission_factor; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.emission_factor
    ADD CONSTRAINT uq_emission_factor UNIQUE (dataset_id, factor_set_id, factor_code, source_version);


--
-- Name: melt_viscosity_model_definition uq_melt_viscosity_model; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.melt_viscosity_model_definition
    ADD CONSTRAINT uq_melt_viscosity_model UNIQUE (dataset_id, model_id, source_version);


--
-- Name: process_parameter_set uq_process_parameter; Type: CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.process_parameter_set
    ADD CONSTRAINT uq_process_parameter UNIQUE (dataset_id, parameter_set_id, parameter_code, source_version);


--
-- Name: idx_accounts_email; Type: INDEX; Schema: User; Owner: -
--

CREATE INDEX idx_accounts_email ON "User".accounts USING btree (lower((email)::text));


--
-- Name: idx_accounts_status; Type: INDEX; Schema: User; Owner: -
--

CREATE INDEX idx_accounts_status ON "User".accounts USING btree (account_status);


--
-- Name: idx_bof_slag_parameter_lookup; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_bof_slag_parameter_lookup ON metallurgy_v2.bof_slag_model_parameter USING btree (model_code, parameter_set_id, is_approved, temperature_min_k, temperature_max_k);


--
-- Name: idx_casting_benchmark_model; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_casting_benchmark_model ON metallurgy_v2.casting_model_benchmark_case USING btree (model_code, within_domain);


--
-- Name: idx_casting_boundary_approved; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_casting_boundary_approved ON metallurgy_v2.casting_boundary_profile USING btree (boundary_profile_id, profile_type, is_approved);


--
-- Name: idx_casting_correlation_lookup; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_casting_correlation_lookup ON metallurgy_v2.casting_material_property_correlation USING btree (property_set_id, property_type, temperature_min_k, temperature_max_k, is_active, priority);


--
-- Name: idx_casting_endpoint_benchmark_model; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_casting_endpoint_benchmark_model ON metallurgy_v2.casting_endpoint_benchmark_case USING btree (model_code, within_domain);


--
-- Name: idx_casting_machine_configuration_approved; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_casting_machine_configuration_approved ON metallurgy_v2.casting_machine_configuration USING btree (machine_configuration_id, is_approved, usage_scope);


--
-- Name: idx_casting_property_set_approved; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_casting_property_set_approved ON metallurgy_v2.casting_material_property_set USING btree (property_set_id, is_approved);


--
-- Name: idx_corr_species; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_corr_species ON metallurgy_v2.thermodynamic_correlation USING btree (species_id, phase, equation_type);


--
-- Name: idx_corr_temp; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_corr_temp ON metallurgy_v2.thermodynamic_correlation USING btree (species_id, temperature_min_k, temperature_max_k);


--
-- Name: idx_element_reference_active; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_element_reference_active ON metallurgy_v2.element_reference USING btree (symbol, is_active);


--
-- Name: idx_emission_factor_approved; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_emission_factor_approved ON metallurgy_v2.emission_factor USING btree (factor_set_id, factor_code, is_approved);


--
-- Name: idx_experiment_benchmark_run; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_experiment_benchmark_run ON metallurgy_v2.experiment_run USING btree (benchmark_run_id);


--
-- Name: idx_invocation_logs_model_id; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_invocation_logs_model_id ON metallurgy_v2.invocation_logs USING btree (model_id);


--
-- Name: idx_invocation_logs_requested_at; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_invocation_logs_requested_at ON metallurgy_v2.invocation_logs USING btree (requested_at);


--
-- Name: idx_invocation_logs_trace_id; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_invocation_logs_trace_id ON metallurgy_v2.invocation_logs USING btree (trace_id);


--
-- Name: idx_kinetic_material; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_kinetic_material ON metallurgy_v2.kinetic_parameter USING btree (material_system);


--
-- Name: idx_melt_viscosity_model_approved; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_melt_viscosity_model_approved ON metallurgy_v2.melt_viscosity_model_definition USING btree (model_id, is_approved);


--
-- Name: idx_metrics_model; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_metrics_model ON metallurgy_v2.model_metrics USING btree (model_id, model_version);


--
-- Name: idx_model_execution_model; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_model_execution_model ON metallurgy_v2.model_execution_log USING btree (model_code, started_at DESC);


--
-- Name: idx_model_execution_trace; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_model_execution_trace ON metallurgy_v2.model_execution_log USING btree (trace_id);


--
-- Name: idx_process_parameter_active; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_process_parameter_active ON metallurgy_v2.process_parameter_set USING btree (process, parameter_set_id, is_active);


--
-- Name: idx_solidification_benchmark_model; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_solidification_benchmark_model ON metallurgy_v2.solidification_benchmark_case USING btree (model_asset_id, within_domain);


--
-- Name: idx_solidification_model_approved; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_solidification_model_approved ON metallurgy_v2.solidification_model_definition USING btree (model_asset_id, is_approved);


--
-- Name: idx_thermo_property_type; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_thermo_property_type ON metallurgy_v2.thermodynamic_property USING btree (property_type);


--
-- Name: idx_thermo_species; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE INDEX idx_thermo_species ON metallurgy_v2.thermodynamic_property USING btree (species);


--
-- Name: uq_reaction_property_source_record; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE UNIQUE INDEX uq_reaction_property_source_record ON metallurgy_v2.reaction_property USING btree (dataset_id, source_record_key) WHERE (source_record_key IS NOT NULL);


--
-- Name: uq_thermo_correlation_source_record; Type: INDEX; Schema: metallurgy_v2; Owner: -
--

CREATE UNIQUE INDEX uq_thermo_correlation_source_record ON metallurgy_v2.thermodynamic_correlation USING btree (source_id, source_record_key, species_id, phase, equation_type, temperature_min_k, temperature_max_k) WHERE ((source_id IS NOT NULL) AND (source_record_key IS NOT NULL));


--
-- Name: benchmark_cases benchmark_cases_model_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.benchmark_cases
    ADD CONSTRAINT benchmark_cases_model_id_fkey FOREIGN KEY (model_id) REFERENCES metallurgy_v2.model_registry(model_id);


--
-- Name: bof_slag_model_parameter bof_slag_model_parameter_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.bof_slag_model_parameter
    ADD CONSTRAINT bof_slag_model_parameter_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- Name: casting_boundary_profile casting_boundary_profile_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_boundary_profile
    ADD CONSTRAINT casting_boundary_profile_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- Name: casting_boundary_profile casting_boundary_profile_property_set_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_boundary_profile
    ADD CONSTRAINT casting_boundary_profile_property_set_id_fkey FOREIGN KEY (property_set_id) REFERENCES metallurgy_v2.casting_material_property_set(property_set_id);


--
-- Name: casting_endpoint_benchmark_case casting_endpoint_benchmark_case_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_endpoint_benchmark_case
    ADD CONSTRAINT casting_endpoint_benchmark_case_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- Name: casting_endpoint_benchmark_case casting_endpoint_benchmark_case_machine_configuration_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_endpoint_benchmark_case
    ADD CONSTRAINT casting_endpoint_benchmark_case_machine_configuration_id_fkey FOREIGN KEY (machine_configuration_id) REFERENCES metallurgy_v2.casting_machine_configuration(machine_configuration_id);


--
-- Name: casting_machine_configuration casting_machine_configuration_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_machine_configuration
    ADD CONSTRAINT casting_machine_configuration_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- Name: casting_material_property_correlation casting_material_property_correlation_property_set_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_material_property_correlation
    ADD CONSTRAINT casting_material_property_correlation_property_set_id_fkey FOREIGN KEY (property_set_id) REFERENCES metallurgy_v2.casting_material_property_set(property_set_id);


--
-- Name: casting_material_property_set casting_material_property_set_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_material_property_set
    ADD CONSTRAINT casting_material_property_set_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- Name: casting_model_benchmark_case casting_model_benchmark_case_boundary_profile_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_model_benchmark_case
    ADD CONSTRAINT casting_model_benchmark_case_boundary_profile_id_fkey FOREIGN KEY (boundary_profile_id) REFERENCES metallurgy_v2.casting_boundary_profile(boundary_profile_id);


--
-- Name: casting_model_benchmark_case casting_model_benchmark_case_property_set_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.casting_model_benchmark_case
    ADD CONSTRAINT casting_model_benchmark_case_property_set_id_fkey FOREIGN KEY (property_set_id) REFERENCES metallurgy_v2.casting_material_property_set(property_set_id);


--
-- Name: dataset_import_issue dataset_import_issue_run_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.dataset_import_issue
    ADD CONSTRAINT dataset_import_issue_run_id_fkey FOREIGN KEY (run_id) REFERENCES metallurgy_v2.dataset_import_run(run_id);


--
-- Name: element_reference element_reference_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.element_reference
    ADD CONSTRAINT element_reference_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- Name: emission_factor emission_factor_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.emission_factor
    ADD CONSTRAINT emission_factor_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- Name: experiment_run experiment_run_trace_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.experiment_run
    ADD CONSTRAINT experiment_run_trace_id_fkey FOREIGN KEY (trace_id) REFERENCES metallurgy_v2.llm_tool_trace(trace_id);


--
-- Name: kinetic_parameter kinetic_parameter_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.kinetic_parameter
    ADD CONSTRAINT kinetic_parameter_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- Name: knowledge_docs knowledge_docs_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.knowledge_docs
    ADD CONSTRAINT knowledge_docs_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- Name: melt_viscosity_model_definition melt_viscosity_model_definition_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.melt_viscosity_model_definition
    ADD CONSTRAINT melt_viscosity_model_definition_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- Name: model_metrics model_metrics_model_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.model_metrics
    ADD CONSTRAINT model_metrics_model_id_fkey FOREIGN KEY (model_id) REFERENCES metallurgy_v2.model_registry(model_id);


--
-- Name: model_versions model_versions_model_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.model_versions
    ADD CONSTRAINT model_versions_model_id_fkey FOREIGN KEY (model_id) REFERENCES metallurgy_v2.model_registry(model_id);


--
-- Name: phase_equilibrium_record phase_equilibrium_record_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.phase_equilibrium_record
    ADD CONSTRAINT phase_equilibrium_record_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- Name: process_parameter_set process_parameter_set_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.process_parameter_set
    ADD CONSTRAINT process_parameter_set_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- Name: reaction_property reaction_property_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.reaction_property
    ADD CONSTRAINT reaction_property_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- Name: reaction_property reaction_property_reaction_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.reaction_property
    ADD CONSTRAINT reaction_property_reaction_id_fkey FOREIGN KEY (reaction_id) REFERENCES metallurgy_v2.reaction_definition(reaction_id);


--
-- Name: solidification_benchmark_case solidification_benchmark_case_model_asset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.solidification_benchmark_case
    ADD CONSTRAINT solidification_benchmark_case_model_asset_id_fkey FOREIGN KEY (model_asset_id) REFERENCES metallurgy_v2.solidification_model_definition(model_asset_id);


--
-- Name: solidification_model_definition solidification_model_definition_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.solidification_model_definition
    ADD CONSTRAINT solidification_model_definition_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- Name: thermodynamic_property thermodynamic_property_dataset_id_fkey; Type: FK CONSTRAINT; Schema: metallurgy_v2; Owner: -
--

ALTER TABLE ONLY metallurgy_v2.thermodynamic_property
    ADD CONSTRAINT thermodynamic_property_dataset_id_fkey FOREIGN KEY (dataset_id) REFERENCES metallurgy_v2.dataset_registry(dataset_id);


--
-- PostgreSQL database dump complete
--

\unrestrict jk3qyWcELiEmqhuiQOgsiNT398IbykbBCAaK3l4ntC5VXYAYX7wyC8F6xA7uFcD

