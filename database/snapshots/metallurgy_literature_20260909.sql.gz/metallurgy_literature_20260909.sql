--
-- PostgreSQL database dump
--

\restrict oOkYhytRY1eP3UEmHIQ5fFOsgbjhM1qeUoJ6H0sGgXwMiGdYEwkE7eLbaAP2Efb

-- Dumped from database version 17.10
-- Dumped by pg_dump version 17.10

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: literature; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA literature;


--
-- Name: generate_document_code(); Type: FUNCTION; Schema: literature; Owner: -
--

CREATE FUNCTION literature.generate_document_code() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.document_code := 'LIT-' || LPAD(NEXTVAL('literature.document_code_seq')::TEXT, 6, '0');
    RETURN NEW;
END;
$$;


--
-- Name: update_timestamp(); Type: FUNCTION; Schema: literature; Owner: -
--

CREATE FUNCTION literature.update_timestamp() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: attachments; Type: TABLE; Schema: literature; Owner: -
--

CREATE TABLE literature.attachments (
    attachment_id bigint NOT NULL,
    document_id bigint NOT NULL,
    file_name text NOT NULL,
    storage_uri text NOT NULL,
    mime_type character varying(128),
    file_size bigint,
    checksum_sha256 character varying(128),
    access_level character varying(32) DEFAULT 'restricted'::character varying NOT NULL,
    can_download boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE attachments; Type: COMMENT; Schema: literature; Owner: -
--

COMMENT ON TABLE literature.attachments IS '附件存储信息，二进制文件不入库，只存路径';


--
-- Name: attachments_attachment_id_seq; Type: SEQUENCE; Schema: literature; Owner: -
--

CREATE SEQUENCE literature.attachments_attachment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: attachments_attachment_id_seq; Type: SEQUENCE OWNED BY; Schema: literature; Owner: -
--

ALTER SEQUENCE literature.attachments_attachment_id_seq OWNED BY literature.attachments.attachment_id;


--
-- Name: authors; Type: TABLE; Schema: literature; Owner: -
--

CREATE TABLE literature.authors (
    author_id bigint NOT NULL,
    author_name character varying(255) NOT NULL,
    author_name_en character varying(255),
    institution text,
    orcid character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE authors; Type: COMMENT; Schema: literature; Owner: -
--

COMMENT ON TABLE literature.authors IS '作者信息，与文献通过关系表关联';


--
-- Name: authors_author_id_seq; Type: SEQUENCE; Schema: literature; Owner: -
--

CREATE SEQUENCE literature.authors_author_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: authors_author_id_seq; Type: SEQUENCE OWNED BY; Schema: literature; Owner: -
--

ALTER SEQUENCE literature.authors_author_id_seq OWNED BY literature.authors.author_id;


--
-- Name: document_authors; Type: TABLE; Schema: literature; Owner: -
--

CREATE TABLE literature.document_authors (
    document_id bigint NOT NULL,
    author_id bigint NOT NULL,
    author_order integer NOT NULL,
    is_corresponding boolean DEFAULT false NOT NULL
);


--
-- Name: TABLE document_authors; Type: COMMENT; Schema: literature; Owner: -
--

COMMENT ON TABLE literature.document_authors IS '文献与作者的多对多关系，含排序和通讯作者标记';


--
-- Name: document_code_seq; Type: SEQUENCE; Schema: literature; Owner: -
--

CREATE SEQUENCE literature.document_code_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: document_domains; Type: TABLE; Schema: literature; Owner: -
--

CREATE TABLE literature.document_domains (
    document_id bigint NOT NULL,
    domain_code character varying(64) NOT NULL,
    is_primary boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: TABLE document_domains; Type: COMMENT; Schema: literature; Owner: -
--

COMMENT ON TABLE literature.document_domains IS '文献与研究领域的多对多关系，一篇文献可属于多个领域';


--
-- Name: document_keywords; Type: TABLE; Schema: literature; Owner: -
--

CREATE TABLE literature.document_keywords (
    document_id bigint NOT NULL,
    keyword_id bigint NOT NULL
);


--
-- Name: TABLE document_keywords; Type: COMMENT; Schema: literature; Owner: -
--

COMMENT ON TABLE literature.document_keywords IS '文献与关键词的多对多关系';


--
-- Name: documents; Type: TABLE; Schema: literature; Owner: -
--

CREATE TABLE literature.documents (
    document_id bigint NOT NULL,
    source_id bigint,
    document_code character varying(64) NOT NULL,
    title text NOT NULL,
    title_en text,
    document_type character varying(32) NOT NULL,
    abstract text,
    abstract_en text,
    journal_name text,
    conference_name text,
    publication_date date,
    publication_year integer,
    volume character varying(32),
    issue character varying(32),
    pages character varying(32),
    doi character varying(255),
    standard_no character varying(128),
    patent_no character varying(128),
    source_url text,
    citation_text text,
    language character varying(16) DEFAULT 'zh-CN'::character varying NOT NULL,
    security_level character varying(32) DEFAULT 'public'::character varying NOT NULL,
    status character varying(32) DEFAULT 'draft'::character varying NOT NULL,
    is_featured boolean DEFAULT false NOT NULL,
    published_at timestamp with time zone,
    created_by character varying(64),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    discovery_source character varying(64),
    scholar_citation_count integer,
    scholar_url text,
    scholar_checked_at timestamp with time zone
);


--
-- Name: TABLE documents; Type: COMMENT; Schema: literature; Owner: -
--

COMMENT ON TABLE literature.documents IS '文献主表，存储论文/标准/专利/报告等元数据';


--
-- Name: COLUMN documents.document_code; Type: COMMENT; Schema: literature; Owner: -
--

COMMENT ON COLUMN literature.documents.document_code IS '自动生成的唯一文献编号，如 LIT-000001';


--
-- Name: COLUMN documents.document_type; Type: COMMENT; Schema: literature; Owner: -
--

COMMENT ON COLUMN literature.documents.document_type IS '取值：paper, standard, patent, report, book, manual';


--
-- Name: COLUMN documents.status; Type: COMMENT; Schema: literature; Owner: -
--

COMMENT ON COLUMN literature.documents.status IS '取值：draft, pending_review, published, archived';


--
-- Name: documents_document_id_seq; Type: SEQUENCE; Schema: literature; Owner: -
--

CREATE SEQUENCE literature.documents_document_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: documents_document_id_seq; Type: SEQUENCE OWNED BY; Schema: literature; Owner: -
--

ALTER SEQUENCE literature.documents_document_id_seq OWNED BY literature.documents.document_id;


--
-- Name: domains; Type: TABLE; Schema: literature; Owner: -
--

CREATE TABLE literature.domains (
    domain_code character varying(64) NOT NULL,
    domain_name character varying(128) NOT NULL,
    description text,
    route_path character varying(255),
    sort_order integer DEFAULT 0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL
);


--
-- Name: TABLE domains; Type: COMMENT; Schema: literature; Owner: -
--

COMMENT ON TABLE literature.domains IS '研究领域分类，与现有5个研究领域页面对应';


--
-- Name: keywords; Type: TABLE; Schema: literature; Owner: -
--

CREATE TABLE literature.keywords (
    keyword_id bigint NOT NULL,
    keyword_name character varying(128) NOT NULL
);


--
-- Name: TABLE keywords; Type: COMMENT; Schema: literature; Owner: -
--

COMMENT ON TABLE literature.keywords IS '关键词字典，去重存储';


--
-- Name: keywords_keyword_id_seq; Type: SEQUENCE; Schema: literature; Owner: -
--

CREATE SEQUENCE literature.keywords_keyword_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: keywords_keyword_id_seq; Type: SEQUENCE OWNED BY; Schema: literature; Owner: -
--

ALTER SEQUENCE literature.keywords_keyword_id_seq OWNED BY literature.keywords.keyword_id;


--
-- Name: sources; Type: TABLE; Schema: literature; Owner: -
--

CREATE TABLE literature.sources (
    source_id bigint NOT NULL,
    source_name character varying(255) NOT NULL,
    source_type character varying(32) NOT NULL,
    provider character varying(255),
    access_url text,
    license_note text,
    security_level character varying(32) DEFAULT 'public'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE sources; Type: COMMENT; Schema: literature; Owner: -
--

COMMENT ON TABLE literature.sources IS '文献来源（期刊/会议/标准平台/专利平台等）';


--
-- Name: COLUMN sources.source_type; Type: COMMENT; Schema: literature; Owner: -
--

COMMENT ON COLUMN literature.sources.source_type IS '取值：journal, conference, standard_platform, patent_platform, internal, manual_import';


--
-- Name: COLUMN sources.security_level; Type: COMMENT; Schema: literature; Owner: -
--

COMMENT ON COLUMN literature.sources.security_level IS '取值：public, internal, confidential';


--
-- Name: sources_source_id_seq; Type: SEQUENCE; Schema: literature; Owner: -
--

CREATE SEQUENCE literature.sources_source_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: sources_source_id_seq; Type: SEQUENCE OWNED BY; Schema: literature; Owner: -
--

ALTER SEQUENCE literature.sources_source_id_seq OWNED BY literature.sources.source_id;


--
-- Name: attachments attachment_id; Type: DEFAULT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.attachments ALTER COLUMN attachment_id SET DEFAULT nextval('literature.attachments_attachment_id_seq'::regclass);


--
-- Name: authors author_id; Type: DEFAULT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.authors ALTER COLUMN author_id SET DEFAULT nextval('literature.authors_author_id_seq'::regclass);


--
-- Name: documents document_id; Type: DEFAULT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.documents ALTER COLUMN document_id SET DEFAULT nextval('literature.documents_document_id_seq'::regclass);


--
-- Name: keywords keyword_id; Type: DEFAULT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.keywords ALTER COLUMN keyword_id SET DEFAULT nextval('literature.keywords_keyword_id_seq'::regclass);


--
-- Name: sources source_id; Type: DEFAULT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.sources ALTER COLUMN source_id SET DEFAULT nextval('literature.sources_source_id_seq'::regclass);


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: literature; Owner: -
--

COPY literature.attachments (attachment_id, document_id, file_name, storage_uri, mime_type, file_size, checksum_sha256, access_level, can_download, created_at) FROM stdin;
1	12	LIT-000012.pdf	https://onlinelibrary.wiley.com/doi/pdfdirect/10.1002/9781118618974.fmatter	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
2	14	LIT-000014.pdf	https://onlinelibrary.wiley.com/doi/pdfdirect/10.1002/9781118618974.index	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
3	25	LIT-000025.pdf	https://onlinelibrary.wiley.com/doi/pdfdirect/10.1002/9781118618974.oth1	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
4	28	LIT-000028.pdf	https://onlinelibrary.wiley.com/doi/pdfdirect/10.1002/9781118618974.oth2	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
5	38	LIT-000038.pdf	https://iopscience.iop.org/article/10.1088/1757-899X/1309/1/012002/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
6	51	LIT-000051.pdf	https://doi.org/10.21275/v5i2.nov161550	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
7	56	LIT-000056.pdf	https://abmproceedings.com.br/ptbr/article/download-pdf/efsopr-system-technology-for-real-time-water-detection-in-eaf-steelmaking	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
8	66	LIT-000066.pdf	https://cvmet.misis.ru/jour/article/download/1426/616	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
9	82	LIT-000082.pdf	https://cvmet.misis.ru/jour/article/download/1609/730	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
10	88	LIT-000088.pdf	https://cvmet.misis.ru/jour/article/download/1525/679	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
11	89	LIT-000089.pdf	https://cvmet.misis.ru/jour/article/download/1425/615	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
12	96	LIT-000096.pdf	http://article.sciencepublishinggroup.com/pdf/10.11648.j.ijmpem.20180302.11.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
13	102	LIT-000102.pdf	https://tpm.ust.edu.ua/article/download/337444/325926	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
14	105	LIT-000105.pdf	https://iopscience.iop.org/article/10.1088/1742-6596/2798/1/012053/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
15	106	LIT-000106.pdf	http://journals.pan.pl/Content/89512/PDF/10172%20Volume%2060%20Issue%201-46%20paper.pdf.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
16	108	LIT-000108.pdf	https://www.mdpi.com/2075-163X/14/6/571/pdf?version=1717060596	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
17	115	LIT-000115.pdf	https://onlinelibrary.wiley.com/doi/pdfdirect/10.1002/srin.202000110	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
18	129	LIT-000129.pdf	https://www.intechopen.com/citation-pdf-url/63272	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
19	144	LIT-000144.pdf	https://link.springer.com/content/pdf/10.1007%2F978-981-16-2171-0_5.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
20	153	LIT-000153.pdf	http://ojs.omniscient.sg/index.php/ntec/article/download/74832/73234	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
21	154	LIT-000154.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/16829/15854	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
22	155	LIT-000155.pdf	https://ssci.cc/tpss/article/view/83/71	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
23	156	LIT-000156.pdf	https://www.sciengine.com/doi/pdf/A8C538CC599840E3ADC2717EAE9514C6	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
24	157	LIT-000157.pdf	http://qccdata.qichacha.com/ReportData/PDF/84ea5c56bc97fafdee3f7b0b65fff278.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
25	158	LIT-000158.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/77787/76146	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
26	159	LIT-000159.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/78135/76494	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
27	160	LIT-000160.pdf	https://ufascience.com/mea/article/download/2414/2179	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
28	161	LIT-000161.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/79363/77716	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
29	162	LIT-000162.pdf	https://wulixb.iphy.ac.cn/cn/article/pdf/preview/10.7498/aps.75.20260634.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
30	163	LIT-000163.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/79277/77630	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
31	164	LIT-000164.pdf	http://www.ysxb.ac.cn/data/article/aps/preview/pdf/10.18654/1000-0569/2026.06.11.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
32	165	LIT-000165.pdf	http://ojs.omniscient.sg/index.php/esra/article/download/79199/77552	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
33	166	LIT-000166.pdf	https://www.sciengine.com/doi/pdf/F156EFCFE4C548598630108B272E612C	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
34	167	LIT-000167.pdf	http://ojs.omniscient.sg/index.php/esra/article/download/78043/76402	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
35	168	LIT-000168.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/77022/75391	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
36	169	LIT-000169.pdf	http://www.ysxb.ac.cn/data/article/aps/preview/pdf/10.18654/1000-0569/2026.06.16.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
37	170	LIT-000170.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/79287/77640	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
38	171	LIT-000171.pdf	http://www.ysxb.ac.cn/data/article/aps/preview/pdf/10.18654/1000-0569/2026.08.02.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
39	172	LIT-000172.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/77004/75373	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
40	173	LIT-000173.pdf	https://perennial.pub/journal/jaet/display/175/jaet-00020.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
41	174	LIT-000174.pdf	http://ojs.omniscient.sg/index.php/emtr/article/download/77915/76273	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
42	175	LIT-000175.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/79421/77774	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
43	176	LIT-000176.pdf	http://ojs.omniscient.sg/index.php/emtr/article/download/78551/76908	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
44	177	LIT-000177.pdf	https://jpm.front-sci.com/index.php/jpm/article/download/8922/8731	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
45	178	LIT-000178.pdf	https://www.resci.cn/CN/PDF/10.18402/resci.2026.05.03	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
46	179	LIT-000179.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/79207/77560	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
47	182	LIT-000182.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/77827/76186	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
48	185	LIT-000185.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/79357/77710	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
49	186	LIT-000186.pdf	http://ojs.omniscient.sg/index.php/esra/article/download/78262/76619	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
50	187	LIT-000187.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/79211/77564	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
51	188	LIT-000188.pdf	http://ojs.omniscient.sg/index.php/emtr/article/download/79997/78340	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
52	189	LIT-000189.pdf	http://ojs.omniscient.sg/index.php/etaqm/article/download/79601/77953	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
53	190	LIT-000190.pdf	http://ojs.omniscient.sg/index.php/ntec/article/download/77997/76356	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
54	191	LIT-000191.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/79334/77687	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
55	192	LIT-000192.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/79335/77688	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
56	193	LIT-000193.pdf	http://ojs.omniscient.sg/index.php/esra/article/download/78018/76377	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
57	194	LIT-000194.pdf	https://www.sciengine.com/doi/pdf/DEEDC2040ABB46DD9F764B45072B6F32	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
58	195	LIT-000195.pdf	http://ojs.omniscient.sg/index.php/emtr/article/download/78538/76895	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
59	196	LIT-000196.pdf	https://www.resci.cn/CN/PDF/10.18402/resci.2026.05.04	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
60	197	LIT-000197.pdf	http://ojs.omniscient.sg/index.php/esra/article/download/80201/78543	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
61	198	LIT-000198.pdf	https://www.wisvora.org/index.php/rwsk/article/download/640/570	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
62	199	LIT-000199.pdf	http://ojs.omniscient.sg/index.php/etaqm/article/download/79648/78000	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
63	200	LIT-000200.pdf	http://ojs.omniscient.sg/index.php/uad/article/download/42585/41505	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
64	201	LIT-000201.pdf	https://www.sciengine.com/doi/pdf/1F7745D8E1764675AD516EAFB7563E94	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
65	202	LIT-000202.pdf	http://ojs.omniscient.sg/index.php/ntec/article/download/80072/78415	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
66	203	LIT-000203.pdf	http://ojs.omniscient.sg/index.php/emtr/article/download/79976/78319	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
67	204	LIT-000204.pdf	http://ojs.omniscient.sg/index.php/ntec/article/download/78955/77309	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
68	205	LIT-000205.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/79250/77603	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
69	206	LIT-000206.pdf	http://ojs.omniscient.sg/index.php/esra/article/download/76956/75325	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
70	207	LIT-000207.pdf	https://www.ecol-env-prot.com/index.php/eep/article/view/3144/3063	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
71	208	LIT-000208.pdf	http://ojs.omniscient.sg/index.php/emtr/article/download/79735/78087	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
72	209	LIT-000209.pdf	http://ojs.omniscient.sg/index.php/uad/article/download/80296/78638	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
73	210	LIT-000210.pdf	http://www.ysxb.ac.cn/data/article/aps/preview/pdf/10.18654/1000-0569/2026.07.16.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
74	211	LIT-000211.pdf	https://pdf.hanspub.org/ms_1282262.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
75	212	LIT-000212.pdf	http://www.ysxb.ac.cn/data/article/aps/preview/pdf/10.18654/1000-0569/2026.07.02.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
76	214	LIT-000214.pdf	https://www.sciengine.com/doi/pdf/A5249D71EE0E4D93A85ACF6B8E5E183B	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
77	215	LIT-000215.pdf	https://www.sciengine.com/doi/pdf/36DAD5941C324F7A8B3B1C9AB48B39C1	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
78	216	LIT-000216.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/79220/77573	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
79	217	LIT-000217.pdf	http://ojs.omniscient.sg/index.php/esra/article/download/80152/78494	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
80	218	LIT-000218.pdf	http://ojs.omniscient.sg/index.php/ntec/article/download/78971/77325	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
81	219	LIT-000219.pdf	http://ojs.omniscient.sg/index.php/mece/article/download/77834/76193	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
82	220	LIT-000220.pdf	http://ojs.omniscient.sg/index.php/mtrbc/article/download/79085/77439	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
83	221	LIT-000221.pdf	http://ojs.omniscient.sg/index.php/ntec/article/download/78879/77233	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
84	222	LIT-000222.pdf	http://ojs.omniscient.sg/index.php/mtrbc/article/download/77643/76003	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
85	223	LIT-000223.pdf	http://ojs.omniscient.sg/index.php/mepm/article/download/78462/76819	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
86	224	LIT-000224.pdf	http://ojs.omniscient.sg/index.php/ntec/article/download/78855/77209	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
87	225	LIT-000225.pdf	https://pdf.hanspub.org/me_2891135.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
88	226	LIT-000226.pdf	https://jpm.front-sci.com/index.php/jpm/article/download/8887/8696	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
89	227	LIT-000227.pdf	http://ojs.omniscient.sg/index.php/emtr/article/download/80019/78362	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
90	228	LIT-000228.pdf	https://wri.org.cn/sites/default/files/2021-12/toward-net-zero-emissions-road-transport-sector-china-CN.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
91	229	LIT-000229.pdf	http://ojs.omniscient.sg/index.php/mepm/article/download/77073/75442	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
92	230	LIT-000230.pdf	http://ojs.omniscient.sg/index.php/ntec/article/download/78003/76362	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
93	231	LIT-000231.pdf	http://www.ysxb.ac.cn/data/article/aps/preview/pdf/10.18654/1000-0569/2026.08.20.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
94	232	LIT-000232.pdf	https://www.sciengine.com/doi/pdf/D409F5A085F04C07AF39ADF0709C7CC8	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
95	233	LIT-000233.pdf	https://files.wri.org/d8/s3fs-public/2022-01/action-plans-policy-recommendations-vehicle-grid-integration-china_0.pdf?VersionId=N_9qVIMgzvUb132BB_px9MhP7pikbk12	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
96	235	LIT-000235.pdf	http://ojs.omniscient.sg/index.php/esra/article/download/79152/77505	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
97	236	LIT-000236.pdf	http://ojs.omniscient.sg/index.php/etaqm/article/download/73779/72212	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
98	238	LIT-000238.pdf	http://ojs.omniscient.sg/index.php/ntec/article/download/78960/77314	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
99	239	LIT-000239.pdf	https://www.sjzyhwh.cn/journal/shfzykjcx/2026/5/5.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
100	240	LIT-000240.pdf	https://www.chinacdc.cn/jkyj/crb2/yl/fjh/jswj_fjh/202410/P020241010432930570191.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
101	243	LIT-000243.pdf	https://www.sci-open.net/index.php/FET/article/download/4559/5732	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
102	246	LIT-000246.pdf	https://www.sciengine.com/doi/pdfView/7C60E2FF13734A8280626C62615AB0C5	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
103	247	LIT-000247.pdf	https://www.sciengine.com/doi/pdf/FF38AABAB0C74C4FAB53C74228FB3C70	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
104	248	LIT-000248.pdf	http://ojs.omniscient.sg/index.php/mepm/article/download/77734/76093	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
105	249	LIT-000249.pdf	http://ojs.omniscient.sg/index.php/ntec/article/download/60029/58784	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
106	250	LIT-000250.pdf	https://www.educ-res.com/index.php/er/article/view/7192/6849	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
107	251	LIT-000251.pdf	http://ojs.omniscient.sg/index.php/ntec/article/download/78013/76372	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
108	253	LIT-000253.pdf	http://ojs.omniscient.sg/index.php/tawcep/article/download/76717/75089	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
109	254	LIT-000254.pdf	http://ojs.omniscient.sg/index.php/ntec/article/download/78864/77218	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
110	255	LIT-000255.pdf	http://ojs.omniscient.sg/index.php/ntec/article/download/77985/76344	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
111	256	LIT-000256.pdf	http://ojs.omniscient.sg/index.php/tawcep/article/download/79943/78286	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
112	258	LIT-000258.pdf	http://ojs.omniscient.sg/index.php/esra/article/download/76916/75285	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
113	259	LIT-000259.pdf	http://ojs.omniscient.sg/index.php/uad/article/download/75967/74347	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
114	260	LIT-000260.pdf	https://www.sciengine.com/doi/pdf/DCC631FDFD544332AAC94051801F98CA	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
115	262	LIT-000262.pdf	https://pdf.hanspub.org/amc_3010245.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
116	263	LIT-000263.pdf	https://arxiv.org/pdf/1612.02496.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
117	264	LIT-000264.pdf	https://arxiv.org/pdf/2512.22277.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
118	265	LIT-000265.pdf	https://arxiv.org/pdf/2503.23739.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
119	266	LIT-000266.pdf	https://arxiv.org/pdf/cond-mat/0410213.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
120	267	LIT-000267.pdf	https://arxiv.org/pdf/1007.4442.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
121	268	LIT-000268.pdf	https://arxiv.org/pdf/2409.20119.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
122	269	LIT-000269.pdf	https://arxiv.org/pdf/cond-mat/0703564.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
123	270	LIT-000270.pdf	https://arxiv.org/pdf/1909.08147.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
124	271	LIT-000271.pdf	https://arxiv.org/pdf/1707.04287.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
125	272	LIT-000272.pdf	https://arxiv.org/pdf/1201.4176.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
126	273	LIT-000273.pdf	https://arxiv.org/pdf/2601.22407.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
127	274	LIT-000274.pdf	https://arxiv.org/pdf/1604.05270.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
128	275	LIT-000275.pdf	https://arxiv.org/pdf/2601.08202.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
129	276	LIT-000276.pdf	https://arxiv.org/pdf/2311.03088.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
130	277	LIT-000277.pdf	https://arxiv.org/pdf/2607.19239.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
131	278	LIT-000278.pdf	https://arxiv.org/pdf/2208.09434.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
132	279	LIT-000279.pdf	https://arxiv.org/pdf/2605.08620.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
133	280	LIT-000280.pdf	https://arxiv.org/pdf/2108.04110.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
134	281	LIT-000281.pdf	https://arxiv.org/pdf/2603.07378.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
135	282	LIT-000282.pdf	https://arxiv.org/pdf/2103.13978.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
136	283	LIT-000283.pdf	https://arxiv.org/pdf/2512.03050.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
137	284	LIT-000284.pdf	https://arxiv.org/pdf/2103.05567.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
138	285	LIT-000285.pdf	https://arxiv.org/pdf/2004.05424.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
139	286	LIT-000286.pdf	https://arxiv.org/pdf/2006.07552.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
140	287	LIT-000287.pdf	https://arxiv.org/pdf/cond-mat/0605577.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
141	288	LIT-000288.pdf	https://arxiv.org/pdf/2411.02053.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
142	289	LIT-000289.pdf	https://arxiv.org/pdf/2104.14603.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
143	290	LIT-000290.pdf	https://arxiv.org/pdf/cond-mat/0301391.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
144	291	LIT-000291.pdf	https://arxiv.org/pdf/2607.01997.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
145	292	LIT-000292.pdf	https://arxiv.org/pdf/2511.21854.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
146	293	LIT-000293.pdf	https://arxiv.org/pdf/2104.10648.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
147	294	LIT-000294.pdf	https://arxiv.org/pdf/1812.04306.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
148	295	LIT-000295.pdf	https://arxiv.org/pdf/1010.1871.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
149	296	LIT-000296.pdf	https://arxiv.org/pdf/2301.02132.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
150	297	LIT-000297.pdf	https://arxiv.org/pdf/2103.16603.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
151	298	LIT-000298.pdf	https://arxiv.org/pdf/2204.08706.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
152	299	LIT-000299.pdf	https://arxiv.org/pdf/1402.1715.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
153	300	LIT-000300.pdf	https://arxiv.org/pdf/2105.08259.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
154	301	LIT-000301.pdf	https://arxiv.org/pdf/2009.06890.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
155	302	LIT-000302.pdf	https://arxiv.org/pdf/2108.04647.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
156	303	LIT-000303.pdf	https://arxiv.org/pdf/1910.05166.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
157	304	LIT-000304.pdf	https://arxiv.org/pdf/0908.3840.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
158	305	LIT-000305.pdf	https://arxiv.org/pdf/0707.2711.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
159	306	LIT-000306.pdf	https://arxiv.org/pdf/1808.06456.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
160	307	LIT-000307.pdf	https://arxiv.org/pdf/1409.3300.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
161	308	LIT-000308.pdf	https://arxiv.org/pdf/1210.2735.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
162	309	LIT-000309.pdf	https://arxiv.org/pdf/2603.10667.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
163	310	LIT-000310.pdf	https://arxiv.org/pdf/1909.12769.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
164	311	LIT-000311.pdf	https://arxiv.org/pdf/2604.12003.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
165	312	LIT-000312.pdf	https://arxiv.org/pdf/2306.09703.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
166	313	LIT-000313.pdf	https://arxiv.org/pdf/1908.04444.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
167	314	LIT-000314.pdf	https://arxiv.org/pdf/2511.22182.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
168	315	LIT-000315.pdf	https://arxiv.org/pdf/1410.4857.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
169	316	LIT-000316.pdf	https://arxiv.org/pdf/2312.02321.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
170	317	LIT-000317.pdf	https://arxiv.org/pdf/1511.00832.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
171	318	LIT-000318.pdf	https://arxiv.org/pdf/2204.08253.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
172	319	LIT-000319.pdf	https://arxiv.org/pdf/2603.25626.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
173	320	LIT-000320.pdf	https://arxiv.org/pdf/0708.3034.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
174	321	LIT-000321.pdf	https://arxiv.org/pdf/2211.11531.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
175	322	LIT-000322.pdf	https://arxiv.org/pdf/2209.09069.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
176	323	LIT-000323.pdf	https://arxiv.org/pdf/2201.13356.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
177	324	LIT-000324.pdf	https://arxiv.org/pdf/2302.14215.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
178	325	LIT-000325.pdf	https://arxiv.org/pdf/2111.11538.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
179	326	LIT-000326.pdf	https://arxiv.org/pdf/0803.2831.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
180	327	LIT-000327.pdf	https://arxiv.org/pdf/2301.06391.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
181	328	LIT-000328.pdf	https://arxiv.org/pdf/1404.3930.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
182	329	LIT-000329.pdf	https://arxiv.org/pdf/2412.20552.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
183	330	LIT-000330.pdf	https://arxiv.org/pdf/2407.04902.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
184	331	LIT-000331.pdf	https://arxiv.org/pdf/2310.20464.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
185	332	LIT-000332.pdf	https://arxiv.org/pdf/1307.6952.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
186	333	LIT-000333.pdf	https://arxiv.org/pdf/2409.20512.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
187	334	LIT-000334.pdf	https://arxiv.org/pdf/2509.09998.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
188	335	LIT-000335.pdf	https://arxiv.org/pdf/2503.11361.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
189	336	LIT-000336.pdf	https://arxiv.org/pdf/2310.17283.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
190	337	LIT-000337.pdf	https://arxiv.org/pdf/1605.03592.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
191	338	LIT-000338.pdf	https://arxiv.org/pdf/1708.03584.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
192	339	LIT-000339.pdf	https://arxiv.org/pdf/2406.05348.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
193	340	LIT-000340.pdf	https://arxiv.org/pdf/1806.07843.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
194	341	LIT-000341.pdf	https://arxiv.org/pdf/1605.06408.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
195	342	LIT-000342.pdf	https://arxiv.org/pdf/cond-mat/0403102.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
196	343	LIT-000343.pdf	https://arxiv.org/pdf/cond-mat/9901216.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
197	344	LIT-000344.pdf	https://arxiv.org/pdf/1505.00878.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
198	345	LIT-000345.pdf	https://arxiv.org/pdf/1705.03862.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
199	346	LIT-000346.pdf	https://arxiv.org/pdf/1609.01392.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
200	347	LIT-000347.pdf	https://arxiv.org/pdf/2509.05344.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
201	348	LIT-000348.pdf	https://arxiv.org/pdf/2309.15859.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
202	349	LIT-000349.pdf	https://arxiv.org/pdf/2404.11637.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
203	350	LIT-000350.pdf	https://arxiv.org/pdf/1406.4164.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
204	351	LIT-000351.pdf	https://arxiv.org/pdf/2305.17790.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
205	352	LIT-000352.pdf	https://arxiv.org/pdf/cond-mat/0507429.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
206	353	LIT-000353.pdf	https://arxiv.org/pdf/2002.05471.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
207	354	LIT-000354.pdf	https://arxiv.org/pdf/1809.03025.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
208	355	LIT-000355.pdf	https://arxiv.org/pdf/1104.1868.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
209	356	LIT-000356.pdf	https://arxiv.org/pdf/2106.08378.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
210	357	LIT-000357.pdf	https://arxiv.org/pdf/cond-mat/0409288.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
211	358	LIT-000358.pdf	https://arxiv.org/pdf/1310.3778.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
212	359	LIT-000359.pdf	https://arxiv.org/pdf/2512.04880.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
213	360	LIT-000360.pdf	https://arxiv.org/pdf/1408.2705.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
214	361	LIT-000361.pdf	https://arxiv.org/pdf/2412.11960.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
215	362	LIT-000362.pdf	https://arxiv.org/pdf/2312.01144.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
216	363	LIT-000363.pdf	https://arxiv.org/pdf/2211.09347.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
217	364	LIT-000364.pdf	https://arxiv.org/pdf/2305.15290.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
218	365	LIT-000365.pdf	https://arxiv.org/pdf/1910.06603.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
219	366	LIT-000366.pdf	https://arxiv.org/pdf/2505.14710.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
220	367	LIT-000367.pdf	https://arxiv.org/pdf/2407.03763.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
221	368	LIT-000368.pdf	https://arxiv.org/pdf/2310.15510.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
222	369	LIT-000369.pdf	https://arxiv.org/pdf/2601.21672.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
223	370	LIT-000370.pdf	https://arxiv.org/pdf/2205.00697.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
224	371	LIT-000371.pdf	https://arxiv.org/pdf/2209.09516.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
225	372	LIT-000372.pdf	https://arxiv.org/pdf/cond-mat/0510399.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
226	373	LIT-000373.pdf	https://arxiv.org/pdf/2506.18362.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
227	374	LIT-000374.pdf	https://arxiv.org/pdf/2302.06317.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
228	375	LIT-000375.pdf	https://arxiv.org/pdf/1805.04231.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
229	376	LIT-000376.pdf	https://arxiv.org/pdf/1804.00165.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
230	377	LIT-000377.pdf	https://arxiv.org/pdf/2509.06323.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
231	378	LIT-000378.pdf	https://arxiv.org/pdf/1409.7219.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
232	379	LIT-000379.pdf	https://arxiv.org/pdf/2306.14513.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
233	380	LIT-000380.pdf	https://arxiv.org/pdf/2008.00684.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
234	381	LIT-000381.pdf	https://arxiv.org/pdf/2110.10564.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
235	382	LIT-000382.pdf	https://arxiv.org/pdf/2109.13918.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
236	383	LIT-000383.pdf	https://arxiv.org/pdf/cond-mat/0602636.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
237	384	LIT-000384.pdf	https://arxiv.org/pdf/1703.03758.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
238	385	LIT-000385.pdf	https://arxiv.org/pdf/2004.11629.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
239	386	LIT-000386.pdf	https://arxiv.org/pdf/1205.2383.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
240	387	LIT-000387.pdf	https://arxiv.org/pdf/1810.10166.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
241	388	LIT-000388.pdf	https://arxiv.org/pdf/1810.10163.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
242	389	LIT-000389.pdf	https://arxiv.org/pdf/1911.10975.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
243	390	LIT-000390.pdf	https://arxiv.org/pdf/1511.00325.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:30:19.684854+08
457	604	LIT-000604.pdf	https://www.sciencedirect.com/science/article/am/pii/S0927025620302998?via%3Dihub	application/pdf	\N	\N	public	t	2026-08-17 11:44:08.720183+08
458	605	LIT-000605.pdf	https://www.sciencedirect.com/science/article/pii/S1359645420308326/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:44:09.475891+08
459	606	LIT-000606.pdf	https://www.osti.gov/servlets/purl/1803661	application/pdf	\N	\N	public	t	2026-08-17 11:44:10.269986+08
460	607	LIT-000607.pdf	https://www.sciencedirect.com/science/article/am/pii/S0020740320342491	application/pdf	\N	\N	public	t	2026-08-17 11:44:10.942982+08
461	608	LIT-000608.pdf	https://www.sciencedirect.com/science/article/pii/S0304386X21000517/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:44:16.617485+08
462	609	LIT-000609.pdf	https://www.sciencedirect.com/science/article/pii/S0304386X19303640/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:44:19.193037+08
358	505	LIT-000505.pdf	https://www.sciencedirect.com/science/article/pii/S1359645416306759/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.558369+08
359	506	LIT-000506.pdf	https://www.sciencedirect.com/science/article/pii/S1369702115004010/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.576266+08
360	507	LIT-000507.pdf	https://www.nature.com/articles/ncomms7529.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.583983+08
361	508	LIT-000508.pdf	https://link.springer.com/content/pdf/10.1007/s40843-017-9195-8.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.591391+08
362	509	LIT-000509.pdf	https://www.sciencedirect.com/science/article/am/pii/S0079642518301178?via%3Dihub	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.595918+08
363	510	LIT-000510.pdf	https://www.sciencedirect.com/science/article/am/pii/S1359645416302610?via%3Dihub	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.603296+08
364	511	LIT-000511.pdf	https://www.nature.com/articles/s41529-017-0009-y.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.611024+08
365	512	LIT-000512.pdf	https://www.osti.gov/servlets/purl/1538047	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.617522+08
366	513	LIT-000513.pdf	https://opus.lib.uts.edu.au/bitstream/10453/41109/3/2-s2.0-84949654966%20am.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.621975+08
367	514	LIT-000514.pdf	https://www.sciencedirect.com/science/article/pii/S1044580318306636/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.627178+08
368	515	LIT-000515.pdf	https://pubs.rsc.org/en/content/articlepdf/2015/nr/c5nr01535a	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.632966+08
369	516	LIT-000516.pdf	https://www.nature.com/articles/s41524-017-0060-9.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.639652+08
370	517	LIT-000517.pdf	https://tecnologiammm.com.br/article/10.4322/2176-1523.1059/pdf/tmm-13-1-3.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.645729+08
371	518	LIT-000518.pdf	https://www.nature.com/articles/s41524-020-0308-7.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.650074+08
372	519	LIT-000519.pdf	https://www.sciencedirect.com/science/article/am/pii/S1359645417302598?via%3Dihub	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.658776+08
373	520	LIT-000520.pdf	https://www.osti.gov/servlets/purl/1287040	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.667941+08
374	521	LIT-000521.pdf	https://www.sciencedirect.com/science/article/pii/S026412752100085X/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.673487+08
375	522	LIT-000522.pdf	https://www.nature.com/articles/ncomms9485.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.678447+08
376	523	LIT-000523.pdf	https://www.sciencedirect.com/science/article/pii/S2213956722000779/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.686561+08
377	524	LIT-000524.pdf	https://www.osti.gov/servlets/purl/1483187	application/pdf	\N	\N	public	t	2026-08-17 11:35:11.692261+08
378	525	LIT-000525.pdf	https://www.mdpi.com/2075-4701/10/7/922/pdf?version=1594634690	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.865736+08
379	526	LIT-000526.pdf	https://link.springer.com/content/pdf/10.1007/s40831-023-00778-y.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.873604+08
380	527	LIT-000527.pdf	https://link.springer.com/content/pdf/10.1007/s12613-021-2400-5.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.878804+08
381	528	LIT-000528.pdf	https://www.mdpi.com/2075-4701/9/3/273/pdf?version=1551322491	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.88456+08
382	529	LIT-000529.pdf	https://www.mdpi.com/1996-1944/15/3/1147/pdf?version=1644327221	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.889052+08
383	530	LIT-000530.pdf	https://pure-oai.bham.ac.uk/ws/files/188084033/1_s2.0_S095965262300121X_main.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.895204+08
384	531	LIT-000531.pdf	https://www.mdpi.com/2075-4701/11/2/222/pdf?version=1611924811	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.899913+08
385	532	LIT-000532.pdf	https://www.jstage.jst.go.jp/article/isijinternational/62/12/62_ISIJINT-2022-117/_pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.904434+08
386	533	LIT-000533.pdf	https://www.mdpi.com/1996-1073/13/3/758/pdf?version=1581507982	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.911102+08
387	534	LIT-000534.pdf	https://www.mdpi.com/2075-163X/8/12/561/pdf?version=1544704898	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.916683+08
388	535	LIT-000535.pdf	https://zaguan.unizar.es/record/125764/files/texto_completo.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.921746+08
389	536	LIT-000536.pdf	https://www.jstage.jst.go.jp/article/isijinternational/59/12/59_ISIJINT-2019-337/_pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.928059+08
390	537	LIT-000537.pdf	https://www.jstage.jst.go.jp/article/isijinternational/56/10/56_ISIJINT-2016-210/_pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.932898+08
391	538	LIT-000538.pdf	https://durham-repository.worktribe.com/file/4690934/1/Accepted%20Journal%20Article	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.938667+08
392	539	LIT-000539.pdf	https://www.sciencedirect.com/science/article/pii/S2351978919306705/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.948038+08
393	540	LIT-000540.pdf	https://link.springer.com/content/pdf/10.1007/s40831-024-00940-0.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.954251+08
394	541	LIT-000541.pdf	https://onlinelibrary.wiley.com/doi/pdfdirect/10.1002/srin.202300854	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.959307+08
395	542	LIT-000542.pdf	https://www.sciencedirect.com/science/article/pii/S0959652621018837/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.966864+08
396	543	LIT-000543.pdf	https://www.mdpi.com/2075-4701/13/5/978/pdf?version=1684460464	application/pdf	\N	\N	public	t	2026-08-17 11:35:12.973686+08
397	544	LIT-000544.pdf	https://www.mdpi.com/2313-4321/2/4/20/pdf?version=1509431074	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.249322+08
398	545	LIT-000545.pdf	https://www.sciencedirect.com/science/article/pii/S0956053X21001082/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.256458+08
399	546	LIT-000546.pdf	https://link.springer.com/content/pdf/10.1007/s40831-017-0128-2.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.264401+08
400	547	LIT-000547.pdf	https://www.nature.com/articles/srep14574.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.269532+08
401	548	LIT-000548.pdf	https://www.nature.com/articles/s41467-018-04060-8.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.274031+08
402	549	LIT-000549.pdf	https://www.sciencedirect.com/science/article/pii/S1383586621016403/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.279901+08
403	550	LIT-000550.pdf	https://www.sciencedirect.com/science/article/pii/S2666790821001749/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.284032+08
404	551	LIT-000551.pdf	https://www.tandfonline.com/doi/pdf/10.1080/10643389.2018.1540760?needAccess=true	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.288379+08
405	552	LIT-000552.pdf	https://www.sciencedirect.com/science/article/pii/S1878029616000232/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.296554+08
406	553	LIT-000553.pdf	https://www.mdpi.com/2305-6304/10/5/231/pdf?version=1652179825	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.300947+08
407	554	LIT-000554.pdf	https://www.mdpi.com/2305-7084/6/1/6/pdf?version=1641548422	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.307923+08
408	555	LIT-000555.pdf	https://www.mdpi.com/2075-163X/10/12/1097/pdf?version=1607390461	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.311855+08
409	556	LIT-000556.pdf	https://www.sciencedirect.com/science/article/pii/S092134491830449X/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.317696+08
410	557	LIT-000557.pdf	https://ars.els-cdn.com/content/image/1-s2.0-S2300396018301836-fx1_lrg.jpg	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.325598+08
411	558	LIT-000558.pdf	https://lirias.kuleuven.be/retrieve/09a97f1e-be9b-42ea-8bac-a26a44b82d35	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.331246+08
412	559	LIT-000559.pdf	https://link.springer.com/content/pdf/10.1007/s10311-023-01611-4.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.340464+08
413	560	LIT-000560.pdf	https://www.nature.com/articles/s41598-020-66894-x.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.345748+08
414	561	LIT-000561.pdf	https://www.sciencedirect.com/science/article/pii/S2666821120300235/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.352369+08
415	562	LIT-000562.pdf	https://link.springer.com/content/pdf/10.1007/s40436-015-0132-3.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.358293+08
416	563	LIT-000563.pdf	https://www.mdpi.com/2075-4701/5/3/1620/pdf?version=1441978599	application/pdf	\N	\N	public	t	2026-08-17 11:35:14.363148+08
417	564	LIT-000564.pdf	https://www.sciencedirect.com/science/article/pii/S1359646222000720/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.827262+08
418	565	LIT-000565.pdf	https://ars.els-cdn.com/content/image/1-s2.0-S0959652622044195-ga1_lrg.jpg	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.869886+08
419	566	LIT-000566.pdf	https://ars.els-cdn.com/content/image/1-s2.0-S0306261923005627-ga1_lrg.jpg	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.881161+08
420	567	LIT-000567.pdf	https://www.sciencedirect.com/science/article/pii/S0959652619330550/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.888978+08
421	568	LIT-000568.pdf	https://www.mdpi.com/2075-4701/10/9/1117/pdf?version=1605262478	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.898726+08
422	569	LIT-000569.pdf	https://ieeexplore.ieee.org/ielx7/6287639/6514899/10424973.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.905654+08
423	570	LIT-000570.pdf	https://www.mdpi.com/1996-1073/13/15/3840/pdf?version=1595847190	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.916783+08
424	571	LIT-000571.pdf	https://www.nature.com/articles/s41560-024-01684-7.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.92593+08
425	572	LIT-000572.pdf	https://www.nature.com/articles/s41467-023-38123-2.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.931434+08
426	573	LIT-000573.pdf	https://pubs.acs.org/doi/pdf/10.1021/acs.est.4c05756?ref=article_openPDF	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.938314+08
427	574	LIT-000574.pdf	https://pubs.acs.org/doi/pdf/10.1021/acs.chemrev.4c00787?ref=article_openPDF	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.943909+08
428	575	LIT-000575.pdf	https://shareok.org/bitstreams/e18438b3-60b5-4174-a06b-c201a7f513d4/download	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.948811+08
429	576	LIT-000576.pdf	https://www.nature.com/articles/s41467-023-43540-4.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.955279+08
430	577	LIT-000577.pdf	https://hal.science/hal-05072295/document	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.961498+08
431	578	LIT-000578.pdf	https://www.sciencedirect.com/science/article/pii/S1876380421600393/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.967286+08
432	579	LIT-000579.pdf	https://link.springer.com/content/pdf/10.1007/s40789-021-00458-w.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.975195+08
433	580	LIT-000580.pdf	https://www.frontiersin.org/articles/10.3389/fenrg.2020.00142/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.980405+08
434	581	LIT-000581.pdf	https://pubs.rsc.org/en/content/articlepdf/2020/ee/d0ee00787k	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.986687+08
435	582	LIT-000582.pdf	https://pubs.acs.org/doi/pdf/10.1021/acs.est.9b01265	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.991655+08
436	583	LIT-000583.pdf	https://research.chalmers.se/publication/534854/file/534854_Fulltext.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:16.998162+08
437	584	LIT-000584.pdf	http://www.scielo.org.za/pdf/jsaimm/v118n8/07.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.254964+08
438	585	LIT-000585.pdf	https://www.mdpi.com/1996-1944/14/9/2211/pdf?version=1619404420	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.259056+08
439	586	LIT-000586.pdf	https://www.sciencedirect.com/science/article/pii/S2238785419301620/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.264521+08
440	587	LIT-000587.pdf	https://www.mdpi.com/1996-1944/13/19/4251/pdf?version=1600935298	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.26955+08
441	588	LIT-000588.pdf	https://www.mdpi.com/1996-1944/15/3/727/pdf?version=1642556578	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.274664+08
442	589	LIT-000589.pdf	https://www.sciencedirect.com/science/article/pii/S2095268622000015/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.281146+08
443	590	LIT-000590.pdf	https://www.mdpi.com/2075-4701/13/10/1768/pdf?version=1697607502	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.286176+08
444	591	LIT-000591.pdf	https://www.sciencedirect.com/science/article/am/pii/S0959652620314013?via%3Dihub	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.291983+08
445	592	LIT-000592.pdf	https://www.mdpi.com/2071-1050/12/21/9295/pdf?version=1605058975	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.297959+08
446	593	LIT-000593.pdf	https://www.mdpi.com/2073-4352/11/12/1504/pdf?version=1638519387	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.305914+08
447	594	LIT-000594.pdf	https://www.sciencedirect.com/science/article/pii/S0147651321004322/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.314917+08
448	595	LIT-000595.pdf	https://www.jstage.jst.go.jp/article/isijinternational/60/3/60_ISIJINT-2019-173/_pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.323195+08
449	596	LIT-000596.pdf	https://www.mdpi.com/1996-1944/16/23/7295/pdf?version=1700739363	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.329742+08
450	597	LIT-000597.pdf	https://www.mdpi.com/1996-1944/13/6/1448/pdf?version=1584877331	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.33708+08
451	598	LIT-000598.pdf	https://www.degruyter.com/downloadpdf/journals/secm/26/1/article-p449.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.349315+08
452	599	LIT-000599.pdf	https://www.mdpi.com/2075-163X/13/6/737/pdf?version=1685956089	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.356056+08
453	600	LIT-000600.pdf	https://www.mdpi.com/1996-1944/15/11/3803/pdf?version=1653643758	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.36514+08
454	601	LIT-000601.pdf	http://downloads.hindawi.com/journals/complexity/2018/6703908.pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.372295+08
455	602	LIT-000602.pdf	https://www.mdpi.com/2071-1050/15/3/2518/pdf?version=1675150874	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.380494+08
456	603	LIT-000603.pdf	https://www.sciencedirect.com/science/article/pii/S0301479718305875/pdf	application/pdf	\N	\N	public	t	2026-08-17 11:35:19.387514+08
\.


--
-- Data for Name: authors; Type: TABLE DATA; Schema: literature; Owner: -
--

COPY literature.authors (author_id, author_name, author_name_en, institution, orcid, created_at) FROM stdin;
1651	D.B. Miracle	\N	United States Air Force Research Laboratory	\N	2026-08-17 11:35:11.558369+08
2	Armando Vazquez	\N	\N	\N	2026-07-28 10:25:58.663065+08
1652	O.N. Senkov	\N	United States Air Force Research Laboratory	\N	2026-08-17 11:35:11.558369+08
1653	Y.F. Ye	\N	City University of Hong Kong	\N	2026-08-17 11:35:11.576266+08
1654	Q. Wang	\N	City University of Hong Kong	\N	2026-08-17 11:35:11.576266+08
1655	Jian Lü	\N	City University of Hong Kong	\N	2026-08-17 11:35:11.576266+08
1656	C.T. Liu	\N	City University of Hong Kong	\N	2026-08-17 11:35:11.576266+08
1657	Yong Yang	\N	City University of Hong Kong	\N	2026-08-17 11:35:11.576266+08
1658	Jonathan D. Miller	\N	United States Air Force Research Laboratory	\N	2026-08-17 11:35:11.583983+08
1659	C. Woodward	\N	United States Air Force Research Laboratory	\N	2026-08-17 11:35:11.583983+08
1660	Weiran Zhang	\N	University of Tennessee at Knoxville	\N	2026-08-17 11:35:11.591391+08
1661	Peter K. Liaw	\N	University of Tennessee at Knoxville	\N	2026-08-17 11:35:11.591391+08
1662	Zezhou Li	\N	University of California San Diego	\N	2026-08-17 11:35:11.595918+08
1663	Shiteng Zhao	\N	Lawrence Berkeley National Laboratory	\N	2026-08-17 11:35:11.595918+08
1664	Robert O. Ritchie	\N	Lawrence Berkeley National Laboratory	\N	2026-08-17 11:35:11.595918+08
1665	Marc A. Meyers	\N	University of California San Diego	\N	2026-08-17 11:35:11.595918+08
1666	F. Otto	\N	Ruhr University Bochum	\N	2026-08-17 11:35:11.603296+08
1667	A. Dlouhý	\N	Czech Academy of Sciences, Institute of Physics of Materials	\N	2026-08-17 11:35:11.603296+08
1668	K.G. Pradeep	\N	Max-Planck-Institut für Nachhaltige Materialien	\N	2026-08-17 11:35:11.603296+08
1669	M. Kuběnová	\N	Czech Academy of Sciences, Institute of Physics of Materials	\N	2026-08-17 11:35:11.603296+08
1670	Gunther Eggeler	\N	Ruhr University Bochum	\N	2026-08-17 11:35:11.603296+08
1671	E.P. George	\N	Ruhr University Bochum	\N	2026-08-17 11:35:11.603296+08
1672	Yao Qiu	\N	Monash University	\N	2026-08-17 11:35:11.611024+08
1673	S. Thomas	\N	Monash University	\N	2026-08-17 11:35:11.611024+08
1674	Mark A. Gibson	\N	CSIRO Manufacturing	\N	2026-08-17 11:35:11.611024+08
1675	Hamish L. Fraser	\N	The Ohio State University	\N	2026-08-17 11:35:11.611024+08
1676	N. Birbilis	\N	Monash University	\N	2026-08-17 11:35:11.611024+08
1677	Renhai Shi	\N	The Ohio State University	\N	2026-08-17 11:35:11.617522+08
1678	Alan A. Luo	\N	The Ohio State University	\N	2026-08-17 11:35:11.617522+08
1679	D.J.M. King	\N	University of Technology Sydney	\N	2026-08-17 11:35:11.621975+08
1680	Simon C. Middleburgh	\N	Westinghouse Electric (Sweden)	\N	2026-08-17 11:35:11.621975+08
1681	A.G. McGregor	\N	\N	\N	2026-08-17 11:35:11.621975+08
1682	Michael B. Cortie	\N	University of Technology Sydney	\N	2026-08-17 11:35:11.621975+08
1683	Yuji Ikeda	\N	Kyoto University	\N	2026-08-17 11:35:11.627178+08
1684	Blazej Grabowski	\N	Max-Planck-Institut für Nachhaltige Materialien	\N	2026-08-17 11:35:11.627178+08
1685	Fritz Körmann	\N	Max-Planck-Institut für Nachhaltige Materialien	\N	2026-08-17 11:35:11.627178+08
1686	Saurabh Bajaj	\N	California Institute of Technology	\N	2026-08-17 11:35:11.632966+08
1687	Michael Haverty	\N	Intel (United States)	\N	2026-08-17 11:35:11.632966+08
1688	Raymundo Arróyave	\N	Texas A&M University	\N	2026-08-17 11:35:11.632966+08
1689	William A. Goddard III FRSC	\N	California Institute of Technology	\N	2026-08-17 11:35:11.632966+08
1690	Sadasivan Shankar	\N	Harvard University	\N	2026-08-17 11:35:11.632966+08
1691	Won-Mi Choi	\N	Pohang University of Science and Technology	\N	2026-08-17 11:35:11.639652+08
1692	Yong Hee Jo	\N	Pohang University of Science and Technology	\N	2026-08-17 11:35:11.639652+08
1693	Seok Su Sohn	\N	Pohang University of Science and Technology	\N	2026-08-17 11:35:11.639652+08
1694	Sunghak Lee	\N	Pohang University of Science and Technology	\N	2026-08-17 11:35:11.639652+08
1695	Byeong‐Joo Lee	\N	Pohang University of Science and Technology	\N	2026-08-17 11:35:11.639652+08
1696	Ursula R. Kattner	\N	National Institute of Standards and Technology	\N	2026-08-17 11:35:11.645729+08
48	B Mitas	\N	\N	\N	2026-07-28 10:26:05.562167+08
49	H Pauna	\N	\N	\N	2026-07-28 10:26:05.562167+08
50	J Feldbacher	\N	\N	\N	2026-07-28 10:26:05.562167+08
51	J Schenk	\N	\N	\N	2026-07-28 10:26:05.562167+08
1697	Zongrui Pei	\N	Oak Ridge Associated Universities	\N	2026-08-17 11:35:11.650074+08
1698	Junqi Yin	\N	Oak Ridge National Laboratory	\N	2026-08-17 11:35:11.650074+08
1699	David E. Alman	\N	National Energy Technology Laboratory	\N	2026-08-17 11:35:11.650074+08
1700	Michael C. Gao	\N	Leidos (United States)	\N	2026-08-17 11:35:11.650074+08
1701	Jiancun Rao	\N	University of Groningen	\N	2026-08-17 11:35:11.658776+08
1702	H. Diao	\N	University of Tennessee at Knoxville	\N	2026-08-17 11:35:11.658776+08
1703	V. Ocelı́k	\N	University of Groningen	\N	2026-08-17 11:35:11.658776+08
1704	David I. Vainchtein	\N	University of Groningen	\N	2026-08-17 11:35:11.658776+08
1705	Chenyu Zhang	\N	CompuTherm (United States)	\N	2026-08-17 11:35:11.658776+08
1706	C. M. Kuo	\N	University of Tennessee at Knoxville	\N	2026-08-17 11:35:11.658776+08
1707	Zijian Tang	\N	University of Tennessee at Knoxville	\N	2026-08-17 11:35:11.658776+08
1708	Wenze Guo	\N	Oak Ridge National Laboratory	\N	2026-08-17 11:35:11.658776+08
1709	Jonathan D. Poplawsky	\N	Oak Ridge National Laboratory	\N	2026-08-17 11:35:11.658776+08
1710	Yun Zhou	\N	Harbin Institute of Technology	\N	2026-08-17 11:35:11.658776+08
1711	J. Th. M. De Hosson	\N	University of Groningen	\N	2026-08-17 11:35:11.658776+08
1712	Chuan Zhang	\N	CompuTherm (United States)	\N	2026-08-17 11:35:11.667941+08
1713	Haoyan Diao	\N	University of Tennessee at Knoxville	\N	2026-08-17 11:35:11.667941+08
1714	Zhi Tang	\N	University of Tennessee at Knoxville	\N	2026-08-17 11:35:11.667941+08
1715	Yingzhi Zeng	\N	Agency for Science, Technology and Research	\N	2026-08-17 11:35:11.673487+08
1716	Mengren Man	\N	Agency for Science, Technology and Research	\N	2026-08-17 11:35:11.673487+08
1717	Kewu Bai	\N	Agency for Science, Technology and Research	\N	2026-08-17 11:35:11.673487+08
1718	Yongwei Zhang	\N	Agency for Science, Technology and Research	\N	2026-08-17 11:35:11.673487+08
1719	Christina M. Rost	\N	North Carolina State University	\N	2026-08-17 11:35:11.678447+08
1720	Edward Sachet	\N	North Carolina State University	\N	2026-08-17 11:35:11.678447+08
1721	Trent Borman	\N	North Carolina State University	\N	2026-08-17 11:35:11.678447+08
1722	Ali Moballegh	\N	North Carolina State University	\N	2026-08-17 11:35:11.678447+08
1723	Elizabeth C. Dickey	\N	North Carolina State University	\N	2026-08-17 11:35:11.678447+08
1724	Dong Hou	\N	North Carolina State University	\N	2026-08-17 11:35:11.678447+08
1725	Jacob L. Jones	\N	North Carolina State University	\N	2026-08-17 11:35:11.678447+08
1726	Stefano Curtarolo	\N	Duke University	\N	2026-08-17 11:35:11.678447+08
1727	Jon‐Paul Maria	\N	North Carolina State University	\N	2026-08-17 11:35:11.678447+08
1728	Janet Meier	\N	The Ohio State University	\N	2026-08-17 11:35:11.686561+08
1729	Josh Caris	\N	\N	\N	2026-08-17 11:35:11.686561+08
1730	Yunzhu Shi	\N	University of Tennessee at Knoxville	\N	2026-08-17 11:35:11.692261+08
1731	Liam Collins	\N	Oak Ridge National Laboratory	\N	2026-08-17 11:35:11.692261+08
127	A. V. Kolesnikov	\N	\N	\N	2026-07-28 10:26:06.573339+08
128	E. I. Ageenko	\N	\N	\N	2026-07-28 10:26:06.573339+08
136	A. A. Lavrinenko	\N	\N	\N	2026-07-28 10:26:06.646718+08
137	I. N. Kuznetsova	\N	\N	\N	2026-07-28 10:26:06.646718+08
138	G. Yu. Golberg	\N	\N	\N	2026-07-28 10:26:06.646718+08
139	O. G. Lusinyan	\N	\N	\N	2026-07-28 10:26:06.646718+08
1732	Rui Feng	\N	University of Tennessee at Knoxville	\N	2026-08-17 11:35:11.692261+08
1733	Nina Balke	\N	Oak Ridge National Laboratory	\N	2026-08-17 11:35:11.692261+08
1734	Bin Yang	\N	University of Science and Technology Beijing	\N	2026-08-17 11:35:11.692261+08
1735	Olivier Mirgaux	\N	Centre National de la Recherche Scientifique	\N	2026-08-17 11:35:12.865736+08
1736	Anton Andersson	\N	Luleå University of Technology	\N	2026-08-17 11:35:12.873604+08
1737	Jenny Isaksson	\N	Luleå University of Technology	\N	2026-08-17 11:35:12.873604+08
1738	Andreas Lennartsson	\N	Luleå University of Technology	\N	2026-08-17 11:35:12.873604+08
1739	Fredrik Engström	\N	Luleå University of Technology	\N	2026-08-17 11:35:12.873604+08
1740	Hiroyuki Matsuura	\N	The University of Tokyo	\N	2026-08-17 11:35:12.878804+08
1741	Xiao Yang	\N	Westlake University	\N	2026-08-17 11:35:12.878804+08
150	A. M. Klyushnikov	\N	\N	\N	2026-07-28 10:26:06.679877+08
151	G. I. Maltsev	\N	\N	\N	2026-07-28 10:26:06.679877+08
1742	Guangqiang Li	\N	Wuhan University of Science and Technology	\N	2026-08-17 11:35:12.878804+08
1743	Zhangfu Yuan	\N	University of Science and Technology Beijing	\N	2026-08-17 11:35:12.878804+08
1744	Fumitaka Tsukihashi	\N	The University of Tokyo	\N	2026-08-17 11:35:12.878804+08
1745	Kai Dong	\N	University of Science and Technology Beijing	\N	2026-08-17 11:35:12.88456+08
1746	Xueliang Wang	\N	University of Science and Technology Beijing	\N	2026-08-17 11:35:12.88456+08
1747	Oleg Bazaluk	\N	Guangdong University of Petrochemical Technology	\N	2026-08-17 11:35:12.889052+08
1748	Lina Kieush	\N	National Metallurgical Academy of Ukraine	\N	2026-08-17 11:35:12.889052+08
1749	Andrii Koveria	\N	Dnipro University of Technology	\N	2026-08-17 11:35:12.889052+08
1750	Johannes Schenk	\N	Montanuniversität Leoben	\N	2026-08-17 11:35:12.889052+08
1751	A. Pfeiffer	\N	Montanuniversität Leoben	\N	2026-08-17 11:35:12.889052+08
1752	Heng Zheng	\N	Montanuniversität Leoben	\N	2026-08-17 11:35:12.889052+08
1753	Vasyl Lozynskyi	\N	Dnipro University of Technology	\N	2026-08-17 11:35:12.889052+08
1754	Harriet Kildahl	\N	University of Birmingham	\N	2026-08-17 11:35:12.895204+08
1755	Li Wang	\N	University of Science and Technology Beijing	\N	2026-08-17 11:35:12.895204+08
1756	Lige Tong	\N	University of Science and Technology Beijing	\N	2026-08-17 11:35:12.895204+08
1757	Yulong Ding	\N	University of Birmingham	\N	2026-08-17 11:35:12.895204+08
168	Yan Junjie	\N	\N	\N	2026-07-28 10:26:07.845946+08
1758	Thomas Echterhof	\N	RWTH Aachen University	\N	2026-08-17 11:35:12.899913+08
1759	Kaoru Nakano	\N	Nippon Steel (Japan)	\N	2026-08-17 11:35:12.904434+08
1760	Hiroshi Sakai	\N	Nippon Steel (Japan)	\N	2026-08-17 11:35:12.904434+08
1761	Yutaka Ujisawa	\N	Nippon Steel (Japan)	\N	2026-08-17 11:35:12.904434+08
1762	Kazumoto Kakiuchi	\N	\N	\N	2026-08-17 11:35:12.904434+08
1763	Koki Nishioka	\N	Nippon Steel (Japan)	\N	2026-08-17 11:35:12.904434+08
1764	Kohei Sunahara	\N	Nippon Steel (Japan)	\N	2026-08-17 11:35:12.904434+08
1765	Yoshinori Matsukura	\N	Nippon Steel (Japan)	\N	2026-08-17 11:35:12.904434+08
1766	Hirokazu Yokoyama	\N	Nippon Steel (Japan)	\N	2026-08-17 11:35:12.904434+08
1767	Abhinav Bhaskar	\N	University of Stavanger	\N	2026-08-17 11:35:12.911102+08
1768	Mohsen Assadi	\N	University of Stavanger	\N	2026-08-17 11:35:12.911102+08
1769	Homam Nikpey Somehsaraei	\N	University of Stavanger	\N	2026-08-17 11:35:12.911102+08
1770	Hesham M. Ahmed	\N	Luleå University of Technology	\N	2026-08-17 11:35:12.916683+08
1771	Jorge Perpiñán	\N	Universidad de Zaragoza	\N	2026-08-17 11:35:12.921746+08
1772	Manuel Bailera	\N	Universidad de Zaragoza	\N	2026-08-17 11:35:12.921746+08
184	ZhouHua Jiang	\N	\N	\N	2026-07-28 10:26:07.89892+08
185	Ce Yang	\N	\N	\N	2026-07-28 10:26:07.89892+08
186	HongChun Zhu	\N	\N	\N	2026-07-28 10:26:07.89892+08
187	HongBin Lu	\N	\N	\N	2026-07-28 10:26:07.89892+08
1773	Begoña Peña	\N	Universidad de Zaragoza	\N	2026-08-17 11:35:12.921746+08
1774	Luis M. Romeo	\N	Universidad de Zaragoza	\N	2026-08-17 11:35:12.921746+08
1775	Valérie Eveloy	\N	Khalifa University of Science and Technology	\N	2026-08-17 11:35:12.921746+08
1776	Alexander Babich	\N	Ferro (United States)	\N	2026-08-17 11:35:12.928059+08
1777	Dieter Senk	\N	Ferro (United States)	\N	2026-08-17 11:35:12.928059+08
1778	Jon Solar	\N	\N	\N	2026-08-17 11:35:12.928059+08
194	Yuanchang Guo	\N	\N	\N	2026-07-28 10:26:07.924798+08
195	Xinyi Wang	\N	\N	\N	2026-07-28 10:26:07.924798+08
196	Kangze Deng	\N	\N	\N	2026-07-28 10:26:07.924798+08
197	K. Vrbek	\N	\N	\N	2026-07-28 10:26:07.933921+08
198	J. Lamut	\N	\N	\N	2026-07-28 10:26:07.933921+08
199	M. Marolt	\N	\N	\N	2026-07-28 10:26:07.933921+08
200	M. Knap	\N	\N	\N	2026-07-28 10:26:07.933921+08
201	Hailin Long	\N	\N	\N	2026-07-28 10:26:07.948039+08
202	Deqing Zhu	\N	\N	\N	2026-07-28 10:26:07.948039+08
203	Jian Pan	\N	\N	\N	2026-07-28 10:26:07.948039+08
204	Siwei Li	\N	\N	\N	2026-07-28 10:26:07.948039+08
205	Congcong Yang	\N	\N	\N	2026-07-28 10:26:07.948039+08
206	Zhengqi Guo	\N	\N	\N	2026-07-28 10:26:07.948039+08
1779	Isabel de Marco	\N	\N	\N	2026-08-17 11:35:12.928059+08
1780	Tatsuro Ariyama	\N	Tohoku University	\N	2026-08-17 11:35:12.932898+08
1781	Michitaka Sato	\N	\N	\N	2026-08-17 11:35:12.932898+08
1782	Taihei Nouchi	\N	\N	\N	2026-08-17 11:35:12.932898+08
1783	Koichi Takahashi	\N	\N	\N	2026-08-17 11:35:12.932898+08
1784	R.Q. Wang	\N	Durham University	\N	2026-08-17 11:35:12.938667+08
1785	L. Jiang	\N	Zhejiang Energy Research Institute	\N	2026-08-17 11:35:12.938667+08
1786	Yaodong Wang	\N	Durham University	\N	2026-08-17 11:35:12.938667+08
1787	Carolina Font-Palma	\N	University of Hull	\N	2026-08-17 11:35:12.938667+08
1788	Vasiliki Skoulou	\N	University of Hull	\N	2026-08-17 11:35:12.938667+08
1789	Anthony Paul Roskilly	\N	Durham University	\N	2026-08-17 11:35:12.938667+08
1790	Comfort Ramakgala	\N	Botswana International University of Science and Technology	\N	2026-08-17 11:35:12.948038+08
1791	Gwiranai Danha	\N	Botswana International University of Science and Technology	\N	2026-08-17 11:35:12.948038+08
1792	Christopher DiGiovanni	\N	Natural Resources Canada	\N	2026-08-17 11:35:12.954251+08
1793	Matthew Kurecki	\N	Arizona State University	\N	2026-08-17 11:35:12.959307+08
1794	N. Meena	\N	Brandenburg University of Applied Sciences	\N	2026-08-17 11:35:12.959307+08
1795	Tetiana Shyrokykh	\N	Arizona State University	\N	2026-08-17 11:35:12.959307+08
1796	Yuri Korobeinikov	\N	Arizona State University	\N	2026-08-17 11:35:12.959307+08
1797	Tova Jarnerud	\N	Swerim	\N	2026-08-17 11:35:12.959307+08
1798	Z. Voß	\N	Oriental University	\N	2026-08-17 11:35:12.959307+08
1799	Eugene B. Pretorius	\N	China Steel (Taiwan)	\N	2026-08-17 11:35:12.959307+08
236	Katharina Rechberger	\N	\N	\N	2026-07-28 10:26:08.027466+08
237	Andreas Spanlang	\N	\N	\N	2026-07-28 10:26:08.027466+08
238	Amaia Sasiain Conde	\N	\N	\N	2026-07-28 10:26:08.027466+08
239	Hermann Wolfmeir	\N	\N	\N	2026-07-28 10:26:08.027466+08
240	Christopher Harris	\N	\N	\N	2026-07-28 10:26:08.027466+08
264	Elena Brandaleze	\N	\N	\N	2026-07-28 10:26:08.790194+08
265	Edgardo Benavidez	\N	\N	\N	2026-07-28 10:26:08.790194+08
266	Leandro Santini	\N	\N	\N	2026-07-28 10:26:08.790194+08
1800	Jeremy Jones	\N	Oriental University	\N	2026-08-17 11:35:12.959307+08
1801	Seetharaman Sridhar	\N	Arizona State University	\N	2026-08-17 11:35:12.959307+08
1802	Andrew Pimm	\N	University of Leeds	\N	2026-08-17 11:35:12.966864+08
1803	Tim Cockerill	\N	University of Leeds	\N	2026-08-17 11:35:12.966864+08
1804	William F. Gale	\N	University of Leeds	\N	2026-08-17 11:35:12.966864+08
275	Lan’er Wu	\N	\N	\N	2026-07-28 10:26:08.861471+08
276	Fenglan Han	\N	\N	\N	2026-07-28 10:26:08.861471+08
277	Guiqun Liu	\N	\N	\N	2026-07-28 10:26:08.861471+08
1805	Daniel Ernst	\N	\N	\N	2026-08-17 11:35:12.973686+08
1806	Gerald Wimmer	\N	Primetals Technologies (Austria)	\N	2026-08-17 11:35:12.973686+08
1807	Miamari Aaltonen	\N	Aalto University	\N	2026-08-17 11:35:14.249322+08
1808	Chao Peng	\N	Aalto University	\N	2026-08-17 11:35:14.249322+08
1809	Benjamin P. Wilson	\N	Aalto University	\N	2026-08-17 11:35:14.249322+08
1810	Mari Lundström	\N	Aalto University	\N	2026-08-17 11:35:14.249322+08
1811	Nathália Vieceli	\N	Chalmers University of Technology	\N	2026-08-17 11:35:14.256458+08
1812	R. Casasola	\N	\N	\N	2026-08-17 11:35:14.256458+08
1813	Gabriele Lombardo	\N	Chalmers University of Technology	\N	2026-08-17 11:35:14.256458+08
1814	Burçak Ebin	\N	Chalmers University of Technology	\N	2026-08-17 11:35:14.256458+08
1815	Martina Petraniková	\N	Chalmers University of Technology	\N	2026-08-17 11:35:14.256458+08
289	Chen Xu	\N	\N	\N	2026-07-30 16:18:20.216124+08
290	张志响	\N	\N	\N	2026-07-30 16:18:20.2358+08
291	夏建国	\N	\N	\N	2026-07-30 16:18:20.2358+08
292	祝道朋	\N	\N	\N	2026-07-30 16:18:20.2358+08
293	朱加义	\N	\N	\N	2026-07-30 16:18:20.2358+08
294	Changkui LI	\N	\N	\N	2026-07-30 16:18:20.246343+08
295	张雅琪	\N	\N	\N	2026-07-30 16:18:20.246343+08
296	Ting Ruan	\N	\N	\N	2026-07-30 16:18:20.254541+08
297	Chunyang LIAO	\N	\N	\N	2026-07-30 16:18:20.254541+08
298	Yawei Wang	\N	\N	\N	2026-07-30 16:18:20.254541+08
299	Maoyong Song	\N	\N	\N	2026-07-30 16:18:20.254541+08
300	Yaqi CAI	\N	\N	\N	2026-07-30 16:18:20.254541+08
301	Guibin Jiang	\N	\N	\N	2026-07-30 16:18:20.254541+08
302	Guanie Lim	\N	\N	\N	2026-07-30 16:18:37.082695+08
303	Chang Yau Hoon	\N	\N	\N	2026-07-30 16:18:37.082695+08
304	Kaili Zhao	\N	\N	\N	2026-07-30 16:18:37.082695+08
305	陈文豪	\N	\N	\N	2026-07-30 16:18:37.096329+08
306	刚晓祥	\N	\N	\N	2026-07-30 16:18:37.096329+08
307	亮 陆	\N	\N	\N	2026-07-30 16:18:37.100455+08
308	諝跃 赵	\N	\N	\N	2026-07-30 16:18:37.10395+08
309	南军 晏	\N	\N	\N	2026-07-30 16:18:37.10395+08
310	昌文 陈	\N	\N	\N	2026-07-30 16:18:37.10395+08
311	臻 卢	\N	\N	\N	2026-07-30 16:18:37.107642+08
312	BU Tongtong	\N	\N	\N	2026-07-30 16:18:37.11003+08
313	LI Xia	\N	\N	\N	2026-07-30 16:18:37.11003+08
314	LOU Chunxiang	\N	\N	\N	2026-07-30 16:18:37.11003+08
315	REN Pingjing	\N	\N	\N	2026-07-30 16:18:37.11003+08
316	DING Shoujun	\N	\N	\N	2026-07-30 16:18:37.11003+08
317	ZOU Yong	\N	\N	\N	2026-07-30 16:18:37.11003+08
318	XIONG Chunming	\N	\N	\N	2026-07-30 16:18:37.11003+08
319	张玲玲	\N	\N	\N	2026-07-30 16:18:37.118307+08
320	毅 王	\N	\N	\N	2026-07-30 16:18:37.118307+08
321	程阿苗	\N	\N	\N	2026-07-30 16:18:37.118307+08
322	BingLiang LIU	\N	\N	\N	2026-07-30 16:18:37.122319+08
323	Zheng Zhao	\N	\N	\N	2026-07-30 16:18:37.122319+08
324	NaXin GUO	\N	\N	\N	2026-07-30 16:18:37.122319+08
325	Chenhao Li	\N	\N	\N	2026-07-30 16:18:37.122319+08
326	Zhu Quanzheng	\N	\N	\N	2026-07-30 16:18:37.126098+08
327	Jing Zhang	\N	\N	\N	2026-07-30 16:18:37.127952+08
328	Dandan Liu	\N	\N	\N	2026-07-30 16:18:37.127952+08
329	Yanzhao Chou	\N	\N	\N	2026-07-30 16:18:37.127952+08
330	Cheng Chen	\N	\N	\N	2026-07-30 16:18:37.127952+08
331	Shengjin Yue	\N	\N	\N	2026-07-30 16:18:37.127952+08
332	Qingwen Li	\N	\N	\N	2026-07-30 16:18:37.127952+08
333	李美晨	\N	\N	\N	2026-07-30 16:18:37.13577+08
334	薛之广	\N	\N	\N	2026-07-30 16:18:37.138398+08
335	ChenHui ZHAO	\N	\N	\N	2026-07-30 16:18:37.140049+08
336	DengHong WANG	\N	\N	\N	2026-07-30 16:18:37.140049+08
337	ChengHui WANG	\N	\N	\N	2026-07-30 16:18:37.140049+08
338	Wusheng Liu	\N	\N	\N	2026-07-30 16:18:37.140049+08
339	Xiong ZHANG	\N	\N	\N	2026-07-30 16:18:37.140049+08
340	Junxue Jiang	\N	\N	\N	2026-07-30 16:18:37.140049+08
341	TingJie LI	\N	\N	\N	2026-07-30 16:18:37.140049+08
342	Xifei Xu	\N	\N	\N	2026-07-30 16:18:37.140049+08
343	Chen Hh	\N	\N	\N	2026-07-30 16:18:37.148603+08
344	Luo CI	\N	\N	\N	2026-07-30 16:18:37.148603+08
345	Zhang Xiaofei	\N	\N	\N	2026-07-30 16:18:37.148603+08
346	WANG JunLu	\N	\N	\N	2026-07-30 16:18:37.148603+08
347	Bing YU	\N	\N	\N	2026-07-30 16:18:37.148603+08
348	HaiYong WANG	\N	\N	\N	2026-07-30 16:18:37.148603+08
349	PingCuo SUOLANG	\N	\N	\N	2026-07-30 16:18:37.148603+08
350	HongLi SU	\N	\N	\N	2026-07-30 16:18:37.148603+08
351	Kang HUA	\N	\N	\N	2026-07-30 16:18:37.148603+08
352	庞振山	\N	\N	\N	2026-07-30 16:18:37.148603+08
353	3. 新疆维吾尔自治区地质局哈密地质大队, 哈密 839000,3. Hami Geological Team of Xinjiang Geological Bureau, Hami 839000, China	\N	\N	\N	2026-07-30 16:18:37.148603+08
354	6. 西藏自治区地质矿产勘查开发局第二地质大队, 拉萨 851400,6. No. 2 Geological Party, Tibet Bureau of Geological Exploration and Exploitation of Mineral Resources, Tibet 851400, China	\N	\N	\N	2026-07-30 16:18:37.148603+08
355	姜新军	\N	\N	\N	2026-07-30 16:18:37.15678+08
356	Guo Wei	\N	\N	\N	2026-07-30 16:18:37.15678+08
357	魏铁龙	\N	\N	\N	2026-07-30 16:18:37.15678+08
358	意 潘	\N	\N	\N	2026-07-30 16:18:37.160934+08
359	孙明传	\N	\N	\N	2026-07-30 16:18:37.162847+08
360	牛传辉	\N	\N	\N	2026-07-30 16:18:37.164404+08
361	勇 王	\N	\N	\N	2026-07-30 16:18:37.167259+08
362	浩东 严	\N	\N	\N	2026-07-30 16:18:37.168867+08
363	Yucheng LIU	\N	\N	\N	2026-07-30 16:18:37.171108+08
364	Luxin YANG	\N	\N	\N	2026-07-30 16:18:37.171108+08
365	吴云鸽	\N	\N	\N	2026-07-30 16:18:37.17358+08
1816	Koen Binnemans	\N	KU Leuven	\N	2026-08-17 11:35:14.264401+08
1817	Peter Tom Jones	\N	KU Leuven	\N	2026-08-17 11:35:14.264401+08
1818	Umesh Jadhav	\N	National Tsing Hua University	\N	2026-08-17 11:35:14.269532+08
1819	H. Hocheng	\N	National Tsing Hua University	\N	2026-08-17 11:35:14.269532+08
1820	Fang Wan	\N	Nankai University	\N	2026-08-17 11:35:14.274031+08
1821	Linlin Zhang	\N	Nankai University	\N	2026-08-17 11:35:14.274031+08
1822	Xi Dai	\N	Nankai University	\N	2026-08-17 11:35:14.274031+08
377	张向斌	\N	\N	\N	2026-07-30 16:18:48.421735+08
385	易靖松	\N	\N	\N	2026-07-30 16:18:48.445298+08
386	郑传昱	\N	\N	\N	2026-07-30 16:18:48.448351+08
387	智 高	\N	\N	\N	2026-07-30 16:18:48.448351+08
388	郑海涛	\N	\N	\N	2026-07-30 16:18:48.448351+08
389	林 何	\N	\N	\N	2026-07-30 16:18:48.448351+08
390	苏志诚	\N	\N	\N	2026-07-30 16:18:48.448351+08
391	颉 李	\N	\N	\N	2026-07-30 16:18:48.453305+08
392	Jiale Lu	\N	\N	\N	2026-07-30 16:18:48.453305+08
393	王晓枫	\N	\N	\N	2026-07-30 16:18:48.458912+08
394	沈会艾	\N	\N	\N	2026-07-30 16:18:48.46219+08
395	贝 许	\N	\N	\N	2026-07-30 16:18:48.465168+08
396	孙宏伟	\N	\N	\N	2026-07-30 16:18:48.467705+08
397	贾俊豪	\N	\N	\N	2026-07-30 16:18:48.470499+08
398	丁树猛	\N	\N	\N	2026-07-30 16:18:48.470499+08
399	何玉林	\N	\N	\N	2026-07-30 16:18:48.470499+08
400	王娜娜	\N	\N	\N	2026-07-30 16:18:48.470499+08
401	卢登攀	\N	\N	\N	2026-07-30 16:18:48.477792+08
402	高丙江	\N	\N	\N	2026-07-30 16:18:48.477792+08
403	Yi ZHANG	\N	\N	\N	2026-07-30 16:18:48.483761+08
404	Chunlong Tian	\N	\N	\N	2026-07-30 16:18:48.483761+08
405	Yi Wang	\N	\N	\N	2026-07-30 16:18:48.483761+08
406	Yong YANG	\N	\N	\N	2026-07-30 16:18:48.483761+08
407	亮 赵	\N	\N	\N	2026-07-30 16:18:48.494627+08
408	Guosong Ma	\N	\N	\N	2026-07-30 16:18:48.497156+08
409	Maosheng DUAN	\N	\N	\N	2026-07-30 16:18:48.497156+08
410	强 杨	\N	\N	\N	2026-07-30 16:18:48.500872+08
411	董桂彬	\N	\N	\N	2026-07-30 16:18:48.503095+08
412	徐世安	\N	\N	\N	2026-07-30 16:18:48.5061+08
413	林 石	\N	\N	\N	2026-07-30 16:18:48.5061+08
414	凯 乐	\N	\N	\N	2026-07-30 16:18:48.5061+08
415	于 乔	\N	\N	\N	2026-07-30 16:18:48.509861+08
416	唐天晟	\N	\N	\N	2026-07-30 16:18:48.509861+08
417	Huahui CHEN	\N	\N	\N	2026-07-30 16:18:48.512436+08
418	Lu Qiao	\N	\N	\N	2026-07-30 16:18:48.512436+08
419	Haiyan HU	\N	\N	\N	2026-07-30 16:18:48.512436+08
420	Yizhang LIU	\N	\N	\N	2026-07-30 16:18:48.512436+08
421	Ping LI	\N	\N	\N	2026-07-30 16:18:48.512436+08
422	任精玲	\N	\N	\N	2026-07-30 16:18:48.520006+08
423	波 薛	\N	\N	\N	2026-07-30 16:18:48.522674+08
424	吴联盟	\N	\N	\N	2026-07-30 16:18:58.274739+08
425	支作伟	\N	\N	\N	2026-07-30 16:18:58.282711+08
426	宦玮	\N	\N	\N	2026-07-30 16:18:58.289248+08
427	冀佳怡	\N	\N	\N	2026-07-30 16:18:58.289248+08
428	政 杨	\N	\N	\N	2026-07-30 16:18:58.29662+08
429	纯 唐	\N	\N	\N	2026-07-30 16:18:58.29662+08
430	龙 刘	\N	\N	\N	2026-07-30 16:18:58.29662+08
431	刚 武	\N	\N	\N	2026-07-30 16:18:58.29662+08
432	婷婷 田	\N	\N	\N	2026-07-30 16:18:58.29662+08
433	翔 李	\N	\N	\N	2026-07-30 16:18:58.30439+08
434	宋晓彬	\N	\N	\N	2026-07-30 16:18:58.307159+08
435	Shengchao Yan	\N	\N	\N	2026-07-30 16:18:58.309591+08
436	Bo Wan	\N	\N	\N	2026-07-30 16:18:58.309591+08
437	XY Li	\N	\N	\N	2026-07-30 16:18:58.309591+08
438	甜甜 张	\N	\N	\N	2026-07-30 16:18:58.31357+08
439	S. F. Lai	\N	\N	\N	2026-07-30 16:18:58.319541+08
440	JiangFeng QIN	\N	\N	\N	2026-07-30 16:18:58.319541+08
441	RenZhi ZHU	\N	\N	\N	2026-07-30 16:18:58.319541+08
442	Min LIU	\N	\N	\N	2026-07-30 16:18:58.319541+08
1823	Xinyu Wang	\N	Nankai University	\N	2026-08-17 11:35:14.274031+08
1824	Zhiqiang Niu	\N	Nankai University	\N	2026-08-17 11:35:14.274031+08
1825	Jun Chen	\N	Nankai University	\N	2026-08-17 11:35:14.274031+08
1826	Zuzanna Wiecka	\N	Poznań University of Technology	\N	2026-08-17 11:35:14.279901+08
1827	Martyna Rzelewska-Piekut	\N	Poznań University of Technology	\N	2026-08-17 11:35:14.279901+08
1828	Magdalena Regel‐Rosocka	\N	Poznań University of Technology	\N	2026-08-17 11:35:14.279901+08
1829	Lukas Hoeber	\N	Montanuniversität Leoben	\N	2026-08-17 11:35:14.284032+08
450	Zongliang Dai	\N	\N	\N	2026-07-30 16:18:58.33485+08
451	Yu Qiao	\N	\N	\N	2026-07-30 16:18:58.33485+08
452	Mao Xu	\N	\N	\N	2026-07-30 16:19:09.27219+08
453	Zongguo Wen	\N	\N	\N	2026-07-30 16:19:09.27219+08
454	Kai Zheng	\N	\N	\N	2026-07-30 16:19:09.27219+08
455	Zhixing Pan	\N	\N	\N	2026-07-30 16:19:09.27219+08
456	Zhenghao Liang	\N	\N	\N	2026-07-30 16:19:09.27219+08
457	全莲菊	\N	\N	\N	2026-07-30 16:19:09.29938+08
458	超 郭	\N	\N	\N	2026-07-30 16:19:09.29938+08
459	华正江	\N	\N	\N	2026-07-30 16:19:09.307923+08
460	郑乔康	\N	\N	\N	2026-07-30 16:19:09.307923+08
461	陈彦旭	\N	\N	\N	2026-07-30 16:19:09.307923+08
462	韩志扬	\N	\N	\N	2026-07-30 16:19:09.315668+08
463	李鹏飞	\N	\N	\N	2026-07-30 16:19:09.321445+08
464	宋春东	\N	\N	\N	2026-07-30 16:19:09.321445+08
465	马志强	\N	\N	\N	2026-07-30 16:19:09.321445+08
466	宇 赵	\N	\N	\N	2026-07-30 16:19:09.321445+08
467	峰 高	\N	\N	\N	2026-07-30 16:19:09.330952+08
468	许雪峰	\N	\N	\N	2026-07-30 16:19:09.330952+08
469	武宏伟	\N	\N	\N	2026-07-30 16:19:09.330952+08
470	郝齐崇	\N	\N	\N	2026-07-30 16:19:09.335332+08
471	朱青旭	\N	\N	\N	2026-07-30 16:19:09.339169+08
472	通 刘	\N	\N	\N	2026-07-30 16:19:09.34317+08
473	黄婵婵	\N	\N	\N	2026-07-30 16:19:09.348087+08
474	瑞 郭	\N	\N	\N	2026-07-30 16:19:09.353503+08
475	启迪 李	\N	\N	\N	2026-07-30 16:19:09.364281+08
476	张睿哲	\N	\N	\N	2026-07-30 16:19:09.369245+08
477	龚德鑫	\N	\N	\N	2026-07-30 16:19:09.369245+08
478	Lulu Xue	\N	\N	\N	2026-07-30 16:19:09.375227+08
479	Yana Jin	\N	\N	\N	2026-07-30 16:19:09.375227+08
480	Rujie Yu	\N	\N	\N	2026-07-30 16:19:09.375227+08
481	Yong Liu	\N	\N	\N	2026-07-30 16:19:09.375227+08
482	Huanhuan Ren	\N	\N	\N	2026-07-30 16:19:09.375227+08
483	杜芸芸	\N	\N	\N	2026-07-30 16:19:09.389927+08
484	锐 张	\N	\N	\N	2026-07-30 16:19:09.395665+08
485	庞驰宸	\N	\N	\N	2026-07-30 16:19:09.395665+08
486	Jing WANG	\N	\N	\N	2026-07-30 16:19:09.402192+08
487	WenJun LI	\N	\N	\N	2026-07-30 16:19:09.402192+08
488	BingYu GAO	\N	\N	\N	2026-07-30 16:19:09.402192+08
489	ShouQian ZHAO	\N	\N	\N	2026-07-30 16:19:09.402192+08
490	Renrui Xiong	\N	\N	\N	2026-07-30 16:19:09.410639+08
491	Yuying Wang	\N	\N	\N	2026-07-30 16:19:09.410639+08
492	Jue Huang	\N	\N	\N	2026-07-30 16:19:09.410639+08
493	Xiaoquan Dong	\N	\N	\N	2026-07-30 16:19:09.410639+08
494	Lulu He	\N	\N	\N	2026-07-30 16:19:09.410639+08
495	Junyi Zhan	\N	\N	\N	2026-07-30 16:19:09.410639+08
496	Daoming Wu	\N	\N	\N	2026-07-30 16:19:09.410639+08
497	Liu Jian	\N	\N	\N	2026-07-30 16:19:09.432776+08
498	Wang Ying	\N	\N	\N	2026-07-30 16:19:09.432776+08
499	Liu Xiaoshi	\N	\N	\N	2026-07-30 16:19:09.432776+08
500	Xiong Ying	\N	\N	\N	2026-07-30 16:19:09.432776+08
1830	Stefan Steinlechner	\N	Montanuniversität Leoben	\N	2026-08-17 11:35:14.284032+08
502	上官国青	\N	\N	\N	2026-07-30 16:19:09.45153+08
503	张成杰	\N	\N	\N	2026-07-30 16:19:09.45153+08
504	朱锋涛	\N	\N	\N	2026-07-30 16:19:09.456327+08
1831	Manivannan Sethurajan	\N	IHE Delft Institute for Water Education	\N	2026-08-17 11:35:14.288379+08
506	潘金科	\N	\N	\N	2026-07-30 16:19:09.461838+08
507	建东 张	\N	\N	\N	2026-07-30 16:19:09.464062+08
508	Jiandong Yang	\N	\N	\N	2026-07-30 16:19:09.467678+08
509	Pengwei Lou	\N	\N	\N	2026-07-30 16:19:09.467678+08
510	Weisheng Zhang	\N	\N	\N	2026-07-30 16:19:09.467678+08
511	Yanggui Chen	\N	\N	\N	2026-07-30 16:19:09.467678+08
512	Yaoqin Lu	\N	\N	\N	2026-07-30 16:19:09.467678+08
513	Na Xue	\N	\N	\N	2026-07-30 16:19:09.467678+08
514	Peisheng Wang	\N	\N	\N	2026-07-30 16:19:09.467678+08
515	Kai Wang	\N	\N	\N	2026-07-30 16:19:09.467678+08
1832	Eric D. van Hullebusch	\N	Institut de physique du globe de Paris	\N	2026-08-17 11:35:14.288379+08
1833	Danilo Fontana	\N	National Agency for New Technologies, Energy and Sustainable Economic Development	\N	2026-08-17 11:35:14.288379+08
1834	Ata Akçıl	\N	Süleyman Demirel Üniversitesi	\N	2026-08-17 11:35:14.288379+08
1835	Hacı Deveci	\N	Karadeniz Technical University	\N	2026-08-17 11:35:14.288379+08
524	林峰	\N	\N	\N	2026-07-30 16:19:18.299525+08
525	赵房楠	\N	\N	\N	2026-07-30 16:19:18.299525+08
526	吴永胜	\N	\N	\N	2026-07-30 16:19:18.299525+08
527	何少杰	\N	\N	\N	2026-07-30 16:19:18.299525+08
528	张战毅	\N	\N	\N	2026-07-30 16:19:18.299525+08
531	希琳 董	\N	\N	\N	2026-07-30 16:19:18.312309+08
532	宇 张	\N	\N	\N	2026-07-30 16:19:18.319175+08
533	李宗鑫	\N	\N	\N	2026-07-30 16:19:18.322323+08
534	美又 王	\N	\N	\N	2026-07-30 16:19:18.32585+08
535	张来福	\N	\N	\N	2026-07-30 16:19:18.329269+08
539	李永周	\N	\N	\N	2026-07-30 16:19:18.33862+08
540	唐仕兴	\N	\N	\N	2026-07-30 16:19:18.341177+08
541	赵梓豪	\N	\N	\N	2026-07-30 16:19:18.344457+08
542	石书苹	\N	\N	\N	2026-07-30 16:19:18.347022+08
1836	Bojan Batinić	\N	University of Novi Sad	\N	2026-08-17 11:35:14.288379+08
1837	João Paulo Leal	\N	University of Lisbon	\N	2026-08-17 11:35:14.288379+08
1838	T. Almeida Gasche	\N	University of Lisbon	\N	2026-08-17 11:35:14.288379+08
1839	Mehmet Ali Küçüker	\N	Universität Hamburg	\N	2026-08-17 11:35:14.288379+08
1840	Kerstin Kuchta	\N	Universität Hamburg	\N	2026-08-17 11:35:14.288379+08
549	朱彩艳	\N	\N	\N	2026-07-30 16:19:18.359525+08
550	王军帅	\N	\N	\N	2026-07-30 16:19:18.361715+08
551	Hongfei Chen	\N	\N	\N	2026-07-30 16:19:18.367985+08
552	Dongxiao Niu	\N	\N	\N	2026-07-30 16:19:18.367985+08
554	永丹 侯	\N	\N	\N	2026-07-30 16:19:18.38511+08
555	Francisco J. Sevilla	\N	\N	\N	2026-07-30 16:24:25.851003+08
556	Iskandar Raufov	\N	\N	\N	2026-07-30 16:24:25.861601+08
557	Dilshod Nematov	\N	\N	\N	2026-07-30 16:24:25.861601+08
558	Saidjafar Murodzoda	\N	\N	\N	2026-07-30 16:24:25.861601+08
559	Sakhidod Sattorzoda	\N	\N	\N	2026-07-30 16:24:25.861601+08
560	Anushervon Ashurov	\N	\N	\N	2026-07-30 16:24:25.861601+08
561	Alpar Turkoglu	\N	\N	\N	2026-07-30 16:24:25.866694+08
562	A. Nihat Berker	\N	\N	\N	2026-07-30 16:24:25.866694+08
563	Alessandro Pluchino	\N	\N	\N	2026-07-30 16:24:25.870339+08
564	Vito Latora	\N	\N	\N	2026-07-30 16:24:25.870339+08
565	Andrea Rapisarda	\N	\N	\N	2026-07-30 16:24:25.870339+08
566	K. Farakos	\N	\N	\N	2026-07-30 16:24:25.873454+08
567	S. Vrentzos	\N	\N	\N	2026-07-30 16:24:25.873454+08
568	Jiří Kozlík	\N	\N	\N	2026-07-30 16:25:44.770369+08
569	František Lukáč	\N	\N	\N	2026-07-30 16:25:44.770369+08
570	Mariano Casas Luna	\N	\N	\N	2026-07-30 16:25:44.770369+08
571	Kristián Šalata	\N	\N	\N	2026-07-30 16:25:44.770369+08
572	Josef Stráský	\N	\N	\N	2026-07-30 16:25:44.770369+08
573	Jozef Veselý	\N	\N	\N	2026-07-30 16:25:44.770369+08
574	Eliška Jača	\N	\N	\N	2026-07-30 16:25:44.770369+08
575	Tomáš Chráska	\N	\N	\N	2026-07-30 16:25:44.770369+08
576	J. W. Cahn	\N	\N	\N	2026-07-30 16:25:44.802389+08
577	W. C. Carter	\N	\N	\N	2026-07-30 16:25:44.802389+08
578	Jicheng Feng	\N	\N	\N	2026-07-30 16:25:44.811388+08
579	Dong Chen	\N	\N	\N	2026-07-30 16:25:44.811388+08
580	Peter V. Pikhitsa	\N	\N	\N	2026-07-30 16:25:44.811388+08
581	Yoon-ho Jung	\N	\N	\N	2026-07-30 16:25:44.811388+08
582	Jun Yang	\N	\N	\N	2026-07-30 16:25:44.811388+08
583	Mansoo Choi	\N	\N	\N	2026-07-30 16:25:44.811388+08
584	I. K. Razumov	\N	\N	\N	2026-07-30 16:25:44.825218+08
585	Yu. N. Gornostyrev	\N	\N	\N	2026-07-30 16:25:44.825218+08
586	M. I. Katsnelson	\N	\N	\N	2026-07-30 16:25:44.825218+08
587	P. Souvatzis	\N	\N	\N	2026-07-30 16:25:44.834252+08
588	E. K. Delczeg-Czirjak	\N	\N	\N	2026-07-30 16:25:44.834252+08
589	L. Vitos	\N	\N	\N	2026-07-30 16:25:44.834252+08
590	O. Eriksson	\N	\N	\N	2026-07-30 16:25:44.834252+08
591	Marc Raventós-Tato	\N	\N	\N	2026-07-30 16:26:05.01541+08
592	S. Leila Panahi	\N	\N	\N	2026-07-30 16:26:05.01541+08
593	Núria Bagués	\N	\N	\N	2026-07-30 16:26:05.01541+08
594	David Frómeta	\N	\N	\N	2026-07-30 16:26:05.01541+08
595	Oleg Usoltsev	\N	\N	\N	2026-07-30 16:26:05.01541+08
596	Núria Cuadrado	\N	\N	\N	2026-07-30 16:26:05.01541+08
597	Joaquín Otón	\N	\N	\N	2026-07-30 16:26:05.01541+08
598	Anton Muehlemann	\N	\N	\N	2026-07-30 16:26:05.029084+08
599	Konstantinos Koumatos	\N	\N	\N	2026-07-30 16:26:05.029084+08
600	Mrinmay Sahu	\N	\N	\N	2026-07-30 16:26:05.033841+08
601	Sorb Yesudhas	\N	\N	\N	2026-07-30 16:26:05.033841+08
602	Valery I. Levitas	\N	\N	\N	2026-07-30 16:26:05.033841+08
603	Dean Smith	\N	\N	\N	2026-07-30 16:26:05.033841+08
604	James A. D. Ball	\N	\N	\N	2026-07-30 16:26:05.038357+08
605	Claire Davis	\N	\N	\N	2026-07-30 16:26:05.038357+08
606	Carl Slater	\N	\N	\N	2026-07-30 16:26:05.038357+08
607	Himanshu Vashishtha	\N	\N	\N	2026-07-30 16:26:05.038357+08
608	Mohammed Said	\N	\N	\N	2026-07-30 16:26:05.038357+08
609	Louis Hébrard	\N	\N	\N	2026-07-30 16:26:05.038357+08
610	Florian Steinhilber	\N	\N	\N	2026-07-30 16:26:05.038357+08
611	Jonathan P. Wright	\N	\N	\N	2026-07-30 16:26:05.038357+08
612	Thomas Connolley	\N	\N	\N	2026-07-30 16:26:05.038357+08
613	Stefan Michalik	\N	\N	\N	2026-07-30 16:26:05.038357+08
614	David M. Collins	\N	\N	\N	2026-07-30 16:26:05.038357+08
615	A. Kareer	\N	\N	\N	2026-07-30 16:26:05.051048+08
616	R. W. Kerr	\N	\N	\N	2026-07-30 16:26:05.051048+08
617	D. Craven	\N	\N	\N	2026-07-30 16:26:05.051048+08
618	A. V. Davydok	\N	\N	\N	2026-07-30 16:26:05.051048+08
619	C. Krywka	\N	\N	\N	2026-07-30 16:26:05.051048+08
620	D. M. Collins	\N	\N	\N	2026-07-30 16:26:05.051048+08
621	Nitish Chandrappa	\N	\N	\N	2026-07-30 16:26:05.057879+08
622	Marc Bernacki	\N	\N	\N	2026-07-30 16:26:05.057879+08
623	Xiaoping Ma	\N	\N	\N	2026-07-30 16:26:05.061933+08
624	Dianzhong Li	\N	\N	\N	2026-07-30 16:26:05.061933+08
625	Zhuo Zhao	\N	\N	\N	2026-07-30 16:26:05.061933+08
626	Saichao Cao	\N	\N	\N	2026-07-30 16:26:05.061933+08
627	Donghao Pei	\N	\N	\N	2026-07-30 16:26:05.061933+08
628	Pei Wang	\N	\N	\N	2026-07-30 16:26:05.061933+08
629	Yuxi Tao	\N	\N	\N	2026-07-30 16:26:05.061933+08
630	Paixian Fu	\N	\N	\N	2026-07-30 16:26:05.061933+08
631	Hongwei Liu	\N	\N	\N	2026-07-30 16:26:05.061933+08
632	Xiuhong Kang	\N	\N	\N	2026-07-30 16:26:05.061933+08
633	Singh	\N	\N	\N	2026-07-30 16:26:05.072513+08
634	Prashant	\N	\N	\N	2026-07-30 16:26:05.072513+08
635	Johnson	\N	\N	\N	2026-07-30 16:26:05.072513+08
636	Duane D	\N	\N	\N	2026-07-30 16:26:05.072513+08
637	Ruth M. Birch	\N	\N	\N	2026-07-30 16:26:05.077161+08
638	Ben Britton	\N	\N	\N	2026-07-30 16:26:05.077161+08
639	Warren J Poole	\N	\N	\N	2026-07-30 16:26:05.077161+08
640	J. -L. Zhang	\N	\N	\N	2026-07-30 16:26:05.081556+08
641	J. L. Cann	\N	\N	\N	2026-07-30 16:26:05.081556+08
642	S. B. Maisel	\N	\N	\N	2026-07-30 16:26:05.081556+08
643	K. Qu	\N	\N	\N	2026-07-30 16:26:05.081556+08
644	E. Plancher	\N	\N	\N	2026-07-30 16:26:05.081556+08
645	H. Springer	\N	\N	\N	2026-07-30 16:26:05.081556+08
646	E. Povoden-Karadeniz	\N	\N	\N	2026-07-30 16:26:05.081556+08
647	P. Gao	\N	\N	\N	2026-07-30 16:26:05.081556+08
648	Y. Ren	\N	\N	\N	2026-07-30 16:26:05.081556+08
649	B. Grabowski	\N	\N	\N	2026-07-30 16:26:05.081556+08
650	C. C. Tasan	\N	\N	\N	2026-07-30 16:26:05.081556+08
651	Peter Hedström	\N	\N	\N	2026-07-30 16:26:05.089718+08
652	Victor Lamelas Cubero	\N	\N	\N	2026-07-30 16:26:05.089718+08
653	Jón Sigurdsson	\N	\N	\N	2026-07-30 16:26:05.089718+08
654	Viktor Österberg	\N	\N	\N	2026-07-30 16:26:05.089718+08
655	Satish Kolli	\N	\N	\N	2026-07-30 16:26:05.089718+08
656	Joakim Odqvist	\N	\N	\N	2026-07-30 16:26:05.089718+08
657	Ziyong Hou	\N	\N	\N	2026-07-30 16:26:05.089718+08
658	Wangzhong Mu	\N	\N	\N	2026-07-30 16:26:05.089718+08
659	Viswanadh Gowtham Arigela	\N	\N	\N	2026-07-30 16:26:05.089718+08
660	Junaid Ahmed	\N	\N	\N	2026-07-30 16:26:05.099462+08
661	Matthew Daly	\N	\N	\N	2026-07-30 16:26:05.099462+08
662	Jian Peng	\N	\N	\N	2026-07-30 16:26:05.102721+08
663	Yukinori Yamamoto	\N	\N	\N	2026-07-30 16:26:05.102721+08
664	Jeffrey A. Hawk	\N	\N	\N	2026-07-30 16:26:05.102721+08
665	Edgar Lara-Curzio	\N	\N	\N	2026-07-30 16:26:05.102721+08
666	Dongwon Shin	\N	\N	\N	2026-07-30 16:26:05.102721+08
667	Soumya Sridar	\N	\N	\N	2026-07-30 16:26:05.107873+08
668	Yunhao Zhao	\N	\N	\N	2026-07-30 16:26:05.107873+08
669	Wei Xiong	\N	\N	\N	2026-07-30 16:26:05.107873+08
670	Mathieu Bouville	\N	\N	\N	2026-07-30 16:26:05.112315+08
671	Rajeev Ahluwalia	\N	\N	\N	2026-07-30 16:26:05.112315+08
672	Timofei Miryashkin	\N	\N	\N	2026-07-30 16:26:05.115839+08
673	Ivan Novoselov	\N	\N	\N	2026-07-30 16:26:05.115839+08
674	Alexey Yanilkin	\N	\N	\N	2026-07-30 16:26:05.115839+08
675	Frank Niessen	\N	\N	\N	2026-07-30 16:26:05.120692+08
676	Tuomo Nyyssönen	\N	\N	\N	2026-07-30 16:26:05.120692+08
677	Azdiar A. Gazder	\N	\N	\N	2026-07-30 16:26:05.120692+08
678	Ralf Hielscher	\N	\N	\N	2026-07-30 16:26:05.120692+08
679	E. Valencia-Morales	\N	\N	\N	2026-07-30 16:26:05.12564+08
680	N. J. Galeano-Alvarez	\N	\N	\N	2026-07-30 16:26:05.12564+08
681	J. Vega-Leyva	\N	\N	\N	2026-07-30 16:26:05.12564+08
682	C. E. Villar	\N	\N	\N	2026-07-30 16:26:05.12564+08
683	J. Hernandez-Ruiz	\N	\N	\N	2026-07-30 16:26:05.12564+08
684	Sneha Samal	\N	\N	\N	2026-07-30 16:26:05.129898+08
685	Shrikant Joshi	\N	\N	\N	2026-07-30 16:26:05.129898+08
686	Stefan Björklund	\N	\N	\N	2026-07-30 16:26:05.129898+08
687	Mohit Chandra	\N	\N	\N	2026-07-30 16:26:05.129898+08
688	Akhil Bhardwaj	\N	\N	\N	2026-07-30 16:26:05.129898+08
689	Jaromír Kopeček	\N	\N	\N	2026-07-30 16:26:05.129898+08
690	Stanislav Habr	\N	\N	\N	2026-07-30 16:26:05.129898+08
691	Lukáš Václavek Jan Tomáštík	\N	\N	\N	2026-07-30 16:26:05.129898+08
692	Ondřej Tyc	\N	\N	\N	2026-07-30 16:26:05.129898+08
693	Petr Šittner	\N	\N	\N	2026-07-30 16:26:05.129898+08
694	Soumya Bandyopadhyay	\N	\N	\N	2026-07-30 16:26:05.136303+08
695	Sourav Chatterjee	\N	\N	\N	2026-07-30 16:26:05.136303+08
696	Dallas R. Trinkle	\N	\N	\N	2026-07-30 16:26:05.136303+08
697	Richard G. Hennig	\N	\N	\N	2026-07-30 16:26:05.136303+08
698	Victoria Miller	\N	\N	\N	2026-07-30 16:26:05.136303+08
699	Michael S. Kesler	\N	\N	\N	2026-07-30 16:26:05.136303+08
700	Michael R. Tonks	\N	\N	\N	2026-07-30 16:26:05.136303+08
701	Ruth Birch	\N	\N	\N	2026-07-30 16:26:05.142592+08
702	Thomas Benjamin Britton	\N	\N	\N	2026-07-30 16:26:05.142592+08
703	P G Kubendran Amos	\N	\N	\N	2026-07-30 16:26:05.146793+08
704	Ephraim Schoof	\N	\N	\N	2026-07-30 16:26:05.146793+08
705	Nick Streichan	\N	\N	\N	2026-07-30 16:26:05.146793+08
706	Daniel Schneider	\N	\N	\N	2026-07-30 16:26:05.146793+08
707	Britta Nestler	\N	\N	\N	2026-07-30 16:26:05.146793+08
708	Mirko Maraldi	\N	\N	\N	2026-07-30 16:26:05.152612+08
709	Garth N. Wells	\N	\N	\N	2026-07-30 16:26:05.152612+08
710	Luisa Molari	\N	\N	\N	2026-07-30 16:26:05.152612+08
711	Zi-Kui Liu	\N	\N	\N	2026-07-30 16:26:05.156955+08
712	D. Schwen	\N	\N	\N	2026-07-30 16:26:05.159978+08
713	C. Jiang	\N	\N	\N	2026-07-30 16:26:05.159978+08
714	L. K. Aagesen	\N	\N	\N	2026-07-30 16:26:05.159978+08
715	M. Hussein N. Assadi	\N	\N	\N	2026-07-30 16:26:20.173032+08
716	Veena Sahajwalla	\N	\N	\N	2026-07-30 16:26:20.173032+08
717	Andrea Ranzani Da Costa	\N	\N	\N	2026-07-30 16:26:20.182743+08
718	D. Wagner	\N	\N	\N	2026-07-30 16:26:20.182743+08
719	Fabrice Patisson	\N	\N	\N	2026-07-30 16:26:20.182743+08
720	S. V. Naydenov	\N	\N	\N	2026-07-30 16:26:20.18663+08
721	O. M. Vovk	\N	\N	\N	2026-07-30 16:26:20.18663+08
722	Yu. V. Siryk	\N	\N	\N	2026-07-30 16:26:20.18663+08
723	S. V. Nizhankovskyi	\N	\N	\N	2026-07-30 16:26:20.18663+08
724	I. M. Pritula	\N	\N	\N	2026-07-30 16:26:20.18663+08
725	Chenbo Zhang	\N	\N	\N	2026-07-30 16:26:20.192217+08
726	Zhuohui Zeng	\N	\N	\N	2026-07-30 16:26:20.192217+08
727	Zeyuan Zhu	\N	\N	\N	2026-07-30 16:26:20.192217+08
728	Mostafa Karami	\N	\N	\N	2026-07-30 16:26:20.192217+08
729	Xian Chen	\N	\N	\N	2026-07-30 16:26:20.192217+08
730	Pritam P Shetty	\N	\N	\N	2026-07-30 16:26:20.197852+08
731	Dmitrii N Maksimov	\N	\N	\N	2026-07-30 16:26:20.197852+08
732	Mahalingam Babu	\N	\N	\N	2026-07-30 16:26:20.197852+08
733	Sudhakara Reddy Bongu	\N	\N	\N	2026-07-30 16:26:20.197852+08
734	Jayachandra Bingi	\N	\N	\N	2026-07-30 16:26:20.197852+08
735	François Morini	\N	\N	\N	2026-07-30 16:26:20.204466+08
736	Emmanuel Dubois	\N	\N	\N	2026-07-30 16:26:20.204466+08
737	Jean-François Robillard	\N	\N	\N	2026-07-30 16:26:20.204466+08
738	Stéphane Monfray	\N	\N	\N	2026-07-30 16:26:20.204466+08
739	Thomas Skotnicki	\N	\N	\N	2026-07-30 16:26:20.204466+08
740	S. Barnoss	\N	\N	\N	2026-07-30 16:26:20.209527+08
741	H. Shanak	\N	\N	\N	2026-07-30 16:26:20.209527+08
742	C. Bof Bufon	\N	\N	\N	2026-07-30 16:26:20.209527+08
743	T. Heinzel	\N	\N	\N	2026-07-30 16:26:20.209527+08
744	C. C. Bof Bufon	\N	\N	\N	2026-07-30 16:26:20.213381+08
745	Marcos Paulo Belançon	\N	\N	\N	2026-07-30 16:26:20.216701+08
746	Shanhe Su	\N	\N	\N	2026-07-30 16:26:20.219415+08
747	Jincan Chen	\N	\N	\N	2026-07-30 16:26:20.219415+08
748	Tien-Mo Shih	\N	\N	\N	2026-07-30 16:26:20.219415+08
749	Steven S. -L. Zhang	\N	\N	\N	2026-07-30 16:26:20.223755+08
750	Shufeng Zhang	\N	\N	\N	2026-07-30 16:26:20.223755+08
751	Xueyang Shen	\N	\N	\N	2026-07-30 16:26:20.227036+08
752	Ruixuan Chu	\N	\N	\N	2026-07-30 16:26:20.227036+08
753	Ding Xu	\N	\N	\N	2026-07-30 16:26:20.227036+08
754	Yuan Gao	\N	\N	\N	2026-07-30 16:26:20.227036+08
755	Wen Zhou	\N	\N	\N	2026-07-30 16:26:20.227036+08
756	Wei Zhang	\N	\N	\N	2026-07-30 16:26:20.227036+08
757	Maiara Mitiko Taniguchi	\N	\N	\N	2026-07-30 16:26:20.234665+08
758	Vitor Santaella Zanuto	\N	\N	\N	2026-07-30 16:26:20.234665+08
759	Pablo Portes	\N	\N	\N	2026-07-30 16:26:20.234665+08
760	Luis Carlos Malacarne	\N	\N	\N	2026-07-30 16:26:20.234665+08
761	Nelson Guilherme Astrath	\N	\N	\N	2026-07-30 16:26:20.234665+08
762	Jorge Diego Marconi	\N	\N	\N	2026-07-30 16:26:20.234665+08
763	Saswata Goswami	\N	\N	\N	2026-07-30 16:26:20.240221+08
764	Caique Campos de Oliveira	\N	\N	\N	2026-07-30 16:26:20.240221+08
765	Abhijith M. B.	\N	\N	\N	2026-07-30 16:26:20.240221+08
766	Varinder Pal	\N	\N	\N	2026-07-30 16:26:20.240221+08
767	Vidya Kochat	\N	\N	\N	2026-07-30 16:26:20.240221+08
768	Pulickel M. Ajayan	\N	\N	\N	2026-07-30 16:26:20.240221+08
769	Samit K. Ray	\N	\N	\N	2026-07-30 16:26:20.240221+08
770	Pedro A. S. Autreto	\N	\N	\N	2026-07-30 16:26:20.240221+08
771	Chandra Sekhar Tiwary	\N	\N	\N	2026-07-30 16:26:20.240221+08
772	Talha Erdem	\N	\N	\N	2026-07-30 16:26:20.247878+08
773	Ali Orenc	\N	\N	\N	2026-07-30 16:26:20.247878+08
774	Dilber Akcan	\N	\N	\N	2026-07-30 16:26:20.247878+08
775	Fatih Duman	\N	\N	\N	2026-07-30 16:26:20.247878+08
776	Zeliha Soran-Erdem	\N	\N	\N	2026-07-30 16:26:20.247878+08
777	S. C. P. van Kooten	\N	\N	\N	2026-07-30 16:26:20.25375+08
778	P. A. Usachev	\N	\N	\N	2026-07-30 16:26:20.25375+08
779	X. Gratens	\N	\N	\N	2026-07-30 16:26:20.25375+08
780	A. R. Naupa	\N	\N	\N	2026-07-30 16:26:20.25375+08
781	V. A. Chitta	\N	\N	\N	2026-07-30 16:26:20.25375+08
782	G. Springholz	\N	\N	\N	2026-07-30 16:26:20.25375+08
783	A. B. Henriques	\N	\N	\N	2026-07-30 16:26:20.25375+08
784	Ruairi Baker	\N	\N	\N	2026-07-30 16:26:20.261633+08
785	Maria Pervez	\N	\N	\N	2026-07-30 16:26:20.261633+08
786	Angus Hawkey	\N	\N	\N	2026-07-30 16:26:20.261633+08
787	Nobuya Sakai	\N	\N	\N	2026-07-30 16:26:20.261633+08
788	Valerie Berryman-Bousquet	\N	\N	\N	2026-07-30 16:26:20.261633+08
789	Bernard Wenger	\N	\N	\N	2026-07-30 16:26:20.261633+08
790	Guilhermino J. M. Fechine	\N	\N	\N	2026-07-30 16:26:20.270042+08
791	Inigo Martin-Fernandez	\N	\N	\N	2026-07-30 16:26:20.270042+08
792	George Yiapanis	\N	\N	\N	2026-07-30 16:26:20.270042+08
793	Ricardo V. Bof de Oliveira	\N	\N	\N	2026-07-30 16:26:20.270042+08
794	Xiao Hu	\N	\N	\N	2026-07-30 16:26:20.270042+08
795	Irene Yarovsky	\N	\N	\N	2026-07-30 16:26:20.270042+08
796	Antonio H. Castro Neto	\N	\N	\N	2026-07-30 16:26:20.270042+08
797	Barbaros Ozyilmaz	\N	\N	\N	2026-07-30 16:26:20.270042+08
798	Leandro Merces	\N	\N	\N	2026-07-30 16:26:20.27992+08
799	Graziâni Candiotto	\N	\N	\N	2026-07-30 16:26:20.27992+08
800	Letícia M. M. Ferro	\N	\N	\N	2026-07-30 16:26:20.27992+08
801	Anerise de Barros	\N	\N	\N	2026-07-30 16:26:20.27992+08
802	Carlos V. S. Batista	\N	\N	\N	2026-07-30 16:26:20.27992+08
803	Ali Nawaz	\N	\N	\N	2026-07-30 16:26:20.27992+08
804	Antonio Riul	\N	\N	\N	2026-07-30 16:26:20.27992+08
805	Rodrigo B. Capaz	\N	\N	\N	2026-07-30 16:26:20.27992+08
806	Carlos C. Bof Bufon	\N	\N	\N	2026-07-30 16:26:20.27992+08
807	Wu-Jun Shi	\N	\N	\N	2026-07-30 16:26:20.291856+08
808	Junwei Liu	\N	\N	\N	2026-07-30 16:26:20.291856+08
809	Yong Xu	\N	\N	\N	2026-07-30 16:26:20.291856+08
810	Shi-Jie Xiong	\N	\N	\N	2026-07-30 16:26:20.291856+08
811	Jian Wu	\N	\N	\N	2026-07-30 16:26:20.291856+08
812	Wenhui Duan	\N	\N	\N	2026-07-30 16:26:20.291856+08
813	Leyla Ramin	\N	\N	\N	2026-07-30 16:26:20.298467+08
814	Jan-Niklas Schäfer	\N	\N	\N	2026-07-30 16:26:20.30362+08
815	Tillmann Carl	\N	\N	\N	2026-07-30 16:26:20.30362+08
816	Kristin Kühl	\N	\N	\N	2026-07-30 16:26:20.30362+08
817	Sonja Kiehren-Ehses	\N	\N	\N	2026-07-30 16:26:20.30362+08
818	Jan Aurich	\N	\N	\N	2026-07-30 16:26:20.30362+08
819	Georg von Freymann	\N	\N	\N	2026-07-30 16:26:20.30362+08
820	Clarissa Schönecker	\N	\N	\N	2026-07-30 16:26:20.30362+08
821	A. G. Guézennec	\N	\N	\N	2026-07-30 16:26:20.312024+08
822	J. C. Huber	\N	\N	\N	2026-07-30 16:26:20.312024+08
823	F. Patisson	\N	\N	\N	2026-07-30 16:26:20.312024+08
824	P. Sessiecq	\N	\N	\N	2026-07-30 16:26:20.312024+08
825	J. P. Birat	\N	\N	\N	2026-07-30 16:26:20.312024+08
826	D. Ablitzer	\N	\N	\N	2026-07-30 16:26:20.312024+08
827	M. Khalid Hossain	\N	\N	\N	2026-07-30 16:26:20.318627+08
828	K. Hashizume	\N	\N	\N	2026-07-30 16:26:20.318627+08
829	Y. Hatano	\N	\N	\N	2026-07-30 16:26:20.318627+08
830	Xuyang Zhou	\N	\N	\N	2026-07-30 16:26:20.324792+08
831	Yang Bai	\N	\N	\N	2026-07-30 16:26:20.324792+08
832	Ayman A. El-Zoka	\N	\N	\N	2026-07-30 16:26:20.324792+08
833	Se-Ho Kim	\N	\N	\N	2026-07-30 16:26:20.324792+08
834	Yan Ma	\N	\N	\N	2026-07-30 16:26:20.324792+08
835	Christian H. Liebscher	\N	\N	\N	2026-07-30 16:26:20.324792+08
836	Baptiste Gault	\N	\N	\N	2026-07-30 16:26:20.324792+08
837	Jaber R. Mianroodi	\N	\N	\N	2026-07-30 16:26:20.324792+08
838	Gerhard Dehm	\N	\N	\N	2026-07-30 16:26:20.324792+08
839	Dierk Raabe	\N	\N	\N	2026-07-30 16:26:20.324792+08
840	Isnaldi R. Souza Filho1	\N	\N	\N	2026-07-30 16:26:20.334164+08
841	Hauke Springer	\N	\N	\N	2026-07-30 16:26:20.334164+08
842	Ankita Mahajan	\N	\N	\N	2026-07-30 16:26:20.334164+08
843	Cauê C. da Silva	\N	\N	\N	2026-07-30 16:26:20.334164+08
844	Michael Kulse	\N	\N	\N	2026-07-30 16:26:20.334164+08
845	Xueli Zheng	\N	\N	\N	2026-07-30 16:26:20.341301+08
846	Subhechchha Paul	\N	\N	\N	2026-07-30 16:26:20.341301+08
847	Lauren Moghimi	\N	\N	\N	2026-07-30 16:26:20.341301+08
848	Yifan Wang	\N	\N	\N	2026-07-30 16:26:20.341301+08
849	Rafael A. Vilá	\N	\N	\N	2026-07-30 16:26:20.341301+08
850	Fan Zhang	\N	\N	\N	2026-07-30 16:26:20.341301+08
851	Xin Gao	\N	\N	\N	2026-07-30 16:26:20.341301+08
852	Junjing Deng	\N	\N	\N	2026-07-30 16:26:20.341301+08
853	Yi Jiang	\N	\N	\N	2026-07-30 16:26:20.341301+08
854	Xin Xiao	\N	\N	\N	2026-07-30 16:26:20.341301+08
855	Chaolumen Wu	\N	\N	\N	2026-07-30 16:26:20.341301+08
856	Louisa C. Greenburg	\N	\N	\N	2026-07-30 16:26:20.341301+08
857	Yufei Yang	\N	\N	\N	2026-07-30 16:26:20.341301+08
858	Yi Cui	\N	\N	\N	2026-07-30 16:26:20.341301+08
859	Arturas Vailionis	\N	\N	\N	2026-07-30 16:26:20.341301+08
860	Ivan Kuzmenko	\N	\N	\N	2026-07-30 16:26:20.341301+08
861	Jan llavsky	\N	\N	\N	2026-07-30 16:26:20.341301+08
862	Yadong Yin	\N	\N	\N	2026-07-30 16:26:20.341301+08
863	Leora Dresselhaus-Marais	\N	\N	\N	2026-07-30 16:26:20.341301+08
864	Jaber Rezaei Mianroodi	\N	\N	\N	2026-07-30 16:26:20.356821+08
865	Alisson Kwiatkowski da Silva	\N	\N	\N	2026-07-30 16:26:20.356821+08
866	Bob Svendsen	\N	\N	\N	2026-07-30 16:26:20.356821+08
867	O. Devisme	\N	\N	\N	2026-07-30 16:26:20.361782+08
868	Leigh T. Stephenson	\N	\N	\N	2026-07-30 16:26:20.364698+08
869	Ran Huang	\N	\N	\N	2026-07-30 16:26:40.338435+08
870	Xiaomin Zhu	\N	\N	\N	2026-07-30 16:26:40.338435+08
871	Haiyan Tu	\N	\N	\N	2026-07-30 16:26:40.338435+08
872	Ajun Wan	\N	\N	\N	2026-07-30 16:26:40.338435+08
873	Shashank Shekhar Mishra	\N	\N	\N	2026-07-30 16:26:40.352352+08
874	Thakur Prasad Yadav	\N	\N	\N	2026-07-30 16:26:40.352352+08
875	Harrison Szeto	\N	\N	\N	2026-07-30 16:26:40.358692+08
876	Vijay Kumar	\N	\N	\N	2026-07-30 16:26:40.358692+08
877	Yangying Zhu	\N	\N	\N	2026-07-30 16:26:40.358692+08
878	Binghan Liu	\N	\N	\N	2026-07-30 16:26:40.363075+08
879	Gary S. Grest	\N	\N	\N	2026-07-30 16:26:40.363075+08
880	Shengfeng Cheng	\N	\N	\N	2026-07-30 16:26:40.363075+08
881	Shai Cohen	\N	\N	\N	2026-07-30 16:26:40.367349+08
882	David Andelman	\N	\N	\N	2026-07-30 16:26:40.367349+08
883	Arpan Mukherjee	\N	\N	\N	2026-07-30 16:26:40.371904+08
884	Deepesh Giri	\N	\N	\N	2026-07-30 16:26:40.371904+08
885	Krishna Rajan	\N	\N	\N	2026-07-30 16:26:40.371904+08
886	Ana M. Valencia	\N	\N	\N	2026-07-30 16:26:40.376626+08
887	Lisa Schraut-May	\N	\N	\N	2026-07-30 16:26:40.376626+08
888	Marie Siegert	\N	\N	\N	2026-07-30 16:26:40.376626+08
889	Sebastian Hammer	\N	\N	\N	2026-07-30 16:26:40.376626+08
890	Beatrice Cula	\N	\N	\N	2026-07-30 16:26:40.376626+08
891	Alexandra Friedrich	\N	\N	\N	2026-07-30 16:26:40.376626+08
892	Holger Helten	\N	\N	\N	2026-07-30 16:26:40.376626+08
893	Jens Pflaum	\N	\N	\N	2026-07-30 16:26:40.376626+08
894	Caterina Cocchi	\N	\N	\N	2026-07-30 16:26:40.376626+08
895	Andreas Opitz	\N	\N	\N	2026-07-30 16:26:40.376626+08
896	Swetha Nair	\N	\N	\N	2026-07-30 16:26:40.386082+08
897	Guillaume Jeanmairet	\N	\N	\N	2026-07-30 16:26:40.386082+08
898	Benjamin Rotenberg	\N	\N	\N	2026-07-30 16:26:40.386082+08
899	Urvesh Patil	\N	\N	\N	2026-07-30 16:26:40.391821+08
900	Nuala M. Caffrey	\N	\N	\N	2026-07-30 16:26:40.391821+08
901	S. M. Koohpayeh	\N	\N	\N	2026-07-30 16:26:40.395725+08
902	Jiajia Zhou	\N	\N	\N	2026-07-30 16:26:40.39897+08
903	Xingkun Man	\N	\N	\N	2026-07-30 16:26:40.39897+08
904	Ying Jiang	\N	\N	\N	2026-07-30 16:26:40.39897+08
905	Masao Doi	\N	\N	\N	2026-07-30 16:26:40.39897+08
906	Satanu Ghosh	\N	\N	\N	2026-07-30 16:26:40.404207+08
907	Neal R. Brodnik	\N	\N	\N	2026-07-30 16:26:40.404207+08
908	Carolina Frey	\N	\N	\N	2026-07-30 16:26:40.404207+08
909	Collin Holgate	\N	\N	\N	2026-07-30 16:26:40.404207+08
910	Tresa M. Pollock	\N	\N	\N	2026-07-30 16:26:40.404207+08
911	Samantha Daly	\N	\N	\N	2026-07-30 16:26:40.404207+08
912	Samuel Carton	\N	\N	\N	2026-07-30 16:26:40.404207+08
913	C. I. Addison	\N	\N	\N	2026-07-30 16:26:40.418752+08
914	A. A. Louis	\N	\N	\N	2026-07-30 16:26:40.418752+08
915	J-. P. Hansen	\N	\N	\N	2026-07-30 16:26:40.418752+08
916	A. Negadi	\N	\N	\N	2026-07-30 16:26:40.423029+08
917	A. Sans-Penninckx	\N	\N	\N	2026-07-30 16:26:40.423029+08
918	M. Bemouna	\N	\N	\N	2026-07-30 16:26:40.423029+08
919	T. A. Vilgis	\N	\N	\N	2026-07-30 16:26:40.423029+08
920	Joohoon Kang	\N	\N	\N	2026-07-30 16:26:40.427984+08
921	Joshua D. Wood	\N	\N	\N	2026-07-30 16:26:40.427984+08
922	Spencer A. Wells	\N	\N	\N	2026-07-30 16:26:40.427984+08
923	Jae-Hyeok Lee	\N	\N	\N	2026-07-30 16:26:40.427984+08
924	Xiaolong Liu	\N	\N	\N	2026-07-30 16:26:40.427984+08
925	Kan-Sheng Chen	\N	\N	\N	2026-07-30 16:26:40.427984+08
926	Mark C. Hersam	\N	\N	\N	2026-07-30 16:26:40.427984+08
927	Abhishek Khetan	\N	\N	\N	2026-07-30 16:26:40.434054+08
928	Heinz Pitsch	\N	\N	\N	2026-07-30 16:26:40.434054+08
929	Venkatasubramanian Viswanathan	\N	\N	\N	2026-07-30 16:26:40.434054+08
930	Qiang Zhao	\N	\N	\N	2026-07-30 16:26:40.438918+08
931	Jan Heyda	\N	\N	\N	2026-07-30 16:26:40.438918+08
932	Joachim Dzubiella	\N	\N	\N	2026-07-30 16:26:40.438918+08
933	Karoline Täuber	\N	\N	\N	2026-07-30 16:26:40.438918+08
934	John W. C. Dunlop	\N	\N	\N	2026-07-30 16:26:40.438918+08
935	Jiayin Yuan	\N	\N	\N	2026-07-30 16:26:40.438918+08
936	Shogo Kunieda	\N	\N	\N	2026-07-30 16:26:40.444831+08
937	Mitsuru Yambe	\N	\N	\N	2026-07-30 16:26:40.444831+08
938	Hiromori Murashima	\N	\N	\N	2026-07-30 16:26:40.444831+08
939	Takeru Nakamura	\N	\N	\N	2026-07-30 16:26:40.444831+08
940	Toshiaki Shintani	\N	\N	\N	2026-07-30 16:26:40.444831+08
941	Hitoshi Kamijima	\N	\N	\N	2026-07-30 16:26:40.444831+08
942	Yoshihiro Hayashi	\N	\N	\N	2026-07-30 16:26:40.444831+08
943	Yosuke Hanawa	\N	\N	\N	2026-07-30 16:26:40.444831+08
944	Ryo Yoshida	\N	\N	\N	2026-07-30 16:26:40.444831+08
945	Aida Serrano	\N	\N	\N	2026-07-30 16:26:40.453945+08
946	Eduardo García-Martín	\N	\N	\N	2026-07-30 16:26:40.453945+08
947	Cecilia Granados-Miralles	\N	\N	\N	2026-07-30 16:26:40.453945+08
948	Jesús López-Sánchez	\N	\N	\N	2026-07-30 16:26:40.453945+08
949	Giulio Gorni	\N	\N	\N	2026-07-30 16:26:40.453945+08
950	Adrián Quesada	\N	\N	\N	2026-07-30 16:26:40.453945+08
951	José F. Fernández	\N	\N	\N	2026-07-30 16:26:40.453945+08
952	Jose Roberto Bautista-Quijano	\N	\N	\N	2026-07-30 16:26:40.463929+08
953	Oscar Telschow	\N	\N	\N	2026-07-30 16:26:40.463929+08
954	Fabian Paulus	\N	\N	\N	2026-07-30 16:26:40.463929+08
955	Yana Vaynzof	\N	\N	\N	2026-07-30 16:26:40.463929+08
956	Hiroki Fujiwara	\N	\N	\N	2026-07-30 16:26:40.471038+08
957	Vi Cecilia Erik Kronberg	\N	\N	\N	2026-07-30 16:26:40.476698+08
958	Stela Andrea Muntean	\N	\N	\N	2026-07-30 16:26:40.476698+08
959	Nils Hendrik Kröger	\N	\N	\N	2026-07-30 16:26:40.476698+08
960	Adrian Muntean	\N	\N	\N	2026-07-30 16:26:40.476698+08
961	Gregory M. Grason	\N	\N	\N	2026-07-30 16:26:40.482923+08
962	B. Kh. Khannanov	\N	\N	\N	2026-07-30 16:26:40.487034+08
963	E. I. Golovenchits	\N	\N	\N	2026-07-30 16:26:40.487034+08
964	V. A. Sanina	\N	\N	\N	2026-07-30 16:26:40.487034+08
965	Weiwei Liu	\N	\N	\N	2026-07-30 16:26:40.493911+08
966	Zheng Zhang	\N	\N	\N	2026-07-30 16:26:40.493911+08
967	Jianting Ji	\N	\N	\N	2026-07-30 16:26:40.493911+08
968	Yixuan Liu	\N	\N	\N	2026-07-30 16:26:40.493911+08
969	Jianshu Li	\N	\N	\N	2026-07-30 16:26:40.493911+08
970	Xiaoqun Wang	\N	\N	\N	2026-07-30 16:26:40.493911+08
971	Hechang Lei	\N	\N	\N	2026-07-30 16:26:40.493911+08
972	Gang Chen	\N	\N	\N	2026-07-30 16:26:40.493911+08
973	Qingming Zhang	\N	\N	\N	2026-07-30 16:26:40.493911+08
974	Arnaud Quintas	\N	\N	\N	2026-07-30 16:26:40.505541+08
975	Daniel Caurant	\N	\N	\N	2026-07-30 16:26:40.505541+08
976	Odile Majérus	\N	\N	\N	2026-07-30 16:26:40.505541+08
977	Marion Lenoir	\N	\N	\N	2026-07-30 16:26:40.505541+08
978	Jean-Luc Dussossoy	\N	\N	\N	2026-07-30 16:26:40.505541+08
979	Thibault Charpentier	\N	\N	\N	2026-07-30 16:26:40.505541+08
980	D. R. Neuville	\N	\N	\N	2026-07-30 16:26:40.505541+08
981	A. Podlesnyak	\N	\N	\N	2026-07-30 16:26:40.513656+08
982	S. Nikitin	\N	\N	\N	2026-07-30 16:26:40.513656+08
983	G. Ehlers	\N	\N	\N	2026-07-30 16:26:40.513656+08
984	Asish K. Kundu	\N	\N	\N	2026-07-30 16:26:40.518387+08
985	K. Ramesha	\N	\N	\N	2026-07-30 16:26:40.518387+08
986	Ram Seshadri	\N	\N	\N	2026-07-30 16:26:40.518387+08
987	C. N. R. Rao	\N	\N	\N	2026-07-30 16:26:40.518387+08
988	Anthony T Paxton	\N	\N	\N	2026-07-30 16:27:00.812737+08
989	Taki Aissou	\N	\N	\N	2026-07-30 16:27:00.821566+08
990	Jerome Menneveux	\N	\N	\N	2026-07-30 16:27:00.821566+08
991	Fanny Casteignau	\N	\N	\N	2026-07-30 16:27:00.821566+08
992	Nadi Braidy	\N	\N	\N	2026-07-30 16:27:00.821566+08
993	Jocelyn Veilleux	\N	\N	\N	2026-07-30 16:27:00.821566+08
994	P. A. S. Autreto	\N	\N	\N	2026-07-30 16:27:00.829812+08
995	J. M. de Sousa	\N	\N	\N	2026-07-30 16:27:00.829812+08
996	D. S. Galvao	\N	\N	\N	2026-07-30 16:27:00.829812+08
997	Thomas Leiner	\N	\N	\N	2026-07-30 16:27:00.834004+08
998	David Holec	\N	\N	\N	2026-07-30 16:27:00.834004+08
999	Vikram Mahamiya	\N	\N	\N	2026-07-30 16:27:00.837357+08
1000	Alok Shukla	\N	\N	\N	2026-07-30 16:27:00.837357+08
1001	Brahmananda Chakraborty	\N	\N	\N	2026-07-30 16:27:00.837357+08
1002	Heena Khanchandani	\N	\N	\N	2026-07-30 16:27:00.840947+08
1003	Rolf Rolli	\N	\N	\N	2026-07-30 16:27:00.840947+08
1004	Hans-Christian Schneider	\N	\N	\N	2026-07-30 16:27:00.840947+08
1005	Christoph Kirchlechner	\N	\N	\N	2026-07-30 16:27:00.840947+08
1006	Stefan Zeiler	\N	\N	\N	2026-07-30 16:27:00.846256+08
1007	Lucas Strobel	\N	\N	\N	2026-07-30 16:27:00.846256+08
1008	Mathias Goeken	\N	\N	\N	2026-07-30 16:27:00.846256+08
1009	Peter Felfer	\N	\N	\N	2026-07-30 16:27:00.846256+08
1010	Eugene Ogosi	\N	\N	\N	2026-07-30 16:27:00.852293+08
1011	Umair Bin Asim	\N	\N	\N	2026-07-30 16:27:00.852293+08
1012	Amir Siddiq	\N	\N	\N	2026-07-30 16:27:00.852293+08
1013	Mehmet Kartal	\N	\N	\N	2026-07-30 16:27:00.852293+08
1014	Xiaohan Bie	\N	\N	\N	2026-07-30 16:27:00.857029+08
1015	Baihua Ren	\N	\N	\N	2026-07-30 16:27:00.857029+08
1016	Xiao Zhou	\N	\N	\N	2026-07-30 16:27:00.857029+08
1017	Salim Brahimi	\N	\N	\N	2026-07-30 16:27:00.857029+08
1018	Stephen Yue	\N	\N	\N	2026-07-30 16:27:00.857029+08
1019	Jun Song	\N	\N	\N	2026-07-30 16:27:00.857029+08
1020	Guillaume Hachet	\N	\N	\N	2026-07-30 16:27:00.861448+08
1021	Ali Tehranchi	\N	\N	\N	2026-07-30 16:27:00.861448+08
1022	Hao Shi	\N	\N	\N	2026-07-30 16:27:00.861448+08
1023	Manoj Prabhakar	\N	\N	\N	2026-07-30 16:27:00.861448+08
1024	Shaolou Wei	\N	\N	\N	2026-07-30 16:27:00.861448+08
1025	Katja Angenendt	\N	\N	\N	2026-07-30 16:27:00.861448+08
1026	Stefan Zaefferer	\N	\N	\N	2026-07-30 16:27:00.861448+08
1027	Binhan Sun	\N	\N	\N	2026-07-30 16:27:00.861448+08
1028	Dirk Ponge	\N	\N	\N	2026-07-30 16:27:00.861448+08
1029	Chunguang Tang	\N	\N	\N	2026-07-30 16:27:00.868654+08
1030	Shunxin Fei	\N	\N	\N	2026-07-30 16:27:00.868654+08
1031	G. David Lin	\N	\N	\N	2026-07-30 16:27:00.868654+08
1032	Yun Liu	\N	\N	\N	2026-07-30 16:27:00.868654+08
1033	Torben Tappe	\N	\N	\N	2026-07-30 16:27:00.872743+08
1034	Louis Becker	\N	\N	\N	2026-07-30 16:27:00.872743+08
1035	Gaurav Kanu	\N	\N	\N	2026-07-30 16:27:00.872743+08
1036	Thomas F. Headen	\N	\N	\N	2026-07-30 16:27:00.872743+08
1037	Dirk Honecker	\N	\N	\N	2026-07-30 16:27:00.872743+08
1038	Gabi Schierning	\N	\N	\N	2026-07-30 16:27:00.872743+08
1039	Santiago Benito	\N	\N	\N	2026-07-30 16:27:00.872743+08
1040	Sebastian Weber	\N	\N	\N	2026-07-30 16:27:00.872743+08
1041	Klara Lünser	\N	\N	\N	2026-07-30 16:27:00.872743+08
1042	Sabrina Disch	\N	\N	\N	2026-07-30 16:27:00.872743+08
1043	Cem Örnek	\N	\N	\N	2026-07-30 16:27:00.885324+08
1044	Alfred Larsson	\N	\N	\N	2026-07-30 16:27:00.885324+08
1045	Mubashir Mansoor	\N	\N	\N	2026-07-30 16:27:00.885324+08
1046	Gary S Harlow	\N	\N	\N	2026-07-30 16:27:00.885324+08
1047	Robin Kroll	\N	\N	\N	2026-07-30 16:27:00.885324+08
1048	Francesco Carlà	\N	\N	\N	2026-07-30 16:27:00.885324+08
1049	Hadeel Hussain	\N	\N	\N	2026-07-30 16:27:00.885324+08
1050	Bora C Derin	\N	\N	\N	2026-07-30 16:27:00.885324+08
1051	Ulf Kivisäkk	\N	\N	\N	2026-07-30 16:27:00.885324+08
1052	Dirk L Engelberg	\N	\N	\N	2026-07-30 16:27:00.885324+08
1053	Edvin Lundgren	\N	\N	\N	2026-07-30 16:27:00.885324+08
1054	Jinshan Pan	\N	\N	\N	2026-07-30 16:27:00.885324+08
1055	Anton Nikitin	\N	\N	\N	2026-07-30 16:27:00.898023+08
1056	Hirohito Ogasawara	\N	\N	\N	2026-07-30 16:27:00.898023+08
1057	David Mann	\N	\N	\N	2026-07-30 16:27:00.898023+08
1058	Reinhard Denecke	\N	\N	\N	2026-07-30 16:27:00.898023+08
1059	Zhiyong Zhang	\N	\N	\N	2026-07-30 16:27:00.898023+08
1060	Hongjie Dai	\N	\N	\N	2026-07-30 16:27:00.898023+08
1061	KJ Cho	\N	\N	\N	2026-07-30 16:27:00.898023+08
1062	Anders Nilsson	\N	\N	\N	2026-07-30 16:27:00.898023+08
1063	Hiroshi Kakinuma	\N	\N	\N	2026-07-30 16:27:00.90817+08
1064	Saya Ajito	\N	\N	\N	2026-07-30 16:27:00.90817+08
1065	Koki Okumura	\N	\N	\N	2026-07-30 16:27:00.90817+08
1066	Makoto Akahoshi	\N	\N	\N	2026-07-30 16:27:00.90817+08
1067	Yu Takabatake	\N	\N	\N	2026-07-30 16:27:00.90817+08
1068	Tomohiko Omura	\N	\N	\N	2026-07-30 16:27:00.90817+08
1069	Motomichi Koyama	\N	\N	\N	2026-07-30 16:27:00.90817+08
1070	Eiji Akiyama	\N	\N	\N	2026-07-30 16:27:00.90817+08
1071	Wei Pei	\N	\N	\N	2026-07-30 16:27:00.919312+08
1072	Si Zhou	\N	\N	\N	2026-07-30 16:27:00.919312+08
1073	Yizhen Bai	\N	\N	\N	2026-07-30 16:27:00.919312+08
1074	Jijun Zhao	\N	\N	\N	2026-07-30 16:27:00.919312+08
1075	D. Gortat	\N	\N	\N	2026-07-30 16:27:00.924178+08
1076	M. Sparkes	\N	\N	\N	2026-07-30 16:27:00.924178+08
1077	S. B. Fairchild	\N	\N	\N	2026-07-30 16:27:00.924178+08
1078	P. T. Murray	\N	\N	\N	2026-07-30 16:27:00.924178+08
1079	M. M. Cahay	\N	\N	\N	2026-07-30 16:27:00.924178+08
1080	T. C. Back	\N	\N	\N	2026-07-30 16:27:00.924178+08
1081	G. J. Gruen	\N	\N	\N	2026-07-30 16:27:00.924178+08
1082	N. P. Lockwood	\N	\N	\N	2026-07-30 16:27:00.924178+08
1083	W. O Neill	\N	\N	\N	2026-07-30 16:27:00.924178+08
1084	Rama Srinivas Varanasi	\N	\N	\N	2026-07-30 16:27:00.934038+08
1085	Shuya Chiba	\N	\N	\N	2026-07-30 16:27:00.934038+08
1086	Viney Dixit	\N	\N	\N	2026-07-30 16:27:00.939144+08
1087	Ashish Bhatnagar	\N	\N	\N	2026-07-30 16:27:00.939144+08
1088	R. R. Shahi	\N	\N	\N	2026-07-30 16:27:00.939144+08
1089	T. P. Yadav	\N	\N	\N	2026-07-30 16:27:00.939144+08
1090	O. N. Srivastava	\N	\N	\N	2026-07-30 16:27:00.939144+08
1091	Taemin Ahn	\N	\N	\N	2026-07-30 16:27:00.945105+08
1092	Tae-Hwan Kim	\N	\N	\N	2026-07-30 16:27:00.945105+08
1093	Andrew J. Breen	\N	\N	\N	2026-07-30 16:27:00.94927+08
1094	Yujiao Li	\N	\N	\N	2026-07-30 16:27:00.94927+08
1095	Olga Kasian	\N	\N	\N	2026-07-30 16:27:00.94927+08
1096	Michael Herbig	\N	\N	\N	2026-07-30 16:27:00.94927+08
1097	M. Amir Siddiq	\N	\N	\N	2026-07-30 16:27:00.956108+08
1098	Arpita Adhikari	\N	\N	\N	2026-07-30 16:27:00.959766+08
1099	Joydip Sengupta	\N	\N	\N	2026-07-30 16:27:00.959766+08
1100	F. Simon	\N	\N	\N	2026-07-30 16:27:00.963418+08
1101	H. Kuzmany	\N	\N	\N	2026-07-30 16:27:00.963418+08
1102	J. Bernardi	\N	\N	\N	2026-07-30 16:27:00.963418+08
1103	F. Hauke	\N	\N	\N	2026-07-30 16:27:00.963418+08
1104	A. Hirsch	\N	\N	\N	2026-07-30 16:27:00.963418+08
1105	Albert J. Pool	\N	\N	\N	2026-07-30 16:27:00.970132+08
1106	Sandeep K. Jain	\N	\N	\N	2026-07-30 16:27:00.970132+08
1107	Gerard T. Barkema	\N	\N	\N	2026-07-30 16:27:00.970132+08
1108	S. Boisseau	\N	\N	\N	2026-07-30 16:27:00.978185+08
1109	A. -B. Duret	\N	\N	\N	2026-07-30 16:27:00.978185+08
1110	J. -J. Chaillout	\N	\N	\N	2026-07-30 16:27:00.978185+08
1111	G. Despesse	\N	\N	\N	2026-07-30 16:27:00.978185+08
1112	Michael Zinigrad	\N	\N	\N	2026-07-30 16:27:29.729325+08
1113	Sang Jun Kim	\N	\N	\N	2026-07-30 16:27:29.73961+08
1114	Ji Yun Kang	\N	\N	\N	2026-07-30 16:27:29.73961+08
1115	Yong Zhang	\N	\N	\N	2026-07-30 16:27:29.73961+08
1116	Yongjie Zhang	\N	\N	\N	2026-07-30 16:27:29.73961+08
1117	Tadashi Furuhara	\N	\N	\N	2026-07-30 16:27:29.73961+08
1118	Eun Soo Park	\N	\N	\N	2026-07-30 16:27:29.73961+08
1119	Cemal Cem Tasan	\N	\N	\N	2026-07-30 16:27:29.73961+08
1120	Yusuke Kataoka	\N	\N	\N	2026-07-30 16:27:29.747289+08
1121	Taisuke Ono	\N	\N	\N	2026-07-30 16:27:29.747289+08
1122	Masami Tsubota	\N	\N	\N	2026-07-30 16:27:29.747289+08
1123	Jiro Kitagawa	\N	\N	\N	2026-07-30 16:27:29.747289+08
1841	Isabel F.F. Neto	\N	Universidade do Porto	\N	2026-08-17 11:35:14.288379+08
1842	Helena M. V. M. Soares	\N	Universidade do Porto	\N	2026-08-17 11:35:14.288379+08
1843	Andrzej Chmielarz	\N	Instytut Metalurgii Żelaza im. Stanisława Staszica	\N	2026-08-17 11:35:14.288379+08
1844	Yan Xu	\N	State Key Joint Laboratory of Environment Simulation and Pollution Control	\N	2026-08-17 11:35:14.296554+08
1845	Jinhui Li	\N	State Key Joint Laboratory of Environment Simulation and Pollution Control	\N	2026-08-17 11:35:14.296554+08
1846	Lili Liu	\N	State Key Joint Laboratory of Environment Simulation and Pollution Control	\N	2026-08-17 11:35:14.296554+08
1847	Muhammad Adnan	\N	Chinese Academy of Sciences	\N	2026-08-17 11:35:14.300947+08
1848	Baohua Xiao	\N	Chinese Academy of Sciences	\N	2026-08-17 11:35:14.300947+08
1849	Peiwen Xiao	\N	Chinese Academy of Sciences	\N	2026-08-17 11:35:14.300947+08
1850	Peng Zhao	\N	Chinese Academy of Sciences	\N	2026-08-17 11:35:14.300947+08
1851	Ruolan Li	\N	Chinese Academy of Sciences	\N	2026-08-17 11:35:14.300947+08
1852	Shaheen Bibi	\N	Lanzhou Veterinary Research Institute	\N	2026-08-17 11:35:14.300947+08
1853	Pavel Yudaev	\N	D. Mendeleyev University of Chemical Technology of Russia	\N	2026-08-17 11:35:14.307923+08
1854	Evgeniy M. Chistyakov	\N	D. Mendeleyev University of Chemical Technology of Russia	\N	2026-08-17 11:35:14.307923+08
1855	Н. В. Фомченко	\N	Russian Academy of Sciences	\N	2026-08-17 11:35:14.311855+08
1856	Maxim Muravyov	\N	Russian Academy of Sciences	\N	2026-08-17 11:35:14.311855+08
1857	Antti Porvali	\N	Aalto University	\N	2026-08-17 11:35:14.317696+08
1858	Severi Ojanen	\N	Aalto University	\N	2026-08-17 11:35:14.317696+08
1859	Omar Velázquez-Martínez	\N	Aalto University	\N	2026-08-17 11:35:14.317696+08
1860	Emmi Eronen	\N	Aalto University	\N	2026-08-17 11:35:14.317696+08
1861	Fupeng Liu	\N	Jiangxi University of Science and Technology	\N	2026-08-17 11:35:14.317696+08
1862	Rodrigo Serna-Guerrero	\N	Aalto University	\N	2026-08-17 11:35:14.317696+08
1863	Shahjadi Hisan Farjana	\N	Macquarie University	\N	2026-08-17 11:35:14.325598+08
1864	Nazmul Huda	\N	Macquarie University	\N	2026-08-17 11:35:14.325598+08
1865	M. A. Parvez Mahmud	\N	Macquarie University	\N	2026-08-17 11:35:14.325598+08
1866	Thupten Palden	\N	KU Leuven	\N	2026-08-17 11:35:14.331246+08
1867	Mercedes Regadío	\N	KU Leuven	\N	2026-08-17 11:35:14.331246+08
1868	Bieke Onghena	\N	KU Leuven	\N	2026-08-17 11:35:14.331246+08
1869	Ipek Tezyapar Kara	\N	Cranfield University	\N	2026-08-17 11:35:14.340464+08
1870	K Kremser	\N	BOKU University	\N	2026-08-17 11:35:14.340464+08
1871	Stuart Wagland	\N	Cranfield University	\N	2026-08-17 11:35:14.340464+08
1872	Frédéric Coulon	\N	Cranfield University	\N	2026-08-17 11:35:14.340464+08
1873	Qiangchao Sun	\N	Shanghai University	\N	2026-08-17 11:35:14.345748+08
1874	Hongwei Cheng	\N	Shanghai University	\N	2026-08-17 11:35:14.345748+08
1875	Xiaoyong Mei	\N	Shanghai University	\N	2026-08-17 11:35:14.345748+08
1876	Yanbo Liu	\N	Shanghai University	\N	2026-08-17 11:35:14.345748+08
1877	Guangshi Li	\N	Shanghai University	\N	2026-08-17 11:35:14.345748+08
1878	Qian Xu	\N	Shanghai University	\N	2026-08-17 11:35:14.345748+08
1879	Xionggang Lu	\N	Shanghai University	\N	2026-08-17 11:35:14.345748+08
1880	Yayun Wang	\N	University of Science and Technology Beijing	\N	2026-08-17 11:35:14.352369+08
1881	Huifen Yang	\N	University of Science and Technology Beijing	\N	2026-08-17 11:35:14.352369+08
1882	Ge Zhang	\N	University of Science and Technology Beijing	\N	2026-08-17 11:35:14.352369+08
1883	Jinxing Kang	\N	University of Science and Technology Beijing	\N	2026-08-17 11:35:14.352369+08
1884	Chuan-Long Wang	\N	\N	\N	2026-08-17 11:35:14.352369+08
1885	Terence Makanyire	\N	University of Leeds	\N	2026-08-17 11:35:14.358293+08
1886	Sergio Sánchez‐Segado	\N	University of Leeds	\N	2026-08-17 11:35:14.358293+08
1887	Animesh Jha	\N	University of Leeds	\N	2026-08-17 11:35:14.358293+08
1888	Rafael M. Santos	\N	Sheridan College	\N	2026-08-17 11:35:14.363148+08
1889	Aldo Van Audenaerde	\N	KU Leuven	\N	2026-08-17 11:35:14.363148+08
1890	Yi Wai Chiang	\N	University of Guelph	\N	2026-08-17 11:35:14.363148+08
1891	Remus Ion Iacobescu	\N	KU Leuven	\N	2026-08-17 11:35:14.363148+08
1892	Pol Knops	\N	\N	\N	2026-08-17 11:35:14.363148+08
1893	Tom Van Gerven	\N	KU Leuven	\N	2026-08-17 11:35:14.363148+08
1894	Isnaldi Rodrigues de Souza Filho	\N	Max-Planck-Institut für Nachhaltige Materialien	\N	2026-08-17 11:35:16.827262+08
1895	Arik Beck	\N	ETH Zurich	\N	2026-08-17 11:35:16.827262+08
1896	Jeroen A. van Bokhoven	\N	Paul Scherrer Institute	\N	2026-08-17 11:35:16.827262+08
1897	Marc‐Georg Willinger	\N	ETH Zurich	\N	2026-08-17 11:35:16.827262+08
1898	Kejiang Li	\N	University of Science and Technology Beijing	\N	2026-08-17 11:35:16.827262+08
1899	Degang Xie	\N	Max-Planck-Institut für Nachhaltige Materialien	\N	2026-08-17 11:35:16.827262+08
1900	Carina Harpprecht	\N	Leiden University	\N	2026-08-17 11:35:16.869886+08
1901	Tobias Naegler	\N	Deutsches Zentrum für Luft- und Raumfahrt e. V. (DLR)	\N	2026-08-17 11:35:16.869886+08
1902	Bernhard Steubing	\N	Leiden University	\N	2026-08-17 11:35:16.869886+08
1903	Arnold Tukker	\N	Leiden University	\N	2026-08-17 11:35:16.869886+08
1904	Sonja Simon	\N	Deutsches Zentrum für Luft- und Raumfahrt e. V. (DLR)	\N	2026-08-17 11:35:16.869886+08
1905	Francesco Superchi	\N	University of Florence	\N	2026-08-17 11:35:16.881161+08
1906	Alessandro Mati	\N	University of Florence	\N	2026-08-17 11:35:16.881161+08
1907	Carlo Carcasci	\N	University of Florence	\N	2026-08-17 11:35:16.881161+08
1908	Alessandro Bianchini	\N	University of Florence	\N	2026-08-17 11:35:16.881161+08
1909	Duncan Kushnir	\N	Lund University	\N	2026-08-17 11:35:16.888978+08
1910	Teis Hansen	\N	Lund University	\N	2026-08-17 11:35:16.888978+08
1911	Valentin Vogl	\N	Lund University	\N	2026-08-17 11:35:16.888978+08
1912	Max Åhman	\N	Lund University	\N	2026-08-17 11:35:16.888978+08
1913	Lauri Holappa	\N	Aalto University	\N	2026-08-17 11:35:16.898726+08
1914	M. Jayachandran	\N	\N	\N	2026-08-17 11:35:16.905654+08
1915	Ranjith Kumar Gatla	\N	\N	\N	2026-08-17 11:35:16.905654+08
1916	Aymen Flah	\N	University of Business and Technology	\N	2026-08-17 11:35:16.905654+08
1917	Ahmad H. Milyani	\N	King Abdulaziz University	\N	2026-08-17 11:35:16.905654+08
1918	Hisham M. Milyani	\N	King Abdulaziz University	\N	2026-08-17 11:35:16.905654+08
1919	Vojtěch Blažek	\N	VSB - Technical University of Ostrava	\N	2026-08-17 11:35:16.905654+08
1920	Lukáš Prokop	\N	VSB - Technical University of Ostrava	\N	2026-08-17 11:35:16.905654+08
1921	Habib Kraiem	\N	Northern Border University	\N	2026-08-17 11:35:16.905654+08
1922	Alla Toktarova	\N	Chalmers University of Technology	\N	2026-08-17 11:35:16.916783+08
1923	Ida Karlsson	\N	Chalmers University of Technology	\N	2026-08-17 11:35:16.916783+08
1924	Johan Rootzén	\N	University of Gothenburg	\N	2026-08-17 11:35:16.916783+08
1925	Lisa Göransson	\N	Chalmers University of Technology	\N	2026-08-17 11:35:16.916783+08
1926	Mikael Odenberger	\N	Chalmers University of Technology	\N	2026-08-17 11:35:16.916783+08
1927	Filip Johnsson	\N	Chalmers University of Technology	\N	2026-08-17 11:35:16.916783+08
1928	Adrian Odenweller	\N	Leibniz Association	\N	2026-08-17 11:35:16.92593+08
1929	Falko Ueckerdt	\N	Leibniz Association	\N	2026-08-17 11:35:16.92593+08
1930	Alexandra Devlin	\N	University of Oxford	\N	2026-08-17 11:35:16.931434+08
1931	Jannik Kossen	\N	University of Oxford	\N	2026-08-17 11:35:16.931434+08
1932	Haulwen Goldie-Jones	\N	University of Oxford	\N	2026-08-17 11:35:16.931434+08
1933	Aidong Yang	\N	University of Oxford	\N	2026-08-17 11:35:16.931434+08
1934	Katherine Jordan	\N	Carnegie Mellon University	\N	2026-08-17 11:35:16.938314+08
1935	Paulina Jaramillo	\N	Carnegie Mellon University	\N	2026-08-17 11:35:16.938314+08
1936	Valerie J. Karplus	\N	Carnegie Mellon University	\N	2026-08-17 11:35:16.938314+08
1937	P. J. Adams	\N	Carnegie Mellon University	\N	2026-08-17 11:35:16.938314+08
1938	Nicholas Z. Muller	\N	National Bureau of Economic Research	\N	2026-08-17 11:35:16.938314+08
1939	Shannon W. Boettcher	\N	Lawrence Berkeley National Laboratory	\N	2026-08-17 11:35:16.943909+08
1940	Md Monjur Hossain Bhuiyan	\N	University of Oklahoma	\N	2026-08-17 11:35:16.948811+08
1941	Zahed Siddique	\N	University of Oklahoma	\N	2026-08-17 11:35:16.948811+08
1942	Yang Guo	\N	Princeton University	\N	2026-08-17 11:35:16.955279+08
1943	Liqun Peng	\N	Princeton University	\N	2026-08-17 11:35:16.955279+08
1944	Jinping Tian	\N	Tsinghua University	\N	2026-08-17 11:35:16.955279+08
1945	Denise L. Mauzerall	\N	Princeton University	\N	2026-08-17 11:35:16.955279+08
1946	Matic Jovičević‐Klug	\N	\N	\N	2026-08-17 11:35:16.961498+08
1947	Alexander Gramlich	\N	RWTH Aachen University	\N	2026-08-17 11:35:16.961498+08
1948	A. Nicholas Grundy	\N	\N	\N	2026-08-17 11:35:16.961498+08
1949	Caineng Zou	\N	Research Institute of Petroleum Exploration and Development	\N	2026-08-17 11:35:16.967286+08
1950	Bo Xiong	\N	Research Institute of Petroleum Exploration and Development	\N	2026-08-17 11:35:16.967286+08
1951	Huaqing Xue	\N	Research Institute of Petroleum Exploration and Development	\N	2026-08-17 11:35:16.967286+08
1952	Dewen Zheng	\N	Research Institute of Petroleum Exploration and Development	\N	2026-08-17 11:35:16.967286+08
1953	GE Zhi-xin	\N	Research Institute of Petroleum Exploration and Development	\N	2026-08-17 11:35:16.967286+08
1954	Ying Wang	\N	Research Institute of Petroleum Exploration and Development	\N	2026-08-17 11:35:16.967286+08
1955	Luyang Jiang	\N	Research Institute of Petroleum Exploration and Development	\N	2026-08-17 11:35:16.967286+08
1956	Songqi Pan	\N	Research Institute of Petroleum Exploration and Development	\N	2026-08-17 11:35:16.967286+08
1957	Songtao Wu	\N	Research Institute of Petroleum Exploration and Development	\N	2026-08-17 11:35:16.967286+08
1958	Quansheng Li	\N	Tianjin Energy Investment Group (China)	\N	2026-08-17 11:35:16.975195+08
1959	Colin D. Hills	\N	University of Greenwich	\N	2026-08-17 11:35:16.980405+08
1960	Nimisha Tripathi	\N	University of Greenwich	\N	2026-08-17 11:35:16.980405+08
1961	Paula J. Carey	\N	University of Greenwich	\N	2026-08-17 11:35:16.980405+08
1962	Marian Flores-Granobles	\N	Ghent University Hospital	\N	2026-08-17 11:35:16.986687+08
1963	Mark Saeys	\N	Ghent University Hospital	\N	2026-08-17 11:35:16.986687+08
1964	Huw Pullin	\N	Cardiff University	\N	2026-08-17 11:35:16.991655+08
1965	Andrew W. Bray	\N	University of Leeds	\N	2026-08-17 11:35:16.991655+08
1966	Ian T. Burke	\N	University of Leeds	\N	2026-08-17 11:35:16.991655+08
1967	Duncan Muir	\N	Cardiff University	\N	2026-08-17 11:35:16.991655+08
1968	Devin Sapsford	\N	Cardiff University	\N	2026-08-17 11:35:16.991655+08
1969	William M. Mayes	\N	University of Hull	\N	2026-08-17 11:35:16.991655+08
1970	Phil Renforth	\N	Heriot-Watt University	\N	2026-08-17 11:35:16.991655+08
1971	Ilman Nuran Zaini	\N	KTH Royal Institute of Technology	\N	2026-08-17 11:35:16.998162+08
1972	Anissa Nurdiawati	\N	KTH Royal Institute of Technology	\N	2026-08-17 11:35:16.998162+08
1973	Joel Gustavsson	\N	\N	\N	2026-08-17 11:35:16.998162+08
1974	Wenjing Wei	\N	KTH Royal Institute of Technology	\N	2026-08-17 11:35:16.998162+08
1975	Henrik Thunman	\N	Chalmers University of Technology	\N	2026-08-17 11:35:16.998162+08
1976	Rutger Gyllenram	\N	\N	\N	2026-08-17 11:35:16.998162+08
1977	Peter Samuelsson	\N	KTH Royal Institute of Technology	\N	2026-08-17 11:35:16.998162+08
1978	Weihong Yang	\N	KTH Royal Institute of Technology	\N	2026-08-17 11:35:16.998162+08
1979	Elias Matinde	\N	University of the Witwatersrand	\N	2026-08-17 11:35:19.254964+08
1980	Alaa M. Rashad	\N	Shaqra University	\N	2026-08-17 11:35:19.264521+08
1981	Alexander S. Brand	\N	Virginia Tech	\N	2026-08-17 11:35:19.26955+08
1982	Punit Singhvi	\N	University of Illinois Urbana-Champaign	\N	2026-08-17 11:35:19.26955+08
1983	Ebenezer O. Fanijo	\N	Virginia Tech	\N	2026-08-17 11:35:19.26955+08
1984	Erol Tutumluer	\N	University of Illinois Urbana-Champaign	\N	2026-08-17 11:35:19.26955+08
1985	Yiliang Liu	\N	North China University of Science and Technology	\N	2026-08-17 11:35:19.274664+08
1986	Youpo Su	\N	North China University of Science and Technology	\N	2026-08-17 11:35:19.274664+08
1987	Guoqiang Xu	\N	North China University of Science and Technology	\N	2026-08-17 11:35:19.274664+08
1988	Yanhua Chen	\N	North China University of Science and Technology	\N	2026-08-17 11:35:19.274664+08
1989	Gaoshuai You	\N	North China Institute of Aerospace Engineering	\N	2026-08-17 11:35:19.274664+08
1990	Xiao Liu	\N	Shandong University of Science and Technology	\N	2026-08-17 11:35:19.281146+08
1991	Peng Gao	\N	State Key Laboratory of Oil and Gas Reservoir Geology and Exploitation	\N	2026-08-17 11:35:19.281146+08
1992	Yuexin Han	\N	State Key Laboratory of Oil and Gas Reservoir Geology and Exploitation	\N	2026-08-17 11:35:19.281146+08
1993	Ju Xu	\N	Wuhan University of Science and Technology	\N	2026-08-17 11:35:19.286176+08
1994	Mengke Liu	\N	Wuhan University of Science and Technology	\N	2026-08-17 11:35:19.286176+08
1995	Guojun Ma	\N	Wuhan University of Science and Technology	\N	2026-08-17 11:35:19.286176+08
1996	Dingli Zheng	\N	Wuhan University of Science and Technology	\N	2026-08-17 11:35:19.286176+08
1997	Xiang Zhang	\N	Wuhan University of Science and Technology	\N	2026-08-17 11:35:19.286176+08
1998	Yanglai Hou	\N	Wuhan University of Science and Technology	\N	2026-08-17 11:35:19.286176+08
1999	Sunil Kumar Tripathy	\N	Centre National de la Recherche Scientifique	\N	2026-08-17 11:35:19.291983+08
2000	Jayalaxmi Dasu	\N	Tata Steel (India)	\N	2026-08-17 11:35:19.291983+08
2001	Y. Rama Murthy	\N	Tata Steel (India)	\N	2026-08-17 11:35:19.291983+08
2002	Gajanan U. Kapure	\N	Tata Steel (India)	\N	2026-08-17 11:35:19.291983+08
2003	Atanu Ranajan Pal	\N	Tata Steel (India)	\N	2026-08-17 11:35:19.291983+08
2004	Lev O. Filippov	\N	Centre National de la Recherche Scientifique	\N	2026-08-17 11:35:19.291983+08
2005	Di Gao	\N	North China University of Science and Technology	\N	2026-08-17 11:35:19.297959+08
2006	Fuping Wang	\N	North China University of Science and Technology	\N	2026-08-17 11:35:19.297959+08
2007	Yitong Wang	\N	North China University of Science and Technology	\N	2026-08-17 11:35:19.297959+08
2008	Yanan Zeng	\N	North China University of Science and Technology	\N	2026-08-17 11:35:19.297959+08
2009	Tlotlo Solomon Gabasiane	\N	Botswana International University of Science and Technology	\N	2026-08-17 11:35:19.305914+08
2010	Tirivaviri Mamvura	\N	Botswana International University of Science and Technology	\N	2026-08-17 11:35:19.305914+08
2011	Tebogo Mashifana	\N	University of Johannesburg	\N	2026-08-17 11:35:19.305914+08
2012	Godfrey Dzinomwa	\N	Namibia University of Science and Technology	\N	2026-08-17 11:35:19.305914+08
2013	Liqun Zhang	\N	University of Science and Technology of China	\N	2026-08-17 11:35:19.314917+08
2014	Huihui Zhou	\N	University of Science and Technology of China	\N	2026-08-17 11:35:19.314917+08
2015	Chen Xing	\N	Anhui University	\N	2026-08-17 11:35:19.314917+08
2016	Guijian Liu	\N	University of Science and Technology of China	\N	2026-08-17 11:35:19.314917+08
2017	Chunlu Jiang	\N	Anhui University	\N	2026-08-17 11:35:19.314917+08
2018	Liugen Zheng	\N	Anhui University	\N	2026-08-17 11:35:19.314917+08
2019	Guangzong Zhang	\N	Universidad del Noreste	\N	2026-08-17 11:35:19.323195+08
2020	Nan Wang	\N	Universidad del Noreste	\N	2026-08-17 11:35:19.323195+08
2021	Min Chen	\N	Universidad del Noreste	\N	2026-08-17 11:35:19.323195+08
2022	Yanqing Cheng	\N	Universidad del Noreste	\N	2026-08-17 11:35:19.323195+08
2023	Katarzyna Nowińska	\N	Silesian University of Technology	\N	2026-08-17 11:35:19.329742+08
2024	Zdzisław Adamczyk	\N	Silesian University of Technology	\N	2026-08-17 11:35:19.329742+08
2025	Jan Pizoń	\N	Silesian University of Technology	\N	2026-08-17 11:35:19.33708+08
2026	Jacek Gołaszewski	\N	Silesian University of Technology	\N	2026-08-17 11:35:19.33708+08
2027	Mohamed Alwaeli	\N	Silesian University of Technology	\N	2026-08-17 11:35:19.33708+08
2028	Patryk Szwan	\N	Silesian University of Technology	\N	2026-08-17 11:35:19.33708+08
2029	Mifeng Gou	\N	Henan Polytechnic University	\N	2026-08-17 11:35:19.349315+08
2030	Longfei Zhou	\N	Henan Polytechnic University	\N	2026-08-17 11:35:19.349315+08
2031	Nathalene Wei Ying Then	\N	Oregon State University	\N	2026-08-17 11:35:19.349315+08
2032	Xiaofei Li	\N	Northeastern University	\N	2026-08-17 11:35:19.356056+08
2033	Ting‐an Zhang	\N	Northeastern University	\N	2026-08-17 11:35:19.356056+08
2034	Guozhi Lv	\N	Northeastern University	\N	2026-08-17 11:35:19.356056+08
2035	Kun Wang	\N	Northeastern University	\N	2026-08-17 11:35:19.356056+08
2036	Song Wang	\N	Northeastern University	\N	2026-08-17 11:35:19.356056+08
2037	Lang Pang	\N	Beijing Jiaotong University	\N	2026-08-17 11:35:19.36514+08
2038	Dengquan Wang	\N	Tsinghua University	\N	2026-08-17 11:35:19.36514+08
2039	Le Kang	\N	Xi'an University of Science and Technology	\N	2026-08-17 11:35:19.372295+08
2040	Hui Du	\N	Xi'an University of Science and Technology	\N	2026-08-17 11:35:19.372295+08
2041	Hao Zhang	\N	Anhui University of Technology	\N	2026-08-17 11:35:19.372295+08
2042	Wan Li	\N	Xi'an University of Science and Technology	\N	2026-08-17 11:35:19.372295+08
2043	Thobeka Pearl Makhathini	\N	Mangosuthu University of Technology	\N	2026-08-17 11:35:19.380494+08
2044	Joseph K. Bwapwa	\N	Mangosuthu University of Technology	\N	2026-08-17 11:35:19.380494+08
2045	Sphesihle Mtsweni	\N	Mangosuthu University of Technology	\N	2026-08-17 11:35:19.380494+08
2046	Helena I. Gomes	\N	University of Hull	\N	2026-08-17 11:35:19.387514+08
2047	Valerio Funari	\N	University of Bologna	\N	2026-08-17 11:35:19.387514+08
2048	Mike Rogerson	\N	University of Hull	\N	2026-08-17 11:35:19.387514+08
2049	Timothy J. Prior	\N	University of Hull	\N	2026-08-17 11:35:19.387514+08
2050	Cheikh Cissé	\N	Colorado School of Mines	\N	2026-08-17 11:44:08.720183+08
2051	Mohsen Asle Zaeem	\N	Colorado School of Mines	\N	2026-08-17 11:44:08.720183+08
2052	Sami Virolainen	\N	Lappeenranta-Lahti University of Technology	\N	2026-08-17 11:44:16.617485+08
2053	Tobias Wesselborg	\N	Lappeenranta-Lahti University of Technology	\N	2026-08-17 11:44:16.617485+08
2054	Arttu Kaukinen	\N	Lappeenranta-Lahti University of Technology	\N	2026-08-17 11:44:16.617485+08
2055	Tuomo Sainio	\N	Lappeenranta-Lahti University of Technology	\N	2026-08-17 11:44:16.617485+08
2056	Eveliina Repo	\N	Lappeenranta-Lahti University of Technology	\N	2026-08-17 11:44:19.193037+08
\.


--
-- Data for Name: document_authors; Type: TABLE DATA; Schema: literature; Owner: -
--

COPY literature.document_authors (document_id, author_id, author_order, is_corresponding) FROM stdin;
505	1651	1	t
505	1652	2	f
506	1653	1	f
506	1654	2	f
506	1655	3	f
506	1656	4	f
506	1657	5	t
507	1652	1	t
507	1658	2	f
507	1651	3	f
507	1659	4	f
508	1660	1	t
508	1661	2	t
508	1115	3	f
509	1662	1	f
509	1663	2	f
509	1664	3	f
509	1665	4	t
510	1666	1	f
510	1667	2	f
510	1668	3	f
510	1669	4	f
510	839	5	f
510	1670	6	f
510	1671	7	t
511	1672	1	f
511	1673	2	f
511	1674	3	f
511	1675	4	f
511	1676	5	t
512	1677	1	f
512	1678	2	t
513	1679	1	t
513	1680	2	f
513	1681	3	f
513	1682	4	f
514	1683	1	t
514	1684	2	f
514	1685	3	f
515	1686	1	t
515	1687	2	f
515	1688	3	f
515	1689	4	f
515	1690	5	f
516	1691	1	f
516	1692	2	f
516	1693	3	f
516	1694	4	f
516	1695	5	t
517	1696	1	t
518	1697	1	t
38	48	1	f
38	49	2	f
38	50	3	f
38	51	4	f
518	1698	2	t
518	664	3	f
518	1699	4	f
518	1700	5	t
519	1701	1	t
519	1702	2	f
519	1703	3	f
519	1704	4	f
519	1705	5	f
519	1706	6	f
519	1707	7	f
519	1708	8	f
519	1709	9	f
519	1710	10	f
519	1661	11	t
519	1711	12	t
520	1712	1	t
520	850	2	f
520	1713	3	f
520	1700	4	f
520	1714	5	f
520	1709	6	f
520	1661	7	f
521	1715	1	f
521	1716	2	f
521	1717	3	t
521	1718	4	t
522	1719	1	f
522	1720	2	f
522	1721	3	f
522	1722	4	f
522	1723	5	f
522	1724	6	f
522	1725	7	f
522	1726	8	t
522	1727	9	t
523	1728	1	f
523	1729	2	f
523	1678	3	t
524	1730	1	f
524	1731	2	f
524	1732	3	f
524	1712	4	f
524	1733	5	f
524	1661	6	t
524	1734	7	t
525	719	1	f
525	1735	2	f
526	1736	1	f
526	1737	2	f
526	1738	3	t
526	1739	4	f
527	1740	1	f
527	1741	2	t
527	1742	3	f
527	1743	4	f
527	1744	5	t
528	1745	1	t
528	1746	2	f
529	1747	1	f
56	2	1	f
529	1748	2	t
529	1749	3	t
529	1750	4	f
529	1751	5	f
529	1752	6	f
529	1753	7	f
530	1754	1	t
530	1755	2	f
530	1756	3	f
530	1757	4	t
531	1758	1	t
532	1759	1	f
532	1760	2	f
532	1761	3	f
532	1762	4	f
532	1763	5	f
532	1764	6	f
532	1765	7	f
532	1766	8	f
533	1767	1	t
66	127	1	f
66	128	2	f
533	1768	2	f
533	1769	3	f
534	1770	1	t
535	1771	1	t
535	1772	2	f
535	1773	3	f
535	1774	4	f
82	136	1	f
82	137	2	f
82	138	3	f
82	139	4	f
535	1775	5	f
536	1776	1	f
536	1777	2	f
536	1778	3	f
536	1779	4	f
537	1780	1	f
537	1781	2	f
537	1782	3	f
537	1783	4	f
538	1784	1	f
538	1785	2	t
88	136	1	f
88	137	2	f
88	139	3	f
88	138	4	f
89	150	1	f
89	151	2	f
538	1786	3	f
538	1787	4	f
538	1788	5	f
538	1789	6	f
539	1790	1	t
539	1791	2	f
540	1792	1	t
540	1758	2	f
541	1793	1	f
541	1794	2	f
541	1795	3	t
541	1796	4	f
541	1797	5	f
541	1798	6	f
541	1799	7	f
541	1800	8	f
96	168	1	f
541	1801	9	f
542	1802	1	t
542	1803	2	f
542	1804	3	f
543	1751	1	t
543	1805	2	f
543	1752	3	f
543	1806	4	f
543	1750	5	f
544	1807	1	f
544	1808	2	f
544	1809	3	f
544	1810	4	t
545	1811	1	t
545	1812	2	f
545	1813	3	f
545	1814	4	f
545	1815	5	f
546	1816	1	t
546	1817	2	f
547	1818	1	f
102	184	1	f
102	185	2	f
102	186	3	f
102	187	4	f
547	1819	2	f
548	1820	1	f
548	1821	2	f
548	1822	3	f
548	1823	4	f
548	1824	5	t
105	194	1	f
105	195	2	f
105	196	3	f
106	197	1	f
106	198	2	f
106	199	3	f
106	200	4	f
548	1825	6	f
108	201	1	f
108	202	2	f
108	203	3	f
108	204	4	f
108	205	5	f
108	206	6	f
549	1826	1	f
549	1827	2	t
549	1828	3	f
550	1829	1	t
550	1830	2	f
551	1831	1	t
551	1832	2	t
551	1833	3	f
551	1834	4	f
551	1835	5	f
551	1836	6	f
551	1837	7	f
551	1838	8	f
551	1839	9	f
551	1840	10	f
551	1841	11	f
551	1842	12	f
551	1843	13	f
552	1844	1	f
552	1845	2	t
552	1846	3	f
553	1847	1	f
553	1848	2	t
553	1849	3	f
553	1850	4	f
553	1851	5	f
553	1852	6	f
554	1853	1	f
554	1854	2	t
555	1855	1	f
555	1856	2	t
115	236	1	f
115	237	2	f
115	238	3	f
115	239	4	f
115	240	5	f
556	1857	1	f
556	1807	2	f
556	1858	3	f
556	1859	4	f
556	1860	5	f
556	1861	6	f
556	1809	7	f
556	1862	8	f
556	1810	9	t
557	1863	1	f
557	1864	2	t
557	1865	3	f
558	1866	1	f
558	1867	2	f
558	1868	3	f
558	1816	4	t
559	1869	1	f
559	1870	2	f
559	1871	3	f
559	1872	4	t
560	1873	1	f
560	1874	2	t
560	1875	3	f
560	1876	4	f
560	1877	5	f
560	1878	6	f
560	1879	7	t
561	1880	1	t
561	1881	2	t
561	1882	3	f
561	1883	4	f
561	1884	5	f
562	1885	1	t
562	1886	2	f
562	1887	3	f
563	1888	1	t
563	1889	2	f
563	1890	3	f
563	1891	4	f
563	1892	5	f
563	1893	6	f
564	834	1	t
129	264	1	f
129	265	2	f
129	266	3	f
564	1894	2	f
564	831	3	f
564	1750	4	f
564	719	5	f
564	1895	6	f
564	1896	7	f
564	1897	8	f
564	1898	9	f
564	1899	10	f
564	1028	11	f
564	1026	12	f
564	836	13	f
144	275	1	f
144	276	2	f
144	277	3	f
564	864	14	f
564	839	15	t
565	1900	1	t
565	1901	2	f
565	1902	3	f
565	1903	4	f
565	1904	5	f
566	1905	1	f
566	1906	2	f
566	1907	3	f
566	1908	4	t
567	1909	1	t
567	1910	2	f
567	1911	3	f
567	1912	4	f
568	1913	1	t
569	1914	1	f
569	1915	2	f
569	1916	3	f
569	1917	4	f
569	1918	5	f
569	1919	6	f
569	1920	7	f
569	1921	8	f
570	1922	1	t
570	1923	2	f
570	1924	3	f
570	1925	4	f
570	1926	5	f
570	1927	6	f
571	1928	1	t
571	1929	2	f
153	289	1	f
154	290	1	f
154	291	2	f
154	292	3	f
154	293	4	f
155	294	1	f
155	295	2	f
156	296	1	f
156	297	2	f
156	298	3	f
156	299	4	f
156	300	5	f
156	301	6	f
157	302	1	f
157	303	2	f
157	304	3	f
158	305	1	f
158	306	2	f
159	307	1	f
160	308	1	f
160	309	2	f
160	310	3	f
161	311	1	f
162	312	1	f
162	313	2	f
162	314	3	f
162	315	4	f
162	316	5	f
162	317	6	f
162	318	7	f
163	319	1	f
163	320	2	f
163	321	3	f
164	322	1	f
164	323	2	f
164	324	3	f
164	325	4	f
165	326	1	f
166	327	1	f
166	328	2	f
166	329	3	f
166	330	4	f
166	331	5	f
166	332	6	f
167	333	1	f
168	334	1	f
169	335	1	f
169	336	2	f
169	337	3	f
169	338	4	f
169	339	5	f
169	340	6	f
169	341	7	f
169	342	8	f
170	321	1	f
170	320	2	f
170	319	3	f
171	343	1	f
171	344	2	f
171	345	3	f
171	346	4	f
171	347	5	f
171	348	6	f
171	349	7	f
171	350	8	f
171	351	9	f
171	352	10	f
171	353	11	f
171	354	12	f
172	355	1	f
172	356	2	f
172	357	3	f
173	358	1	f
174	359	1	f
175	360	1	f
176	361	1	f
177	362	1	f
178	363	1	f
178	364	2	f
179	365	1	f
572	1930	1	f
572	1931	2	f
572	1932	3	f
572	1933	4	t
573	1934	1	t
573	1935	2	f
573	1936	3	f
573	1937	4	f
573	1938	5	f
574	1939	1	t
575	1940	1	t
182	377	1	f
575	1941	2	f
576	1942	1	t
576	1943	2	f
576	1944	3	f
576	1945	4	t
577	839	1	f
577	1946	2	f
185	385	1	f
186	386	1	f
186	387	2	f
186	388	3	f
186	389	4	f
186	390	5	f
187	391	1	f
187	392	2	f
188	393	1	f
189	394	1	f
190	395	1	f
191	396	1	f
192	397	1	f
192	398	2	f
192	399	3	f
192	400	4	f
193	401	1	f
193	402	2	f
194	403	1	f
194	404	2	f
194	405	3	f
194	406	4	f
195	407	1	f
196	408	1	f
196	409	2	f
197	410	1	f
198	411	1	f
199	412	1	f
199	413	2	f
199	414	3	f
200	415	1	f
200	416	2	f
201	417	1	f
201	418	2	f
201	419	3	f
201	420	4	f
201	421	5	f
202	422	1	f
203	423	1	f
204	424	1	f
205	425	1	f
206	426	1	f
206	427	2	f
207	428	1	f
207	429	2	f
207	430	3	f
207	431	4	f
207	432	5	f
208	433	1	f
209	434	1	f
210	435	1	f
210	436	2	f
210	437	3	f
211	438	1	f
212	439	1	f
212	440	2	f
212	441	3	f
212	442	4	f
577	1028	3	f
577	1947	4	f
577	865	5	f
577	1948	6	f
577	841	7	f
577	1894	8	f
577	834	9	f
214	450	1	f
214	451	2	f
215	452	1	f
215	453	2	f
215	454	3	f
215	455	4	f
215	456	5	f
216	457	1	f
216	458	2	f
217	459	1	f
217	460	2	f
217	461	3	f
218	462	1	f
219	463	1	f
219	464	2	f
219	465	3	f
219	466	4	f
220	467	1	f
220	468	2	f
220	469	3	f
221	470	1	f
222	471	1	f
223	472	1	f
224	473	1	f
225	474	1	f
226	475	1	f
227	476	1	f
227	477	2	f
228	478	1	f
228	479	2	f
228	480	3	f
228	481	4	f
228	482	5	f
229	483	1	f
230	484	1	f
230	485	2	f
231	486	1	f
231	487	2	f
231	488	3	f
231	489	4	f
232	490	1	f
232	491	2	f
232	492	3	f
232	493	4	f
232	494	5	f
232	495	6	f
232	496	7	f
233	478	1	f
233	497	2	f
233	498	3	f
233	499	4	f
233	500	5	f
578	1949	1	f
235	502	1	f
235	503	2	f
236	504	1	f
578	1950	2	t
238	506	1	f
239	507	1	f
240	508	1	f
240	509	2	f
240	510	3	f
240	511	4	f
240	512	5	f
240	513	6	f
240	514	7	f
240	515	8	f
578	1951	3	f
578	1952	4	f
578	1953	5	f
578	1954	6	f
578	1955	7	f
578	1956	8	f
578	1957	9	f
579	1958	1	t
243	524	1	f
243	525	2	f
243	526	3	f
243	527	4	f
243	528	5	f
580	1959	1	t
580	1960	2	f
246	531	1	f
247	531	1	f
248	532	1	f
249	533	1	f
250	534	1	f
251	535	1	f
580	1961	3	f
581	1962	1	f
581	1963	2	t
253	539	1	f
254	540	1	f
255	541	1	f
256	542	1	f
582	1964	1	t
582	1965	2	f
582	1966	3	f
582	1967	4	f
582	1968	5	f
582	1969	6	f
258	549	1	f
259	550	1	f
260	551	1	f
260	552	2	f
582	1970	7	f
262	554	1	f
263	555	1	f
264	556	1	f
264	557	2	f
264	558	3	f
264	559	4	f
264	560	5	f
265	561	1	f
265	562	2	f
266	563	1	f
266	564	2	f
266	565	3	f
267	566	1	f
267	567	2	f
268	568	1	f
268	569	2	f
268	570	3	f
268	571	4	f
268	572	5	f
268	573	6	f
268	574	7	f
268	575	8	f
269	576	1	f
269	577	2	f
270	578	1	f
270	579	2	f
270	580	3	f
270	581	4	f
270	582	5	f
270	583	6	f
271	584	1	f
271	585	2	f
271	586	3	f
272	587	1	f
272	588	2	f
272	589	3	f
272	590	4	f
273	591	1	f
273	592	2	f
273	593	3	f
273	594	4	f
273	595	5	f
273	596	6	f
273	597	7	f
274	598	1	f
274	599	2	f
275	600	1	f
275	601	2	f
275	602	3	f
275	603	4	f
276	604	1	f
276	605	2	f
276	606	3	f
276	607	4	f
276	608	5	f
276	609	6	f
276	610	7	f
276	611	8	f
276	612	9	f
276	613	10	f
276	614	11	f
277	615	1	f
277	616	2	f
277	617	3	f
277	618	4	f
277	619	5	f
277	620	6	f
278	621	1	f
278	622	2	f
279	623	1	f
279	624	2	f
279	625	3	f
279	626	4	f
279	627	5	f
279	628	6	f
279	629	7	f
279	630	8	f
279	631	9	f
279	632	10	f
280	633	1	f
280	634	2	f
280	635	3	f
280	636	4	f
281	637	1	f
281	638	2	f
281	639	3	f
282	640	1	f
282	641	2	f
282	642	3	f
282	643	4	f
282	644	5	f
282	645	6	f
282	646	7	f
282	647	8	f
282	648	9	f
282	649	10	f
282	650	11	f
283	651	1	f
283	652	2	f
283	653	3	f
283	654	4	f
283	655	5	f
283	656	6	f
283	657	7	f
283	658	8	f
283	659	9	f
284	660	1	f
284	661	2	f
285	662	1	f
285	663	2	f
285	664	3	f
285	665	4	f
285	666	5	f
286	667	1	f
286	668	2	f
286	669	3	f
287	670	1	f
287	671	2	f
288	672	1	f
288	673	2	f
288	674	3	f
289	675	1	f
289	676	2	f
289	677	3	f
289	678	4	f
290	679	1	f
290	680	2	f
290	681	3	f
290	682	4	f
290	683	5	f
291	684	1	f
291	685	2	f
291	686	3	f
291	687	4	f
291	688	5	f
291	689	6	f
291	690	7	f
291	691	8	f
291	692	9	f
291	693	10	f
292	694	1	f
292	695	2	f
292	696	3	f
292	697	4	f
292	698	5	f
292	699	6	f
292	700	7	f
293	701	1	f
293	702	2	f
294	703	1	f
294	704	2	f
294	705	3	f
294	706	4	f
294	707	5	f
295	708	1	f
295	709	2	f
295	710	3	f
296	711	1	f
297	712	1	f
297	713	2	f
297	714	3	f
298	715	1	f
298	716	2	f
299	717	1	f
299	718	2	f
299	719	3	f
300	720	1	f
300	721	2	f
300	722	3	f
300	723	4	f
300	724	5	f
301	725	1	f
301	726	2	f
301	727	3	f
301	728	4	f
301	729	5	f
302	730	1	f
302	731	2	f
302	732	3	f
302	733	4	f
302	734	5	f
303	735	1	f
303	736	2	f
303	737	3	f
303	738	4	f
303	739	5	f
304	740	1	f
304	741	2	f
304	742	3	f
304	743	4	f
305	744	1	f
305	743	2	f
306	745	1	f
307	746	1	f
307	747	2	f
307	748	3	f
308	749	1	f
308	750	2	f
309	751	1	f
309	752	2	f
309	753	3	f
309	754	4	f
309	755	5	f
309	756	6	f
310	757	1	f
310	758	2	f
310	759	3	f
310	760	4	f
310	761	5	f
310	762	6	f
310	745	7	f
311	763	1	f
311	764	2	f
311	765	3	f
311	766	4	f
311	767	5	f
311	768	6	f
311	769	7	f
311	770	8	f
311	771	9	f
312	772	1	f
312	773	2	f
312	774	3	f
312	775	4	f
312	776	5	f
313	777	1	f
313	778	2	f
313	779	3	f
313	780	4	f
313	781	5	f
313	782	6	f
313	783	7	f
314	784	1	f
314	785	2	f
314	786	3	f
314	787	4	f
314	788	5	f
314	789	6	f
315	790	1	f
315	791	2	f
315	792	3	f
315	793	4	f
315	794	5	f
315	795	6	f
315	796	7	f
315	797	8	f
316	798	1	f
316	799	2	f
316	800	3	f
316	801	4	f
316	802	5	f
316	803	6	f
316	804	7	f
316	805	8	f
316	806	9	f
317	807	1	f
317	808	2	f
317	809	3	f
317	810	4	f
317	811	5	f
317	812	6	f
318	813	1	f
318	715	2	f
318	716	3	f
319	814	1	f
319	815	2	f
319	816	3	f
319	817	4	f
319	818	5	f
319	819	6	f
319	820	7	f
320	821	1	f
320	822	2	f
320	823	3	f
320	824	4	f
320	825	5	f
320	826	6	f
321	827	1	f
321	828	2	f
321	829	3	f
322	830	1	f
322	831	2	f
322	832	3	f
322	833	4	f
322	834	5	f
322	835	6	f
322	836	7	f
322	837	8	f
322	838	9	f
322	839	10	f
323	840	1	f
323	841	2	f
323	834	3	f
323	842	4	f
323	843	5	f
323	844	6	f
323	839	7	f
324	845	1	f
324	846	2	f
324	847	3	f
324	848	4	f
324	849	5	f
324	850	6	f
324	851	7	f
324	852	8	f
324	853	9	f
324	854	10	f
324	855	11	f
324	856	12	f
324	857	13	f
324	858	14	f
324	859	15	f
324	860	16	f
324	861	17	f
324	862	18	f
324	863	20	f
325	831	1	f
325	864	2	f
325	834	3	f
325	865	4	f
325	866	5	f
325	839	6	f
326	718	1	f
326	867	2	f
326	823	3	f
326	826	4	f
327	832	1	f
327	868	2	f
327	833	3	f
327	836	4	f
327	839	5	f
328	869	1	f
328	870	2	f
328	871	3	f
328	872	4	f
329	873	1	f
329	874	2	f
330	875	1	f
330	876	2	f
330	877	3	f
331	878	1	f
331	879	2	f
331	880	3	f
332	881	1	f
332	882	2	f
333	883	1	f
333	884	2	f
333	885	3	f
334	886	1	f
334	887	2	f
334	888	3	f
334	889	4	f
334	890	5	f
334	891	6	f
334	892	7	f
334	893	8	f
334	894	9	f
334	895	10	f
335	896	1	f
335	897	2	f
335	898	3	f
336	899	1	f
336	900	2	f
337	901	1	f
338	902	1	f
338	903	2	f
338	904	3	f
338	905	4	f
339	906	1	f
339	907	2	f
339	908	3	f
339	909	4	f
339	910	5	f
339	911	6	f
339	912	7	f
340	899	1	f
340	900	2	f
341	880	1	f
341	879	2	f
342	913	1	f
342	914	2	f
342	915	3	f
343	916	1	f
343	917	2	f
343	918	3	f
343	919	4	f
344	920	1	f
344	921	2	f
344	922	3	f
344	923	4	f
344	924	5	f
344	925	6	f
344	926	7	f
345	927	1	f
345	928	2	f
345	929	3	f
346	930	1	f
346	931	2	f
346	932	3	f
346	933	4	f
346	934	5	f
346	935	6	f
347	936	1	f
347	937	2	f
347	938	3	f
347	939	4	f
347	940	5	f
347	941	6	f
347	942	7	f
347	943	8	f
347	944	9	f
348	945	1	f
348	946	2	f
348	947	3	f
348	948	4	f
348	949	5	f
348	950	6	f
348	951	7	f
349	952	1	f
349	953	2	f
349	954	3	f
349	955	4	f
350	956	1	f
351	957	1	f
351	958	2	f
351	959	3	f
351	960	4	f
352	961	1	f
353	962	1	f
353	963	2	f
353	964	3	f
354	965	1	f
354	966	2	f
354	967	3	f
354	968	4	f
354	969	5	f
354	970	6	f
354	971	7	f
354	972	8	f
354	973	9	f
355	974	1	f
355	975	2	f
355	976	3	f
355	977	4	f
355	978	5	f
355	979	6	f
355	980	7	f
356	981	1	f
356	982	2	f
356	983	3	f
357	984	1	f
357	985	2	f
357	986	3	f
357	987	4	f
358	988	1	f
359	989	1	f
359	990	2	f
359	991	3	f
359	992	4	f
359	993	5	f
360	994	1	f
360	995	2	f
360	996	3	f
361	997	1	f
361	998	2	f
362	999	1	f
362	1000	2	f
362	1001	3	f
363	1002	1	f
363	1003	2	f
363	1004	3	f
363	1005	4	f
363	836	5	f
364	1002	1	f
364	1006	2	f
364	1007	3	f
364	1008	4	f
364	1009	5	f
365	1010	1	f
365	1011	2	f
365	1012	3	f
365	1013	4	f
366	1014	1	f
366	1015	2	f
366	1016	3	f
366	1017	4	f
366	1018	5	f
366	1019	6	f
367	1020	1	f
367	1021	2	f
367	1022	3	f
367	1023	4	f
367	1024	5	f
367	1025	6	f
367	1026	7	f
367	836	8	f
367	1027	9	f
367	1028	10	f
367	839	11	f
368	1029	1	f
368	1030	2	f
368	1031	3	f
368	1032	4	f
369	1033	1	f
369	1034	2	f
369	1035	3	f
369	1036	4	f
369	1037	5	f
369	1038	6	f
369	1039	7	f
369	1040	8	f
369	1041	9	f
369	1042	10	f
370	1002	1	f
370	1028	2	f
370	1026	3	f
370	836	4	f
371	1043	1	f
371	1044	2	f
371	1045	3	f
371	850	4	f
371	1046	5	f
371	1047	6	f
371	1048	7	f
371	1049	8	f
371	1050	9	f
371	1051	10	f
371	1052	11	f
371	1053	12	f
371	1054	13	f
372	1055	1	f
372	1056	2	f
372	1057	3	f
372	1058	4	f
372	1059	5	f
372	1060	6	f
372	1061	7	f
372	1062	8	f
373	1063	1	f
373	1064	2	f
373	1065	3	f
373	1066	4	f
373	1067	5	f
373	1068	6	f
373	1069	7	f
373	1070	8	f
374	1002	1	f
374	836	2	f
375	1071	1	f
375	1072	2	f
375	1073	3	f
375	1074	4	f
376	1075	1	f
376	1076	2	f
376	1077	3	f
376	1078	4	f
376	1079	5	f
376	1080	6	f
376	1081	7	f
376	1082	8	f
376	1083	9	f
377	1084	1	f
377	1069	2	f
377	1085	3	f
377	1064	4	f
377	1070	5	f
378	1086	1	f
378	1087	2	f
378	1088	3	f
378	1089	4	f
378	1090	5	f
379	1091	1	f
379	1092	2	f
380	1093	1	f
380	868	2	f
380	1027	3	f
380	1094	4	f
380	1095	5	f
380	839	6	f
380	1096	7	f
380	836	8	f
381	1097	1	f
382	1098	1	f
382	1099	2	f
383	1100	1	f
383	1101	2	f
383	1102	3	f
383	1103	4	f
383	1104	5	f
384	1105	1	f
384	1106	2	f
384	1107	3	f
385	1099	1	f
386	1108	1	f
386	1109	2	f
386	1110	3	f
386	1111	4	f
387	1112	1	f
388	1112	1	f
389	1024	1	f
389	1113	2	f
389	1114	3	f
389	1115	4	f
389	1116	5	f
389	1117	6	f
389	1118	7	f
389	1119	8	f
390	1120	1	f
390	1121	2	f
390	1122	3	f
390	1123	4	f
583	1971	1	t
583	1972	2	f
583	1973	3	f
583	1974	4	f
583	1975	5	f
583	1976	6	f
583	1977	7	f
583	1978	8	f
584	1979	1	t
585	684	1	t
586	1980	1	t
587	1981	1	t
587	1982	2	f
587	1983	3	f
587	1984	4	f
588	1985	1	t
588	1986	2	f
588	1987	3	f
588	1988	4	f
588	1989	5	f
589	1990	1	f
589	1991	2	t
589	1992	3	f
590	1993	1	f
590	1994	2	t
590	1995	3	t
590	1996	4	f
590	1997	5	f
590	1998	6	f
591	1999	1	t
591	2000	2	f
591	2001	3	f
591	2002	4	f
591	2003	5	f
591	2004	6	f
592	2005	1	f
592	2006	2	f
592	2007	3	t
592	2008	4	t
593	2009	1	t
593	1791	2	f
593	2010	3	f
593	2011	4	f
593	2012	5	f
594	2013	1	f
594	2014	2	f
594	2015	3	f
594	2016	4	f
594	2017	5	f
594	2018	6	t
595	2019	1	f
595	2020	2	f
595	2021	3	f
595	2022	4	f
596	2023	1	t
596	2024	2	f
597	2025	1	t
597	2026	2	f
597	2027	3	f
597	2028	4	f
598	2029	1	t
598	2030	2	f
598	2031	3	f
599	2032	1	f
599	2033	2	t
599	2034	3	f
599	2035	4	f
599	2036	5	f
600	930	1	f
600	2037	2	f
600	2038	3	t
601	2039	1	t
601	2040	2	f
601	2041	3	f
601	2042	4	f
602	2043	1	t
602	2044	2	f
602	2045	3	f
603	2046	1	t
603	2047	2	f
603	1969	3	f
603	2048	4	f
603	2049	5	f
604	2050	1	f
604	2051	2	t
605	2050	1	f
605	2051	2	t
606	2050	1	f
606	2051	2	t
607	2050	1	f
607	2051	2	t
608	2052	1	t
608	2053	2	f
608	2054	3	f
608	2055	4	f
609	2052	1	f
609	2056	2	f
609	2055	3	t
\.


--
-- Data for Name: document_domains; Type: TABLE DATA; Schema: literature; Owner: -
--

COPY literature.document_domains (document_id, domain_code, is_primary, sort_order) FROM stdin;
604	basic_principles	t	0
605	basic_principles	t	0
606	basic_principles	t	0
607	basic_principles	t	0
608	non_ferrous	t	0
609	resource_utilization	t	0
12	basic_principles	t	0
14	basic_principles	t	0
25	basic_principles	t	0
28	basic_principles	t	0
38	steel_metallurgy	t	0
51	steel_metallurgy	t	0
56	steel_metallurgy	t	0
66	non_ferrous	t	0
82	non_ferrous	t	0
88	non_ferrous	t	0
89	non_ferrous	t	0
96	energy_restructuring	t	0
102	energy_restructuring	t	0
105	energy_restructuring	t	0
106	energy_restructuring	t	0
108	energy_restructuring	t	0
115	energy_restructuring	t	0
129	resource_utilization	t	0
144	resource_utilization	t	0
153	steel_metallurgy	t	0
154	steel_metallurgy	t	0
155	steel_metallurgy	t	0
156	steel_metallurgy	t	0
157	basic_principles	t	0
158	basic_principles	t	0
159	basic_principles	t	0
160	basic_principles	t	0
161	basic_principles	t	0
162	basic_principles	t	0
163	basic_principles	t	0
164	basic_principles	t	0
165	basic_principles	t	0
166	basic_principles	t	0
167	basic_principles	t	0
168	basic_principles	t	0
169	basic_principles	t	0
170	basic_principles	t	0
171	basic_principles	t	0
172	basic_principles	t	0
173	basic_principles	t	0
174	basic_principles	t	0
175	basic_principles	t	0
176	basic_principles	t	0
177	basic_principles	t	0
178	basic_principles	t	0
179	basic_principles	t	0
182	steel_metallurgy	t	0
185	steel_metallurgy	t	0
186	steel_metallurgy	t	0
187	steel_metallurgy	t	0
188	steel_metallurgy	t	0
189	steel_metallurgy	t	0
190	steel_metallurgy	t	0
191	steel_metallurgy	t	0
192	steel_metallurgy	t	0
193	steel_metallurgy	t	0
194	steel_metallurgy	t	0
195	steel_metallurgy	t	0
196	steel_metallurgy	t	0
197	steel_metallurgy	t	0
198	steel_metallurgy	t	0
199	steel_metallurgy	t	0
200	steel_metallurgy	t	0
201	steel_metallurgy	t	0
202	steel_metallurgy	t	0
203	steel_metallurgy	t	0
204	non_ferrous	t	0
205	non_ferrous	t	0
206	non_ferrous	t	0
207	non_ferrous	t	0
208	non_ferrous	t	0
209	non_ferrous	t	0
210	non_ferrous	t	0
211	non_ferrous	t	0
212	non_ferrous	t	0
214	non_ferrous	t	0
215	energy_restructuring	t	0
216	energy_restructuring	t	0
217	energy_restructuring	t	0
218	energy_restructuring	t	0
219	energy_restructuring	t	0
220	energy_restructuring	t	0
221	energy_restructuring	t	0
222	energy_restructuring	t	0
223	energy_restructuring	t	0
224	energy_restructuring	t	0
225	energy_restructuring	t	0
226	energy_restructuring	t	0
227	energy_restructuring	t	0
228	energy_restructuring	t	0
229	energy_restructuring	t	0
230	energy_restructuring	t	0
231	energy_restructuring	t	0
232	energy_restructuring	t	0
233	energy_restructuring	t	0
235	energy_restructuring	t	0
236	energy_restructuring	t	0
238	energy_restructuring	t	0
239	energy_restructuring	t	0
240	energy_restructuring	t	0
243	resource_utilization	t	0
505	basic_principles	t	0
506	basic_principles	t	0
246	resource_utilization	t	0
247	resource_utilization	t	0
248	resource_utilization	t	0
249	resource_utilization	t	0
250	resource_utilization	t	0
251	resource_utilization	t	0
507	basic_principles	t	0
253	resource_utilization	t	0
254	resource_utilization	t	0
255	resource_utilization	t	0
256	resource_utilization	t	0
508	basic_principles	t	0
258	resource_utilization	t	0
509	basic_principles	t	0
510	basic_principles	t	0
511	basic_principles	t	0
512	basic_principles	t	0
259	resource_utilization	t	0
260	resource_utilization	t	0
262	resource_utilization	t	0
263	basic_principles	t	0
264	basic_principles	t	0
265	basic_principles	t	0
266	basic_principles	t	0
267	basic_principles	t	0
268	basic_principles	t	0
269	basic_principles	t	0
270	basic_principles	t	0
271	basic_principles	t	0
272	basic_principles	t	0
273	basic_principles	t	0
274	basic_principles	t	0
275	basic_principles	t	0
276	basic_principles	t	0
277	basic_principles	t	0
278	basic_principles	t	0
279	basic_principles	t	0
280	basic_principles	t	0
281	basic_principles	t	0
282	basic_principles	t	0
283	basic_principles	t	0
284	basic_principles	t	0
285	basic_principles	t	0
286	basic_principles	t	0
287	basic_principles	t	0
288	basic_principles	t	0
289	basic_principles	t	0
290	basic_principles	t	0
291	basic_principles	t	0
292	basic_principles	t	0
293	basic_principles	t	0
294	basic_principles	t	0
295	basic_principles	t	0
296	basic_principles	t	0
297	basic_principles	t	0
298	steel_metallurgy	t	0
299	steel_metallurgy	t	0
300	steel_metallurgy	t	0
301	steel_metallurgy	t	0
302	steel_metallurgy	t	0
303	steel_metallurgy	t	0
304	steel_metallurgy	t	0
305	steel_metallurgy	t	0
306	steel_metallurgy	t	0
307	steel_metallurgy	t	0
308	steel_metallurgy	t	0
309	steel_metallurgy	t	0
310	steel_metallurgy	t	0
311	steel_metallurgy	t	0
312	steel_metallurgy	t	0
313	steel_metallurgy	t	0
314	steel_metallurgy	t	0
315	steel_metallurgy	t	0
316	steel_metallurgy	t	0
317	steel_metallurgy	t	0
318	steel_metallurgy	t	0
319	steel_metallurgy	t	0
320	steel_metallurgy	t	0
321	steel_metallurgy	t	0
322	steel_metallurgy	t	0
323	steel_metallurgy	t	0
324	steel_metallurgy	t	0
325	steel_metallurgy	t	0
326	steel_metallurgy	t	0
327	steel_metallurgy	t	0
328	non_ferrous	t	0
329	non_ferrous	t	0
330	non_ferrous	t	0
331	non_ferrous	t	0
332	non_ferrous	t	0
333	non_ferrous	t	0
334	non_ferrous	t	0
335	non_ferrous	t	0
336	non_ferrous	t	0
337	non_ferrous	t	0
338	non_ferrous	t	0
339	non_ferrous	t	0
340	non_ferrous	t	0
341	non_ferrous	t	0
342	non_ferrous	t	0
343	non_ferrous	t	0
344	non_ferrous	t	0
345	non_ferrous	t	0
346	non_ferrous	t	0
347	non_ferrous	t	0
348	non_ferrous	t	0
349	non_ferrous	t	0
350	non_ferrous	t	0
351	non_ferrous	t	0
352	non_ferrous	t	0
353	non_ferrous	t	0
354	non_ferrous	t	0
355	non_ferrous	t	0
356	non_ferrous	t	0
357	non_ferrous	t	0
358	energy_restructuring	t	0
359	energy_restructuring	t	0
360	energy_restructuring	t	0
361	energy_restructuring	t	0
362	energy_restructuring	t	0
363	energy_restructuring	t	0
364	energy_restructuring	t	0
365	energy_restructuring	t	0
366	energy_restructuring	t	0
367	energy_restructuring	t	0
368	energy_restructuring	t	0
369	energy_restructuring	t	0
370	energy_restructuring	t	0
371	energy_restructuring	t	0
372	energy_restructuring	t	0
373	energy_restructuring	t	0
374	energy_restructuring	t	0
375	energy_restructuring	t	0
376	energy_restructuring	t	0
377	energy_restructuring	t	0
378	energy_restructuring	t	0
379	energy_restructuring	t	0
380	energy_restructuring	t	0
381	energy_restructuring	t	0
382	energy_restructuring	t	0
383	energy_restructuring	t	0
384	energy_restructuring	t	0
385	energy_restructuring	t	0
386	energy_restructuring	t	0
387	resource_utilization	t	0
388	resource_utilization	t	0
389	resource_utilization	t	0
390	resource_utilization	t	0
513	basic_principles	t	0
514	basic_principles	t	0
515	basic_principles	t	0
516	basic_principles	t	0
517	basic_principles	t	0
518	basic_principles	t	0
519	basic_principles	t	0
520	basic_principles	t	0
521	basic_principles	t	0
522	basic_principles	t	0
523	basic_principles	t	0
524	basic_principles	t	0
525	steel_metallurgy	t	0
526	steel_metallurgy	t	0
527	steel_metallurgy	t	0
528	steel_metallurgy	t	0
529	steel_metallurgy	t	0
530	steel_metallurgy	t	0
531	steel_metallurgy	t	0
532	steel_metallurgy	t	0
533	steel_metallurgy	t	0
534	steel_metallurgy	t	0
535	steel_metallurgy	t	0
536	steel_metallurgy	t	0
537	steel_metallurgy	t	0
538	steel_metallurgy	t	0
539	steel_metallurgy	t	0
540	steel_metallurgy	t	0
541	steel_metallurgy	t	0
542	steel_metallurgy	t	0
543	steel_metallurgy	t	0
544	non_ferrous	t	0
545	non_ferrous	t	0
546	non_ferrous	t	0
547	non_ferrous	t	0
548	non_ferrous	t	0
549	non_ferrous	t	0
550	non_ferrous	t	0
551	non_ferrous	t	0
552	non_ferrous	t	0
553	non_ferrous	t	0
554	non_ferrous	t	0
555	non_ferrous	t	0
556	non_ferrous	t	0
557	non_ferrous	t	0
558	non_ferrous	t	0
559	non_ferrous	t	0
560	non_ferrous	t	0
561	non_ferrous	t	0
562	non_ferrous	t	0
563	non_ferrous	t	0
564	energy_restructuring	t	0
565	energy_restructuring	t	0
566	energy_restructuring	t	0
567	energy_restructuring	t	0
568	energy_restructuring	t	0
569	energy_restructuring	t	0
570	energy_restructuring	t	0
571	energy_restructuring	t	0
572	energy_restructuring	t	0
573	energy_restructuring	t	0
574	energy_restructuring	t	0
575	energy_restructuring	t	0
576	energy_restructuring	t	0
577	energy_restructuring	t	0
578	energy_restructuring	t	0
579	energy_restructuring	t	0
580	energy_restructuring	t	0
581	energy_restructuring	t	0
582	energy_restructuring	t	0
583	energy_restructuring	t	0
584	resource_utilization	t	0
585	resource_utilization	t	0
586	resource_utilization	t	0
587	resource_utilization	t	0
588	resource_utilization	t	0
589	resource_utilization	t	0
590	resource_utilization	t	0
591	resource_utilization	t	0
592	resource_utilization	t	0
593	resource_utilization	t	0
594	resource_utilization	t	0
595	resource_utilization	t	0
596	resource_utilization	t	0
597	resource_utilization	t	0
598	resource_utilization	t	0
599	resource_utilization	t	0
600	resource_utilization	t	0
601	resource_utilization	t	0
602	resource_utilization	t	0
603	resource_utilization	t	0
\.


--
-- Data for Name: document_keywords; Type: TABLE DATA; Schema: literature; Owner: -
--

COPY literature.document_keywords (document_id, keyword_id) FROM stdin;
604	2447
604	1491
604	2449
604	2450
604	2451
604	2452
604	1558
604	2454
604	2455
604	2456
605	2457
605	1491
605	2447
605	2460
605	2454
605	2462
605	1539
605	2456
605	1679
605	2466
606	1491
606	2468
606	2469
606	2460
606	2455
606	2472
606	1679
606	1558
606	2475
606	1539
607	1491
607	2447
607	1679
607	1503
607	2481
607	2466
607	2483
607	2484
607	2456
607	1502
608	1561
537	1797
537	1684
537	1799
537	1605
537	1738
537	1506
537	1704
537	1557
12	50
537	1491
537	1507
14	53
538	1725
538	1706
538	1809
538	1704
538	1744
538	1812
538	1688
538	1684
538	1815
538	1723
539	1699
539	1684
539	1736
539	1723
539	1706
539	1681
539	159
539	1687
539	1825
539	1826
540	159
540	1681
540	1829
540	1605
540	1507
540	1704
540	1735
540	1494
540	1506
540	1491
541	1690
541	1681
541	159
541	1706
541	1841
541	1826
541	1695
541	1704
541	1506
541	1507
542	1847
542	159
542	1786
542	1706
542	1851
542	1735
25	100
25	101
542	1853
542	1704
542	1855
542	1557
543	159
543	1681
543	1491
543	1506
543	1696
543	1690
543	1689
543	1682
543	1865
28	115
28	116
28	117
543	1866
544	1867
544	1841
544	1869
544	1870
544	1561
544	1872
544	1873
544	1874
544	1875
544	1876
545	1841
545	1878
545	1870
545	1506
545	1825
545	1696
545	1706
545	1491
545	1561
545	1704
546	1887
546	1888
546	1841
546	1890
546	1561
546	1892
546	1826
546	1894
546	1875
546	1896
547	1841
547	1898
547	1899
547	1900
547	1901
547	1902
547	1506
38	156
38	157
38	158
38	159
547	1491
547	1706
547	1906
548	1907
548	1908
548	1890
548	1910
548	1911
548	1875
548	1913
548	1855
548	1896
548	1561
549	1917
549	1561
549	1841
549	1875
549	1921
549	1922
549	1876
549	1924
549	1925
549	1926
550	1927
550	1887
550	1929
608	1874
608	1870
608	2490
608	1875
608	2492
608	1950
608	1948
608	1873
608	2496
609	2497
609	1561
609	2499
609	2500
609	1841
609	2502
609	1898
609	2504
609	2505
609	1876
51	178
51	236
51	237
51	238
51	239
51	240
51	241
51	242
550	1930
550	1826
550	1704
550	1568
550	1706
550	1506
550	1888
551	1892
551	1841
551	1888
551	1706
551	1887
551	1942
551	1704
551	1491
551	1506
551	1507
552	1841
552	1948
552	1706
552	1950
552	1901
56	267
56	5
56	33
56	270
56	271
56	272
56	10
552	1899
552	1953
552	1954
552	1887
552	1704
553	1696
553	1958
553	1704
553	1703
553	1961
553	1962
553	1963
553	1964
553	1506
553	1561
554	1967
554	1968
554	1969
554	1970
554	1971
554	1922
554	1973
554	1902
554	1561
554	1926
555	1929
555	1978
555	1506
555	1841
555	1690
555	1982
555	1983
555	1950
555	1908
555	1561
556	1841
556	1988
556	1568
556	1491
556	1991
556	1992
556	1506
556	1902
556	1706
556	1996
557	1997
557	1704
557	1999
557	2000
557	1851
66	324
66	287
66	326
66	327
66	328
66	329
66	330
66	308
557	1867
557	2003
557	1853
557	2005
557	2006
558	1561
558	1841
558	1927
558	1875
558	1908
558	2012
558	2013
558	2014
558	1902
558	1887
559	1929
559	1704
559	1706
559	1978
559	1953
559	2022
559	2023
559	1815
559	2000
559	1506
560	2027
560	1872
560	1841
560	1867
560	2031
560	1950
560	1561
560	2034
560	1506
560	1875
561	1887
561	1927
561	1561
561	1908
561	2041
561	2042
561	2027
561	2044
561	1876
561	1506
82	426
82	427
82	428
82	429
82	430
82	431
82	432
82	433
562	1969
562	1970
562	2049
562	1894
562	2051
562	2052
562	2053
562	2054
562	1561
562	1902
563	2057
563	2058
563	2059
563	1841
563	1506
563	2062
563	2063
563	1561
563	2065
563	1872
564	1490
564	1491
564	1537
564	523
564	2071
564	1751
564	1660
564	1504
564	1558
564	1506
565	2077
565	1771
565	1704
565	1786
565	2081
88	469
88	470
88	471
88	472
88	473
88	474
88	430
88	476
89	477
89	478
89	15
89	480
89	481
89	310
89	433
89	484
565	1735
565	2083
565	1744
565	1724
565	2086
566	2003
566	1557
566	2089
566	1853
566	1704
566	1744
566	2083
566	1851
566	2095
566	2096
567	1751
567	2098
567	2099
567	2100
567	2101
567	2102
567	2103
567	1507
567	2096
567	2106
568	1735
568	159
568	1744
568	2086
568	2111
568	2112
568	1704
568	2083
568	2115
568	2005
569	2003
569	1735
569	2119
569	2096
569	2121
96	525
96	526
96	527
96	528
96	159
96	530
96	531
569	1744
569	2102
569	2124
569	1704
569	2086
570	1681
570	159
570	1684
570	1706
570	1689
570	1725
570	1724
570	2134
570	1744
570	1771
571	523
571	1491
571	1704
571	2102
571	1552
572	2003
572	159
572	1744
572	1687
102	569
102	176
102	571
102	572
102	505
102	464
105	591
105	519
105	593
105	594
105	595
105	523
105	464
105	304
106	599
106	523
106	601
106	300
106	159
572	1771
108	612
108	613
108	614
108	615
108	616
108	617
108	618
108	619
572	1704
572	2086
572	1706
572	1491
572	1506
573	2083
573	1686
573	1704
573	523
573	1561
573	2157
574	2158
574	1561
574	2160
574	2161
574	2162
574	1507
574	1494
574	1505
575	2166
575	2083
575	1686
575	2169
575	2124
575	1704
575	2172
575	1706
575	1557
575	2096
576	1771
576	1735
576	1704
576	1703
576	1825
576	2003
576	2086
576	2183
576	2184
576	1964
577	1490
577	1491
577	1699
577	2189
577	1506
577	1496
577	1552
115	584
115	667
115	236
115	110
115	670
115	159
578	2193
578	1735
578	1704
578	2196
578	2197
578	1724
578	2199
578	1744
578	1738
578	2202
579	1771
579	2183
579	2205
579	2206
579	1735
579	2208
579	1706
579	1507
579	2096
579	1851
580	2057
580	1716
580	1825
580	1706
580	1738
580	1704
580	1786
580	2202
580	2221
580	2063
581	2003
581	1853
581	2225
581	1704
581	2227
581	1706
581	1507
581	1851
581	2086
581	1491
582	2057
582	2234
582	2202
582	1738
582	1695
582	1690
582	1506
582	2240
582	2063
582	2242
583	2193
583	1786
583	1682
583	2246
583	1736
583	1724
583	1704
583	1725
583	1569
583	1706
584	1706
584	1704
584	1506
584	2256
584	1507
584	1491
585	2259
585	1902
585	1953
505	1488
505	1489
505	1490
505	1491
505	1492
129	746
129	719
129	63
129	122
505	1493
505	1494
505	1495
505	1496
505	1497
506	1488
506	1491
506	1492
506	1501
506	1502
506	1503
506	1504
506	1505
506	1506
506	1507
507	1492
507	1509
507	1488
507	1491
507	1512
507	1513
507	1490
507	1515
507	1496
507	1517
508	1488
508	1491
508	1490
508	1521
508	1504
508	1506
509	1491
509	1488
509	1492
509	1527
509	1528
509	1529
509	1502
509	1531
509	1532
509	1506
510	1491
510	1492
510	1488
510	1537
510	1538
510	1539
510	1515
510	1541
510	1542
510	1490
511	1488
511	1512
511	1521
511	1492
511	1491
511	1513
511	1506
511	1496
511	1552
512	1489
512	1491
512	1555
512	1494
512	1557
512	1558
512	1493
512	1507
512	1561
513	1488
513	1491
513	1492
513	1496
513	1566
513	1567
513	1568
513	1569
144	777
144	731
144	829
144	722
513	1517
513	1494
514	1491
514	1488
514	1574
514	1492
514	1576
514	1496
514	1578
514	1579
514	1512
514	1581
515	1489
515	1493
515	1496
515	1491
515	1569
515	1558
515	1588
515	1589
515	1590
153	852
154	853
155	854
155	855
156	525
156	857
156	858
156	859
156	860
156	861
156	220
157	863
157	864
157	865
157	866
157	857
157	868
157	24
157	870
158	871
158	872
159	873
160	874
161	875
162	876
162	857
162	426
162	477
162	859
162	881
162	882
163	883
164	884
164	885
165	886
166	887
166	525
166	870
166	890
166	843
166	892
166	857
166	894
167	895
167	896
168	897
169	898
169	899
170	900
171	901
172	902
173	903
174	904
175	905
176	906
177	907
178	908
179	909
515	1591
516	1488
182	912
516	1491
516	1492
185	915
186	916
187	917
188	918
189	919
190	920
191	921
192	922
193	923
194	178
194	859
194	926
194	927
194	928
194	929
194	890
194	492
195	932
196	933
197	934
198	935
198	936
198	937
199	938
200	939
201	265
201	941
201	929
201	943
201	944
201	928
201	857
201	947
202	948
203	949
204	950
205	951
206	952
207	953
208	954
209	955
210	956
211	265
211	525
211	929
211	960
211	961
211	962
211	870
211	890
212	965
212	966
516	1529
516	1596
516	1597
516	1496
516	1506
516	1517
516	1490
517	1489
214	975
214	976
214	857
214	887
214	979
214	870
214	890
214	982
215	983
215	984
215	976
215	857
215	987
215	859
215	989
215	990
216	991
217	992
217	993
217	994
218	995
219	996
219	997
220	998
221	999
222	1000
223	1001
224	1002
225	265
225	525
225	929
225	1006
225	1007
225	1008
225	1009
225	1010
226	1011
227	1012
228	547
228	1014
228	516
228	188
228	870
228	890
228	1019
228	44
229	1021
230	1022
231	1023
232	1024
232	870
232	1026
232	13
232	857
232	1029
232	686
232	1031
233	1032
233	1033
233	857
233	1035
233	1036
233	929
233	1038
233	1039
517	1603
235	1041
236	1042
517	1494
238	1044
239	1045
240	1046
240	857
240	1048
240	1049
240	859
240	1051
240	1052
240	870
517	1605
517	1496
517	1493
517	1491
517	1561
517	1558
517	1611
518	1612
518	1515
243	1063
518	1496
518	1493
518	1489
246	1067
247	1067
248	1069
249	1070
250	1071
251	1072
518	1617
253	1074
254	1075
255	1076
256	1077
518	1618
258	1079
259	1080
260	1081
260	1082
260	1083
260	1084
260	157
260	859
260	609
260	1088
518	1494
518	1517
518	1491
519	1491
519	1488
519	1492
519	1537
519	1538
262	555
262	857
262	1099
262	163
262	859
262	1102
262	1103
262	1104
263	1105
263	1106
264	1107
265	1106
266	1106
267	1110
267	1111
267	1112
268	1107
269	1107
269	1115
270	1116
270	1107
270	1118
271	1107
272	1107
273	1107
274	1107
274	1123
275	1107
276	1107
277	1107
278	1127
278	1107
279	1107
280	1107
281	1107
282	1107
283	1133
283	1107
283	1135
284	1107
285	1107
285	1135
286	1107
286	1116
287	1107
288	1107
288	1135
289	1107
290	1107
291	1107
292	1107
293	1107
294	1107
295	1107
296	1106
296	1107
297	1107
298	1107
298	1155
298	1156
299	1107
300	1158
300	1107
300	1116
301	1116
301	1107
302	1158
302	1107
302	1116
302	1166
303	1107
303	1116
304	1107
304	1156
305	1171
305	1107
306	1116
306	1107
307	1107
308	1176
308	1107
309	1107
310	1107
310	1116
310	1158
311	1158
311	1107
311	1156
312	1158
312	1107
313	1107
314	1107
315	1107
316	1107
316	1176
316	1118
317	1107
318	1156
318	1107
319	1196
319	1107
320	1107
321	1107
321	1118
322	1107
322	1135
323	1107
323	1116
324	1107
325	1107
326	1107
327	1107
328	1107
328	1156
329	1107
330	1107
331	1156
331	1107
332	1156
332	1107
332	1106
333	1118
333	1107
334	1107
334	1118
335	1118
335	1107
335	1135
336	1107
336	1176
337	1107
338	1156
338	1107
339	1230
339	1107
339	1232
339	1233
340	1107
341	1156
341	1107
342	1156
342	1107
343	1156
343	1107
344	1107
345	1107
346	1156
346	1107
347	1156
347	1107
348	1107
349	1107
350	1107
350	1118
350	1158
351	1156
351	1107
351	1106
352	1156
352	1107
353	1107
354	1115
354	1107
354	1260
355	1107
356	1115
356	1107
357	1107
358	1107
359	1107
360	1107
361	1107
361	1176
362	1107
363	1107
364	1107
365	1107
366	1107
367	1107
368	1118
368	1107
369	1107
370	1107
371	1107
371	1110
371	1135
372	1107
372	1156
373	1118
373	1107
373	1116
374	1107
375	1107
376	1107
377	1107
378	1107
379	1107
379	1116
380	1107
381	1107
381	1176
381	1106
382	1107
383	1107
384	1107
384	1176
385	1116
385	1107
386	1107
387	1107
388	1107
389	1107
389	1116
390	1107
519	1541
519	1529
519	1542
519	1496
519	1506
520	1491
520	1489
520	1488
520	1492
520	1636
520	1558
520	1506
520	1493
520	1496
520	1641
521	1642
521	1489
521	1488
521	1491
521	1492
521	1496
521	1558
521	1649
521	1650
521	1494
522	1512
522	1513
522	1654
522	1655
522	1517
522	1496
522	1491
522	1659
522	1660
522	1561
523	1491
523	1489
523	1492
523	1509
523	1501
523	1493
523	1568
523	1490
523	1558
523	1671
524	1672
524	1521
524	1491
524	1490
524	1542
524	1488
524	1506
524	1679
525	159
525	1681
525	1682
525	1683
525	1684
525	523
525	1686
525	1687
525	1688
525	1689
526	1690
526	159
526	1681
526	1506
526	1694
526	1695
526	1696
526	1684
526	1698
526	1699
527	159
527	1690
527	1698
527	1703
527	1704
527	1506
527	1706
527	1507
527	1491
528	1506
528	159
528	1684
528	1712
528	1713
528	1690
528	1696
528	1716
528	1717
528	1706
529	1684
529	1681
529	1689
529	1722
529	1723
529	1724
529	1725
529	1491
529	1506
529	1728
530	1684
530	1698
530	1717
530	1723
530	1506
530	1706
530	1735
530	1736
530	1724
530	1738
531	159
531	1699
531	1724
531	1706
531	1690
531	1744
531	1704
531	1684
531	1491
531	1506
532	1684
532	1724
532	1751
532	1717
532	1491
532	1506
532	1706
532	1704
532	1557
532	1507
533	1684
533	1681
533	1698
533	1687
533	1723
533	1506
533	1706
533	1704
533	1717
533	1768
534	1723
534	1684
534	1771
534	1704
534	1706
534	1724
534	1736
534	1744
534	1682
534	1778
535	1717
535	159
535	1684
535	1706
535	1783
535	1784
535	1785
535	1786
535	1704
535	1788
536	1684
536	1725
536	1506
536	1706
536	1704
536	1491
536	1557
536	1507
585	1970
585	2052
585	1506
585	1491
585	1704
585	1706
585	1561
586	1491
586	1694
586	1699
586	2272
586	1506
586	1681
586	2275
586	1698
586	2277
586	1690
587	2279
587	1690
587	1491
587	2282
587	1695
587	2284
587	2285
587	2286
587	1506
587	2288
588	1694
588	1690
588	2291
588	2292
588	1695
588	1706
588	1491
588	1506
588	2297
588	1704
589	1978
589	1690
589	1506
589	1491
589	2292
589	1695
589	2305
589	159
589	2307
589	2041
590	2309
590	1690
590	2311
590	1506
590	1826
590	1491
590	2315
590	1706
590	1696
590	1507
591	1695
591	1690
591	1506
591	1694
591	1491
591	2292
591	2325
591	1684
591	1706
591	159
592	1690
592	2330
592	2331
592	159
592	2333
592	1706
592	2335
592	1704
592	1491
592	1506
593	2291
593	1690
593	1826
593	2342
593	1506
593	2027
593	1950
593	1841
593	1704
593	1706
594	1978
594	1841
594	1696
594	2352
594	1506
594	2291
594	1690
594	2356
594	1704
594	1706
595	1690
595	1506
595	2361
595	1872
595	1491
595	1492
595	1826
595	2366
595	1696
596	1506
596	1696
596	1826
596	1929
596	1908
596	2373
596	1491
596	1690
596	1888
596	1902
597	2325
597	1706
597	1491
597	2381
597	2286
597	1506
597	1704
597	1679
597	1507
598	1978
598	1694
598	2292
598	2286
598	2391
598	2392
598	2272
598	2307
598	2325
598	1706
599	2259
599	2398
599	2399
599	1704
599	1706
599	2402
599	1506
599	1491
599	1507
599	1561
600	1506
600	1694
600	1690
600	1491
600	2291
600	2412
600	1698
600	1681
600	159
600	1841
601	1690
601	2418
601	1494
601	1497
601	1704
601	1557
601	1506
601	2424
601	1491
601	1507
602	2427
602	2342
602	2121
602	2430
602	2330
602	1507
602	2433
602	1825
602	1706
602	2436
603	1929
603	1948
603	1506
603	1841
603	1698
603	1690
603	1561
603	2311
603	1491
603	159
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: literature; Owner: -
--

COPY literature.documents (document_id, source_id, document_code, title, title_en, document_type, abstract, abstract_en, journal_name, conference_name, publication_date, publication_year, volume, issue, pages, doi, standard_no, patent_no, source_url, citation_text, language, security_level, status, is_featured, published_at, created_by, created_at, updated_at, discovery_source, scholar_citation_count, scholar_url, scholar_checked_at) FROM stdin;
153	3	LIT-000153	高效炼钢工艺在转炉冶金中的应用与优化	\N	paper	\N	\N	工程施工新技术	\N	\N	2026	\N	\N	\N	10.37155/2811-0609-0503-63	\N	\N	https://doi.org/10.37155/2811-0609-0503-63	Chen Xu. (2026). 高效炼钢工艺在转炉冶金中的应用与优化. 工程施工新技术. https://doi.org/10.37155/2811-0609-0503-63.	en	public	published	f	2026-07-30 16:18:20.216124+08	openalex_import	2026-07-30 16:18:20.216124+08	2026-07-30 16:18:20.216124+08	\N	\N	\N	\N
604	6	LIT-000604	On the elastocaloric effect in CuAlBe shape memory alloys: A quantitative phase-field modeling approach	\N	paper	\N	\N	Computational Materials Science	\N	\N	2020	183	\N	109808-109808	10.1016/j.commatsci.2020.109808	\N	\N	https://doi.org/10.1016/j.commatsci.2020.109808	On the elastocaloric effect in CuAlBe shape memory alloys: A quantitative phase-field modeling approach. https://doi.org/10.1016/j.commatsci.2020.109808	en	public	published	t	2026-08-17 11:44:08.720183+08	google_scholar_seed	2026-08-17 11:44:08.720183+08	2026-08-17 11:44:08.720183+08	google_scholar	27	https://scholar.google.com/citations?user=XmPeaCkAAAAJ	2026-08-17 11:44:08.720183+08
605	6	LIT-000605	An Asymmetric Elasto-Plastic Phase-Field Model for Shape Memory Effect, Pseudoelasticity and Thermomechanical Training in Polycrystalline Shape Memory Alloys	\N	paper	We propose an elasto-plastic phase-field model (PFM) to conduct the first microscopic computational study of shape memory effect (SME), pseudoelasticity, stress assisted two-way memory effect (SATWME), and thermomechanical training of CuAlBe shape memory alloy (SMA). This non-isothermal PFM model considers the effects of temperature dependent properties, latent heat, grain boundaries, and asymmetric transformation and plasticity. PFM simulations demonstrate the capacity of our model to capture the thermomechanical and purely mechanical shape recovery in the SMA. When considering transforming grain boundaries, grain refinement generates a higher transformation stress, a steeper transformation hardening, and smaller hysteresis loops for both SME and pseudoelasticity. The results also point out slightly higher transformation stress when geometrical grain boundaries are used. The simulations of SATWME highlight an augmentation of the residual martensite as the hold stress increases, which is consistent with experimental observations. This is the first PFM that can mimic the thermal training within several SATWME cycles, showing an asymptotic increase of plastic strain and the related retained transformation strain until the fourth cycle, and their stabilization thereafter. The activation of plasticity occurs always after initiation of phase transformation. Although plasticity results in more stress relaxation, it deteriorates the shape recovery for both SME and pseudoelasticity by hindering the reverse transformation. Comparison between tension and compression demonstrates the capacity of this PFM to account for, for the first time, the nonsymmetrical transformation and plastic responses of SMAs.	\N	Acta Materialia	\N	\N	2020	201	\N	580-595	10.1016/j.actamat.2020.10.034	\N	\N	https://doi.org/10.1016/j.actamat.2020.10.034	An Asymmetric Elasto-Plastic Phase-Field Model for Shape Memory Effect, Pseudoelasticity and Thermomechanical Training in Polycrystalline Shape Memory Alloys. https://doi.org/10.1016/j.actamat.2020.10.034	en	public	published	t	2026-08-17 11:44:09.475891+08	google_scholar_seed	2026-08-17 11:44:09.475891+08	2026-08-17 11:44:09.475891+08	google_scholar	47	https://scholar.google.com/citations?user=XmPeaCkAAAAJ	2026-08-17 11:44:09.475891+08
606	6	LIT-000606	A phase-field model for non-isothermal phase transformation and plasticity in polycrystalline yttria-stabilized tetragonal zirconia	\N	paper	\N	\N	Acta Materialia	\N	\N	2020	191	\N	111-123	10.1016/j.actamat.2020.03.025	\N	\N	https://doi.org/10.1016/j.actamat.2020.03.025	A phase-field model for non-isothermal phase transformation and plasticity in polycrystalline yttria-stabilized tetragonal zirconia. https://doi.org/10.1016/j.actamat.2020.03.025	en	public	published	t	2026-08-17 11:44:10.269986+08	google_scholar_seed	2026-08-17 11:44:10.269986+08	2026-08-17 11:44:10.269986+08	google_scholar	38	https://scholar.google.com/citations?user=XmPeaCkAAAAJ	2026-08-17 11:44:10.269986+08
607	6	LIT-000607	Transformation-induced fracture toughening in CuAlBe shape memory alloys: A phase-field study	\N	paper	\N	\N	International Journal of Mechanical Sciences	\N	\N	2020	192	\N	106144-106144	10.1016/j.ijmecsci.2020.106144	\N	\N	https://doi.org/10.1016/j.ijmecsci.2020.106144	Transformation-induced fracture toughening in CuAlBe shape memory alloys: A phase-field study. https://doi.org/10.1016/j.ijmecsci.2020.106144	en	public	published	t	2026-08-17 11:44:10.942982+08	google_scholar_seed	2026-08-17 11:44:10.942982+08	2026-08-17 11:44:10.942982+08	google_scholar	30	https://scholar.google.com/citations?user=XmPeaCkAAAAJ	2026-08-17 11:44:10.942982+08
12	2	LIT-000012	Frontmatter	\N	paper	The prelims comprise: Half Title Title Copyright Contents Preface	The prelims comprise: Half Title Title Copyright Contents Preface	Extractive Metallurgy 1	\N	\N	2013	\N	\N	\N	10.1002/9781118618974.fmatter	\N	\N	https://doi.org/10.1002/9781118618974.fmatter	(2013). Frontmatter. Extractive Metallurgy 1. https://doi.org/10.1002/9781118618974.fmatter.	en	public	published	f	2026-07-28 10:26:04.144989+08	crossref_import	2026-07-28 10:26:04.144989+08	2026-08-17 11:35:49.846162+08	\N	\N	\N	\N
608	6	LIT-000608	Removal of iron, aluminium, manganese and copper from leach solutions of lithium-ion battery waste using ion exchange	\N	paper	The shift to electric mobility necessitates recycling the metals from lithium ion battery waste. Ion exchange was studied for use in the removal of impurities from synthetic lithium ion battery waste leachate in laboratory-scale batch and column experiments. Aminomethylphosphonic acid functional chelating resin (Lewatit TP260) was capable of removing Fe, Al, Mn, and Cu from the leachate, while leaving valuable Co, Ni, and Li as a pure mixture in the raffinate. Increasing the pH up to 3 and the temperature to 60 °C improved the purity and productivity. Iron and aluminium could not be eluted efficiently by mineral acids, but an oxalate solution was found feasible. A two-step elution procedure, in which Cu and Mn are first removed with sulfuric acid, followed by Fe and Al removal with potassium oxalate, was successfully demonstrated. The suggested process produced a > 99.6% pure Li + Co + Ni solution (battery grade), along with a Mn and Cu rich sulfuric acid solution with Co as an impurity and an oxalate solution of Fe + Al as by-products. The productivities for these solutions were 0.39, 0.16, and 0.38 BV/h, respectively. The Co loss was very low (1.1%) as compared to previously suggested impurity removal processes using precipitation and solvent extraction. Moreover, Co can be easily recycled back to the ion exchange column feed after Mn and Cu are recovered as pure by-products.	\N	Hydrometallurgy	\N	\N	2021	202	\N	105602-105602	10.1016/j.hydromet.2021.105602	\N	\N	https://doi.org/10.1016/j.hydromet.2021.105602	Removal of iron, aluminium, manganese and copper from leach solutions of lithium-ion battery waste using ion exchange. https://doi.org/10.1016/j.hydromet.2021.105602	en	public	published	t	2026-08-17 11:44:16.617485+08	google_scholar_seed	2026-08-17 11:44:16.617485+08	2026-08-17 11:44:16.617485+08	google_scholar	125	https://scholar.google.com/citations?user=4bLI4tsAAAAJ	2026-08-17 11:44:16.617485+08
609	6	LIT-000609	Recovering rare earth elements from phosphogypsum using a resin-in-leach process: Selection of resin, leaching agent, and eluent	\N	paper	Phosphogypsum (PG) is an attractive secondary raw material for rare earth elements (REEs) because it is abundant and contains significant amounts of REEs. Herein, the resin-in-leach (RIL) process for REE recovery from PG was studied, and the factors affecting the yield and selectivity of conventional leaching and RIL are discussed based on the batch equilibrium data obtained using four different lixiviants, H2SO4, HCl, H3PO4, and NaCl. It was found that the chelating resin enabled the use of a low H2SO4 concentration (1 g/L) in the RIL process. The REE recovery yield and purity in the single-stage RIL process were higher when the chelating resin was used than when strong acid resins were used. The difference was significant in the multistage cross-current RIL process, where a loading of 19.2 g(REE)/kg(resin) and up to 20% purity were obtained with the chelating resin (vs. 3% in strong acid resin) after four stages. It is concluded that neither the breaking of the PG structure, nor the adsorption of calcium by the resin is necessary to enhance REE recovery. Considering the available literature and patents, this is a promising finding. REEs can be eluted from strong cation exchangers using a saturated sodium chloride solution, while EDTA or concentrated hydrochloric acid is required in the case of a chelating resin. However, Ca and REE can be further separated during elution of the chelating resin.	\N	Hydrometallurgy	\N	\N	2019	189	\N	105125-105125	10.1016/j.hydromet.2019.105125	\N	\N	https://doi.org/10.1016/j.hydromet.2019.105125	Recovering rare earth elements from phosphogypsum using a resin-in-leach process: Selection of resin, leaching agent, and eluent. https://doi.org/10.1016/j.hydromet.2019.105125	en	public	published	t	2026-08-17 11:44:19.193037+08	google_scholar_seed	2026-08-17 11:44:19.193037+08	2026-08-17 11:44:19.193037+08	google_scholar	71	https://scholar.google.com/citations?user=4bLI4tsAAAAJ	2026-08-17 11:44:19.193037+08
28	2	LIT-000028	Summaries of Other Volumes	\N	paper	\N	\N	Extractive Metallurgy 1	\N	\N	2013	\N	\N	345-351	10.1002/9781118618974.oth2	\N	\N	https://doi.org/10.1002/9781118618974.oth2	(2013). Summaries of Other Volumes. Extractive Metallurgy 1. 345-351. https://doi.org/10.1002/9781118618974.oth2.	en	public	published	f	2026-07-28 10:26:04.19869+08	crossref_import	2026-07-28 10:26:04.19869+08	2026-08-17 11:35:51.676002+08	\N	\N	\N	\N
154	3	LIT-000154	高炉炼铁工艺节能减排技术探讨	\N	paper	钢铁产业是我国社会经济发展不可或缺的一部分。进入新阶段，生产制造与生活对建筑钢材的需要日益 提升，这极大促进了炼钢厂炼钢和冶金工业的脚步。但另一方面，钢铁产业往往伴随着高耗能，给自然生态系统平衡 长期稳定带来了极大的毁坏。因而，在绿色环保理念和生态环保可持续发展观理念的推动下，怎样做好高炉炼铁全过 程节能减排技术的开发与应用，已成为当前钢铁企业的重要课题。剖析节能减排技术在高炉炼铁工艺中的运用优点， 依据节能减排理念下高炉炼铁工艺的发展现状，明确提出节能减排技术在高炉炼铁工艺中的运用防范措施，将节能减 排理念列入公司改进运营和转型发展的战略目标，在符合广大群众日益持续增长的钢材需求的同时，确保环境保护工 作，降低污染排放，完成人与自然和睦相处。	\N	机械与电子控制工程	\N	\N	2023	\N	\N	\N	10.37155/2717-5197-0503-39	\N	\N	https://doi.org/10.37155/2717-5197-0503-39	张志响, 夏建国, 祝道朋, 朱加义. (2023). 高炉炼铁工艺节能减排技术探讨. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0503-39.	zh	public	published	t	2026-07-30 16:18:20.2358+08	openalex_import	2026-07-30 16:18:20.2358+08	2026-07-30 16:18:20.2358+08	\N	\N	\N	\N
38	2	LIT-000038	An In-Situ Analysis Method in EAF and BOF Steelmaking	\N	paper	Abstract\n               An analysis was conducted to gage the feasibility of using a spectroscopic method to determine the chemical composition of the liquid metal phase in EAF and BOF steelmaking. The hypothesis that certain radiation intensities found in UV- and UV-near regions of an spectrum emitted from the hot-spot in the BOF or the impingement area of oxyfuel burners in EAF steelmaking can be used for analysing the chemical components present in the liquid metal is tested. Significant lab-scale experiment results and the conclusions regarding industrial scale implementation are presented.	\N	IOP Conference Series: Materials Science and Engineering	\N	\N	2024	1309	1	012002	10.1088/1757-899x/1309/1/012002	\N	\N	https://doi.org/10.1088/1757-899x/1309/1/012002	Mitas B, Pauna H, Feldbacher J, Schenk J. (2024). An In-Situ Analysis Method in EAF and BOF Steelmaking. IOP Conference Series: Materials Science and Engineering. 1309(1). 012002. https://doi.org/10.1088/1757-899x/1309/1/012002.	en	public	published	f	2026-07-28 10:26:05.562167+08	crossref_import	2026-07-28 10:26:05.562167+08	2026-07-28 10:26:05.562167+08	\N	\N	\N	\N
155	3	LIT-000155	颠覆性技术研究（一）——理论起源、概念界定与五维分析框架	\N	paper	本文旨在剖析21世纪“颠覆性技术”在国家竞争体系中的多维内涵与战略价值。通过突破传统以市场为中心的理论局限，融合地缘政治与前沿科技演进，本文构建了包含“市场颠覆、赋能范围、战略安全、产业主权、社会伦理”的五维分析框架，以此作为系统性评估关键技术的统一标尺。结合生成式人工智能与低轨卫星通信等当代复杂技术案例的五维解构，该框架有效拓展了颠覆性技术定义的战略深度。本研究不仅为洞察全球技术变革动力提供了更为宏大的分析视角，也为国家层面进行新兴颠覆性技术的识别与战略布局构建了坚实的理论基石。 关键词 颠覆性技术；国家战略；五维分析模型；技术治理；大国竞争；创新经济学	\N	Theory and Practice of Social Science	\N	\N	2026	\N	\N	\N	10.6914/tpss.080101	\N	\N	https://doi.org/10.6914/tpss.080101	Changkui LI, 张雅琪. (2026). 颠覆性技术研究（一）——理论起源、概念界定与五维分析框架. Theory and Practice of Social Science. https://doi.org/10.6914/tpss.080101.	zh	public	published	t	2026-07-30 16:18:20.246343+08	openalex_import	2026-07-30 16:18:20.246343+08	2026-07-30 16:18:20.246343+08	\N	\N	\N	\N
66	2	LIT-000066	Comparative studies of the discharge of hydronium ions on zinc, copper and aluminum cathodes	\N	paper	Electrochemical reduction of hydrogen (hydronium ion) was carried out on zinc, aluminum and copper cathodes from acidic aqueous solutions containing sulfuric acid (0.09, 0.18 and 0.36 mol/l) to study the effect of electrolyte acidity, the type of cathodes used and potential values on electrolysis indicators. The studies were carried out on the potentiostat using a three-electrode cell under conditions of intensive electrolyte stirring with a magnetic stirrer. At the initial stage, electrolysis was performed in the following modes: potentiodynamic measurements at a sweep rate of 1 mV/s in the potential range Е = –(700÷850) mV on a copper and aluminum electrode and Е = –(1000÷1150) mV on a zinc electrode. In the indicated potential range, hydronium discharge parameters at each cathode were calculated: Tafel slope, apparent transfer coefficients and exchange currents. Dependences of these parameters on electrolyte acidity were considered. Average values of steady state potentials were obtained, which, similar to the apparent exchange current, significantly depended on the cathode material: –923.1 mV (zinc cathode); +36.1 mV (copper cathode), and –603.7 mV (aluminum cathode) (AgCl/Ag). The effect of surfactants on all the kinetic parameters considered was shown. The order of the reaction with and without surfactant additives was determined. At the next stage, the electrochemical parameters of hydronium discharge on the copper electrode only were compared. It was shown that the electrochemical parameters significantly depend on the cathodic potential range where they are determined, and on the methods used for their calculation. It was noted that the process proceeds in the region of mixed kinetics. As the electrode polarization decreases, the hydrogen discharge mechanism changes, while the proportion of electrochemical kinetics will increase in the region of mixed kinetics. We suppose that the data obtained can also be of practical importance for the zinc electrolysis technology. The data obtained in this research on the electrochemical parameters of hydrogen discharge in a wide range of potentials on cathodes made of different metals as well as on the effect of electrolyte acidity on the behavior of surfactants during electrolysis will expand knowledge about the zinc electrolysis technology.	\N	Izvestiya Vuzov. Tsvetnaya Metallurgiya (Universities' Proceedings Non-Ferrous Metallurgy)	\N	\N	2022	28	6	22-31	10.17073/0021-3438-2022-6-22-31	\N	\N	https://doi.org/10.17073/0021-3438-2022-6-22-31	Kolesnikov A. V., Ageenko E. I.. (2022). Comparative studies of the discharge of hydronium ions on zinc, copper and aluminum cathodes. Izvestiya Vuzov. Tsvetnaya Metallurgiya (Universities' Proceedings Non-Ferrous Metallurgy). 28(6). 22-31. https://doi.org/10.17073/0021-3438-2022-6-22-31.	en	public	published	f	2026-07-28 10:26:06.573339+08	crossref_import	2026-07-28 10:26:06.573339+08	2026-07-28 10:26:06.573339+08	\N	\N	\N	\N
156	3	LIT-000156	Progress and prospective of new pollutants study	\N	paper	The governance of new pollutants has been becoming a critical strategic demand for the high-quality development of China. The policy will be further advanced during the coming National 15th Five-Year Plan period. Nevertheless, significant challenges remain in aspects such as list of controlled chemicals, standard development, measurement methods, alternative approaches, and remediation techniques. Existing experience in addressing traditional pollutants remains insufficient to adequately address the concealed and complex ecological and/or health risks associated with new pollutants. Thus, a strengthening of basic research is the optimal approach to tackling these challenges and avoiding detours. To better identify the critical scientific challenges and outline key breakthroughs for fundamental research, this study systematically discusses the following five central aspects, namely, the origins of new pollutants research, the definition and scope of new pollutants, the foundation and development of scientific research in China, the current primary challenges, and the future research directions. The outcome will contribute to advancing the development of national risk prevention and control system, facilitating the fulfillment of international commitments, and achieving the goals of building a Healthy China.	\N	Zhongguo Kexueyuan yuankan	\N	\N	2026	\N	\N	\N	10.3724/j.issn.1000-3045.20260119005	\N	\N	https://doi.org/10.3724/j.issn.1000-3045.20260119005	Ting Ruan, Chunyang LIAO, Yawei Wang, Maoyong Song, Yaqi CAI, Guibin Jiang. (2026). Progress and prospective of new pollutants study. Zhongguo Kexueyuan yuankan. https://doi.org/10.3724/j.issn.1000-3045.20260119005.	en	public	published	f	2026-07-30 16:18:20.254541+08	openalex_import	2026-07-30 16:18:20.254541+08	2026-07-30 16:18:20.254541+08	\N	\N	\N	\N
592	5	LIT-000592	Sustainable Utilization of Steel Slag from Traditional Industry and Agriculture to Catalysis	\N	paper	Steel slag is a large amount of residual material produced in the process of steel manufacturing. With the requirements of sustainable development in China, the utilization of steel slag has become a hot issue. Through an in-depth study on steel slag, it is apparent that it has been widely used in various fields in recent years. The resource utilization of steel slag is not only conducive to resource conservation, but also conducive to sustainable production and environmental protection. In this paper, the common ways of resource utilization of steel slag in construction, agriculture, industry, and catalysis are reviewed. Steel slag as a solid waste with great development potential and large output is expected to be widely developed into high value-added products such as catalytic material in the future.	\N	Sustainability	\N	\N	2020	12	21	9295-9295	10.3390/su12219295	\N	\N	https://doi.org/10.3390/su12219295	Di Gao, Fuping Wang, Yitong Wang, Yanan Zeng. (2020). Sustainable Utilization of Steel Slag from Traditional Industry and Agriculture to Catalysis. Sustainability. https://doi.org/10.3390/su12219295	en	public	published	t	2026-08-17 11:35:19.297959+08	openalex_oa_curated	2026-08-17 11:35:19.297959+08	2026-08-17 11:35:19.297959+08	\N	\N	\N	\N
593	5	LIT-000593	Environmental and Socioeconomic Impact of Copper Slag—A Review	\N	paper	Copper slag is generated when copper and nickel ores are recovered from their parent ores using a pyrometallurgical process, and these ores usually contain other elements which include iron, cobalt, silica, and alumina. Slag is a major problem in the metallurgical industries as it is dumped into heaps which have accumulated into millions of tons over the years. Moreover, they pose a danger to the environment as they occupy vacant land (space problems). Over the past few years, studies have been conducted to investigate the copper slag-producing outlets to learn their behavior, as well as properties of slag, to have the knowledge of how to better reuse and recycle copper slag. This review article provides the environmental and socioeconomic impacts of slag, as well as a characterization of copper slag, with the aim of reusing and recycling the slag to benefit the environment and economy. Recycling methods are considered an attractive technological pathway for reducing waste and greenhouse gas emissions, as well as promoting the concept of circular economy through the utilization of waste. These metal elements have value depending on their characteristics; hence, copper slag is considered as a secondary source of valuable metals. Some of the pyrometallurgical and hydrometallurgical processes to consider are physical separation, magnetic separation, flotation, leaching, and direct reduction roasting of iron (DRI). Some of the possible metals that can be recovered from the copper slag include Cu, Fe, Ni, Co, and Ag (precious metals).	\N	Crystals	\N	\N	2021	11	12	1504-1504	10.3390/cryst11121504	\N	\N	https://doi.org/10.3390/cryst11121504	Tlotlo Solomon Gabasiane, Gwiranai Danha, Tirivaviri Mamvura, Tebogo Mashifana, Godfrey Dzinomwa. (2021). Environmental and Socioeconomic Impact of Copper Slag—A Review. Crystals. https://doi.org/10.3390/cryst11121504	en	public	published	t	2026-08-17 11:35:19.305914+08	openalex_oa_curated	2026-08-17 11:35:19.305914+08	2026-08-17 11:35:19.305914+08	\N	\N	\N	\N
594	5	LIT-000594	Study of the micromorphology and health risks of arsenic in copper smelting slag tailings for safe resource utilization	\N	paper	Slag tailings are produced by “cooling-grinding-ball milling-flotation” and other processes of slag, while slag is produced by the flash smelting of the original ore. The utilization and environmental hazards of arsenic in slag tailings have become a focus of attention. This study on slag tailings reveals the presence of arsenic in copper smelting tailings from the mineralogy and leaching perspectives, and the noncarcinogenic and carcinogenic risks of arsenic to the human body were assessed by using the USEPA health risk model. The surface particles of the slag tailings were unevenly dispersed, and the mineral crystals were relatively complete. A small amount of secondary minerals had grown on the mineral surface. Most of the fine particles adhered to the surface of the main mineral to form inclusions. The mineral composition of the slag tailings was dominated by maghemite (Fe3O4) and fayalite (Fe2SiO4), and the arsenic-bearing minerals were unevenly distributed, where As (Ⅴ) fine particles were embedded in maghemite, amorphous phase and fayalite. There was a large amount of residual arsenic in the slag tailing particles, and the leaching content of arsenic in the toxicity leaching procedure was always lower than the limit of 5 mg/L. The health risk to the exposed population was evaluated by the USEPA health risk model. Since the exposed population in the industrial land is mainly adults, it is determined that the tailings will not cause harm to children's health. In this evaluation, the exposure duration (length of service of the workers) of 30 years, exposure frequency of 314 d/y and body weight of 60 kg (average weight of the workers) were taken as the parameters of three exposure pathways: hand-oral ingestion, respiratory system inhalation and skin contact. Therefore, longer activity time of the workers in the tailing workshop corresponds to a higher HI (hazard index). Although the arsenic in the slag tailings had a certain degree of bioavailability, it was not sufficient to adversely affect human health.	\N	Ecotoxicology and Environmental Safety	\N	\N	2021	219	\N	112321-112321	10.1016/j.ecoenv.2021.112321	\N	\N	https://doi.org/10.1016/j.ecoenv.2021.112321	Liqun Zhang, Huihui Zhou, Chen Xing, Guijian Liu, Chunlu Jiang, Liugen Zheng. (2021). Study of the micromorphology and health risks of arsenic in copper smelting slag tailings for safe resource utilization. Ecotoxicology and Environmental Safety. https://doi.org/10.1016/j.ecoenv.2021.112321	en	public	published	t	2026-08-17 11:35:19.314917+08	openalex_oa_curated	2026-08-17 11:35:19.314917+08	2026-08-17 11:35:19.314917+08	\N	\N	\N	\N
82	2	LIT-000082	Joint use of sodium silicate and polysaccharides in the flotation of talcose copper-nickel ores	\N	paper	The paper considers the combined effect of polysaccharides (carboxymethyl cellulose and carboxymethyl starch) with sodium silicate in the f lotation of talcose copper-nickel ore. The analysis of the f lotation results and the assessment of hydrophobicity and surface charge of minerals showed that the composition of carboxymethylated  polysaccharides  and  sodium  silicate  hydrophilizes  the talc surface more effectively than each of the reagents separately. Moreover, sodium silicate alone hardly depresses the talc surface at all. The depression of f lotation-active silicates is effective when polysaccharide and sodium silicate are sequentially supplied. Under these conditions, sodium silicate makes a significant contribution to increasing the negative charge on the talc particles surface. The effect is more pronounced for compositions with starch, characterized by a lower degree of substitution compared to cellulose. It results in a significantly reduced recovery of f lotation-active magnesium-containing silicates and a slight decrease in sulfide recovery. To determine the features of the mechanism of talc and sulfide minerals depression in f lotation, we performed calculations using the extended DLVO theory based on the obtained values of the zeta potential and force of detachment. We established that sulfide minerals have no potential barrier preventing their interaction with an air bubble, regardless of the compositions of the studied depressants used. We propose the following interaction mechanism: when sodium silicate is supplied first, the talc basal surface is very insignificantly hydrophilized as SiO(OH)– ions are not easy to fix. On the contrary, when the carboxymethylated polysaccharide is supplied first, significant hydrophilization of the talc surface with carboxyl groups occurs due to the hydrophobic interaction between the corresponding regions of the macromolecule and the talc basal surface.	\N	Izvestiya. Non-Ferrous Metallurgy	\N	\N	2024	\N	2	5-15	10.17073/0021-3438-2024-2-5-15	\N	\N	https://doi.org/10.17073/0021-3438-2024-2-5-15	Lavrinenko A. A., Kuznetsova I. N., Golberg G. Yu., Lusinyan O. G.. (2024). Joint use of sodium silicate and polysaccharides in the flotation of talcose copper-nickel ores. Izvestiya. Non-Ferrous Metallurgy. 2). 5-15. https://doi.org/10.17073/0021-3438-2024-2-5-15.	en	public	published	f	2026-07-28 10:26:06.646718+08	crossref_import	2026-07-28 10:26:06.646718+08	2026-07-28 10:26:06.646718+08	\N	\N	\N	\N
162	3	LIT-000162	Prediction and Joint Optimization of Hardness and Thermal Conductivity of Aluminum-Copper Alloys Based on Machine Learning	\N	paper	针对铝铜合金性能预测中小样本建模困难、传统设计难以协同优化硬度与导热性能的问题，构建物理衍生特征与多级降维筛选相结合的机器学习框架，实现合金性能预测与成分优化.以相同工艺制备的24组铝铜合金为研究对象，结合元素理化特性构建物理衍生特征空间，通过层次聚类、正则化回归与全子集搜索相结合的多级特征筛选方法提取核心特征，分别建立硬度与导热率的最小绝对收缩和选择算子预测模型.采用全局拉丁超立方体采样与局部高斯精修相结合的两阶段策略，基于综合评分函数开展硬度与导热性能的协同优化，在可行成分域内生成候选样本并筛选高性能种子成分，通过高斯重采样与成分归一化定位最优成分.最终获得四组综合性能优异的合金成分，实现硬度与导热性能的均衡提升.该框架可为小样本条件下高性能铝铜合金的双性能协同优化设计提供有效技术途径.	\N	Acta Physica Sinica	\N	\N	2026	\N	\N	\N	10.7498/aps.75.20260634	\N	\N	https://doi.org/10.7498/aps.75.20260634	BU Tongtong, LI Xia, LOU Chunxiang, REN Pingjing, DING Shoujun, ZOU Yong, XIONG Chunming. (2026). Prediction and Joint Optimization of Hardness and Thermal Conductivity of Aluminum-Copper Alloys Based on Machine Learning. Acta Physica Sinica. https://doi.org/10.7498/aps.75.20260634.	zh	public	published	f	2026-07-30 16:18:37.11003+08	openalex_import	2026-07-30 16:18:37.11003+08	2026-07-30 16:18:37.11003+08	\N	\N	\N	\N
88	2	LIT-000088	Utilizing Russian polymer anion active depressants in the flotation of out-of-balance talcose copper nickel ore	\N	paper	Experimental studies were conducted on the flotation of low-sulfide copper-nickel ore containing flotation-active magnesium silicates, specifically talc, using organic polymeric anionic reagents containing carboxyl and hydroxyl groups as depressants. The following reagents, which contain carboxyl groups, were examined: carboxymethyl cellulose and carboxymethylated starch; polyacrylic acid and its derivatives; sodium humate. Copolymers of ethylene oxide with ethylenediamine and glycerol containing hydroxyl groups were also investigated. The objective of this study was to identify new efficient domestic depressants for flotation-active silicates, selectively acting in the flotation of low-sulfide copper-nickel ore, in comparison with the performance of foreign Depramin 347 depressant. The impact of depressant reagents on the surface properties of talc was determined by the values of air bubble detachment force and electrokinetic potential. It was observed that for reagents containing carboxyl groups, the depressing effectiveness decreased in the following order: carboxymethyl cellulose → carboxymethylated starch → polyacrylic acid → sodium humate. This reduction was attributed to a decrease in the acidic properties of the reagents, a decline in their adsorption affinity for talc, and a decrease in the proportion of active carboxyl groups participating in the formation of the electrokinetic potential. Furthermore, a trend towards increased depressing ability was noted for carboxymethyl cellulose samples with an increasing degree of substitution. In contrast, reagents containing hydroxyl groups had virtually no depressing effect on talc. The data obtained support the use of domestic industrial samples of carboxymethyl cellulose, namely CMC 7N and PAC-N, as depressants for floating silicates, particularly talc, which is a detrimental impurity in the concentrate. 	\N	Izvestiya. Non-Ferrous Metallurgy	\N	\N	2023	29	5	5-14	10.17073/0021-3438-2023-5-5-14	\N	\N	https://doi.org/10.17073/0021-3438-2023-5-5-14	Lavrinenko A. A., Kuznetsova I. N., Lusinyan O. G., Golberg G. Yu.. (2023). Utilizing Russian polymer anion active depressants in the flotation of out-of-balance talcose copper nickel ore. Izvestiya. Non-Ferrous Metallurgy. 29(5). 5-14. https://doi.org/10.17073/0021-3438-2023-5-5-14.	en	public	published	f	2026-07-28 10:26:06.675862+08	crossref_import	2026-07-28 10:26:06.675862+08	2026-07-28 10:26:06.675862+08	\N	\N	\N	\N
89	2	LIT-000089	Optimization of converting process for matte of oxidized nickel ores and sulfide copper ores joint smelting based on thermodynamic simulation	\N	paper	The paper presents the results obtained in the thermodynamic modeling of converting copper-nickel matte (11.3 wt.% Ni + Cu + + Co, 61.5 wt.% Fe, 25.9 wt.% S) produced by joint smelting of oxidized nickel ore and sulfide copper ore. Calculations were made in the approximation of ideal molecular solutions using the HSC Chemistry software package (Outotec Research Oy, Finland). The possibility of low-iron matte, converter slag and gas phase separation was shown. Estimated conditional equilibrium constants of exchange reactions between low-iron matte and slag (KNi/Fe = 0.004÷0.005, KCo/Fe = 0.056÷0.099) are close to ideal values. Statistical data processing was carried out using the mathematical experiment planning method. The converting temperature (t = 1100÷1300 °C) and iron and sulfur oxidation completeness level (q = 0.9÷1.0) determining the air and flux (SiO2) consumption were chosen as the factors to study. Obtained mathematical models of the process were used for its optimization. It was shown that the best converting performance can be achieved at t = 1150 °С and q = 0.950 when the low-iron matte contains 70.7 wt.% Ni + Cu + Co. At a yield of 8.74 % of the charge mass, the nickel, copper and cobalt recovery rates are 67.9, 97.9 and 9.1 %, respectively. The supposed air consumption (145.1 m3 (under normal conditions) per 100 kg of matte) and SiO2 (34.4 kg per 100 kg of matte) as well as slag yield (89.1 % of the charge mass) are close to working regime parameters. The results of the study confirm the possibility of cost-effective processing of poor copper-nickel matte and after experimental verification they can be used to develop automation flowcharts for converter departments at existing and designed production facilities.	\N	Izvestiya Vuzov. Tsvetnaya Metallurgiya (Universities' Proceedings Non-Ferrous Metallurgy)	\N	\N	2022	28	6	12-21	10.17073/0021-3438-2022-6-12-21	\N	\N	https://doi.org/10.17073/0021-3438-2022-6-12-21	Klyushnikov A. M., Maltsev G. I.. (2022). Optimization of converting process for matte of oxidized nickel ores and sulfide copper ores joint smelting based on thermodynamic simulation. Izvestiya Vuzov. Tsvetnaya Metallurgiya (Universities' Proceedings Non-Ferrous Metallurgy). 28(6). 12-21. https://doi.org/10.17073/0021-3438-2022-6-12-21.	en	public	published	f	2026-07-28 10:26:06.679877+08	crossref_import	2026-07-28 10:26:06.679877+08	2026-07-28 10:26:06.679877+08	\N	\N	\N	\N
163	3	LIT-000163	汽车冲压模具设计制造与维修研究	\N	paper	随着全球汽车产业的快速发展和制造技术的不断进步，汽车冲压模具作为汽车车身及结构件成形的关键 工艺装备，其设计、制造与维修水平直接影响整车的质量、成本与生产效率。本文系统分析了现代冲压模具在设计阶 段所采用的先进理念与关键技术，包括模块化设计、CAE仿真优化、材料选择策略等；详细探讨了高精度制造过程中 涉及的数控加工、电火花加工、表面处理等核心工艺及其质量控制要点；同时，针对模具在使用过程中常见的失效形 式（如磨损、开裂、变形等），提出了科学有效的维修策略与预防性维护体系。最后，结合智能制造与数字孪生等新 兴技术趋势，展望了未来汽车冲压模具全生命周期管理的发展方向。本研究旨在为提升我国汽车冲压模具产业的核心 竞争力提供理论支撑与实践指导。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0808-72	\N	\N	https://doi.org/10.37155/2717-5197-0808-72	张玲玲, 毅 王, 程阿苗. (2026). 汽车冲压模具设计制造与维修研究. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0808-72.	en	public	published	f	2026-07-30 16:18:37.118307+08	openalex_import	2026-07-30 16:18:37.118307+08	2026-07-30 16:18:37.118307+08	\N	\N	\N	\N
547	5	LIT-000547	Hydrometallurgical Recovery of Metals from Large Printed Circuit Board Pieces	\N	paper	The recovery of precious metals from waste printed circuit boards (PCBs) is an effective recycling process. This paper presents a promising hydrometallurgical process to recover precious metals from waste PCBs. To simplify the metal leaching process, large pieces of PCBs were used instead of a pulverized sample. The chemical coating present on the PCBs was removed by sodium hydroxide (NaOH) treatment prior to the hydrometallurgical treatment. Among the leaching reagents examined, hydrochloric acid (HCl) showed great potential for the recovery of metals. The HCl-mediated leaching of waste PCBs was investigated over a range of conditions. Increasing the acid concentration decreased the time required for complete metal recovery. The shaking speed showed a pronounced positive effect on metal recovery, but the temperature showed an insignificant effect. The results showed that 1 M HCl recovered all of the metals from 4 cm × 4 cm PCBs at room temperature and 150 rpm shaking speed in 22 h.	\N	Scientific Reports	\N	\N	2015	5	1	14574-14574	10.1038/srep14574	\N	\N	https://doi.org/10.1038/srep14574	Umesh Jadhav, H. Hocheng. (2015). Hydrometallurgical Recovery of Metals from Large Printed Circuit Board Pieces. Scientific Reports. https://doi.org/10.1038/srep14574	en	public	published	t	2026-08-17 11:35:14.269532+08	openalex_oa_curated	2026-08-17 11:35:14.269532+08	2026-08-17 11:35:14.269532+08	\N	\N	\N	\N
548	5	LIT-000548	Aqueous rechargeable zinc/sodium vanadate batteries with enhanced performance from simultaneous insertion of dual carriers	\N	paper	Abstract Rechargeable aqueous zinc-ion batteries are promising energy storage devices due to their high safety and low cost. However, they remain in their infancy because of the limited choice of positive electrodes with high capacity and satisfactory cycling performance. Furthermore, their energy storage mechanisms are not well established yet. Here we report a highly reversible zinc/sodium vanadate system, where sodium vanadate hydrate nanobelts serve as positive electrode and zinc sulfate aqueous solution with sodium sulfate additive is used as electrolyte. Different from conventional energy release/storage in zinc-ion batteries with only zinc-ion insertion/extraction, zinc/sodium vanadate hydrate batteries possess a simultaneous proton, and zinc-ion insertion/extraction process that is mainly responsible for their excellent performance, such as a high reversible capacity of 380 mAh g –1 and capacity retention of 82% over 1000 cycles. Moreover, the quasi-solid-state zinc/sodium vanadate hydrate battery is also a good candidate for flexible energy storage device.	\N	Nature Communications	\N	\N	2018	9	1	1656-1656	10.1038/s41467-018-04060-8	\N	\N	https://doi.org/10.1038/s41467-018-04060-8	Fang Wan, Linlin Zhang, Xi Dai, Xinyu Wang, Zhiqiang Niu, Jun Chen. (2018). Aqueous rechargeable zinc/sodium vanadate batteries with enhanced performance from simultaneous insertion of dual carriers. Nature Communications. https://doi.org/10.1038/s41467-018-04060-8	en	public	published	t	2026-08-17 11:35:14.274031+08	openalex_oa_curated	2026-08-17 11:35:14.274031+08	2026-08-17 11:35:14.274031+08	\N	\N	\N	\N
549	5	LIT-000549	Recovery of platinum group metals from spent automotive converters by leaching with organic and inorganic acids and extraction with quaternary phosphonium salts	\N	paper	The paper presents studies on the application of hydrometallurgical recovery of platinum group metals (PGM) from spent automotive converters (SAC), which is not only commercially viable but also important from an ecological perspective. The work proposes an integrated four-stage process, which includes: leaching with oxalic or lactic acids, then leaching with mineral acids from catalyst left after the first stage and next extraction of PGM with phosphonium or ammonium salts: Cyphos IL 101 (trihexyl(tetradecyl)phosphonium chloride), Cyphos IL 104 (trihexyl(tetradecyl)phosphonium bis(2,4,4-trimethylpentyl)phosphinate), and in the final stage, stripping with 0.1 M thiourea in 0.5 M HCl and 3 M HNO3 to recover PGM. The use of carboxylic acids in the first step of leaching reduces the amount of non-precious metals (Fe ions, Mg(II), Zn(II)) leached in the second stage. The highest concentration of the leached Al(III), Fe ions, Mg(II) and Zn(II) was 600, 25, 110 and 45 mg/dm3. To leach PGM from SAC, it was necessary to use stronger acidic solutions (e.g. a mixture of inorganic acids with an oxidant). The concentrations of Pt(IV), Pd(II), Rh(III) in the solutions after the second step of leaching were 34–40, about 3, 4.5–5 mg/dm3, respectively. After two stages of extraction, Rh(III) and Al(III) are left in the raffinate, therefore Pt(IV) and Pd(II) can be separated from Rh(III). Afterward, Pd(II) and Pt(IV) extracted to the organic phases can be separated in the first stage of stripping.	\N	Separation and Purification Technology	\N	\N	2021	280	\N	119933-119933	10.1016/j.seppur.2021.119933	\N	\N	https://doi.org/10.1016/j.seppur.2021.119933	Zuzanna Wiecka, Martyna Rzelewska-Piekut, Magdalena Regel‐Rosocka. (2021). Recovery of platinum group metals from spent automotive converters by leaching with organic and inorganic acids and extraction with quaternary phosphonium salts. Separation and Purification Technology. https://doi.org/10.1016/j.seppur.2021.119933	en	public	published	t	2026-08-17 11:35:14.279901+08	openalex_oa_curated	2026-08-17 11:35:14.279901+08	2026-08-17 11:35:14.279901+08	\N	\N	\N	\N
571	5	LIT-000571	The green hydrogen ambition and implementation gap	\N	paper	Abstract Green hydrogen is critical for decarbonizing hard-to-electrify sectors, but it faces high costs and investment risks. Here we define and quantify the green hydrogen ambition and implementation gap, showing that meeting hydrogen expectations will remain challenging despite surging announcements of projects and subsidies. Tracking 190 projects over 3 years, we identify a wide 2023 implementation gap with only 7% of global capacity announcements finished on schedule. In contrast, the 2030 ambition gap towards 1.5 °C scenarios has been gradually closing as the announced project pipeline has nearly tripled to 422 GW within 3 years. However, we estimate that, without carbon pricing, realizing all these projects would require global subsidies of US$1.3 trillion (US$0.8–2.6 trillion range), far exceeding announced subsidies. Given past and future implementation gaps, policymakers must prepare for prolonged green hydrogen scarcity. Policy support needs to secure hydrogen investments, but should focus on applications where hydrogen is indispensable.	\N	Nature Energy	\N	\N	2025	10	1	110-123	10.1038/s41560-024-01684-7	\N	\N	https://doi.org/10.1038/s41560-024-01684-7	Adrian Odenweller, Falko Ueckerdt. (2025). The green hydrogen ambition and implementation gap. Nature Energy. https://doi.org/10.1038/s41560-024-01684-7	en	public	published	t	2026-08-17 11:35:16.92593+08	openalex_oa_curated	2026-08-17 11:35:16.92593+08	2026-08-17 11:35:16.92593+08	\N	\N	\N	\N
102	2	LIT-000102	The-state-Art of steelmaking technology based on hydrogen metallurgy	\N	paper	This paper puts forward the viewpoint that “hydrogen steelmaking” replaces “oxygen steelmaking”, and summarizes and evaluates the research status of “hydrogen steelmaking”. Hydrogen metallurgy steelmaking has unique advantages in energy saving, consumption reduction and product quality improvement. On the one hand, hydrogen has a highly efficient melting effect, which can effectively reduce the energy consumption of steelmaking. “Hydrogen” in plasma state has the characteristics of high temperature and high thermal conductivity, which can be used as a highly efficient heat source to realize the melting of charge and heating of steel, and has been applied in steelmaking processes such as EAF, converter and tundish. Blowing gaseous “Hydrogen” can accelerate the homogenization in the composition and temperature, and the movement of hydrogen bubbles can be adhered to the non-metallic inclusions which can be accelerated to float out. At the same time, hydrogen reacts with oxygen in the liquid steel to release a large amount of heat, which improves the thermodynamic and kinetic conditions of the melt pool reaction. In addition, “Hydrogen” can inhibit oxidation and reduce the loss of Cr, Mn and other alloying elements by creating a reducing atmosphere. On the other hand, “Hydrogen” has a non-polluting refining effect that significantly improves the cleanliness of the steel. Based on the high activity and high reducibility of “Hydrogen”, “Hydrogen” can effectively remove impurity elements such as O, C, N, S and P in steel, especially “Hydrogen” in plasma state, which can directly react with the impurity elements to generate H2O, CH4, NH3, H2S and PH3 and other gaseous products that are easy to be volatilized and removed, so as to avoid the formation of non-metallic inclusions, and to realize the highly efficient and high-cleanliness steelmaking with “zero inclusions”. Therefore, the development of a new generation of green, near-zero carbon, “zero inclusion” and pollution-free steelmaking process using “hydrogen” instead of “carbon” will accelerate the green, high-quality, and sustainable development of the steel industry.	\N	Theory and Practice of Metallurgy	\N	\N	2025	\N	1	16-30	10.15802/tpm.1.2025.03	\N	\N	https://doi.org/10.15802/tpm.1.2025.03	Jiang ZhouHua, Yang Ce, Zhu HongChun, Lu HongBin. (2025). The-state-Art of steelmaking technology based on hydrogen metallurgy. Theory and Practice of Metallurgy. 1). 16-30. https://doi.org/10.15802/tpm.1.2025.03.	en	public	published	f	2026-07-28 10:26:07.89892+08	crossref_import	2026-07-28 10:26:07.89892+08	2026-07-28 10:26:07.89892+08	\N	\N	\N	\N
105	2	LIT-000105	The road to carbon neutrality in the metallurgical industry: Hydrogen metallurgy processes represented by hydrogen-rich coke oven gas, short-process metallurgy of scrap and low-carbon policy	\N	paper	Abstract\n               With the acceleration of global industrialization, the concentration of carbon dioxide is increasing in the atmosphere, and its negative impacts have seriously affected all walks of human life, so achieving carbon neutrality has become an urgent task for achieving sustainable development. As an important energy-intensive industry, the metallurgical industry occupies an important position in the global carbon-neutral agenda. In China, the metallurgical industry is actively researching and developing a new green metallurgical model of “replacing carbon with hydrogen”, exploring the feasibility of utilizing renewable energy sources to produce hydrogen from electrolysis to reduce iron ore, and at the same time utilizing hydrogen-rich coke oven gas to get rid of the over-reliance on coke; at the same time, the government’s policies provide support and incentives to elevate sustainable development and technological innovation in the metallurgical industry. support and incentives to elevate sustainable development and technological innovation in the metallurgical industry. Against this background, this paper describes the key initiatives taken by the metallurgical industry in the process of achieving carbon neutrality, including the metallurgy using hydrogen processes using hydrogen-rich coke oven gas as a source of reducing gas, short-process metallurgy of scrap, and technology that reduce emissions and save energy. Through case studies and policy analyses of new green metallurgy, this study demonstrates the potential and achievements of the metallurgical industry in achieving global carbon neutrality. It concludes with a call for the metallurgical industry to continue to strengthen innovation and work with governments and academia to pave the way toward carbon neutrality. Through new metallurgical technologies, improved energy and resource efficiency, and sustainable development, the metallurgical industry will make a significant contribution to the goal of global carbon neutrality.	\N	Journal of Physics: Conference Series	\N	\N	2024	2798	1	012053	10.1088/1742-6596/2798/1/012053	\N	\N	https://doi.org/10.1088/1742-6596/2798/1/012053	Guo Yuanchang, Wang Xinyi, Deng Kangze. (2024). The road to carbon neutrality in the metallurgical industry: Hydrogen metallurgy processes represented by hydrogen-rich coke oven gas, short-process metallurgy of scrap and low-carbon policy. Journal of Physics: Conference Series. 2798(1). 012053. https://doi.org/10.1088/1742-6596/2798/1/012053.	en	public	published	f	2026-07-28 10:26:07.924798+08	crossref_import	2026-07-28 10:26:07.924798+08	2026-07-28 10:26:07.924798+08	\N	\N	\N	\N
106	2	LIT-000106	Changes in Hydrogen Content During Steelmaking	\N	paper	Abstract\nŠtore Steel produces steel grades for spring, forging and engineering industry applications. Steelmaking technology consists of scrap melting in Electric Arc Furnace (EAF), secondary metallurgy in Ladle Furnace (LF) and continuous casting of billets (CC). Hydrogen content during steelmaking of various steel grades and steelmaking technologies was measured. Samples of steel melt from EAF, LF and CC were collected and investigated. Sampling from Electric Arc Furnace and Ladle Furnace was carried out using vacuum pin tubes. Regular measurements of hydrogen content in steel melt were made using Hydris device. Hydrogen content results measured in tundish by Hydris device were compared with results from pin tube samples. Based on the measurement results it was established that hydrogen content during steelmaking increases. The highest values were determined in tundish during casting. Factors that influence the hydrogen content in liquid steel the most were steelmaking technology and alloying elements.	\N	Archives of Metallurgy and Materials	\N	\N	2015	60	1	295-299	10.1515/amm-2015-0047	\N	\N	https://doi.org/10.1515/amm-2015-0047	Vrbek K., Lamut J., Marolt M., Knap M.. (2015). Changes in Hydrogen Content During Steelmaking. Archives of Metallurgy and Materials. 60(1). 295-299. https://doi.org/10.1515/amm-2015-0047.	en	public	published	f	2026-07-28 10:26:07.933921+08	crossref_import	2026-07-28 10:26:07.933921+08	2026-07-28 10:26:07.933921+08	\N	\N	\N	\N
108	2	LIT-000108	Advanced Processing Techniques and Impurity Management for High-Purity Quartz in Diverse Industrial Applications	\N	paper	While numerous studies have explored the mineralogical characteristics and purification techniques of high-purity quartz (HPQ), discussions on impurity control during various purification processes and their applications in photovoltaics, electronics, and optics remain limited. This review delves into the adverse effects of impurities such as aluminum, iron, and sodium in the manufacturing processes of these industries, emphasizing their critical role as these impurities can degrade material performance. This paper focuses on analyzing the types of impurities found in quartz and evaluates existing purification technologies such as acid washing, ultrasonic acid washing, chlorination roasting, and calcination quenching. It highlights the limitations of current technologies in processing quartz ore and discusses the advantages of different impurity types under various technological treatments. Moreover, it explores the environmental and economic impacts of these high-purity processes, underlining the necessity for more environmentally friendly and cost-effective purification techniques. The purpose of this review is to provide a comprehensive technical and strategic framework for the use of high-purity quartz in high-tech applications, supporting future research and industrial applications in this critical material field.	\N	Minerals	\N	\N	2024	14	6	571	10.3390/min14060571	\N	\N	https://doi.org/10.3390/min14060571	Long Hailin, Zhu Deqing, Pan Jian, Li Siwei, Yang Congcong, Guo Zhengqi. (2024). Advanced Processing Techniques and Impurity Management for High-Purity Quartz in Diverse Industrial Applications. Minerals. 14(6). 571. https://doi.org/10.3390/min14060571.	en	public	published	f	2026-07-28 10:26:07.948039+08	crossref_import	2026-07-28 10:26:07.948039+08	2026-07-28 10:26:07.948039+08	\N	\N	\N	\N
171	3	LIT-000171	西藏罗布莎-香卡山-康金拉矿集区铬铁矿找矿突破及其启示	\N	paper	铬铁矿是我国紧缺战略性矿产资源,也是找矿难度最大的矿种之一,罗布莎-香卡山-康金拉是国内唯一大型及在产铬铁矿矿山,其深边部的找矿突破对于铬铁矿资源安全保障具有重要意义。"十四五"以来,随着新一轮找矿突破战略行动的深入实施,通过央-地-企协调联动与持续加大勘查投入,该矿集区取得了重大找矿进展,新增铬铁矿资源量70多万吨,有力支撑了国内铬铁矿找矿目标的实现。本文系统梳理了该矿集区的地质概况、矿体特征、勘查历史,重点报道了在罗布莎岩体内取得"四新"突破,新矿体显示以往大型矿体的旁侧仍有较大找矿潜力,新深度的突破极大拓展了罗布莎岩体深部找矿空间,新类型的发现说明北部纯橄岩相带的找矿需要加强,新地区进一步证实在岩体广阔覆盖区以下找矿的重要性。进一步总结该类型矿床的找矿标志表明,矿体严格受罗布莎岩体内部含矿构造岩相带控制,呈"成带分布、成群出现、分段集中"的规律展布;特定的岩相-岩性-构造耦合是找矿突破的关键,其中纯橄岩岩相带以下100~800m范围为最佳找矿空间,矿体在平面上呈雁行状展布、剖面上呈叠瓦状排列;浸染状矿体作为新的工业矿化类型,其找寻是未来深边部找矿的重要突破方向。研究认为,罗布莎岩体深边部仍具备较大的找矿潜力,未来应持续加大勘查投入,深化"攻深找盲"工作;同时,应系统总结该矿集区成矿规律与勘查经验,指导雅鲁藏布江缝合带乃至青藏高原其他地区同类型铬铁矿床的找矿部署,为我国铬铁矿资源安全保障提供持续的理论支撑与实践依据。	\N	Acta Petrologica Sinica	\N	\N	2026	\N	\N	\N	10.18654/1000-0569/2026.08.02	\N	\N	https://doi.org/10.18654/1000-0569/2026.08.02	Chen Hh, Luo CI, Zhang Xiaofei, WANG JunLu, Bing YU, HaiYong WANG, PingCuo SUOLANG, HongLi SU, Kang HUA, 庞振山, 3. 新疆维吾尔自治区地质局哈密地质大队, 哈密 839000,3. Hami Geological Team of Xinjiang Geological Bureau, Hami 839000, China, 6. 西藏自治区地质矿产勘查开发局第二地质大队, 拉萨 851400,6. No. 2 Geological Party, Tibet Bureau of Geological Exploration and Exploitation of Mineral Resources, Tibet 851400, China. (2026). 西藏罗布莎-香卡山-康金拉矿集区铬铁矿找矿突破及其启示. Acta Petrologica Sinica. https://doi.org/10.18654/1000-0569/2026.08.02.	en	public	published	f	2026-07-30 16:18:37.148603+08	openalex_import	2026-07-30 16:18:37.148603+08	2026-07-30 16:18:37.148603+08	\N	\N	\N	\N
115	2	LIT-000115	Green Hydrogen‐Based Direct Reduction for Low‐Carbon Steelmaking	\N	paper	The European steel industry aims at a CO2 reduction of 80–95% by 2050, ensuring that Europe will meet the requirements of the Paris Agreement. As the reduction potentials of the current steelmaking routes are low, the transfer toward breakthrough‐technologies is essential to reach these goals. Hydrogen‐based steelmaking is one approach to realize CO2‐lean steelmaking. Therefore, the natural gas (NG)‐based direct reduction (DR) acts as a basis for the first step of this transition. The high flexibility of this route allows the gradual addition of hydrogen and, in a long‐term view, runs the process with pure hydrogen. Model‐based calculations are performed to assess the possibilities for injecting hydrogen. Therefore, NG‐ and hydrogen‐based DR models are developed to create new process know‐how and enable an evaluation of these processes in terms of energy demand, CO2‐reduction potentials, and so on. The examinations show that the hydrogen‐based route offers a huge potential for green steelmaking which is strongly depending on the carbon footprint of the electricity used for the production of hydrogen. Only if the carbon intensity is less than about 120 g CO2 kWh−1, the hydrogen‐based process emits less CO2 than the NG‐based DR process.	\N	steel research international	\N	\N	2020	91	11	\N	10.1002/srin.202000110	\N	\N	https://doi.org/10.1002/srin.202000110	Rechberger Katharina, Spanlang Andreas, Sasiain Conde Amaia, Wolfmeir Hermann, Harris Christopher. (2020). Green Hydrogen‐Based Direct Reduction for Low‐Carbon Steelmaking. steel research international. 91(11). https://doi.org/10.1002/srin.202000110.	en	public	published	f	2026-07-28 10:26:08.027466+08	crossref_import	2026-07-28 10:26:08.027466+08	2026-07-28 10:26:08.027466+08	\N	\N	\N	\N
172	3	LIT-000172	冶金机械自动化校准的溯源性体系构建研究	\N	paper	1. 来稿要真实性、科学性和科学性，资料可靠真实，数据准确详实，逻辑严密、文字精炼。 2. 来稿文责自负。所有作者应对稿件内容和署名无异议，稿件内容不得抄袭或重复发表。 3. 文章题目要简短精炼，准确概括文章中心内容，不超过20字。各级标题的编码方法为：第一级标题用一、二、三……依次编码；第二级用标题（一）（二）（三）……依次编码；第三级用1，2，3……依次编码。示例如下： 一、第一级标题 （一）第二级标题 （二）第二级标题 1. 第三级标题 2. 第三级标题 二、第一级标题 4. 来稿必须附有100-250字的摘要，一般应包括：目的、方法、结果和结论。需提供3-5个关键词，用分号隔开。 5. 英文标题、摘要、关键词及作者单位务必附在标题页。 6. 来稿必须附有第一作者和通讯作者的简介，包括真实姓名、出生年月、性别、民族、籍贯、工作单位、职务、职称、学位、研究方向等（研究生须注明博士研究生或硕士研究生）；其他作者附真实姓名、工作单位、职务、职称、邮编等。 7. 已被录用稿件原则上不允许更改作者顺序，或增删作者等。 8. 来稿正文字数一般以3000-6000字为宜 （不包括题目、作者信息、图表、参考文献）。 9. 文章格式一般包括：题目、作者及单位、通讯作者地址、邮编、内容摘要、关键词、正文、参考文献等。 10. 参考文献格式采用顺序编码制，请按文中出现的先后顺序编号；在文中引文出现的地方以阿拉伯数字按序编码并用方括号括起来上标；在文末列出参考文献需与正文中的标注序号一一对应。参考文献不少于8条。 1）著作类：[序号]作者．书名[M]．出版地：出版社，出版年，页码． 2）报纸、期刊论文类：[序号]作者．文章题目．报纸名/刊名[N/J]．年代（期、版次）：起止页码． 3）电子文献：[序号]作者．电子文献题目[EB/OL]．电子文献出处或可获得地址，发表日期/引用日期． 4）学位论文：[序号]作者．论文题目[D]：[硕士或博士学位论文]．保存地：保存单位，年份． 5）论文集中的析出文献：[序号]析出文献作者．析出文献题名[A]．原文献作者．原文献题名[C]．出版地：出版者，出版年．析出文献起止页码． 6）专利：[序号]专利申请者．专利名称[P]．国别，专利号．出版日期． 7）技术标准：[序号]起草责任者．标准编号．标准名称[S]．出版地： 出版社，出版年． 11. 参考文献中的标点符号以英文半角符号书写，字体请用Times New Roman。各类参考文献的标识符号是：专著[M]、论文集[C]、期刊文章[J]、报纸文章[N]、学位论文[D]、报告[R]、标准[S]、专利[P]、论文集中的析出文献[A]、各种未定义的文献[Z]。 12. 图表要求：文中表格建议采用三线表，表名置于表上方居中；文中图像要清晰可编辑，将图名置于图下方居中；图表如使用缩略语，需在图表注中说明。图表编号一律用阿拉伯数字，图表标号依次排列，如表1、表2、表3，图1、图2、图3。 13. 计量单位请参照中华人民共和国法定计量单位最新标准。外文字符必须分清大、小写，正、斜体，黑、白体，上下角标应区别明显（必要时可旁注说明）。 14. 缩略词在文中第一次出现时应给予明确定义。中英文缩略词都应在全文中统一。 15. 稿件必须采用Word格式随邮件的附件发送或在线提交稿件。 16. 来稿请注明通讯作者的详细联系地址、邮编、邮箱、联系电话。 17. 来稿如为研究课题或课题/项目/基金支持论文，请注明课题名称、审批机关、基金项目名称、年度及其项目编号。多项基金项目应依次列出，其间以分号“；”隔开。 18. 编辑部对来稿有删修权，不同意删修的稿件请在来稿中声明。 19. 所有来稿均不退，请作者自留底稿。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0805-15	\N	\N	https://doi.org/10.37155/2717-5197-0805-15	姜新军, Guo Wei, 魏铁龙. (2026). 冶金机械自动化校准的溯源性体系构建研究. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0805-15.	en	public	published	f	2026-07-30 16:18:37.15678+08	openalex_import	2026-07-30 16:18:37.15678+08	2026-07-30 16:18:37.15678+08	\N	\N	\N	\N
224	3	LIT-000224	基于生命周期理论的水利工程施工期碳排放核算方法与应用	\N	paper	随着水利建设规模扩大，碳排放管理成为关键。本文聚焦水利工程施工阶段碳排放问题，深入剖析其碳 排放主要来源，涵盖材料生产与运输、施工机械使用以及施工人员生活耗能等方面。详细阐述碳排放核算模型的构建 过程，包括明确核算边界、精准采集数据、合理选择计算方法等关键步骤。同时，有针对性地提出一系列减排策略， 如优化材料选择与运输方式、选用高效施工机械、强化能源管理以及推广绿色施工技术等，旨在为水利工程施工阶段 的碳排放核算与减排提供科学依据和有效指导，助力水利工程实现绿色可持续发展。	\N	工程施工新技术	\N	\N	2026	\N	\N	\N	10.37155/2811-0609-0508-36	\N	\N	https://doi.org/10.37155/2811-0609-0508-36	黄婵婵. (2026). 基于生命周期理论的水利工程施工期碳排放核算方法与应用. 工程施工新技术. https://doi.org/10.37155/2811-0609-0508-36.	en	public	published	f	2026-07-30 16:19:09.348087+08	openalex_import	2026-07-30 16:19:09.348087+08	2026-07-30 16:19:09.348087+08	\N	\N	\N	\N
554	5	LIT-000554	Ionic Liquids as Components of Systems for Metal Extraction	\N	paper	This review addresses research and development on the use of ionic liquids as extractants and diluents in the solvent extraction of metals. Primary attention is given to the efficiency and selectivity of metal extraction from industrial wastewater with ionic liquids composed of various cations and anions. The review covers literature sources published in the period of 2010–2021. The bibliography includes 98 references dedicated to research on the extraction and separation of lanthanides (17 sources), actinides (5 sources), heavy metals (35 sources), noble metals, including the platinum group (16 sources), and some other metals.	\N	ChemEngineering	\N	\N	2022	6	1	6-6	10.3390/chemengineering6010006	\N	\N	https://doi.org/10.3390/chemengineering6010006	Pavel Yudaev, Evgeniy M. Chistyakov. (2022). Ionic Liquids as Components of Systems for Metal Extraction. ChemEngineering. https://doi.org/10.3390/chemengineering6010006	en	public	published	t	2026-08-17 11:35:14.307923+08	openalex_oa_curated	2026-08-17 11:35:14.307923+08	2026-08-17 11:35:14.307923+08	\N	\N	\N	\N
555	5	LIT-000555	Sequential Bioleaching of Pyritic Tailings and Ferric Leaching of Nonferrous Slags as a Method for Metal Recovery from Mining and Metallurgical Wastes	\N	paper	In this work, we proposed a method for biohydrometallurgical processing of mining (old pyritic flotation tailings) and metallurgical (slag) wastes to recover gold and other nonferrous metals. Since this processing allows the removal of toxic metals or at least decreases their content in the solids, this approach may reduce the negative environmental impacts of such waste. The proposed process was based on pyritic tailings’ bioleaching to recover metals and produce leach liquor containing a strong oxidizing agent (ferric sulfate) to dissolve nonferrous metal from slag. This approach also allows us to increase concentrations of nonferrous metals in the pregnant leach solution after pyritic waste bioleaching to allow efficient extraction. The old pyritic tailings were previously leached with 0.25% sulfuric acid for 10 min to remove soluble metal sulfates. As a result, 36% of copper and 35% of zinc were extracted. After 12 days of bioleaching with a microbial consortium containing Leptospirillum spp., Sulfobacillus spp., Ferroplasma spp., and Acidithiobacillus spp. at 35 °C, the total recovery of metals from pyritic tailings reached 68% for copper and 77% for zinc; and subsequent cyanidation allowed 92% recovery of gold. Ferric leaching of two types of slag at 70 °C with the leachate obtained during bioleaching of the tailings and containing 15 g/L of Fe3+ allowed 88.9 and 43.4% recovery of copper and zinc, respectively, from copper slag within 150 min. Meanwhile, 91.5% of copper, 84.1% of nickel, and 70.2% of cobalt were extracted from copper–nickel slag within 120 min under the same conditions.	\N	Minerals	\N	\N	2020	10	12	1097-1097	10.3390/min10121097	\N	\N	https://doi.org/10.3390/min10121097	Н. В. Фомченко, Maxim Muravyov. (2020). Sequential Bioleaching of Pyritic Tailings and Ferric Leaching of Nonferrous Slags as a Method for Metal Recovery from Mining and Metallurgical Wastes. Minerals. https://doi.org/10.3390/min10121097	en	public	published	t	2026-08-17 11:35:14.311855+08	openalex_oa_curated	2026-08-17 11:35:14.311855+08	2026-08-17 11:35:14.311855+08	\N	\N	\N	\N
556	5	LIT-000556	Mechanical and hydrometallurgical processes in HCl media for the recycling of valuable metals from Li-ion battery waste	\N	paper	The present work offers a study on the engineering implications of the recovery of valuable fractions from industrially collected lithium battery (LIB) waste by mechanical and hydrometallurgical processes in HCl media. Direct leaching of LIB waste provides a possibility for Li extraction, a component that is lost into the slag fraction in the state-of-art high temperature processes. The challenges arising from the heterogeneous composition of industrial battery waste are highlighted, and the behavior of main metals present such as Co, Cu, Li, Mn, Ni and Al is observed. It is shown that mechanical separation processes can form fractions rich on Cu and Al, although subsequent refining stages are necessary. Regarding direct leaching, fast kinetics were found, as complete Li dissolution can be achieved in ca. 120 min. Furthermore, high solid/liquid ratio (>1/10) is required to increase metal value concentrations, resulting in a viscous slurry due to the graphite, plastics and other undissolved materials, which challenges filtration and washing of leach residue. Neutralization of the product liquid solution (PLS) result in co-precipitation of valuable battery metals along with Fe and Al. The highest value of LIBs lies in Co, subjected for solvent extraction (SX) or direct precipitation to make an intermediate product. SX can provide selectivity whereas Na 2 CO 3 precipitation provides a fast route for Co-Ni bulk production. Li 2 CO 3 precipitation from the remaining PLS is possible as zabuyelite - however, due to heterogeneity of the battery waste, the recovery of Li 2 CO 3 with battery-grade purity remains a difficult task to be achieved by direct precipitation route.	\N	Resources Conservation and Recycling	\N	\N	2018	142	\N	257-266	10.1016/j.resconrec.2018.11.023	\N	\N	https://doi.org/10.1016/j.resconrec.2018.11.023	Antti Porvali, Miamari Aaltonen, Severi Ojanen, Omar Velázquez-Martínez, Emmi Eronen, Fupeng Liu, Benjamin P. Wilson, Rodrigo Serna-Guerrero, Mari Lundström. (2018). Mechanical and hydrometallurgical processes in HCl media for the recycling of valuable metals from Li-ion battery waste. Resources Conservation and Recycling. https://doi.org/10.1016/j.resconrec.2018.11.023	en	public	published	t	2026-08-17 11:35:14.317696+08	openalex_oa_curated	2026-08-17 11:35:14.317696+08	2026-08-17 11:35:14.317696+08	\N	\N	\N	\N
577	5	LIT-000577	Circular Steel for Fast Decarbonization: Thermodynamics, Kinetics, and Microstructure Behind Upcycling Scrap into High-Performance Sheet Steel	\N	paper	Steel production accounts for approximately 8% of all global CO 2 emissions, with the primary steelmaking route using iron ores contributing approximately 80% of those emissions, mainly due to the use of fossil-based reductants and fuel. Hydrogen-based reduction of iron oxide is an alternative for primary synthesis. However, to counteract global warming, decarbonization of the steel sector must proceed much faster than the ongoing transition kinetics in primary steelmaking. Insufficient supply of green hydrogen is a particular bottleneck. Realizing a higher fraction of secondary steelmaking is thus gaining momentum as a sustainable alternative to primary production. Steel production from scrap is well established for long products (rails, bars, wire), but there are two main challenges. First, there is not sufficient scrap available to satisfy market needs. Today, only one-third of global steel demand can be met by secondary metallurgy using scrap since many steel products have a lifetime of several decades. However, scrap availability will increase to about two-thirds of total demand by 2050 such that this sector will grow massively in the next decades. Second, scrap is often too contaminated to produce high-performance sheet steels. This is a serious obstacle because advanced products demand explicit low-tolerance specifications for safety-critical and high-strength steels, such as for electric vehicles, energy conversion and grids, high-speed trains, sustainable buildings, and infrastructure. Therefore, we review the metallurgical and microstructural challenges and opportunities for producing high-performance sheet steels via secondary synthesis. Focus is placed on the thermodynamic, kinetic, chemical, and microstructural fundamentals as well as the effects of scrap-related impurities on steel properties.	\N	Annual Review of Materials Research	\N	\N	2024	54	1	247-297	10.1146/annurev-matsci-080222-123648	\N	\N	https://doi.org/10.1146/annurev-matsci-080222-123648	Dierk Raabe, Matic Jovičević‐Klug, Dirk Ponge, Alexander Gramlich, Alisson Kwiatkowski da Silva, A. Nicholas Grundy, Hauke Springer, Isnaldi Rodrigues de Souza Filho, Yan Ma. (2024). Circular Steel for Fast Decarbonization: Thermodynamics, Kinetics, and Microstructure Behind Upcycling Scrap into High-Performance Sheet Steel. Annual Review of Materials Research. https://doi.org/10.1146/annurev-matsci-080222-123648	en	public	published	t	2026-08-17 11:35:16.961498+08	openalex_oa_curated	2026-08-17 11:35:16.961498+08	2026-08-17 11:35:16.961498+08	\N	\N	\N	\N
232	3	LIT-000232	Differences in aggregation effect and heavy metal activity in rare earth mining soil under different sludge application	\N	paper	摘 要：【目的】筛选用于改良稀土矿迹地土壤结构的高效且低风险的城市污泥施用方法。【方法】通过污泥形态（100%干污泥、100%湿污泥和50%干污泥+50%湿污泥）、水分添加量（体积比15%、20%和25%）、污泥施用量（体积比10%、20%和30%）和培养时间（30d、60d和90d）4种因素的L9（34）正交设计，以纯矿土培养为对照（CK），开展不同条件下污泥与稀土矿迹地土壤混合的分层培养实验，分析不同条件下添加污泥对土壤团聚效果及重金属活性的影响差异。【结果】混合污泥培养后，上层干筛和湿筛>2 mm的宏团聚体占比分别为23.93%~37.53%和15.28%~25.80%，与CK相比分别显著增加了60.76%~157.94%和120.17%~271.76%，干湿筛土壤平均重量直径（MWD）分别显著提升了10.53%~34.21%和20.48%~55.42%；土壤团聚效果较好的处理是T6（添加30%体积的干湿混合污泥和15%体积的水，培养60d）和T7（添加30%体积的干污泥和25%体积的水，培养90d），二者傅里叶红外光谱特征在3406 cm⁻¹（N-H）、2960~2853 cm⁻¹（脂肪族C-H）、1655 cm⁻¹（C=O）和1384 cm⁻¹（C-H）处与其他处理存在差异；污泥添加使土壤DTPA提取态Cu、Zn和Ni含量升高，但T7处理的重金属含量与纯矿土无显著差异；土壤团聚效果和重金属含量的隶属函数综合排名前三的处理分别为T6、T7、T9（添加10%体积的干湿混合污泥和20%体积的水，培养90d）；主效应分析表明，污泥添加量和培养时间对土壤团聚效果影响显著；污泥形态、水分添加量、污泥施用量和培养时间4种因素对土壤重金属活性都产生显著影响（P<0.05），4种因素联合作用对其方差贡献度达85.3%~98.2%。【结论】污泥配施可促进稀土矿迹地土壤团聚，但团聚效果主要受污泥添加量和培养时间影响。本研究中，按30%体积比添加干污泥和25%体积比添加水并培养90天的污泥配施（T7），可以高效且低重金属风险促进稀土矿采矿迹地土壤团聚。研究结果可为有效改良采矿迹地土壤结构和城市污泥资源化利用提供参考。	\N	ACTA AGRICULTURAE UNIVERSITATIS JIANGXIENSIS	\N	\N	2026	\N	\N	\N	10.3724/aauj.2026099	\N	\N	https://doi.org/10.3724/aauj.2026099	Renrui Xiong, Yuying Wang, Jue Huang, Xiaoquan Dong, Lulu He, Junyi Zhan, Daoming Wu. (2026). Differences in aggregation effect and heavy metal activity in rare earth mining soil under different sludge application. ACTA AGRICULTURAE UNIVERSITATIS JIANGXIENSIS. https://doi.org/10.3724/aauj.2026099.	en	public	published	f	2026-07-30 16:19:09.410639+08	openalex_import	2026-07-30 16:19:09.410639+08	2026-07-30 16:19:09.410639+08	\N	\N	\N	\N
233	3	LIT-000233	Action Plans and Policy Recommendations on Vehicle Grid Integration in China	\N	paper	Assessing the technological and regulatory landscapes within China, this report identifies barriers to scaling up Vehicle Grid Integration (VGI) and offers a potential action plan and corresponding policy recommendations.	\N		\N	\N	2020	\N	\N	\N	10.46830/wrirpt.19.00101	\N	\N	https://doi.org/10.46830/wrirpt.19.00101	Lulu Xue, Liu Jian, Wang Ying, Liu Xiaoshi, Xiong Ying. (2020). Action Plans and Policy Recommendations on Vehicle Grid Integration in China. https://doi.org/10.46830/wrirpt.19.00101.	zh	public	published	f	2026-07-30 16:19:09.432776+08	openalex_import	2026-07-30 16:19:09.432776+08	2026-07-30 16:19:09.432776+08	\N	\N	\N	\N
14	2	LIT-000014	Index	\N	paper	A activities of metals in liquid copper, 77 of metals in liquid iron, 78 Ag-Cu system, 75 CaO-FeO-Fe 2 O 3 slags, 119 CaO-SiO 2 -Al 2 O 3 slag, 112 CaO-SiO 2 -Al 2 O 3 -MgO slag, 114 CaO-SiO 2 -CrO slag, 125 CaO-SiO 2 -FeO slags, 123 Cu-S matte, 95 Cu-Zn system, 75 Fe-Cu system, 79 Fe-Cu-S matte, 98 Fe-Cu-S-O, 104 Fe-Mn system, 79 Fe-Ni-S matte, 98 Fe-S matte, 95 Fe-Si system, 79 Pb-S matte, 95 SiO 2 -FeO-Fe 2 O 3 slags, 117 activity in dilute metal solutions, 26 of a metalloid in metal solutions, 27, 48 of an ion in aqueous solutions, 136 affinity of a reaction, 19, 28 alumina (Al 2 O 3 ) solubility in cryolite (Na 3 AlF 6 ), 177 aluminum sulfate (Al 2 (SO 4 ) 3 ) solubility in aqueous solutions, 167 Arrhenius' law activation energy, 189	A activities of metals in liquid copper, 77 of metals in liquid iron, 78 Ag-Cu system, 75 CaO-FeO-Fe 2 O 3 slags, 119 CaO-SiO 2 -Al 2 O 3 slag, 112 CaO-SiO 2 -Al 2 O 3 -MgO slag, 114 CaO-SiO 2 -CrO slag, 125 CaO-SiO 2 -FeO slags, 123 Cu-S matte, 95 Cu-Zn system, 75 Fe-Cu system, 79 Fe-Cu-S matte, 98 Fe-Cu-S-O, 104 Fe-Mn system, 79 Fe-Ni-S matte, 98 Fe-S matte, 95 Fe-Si system, 79 Pb-S matte, 95 SiO 2 -FeO-Fe 2 O 3 slags, 117 activity in dilute metal solutions, 26 of a metalloid in metal solutions, 27, 48 of an ion in aqueous solutions, 136 affinity of a reaction, 19, 28 alumina (Al 2 O 3 ) solubility in cryolite (Na 3 AlF 6 ), 177 aluminum sulfate (Al 2 (SO 4 ) 3 ) solubility in aqueous solutions, 167 Arrhenius' law activation energy, 189	Extractive Metallurgy 1	\N	\N	2013	\N	\N	337-344	10.1002/9781118618974.index	\N	\N	https://doi.org/10.1002/9781118618974.index	(2013). Index. Extractive Metallurgy 1. 337-344. https://doi.org/10.1002/9781118618974.index.	en	public	published	t	2026-07-28 10:26:04.149298+08	crossref_import	2026-07-28 10:26:04.149298+08	2026-08-17 11:35:50.459171+08	\N	\N	\N	\N
505	5	LIT-000505	A critical review of high entropy alloys and related concepts	\N	paper	High entropy alloys (HEAs) are barely 12 years old. The field has stimulated new ideas and has inspired the exploration of the vast composition space offered by multi-principal element alloys (MPEAs). Here we present a critical review of this field, with the intent of summarizing key findings, uncovering major trends and providing guidance for future efforts. Major themes in this assessment include definition of terms; thermodynamic analysis of complex, concentrated alloys (CCAs); taxonomy of current alloy families; microstructures; mechanical properties; potential applications; and future efforts. Based on detailed analyses, the following major results emerge. Although classical thermodynamic concepts are unchanged, trends in MPEAs can be different than in simpler alloys. Common thermodynamic perceptions can be misleading and new trends are described. From a strong focus on 3d transition metal alloys, there are now seven distinct CCA families. A new theme of designing alloy families by selecting elements to achieve a specific, intended purpose is starting to emerge. A comprehensive microstructural assessment is performed using three datasets: experimental data drawn from 408 different alloys and two computational datasets generated using the CALculated PHAse Diagram (CALPHAD) method. Each dataset emphasizes different elements and shows different microstructural trends. Trends in these three datasets are all predicted by a ‘structure in – structure out’ (SISO) analysis developed here that uses the weighted fractions of the constituent element crystal structures in each dataset. A total of 13 distinct multi-principal element single-phase fields are found in this microstructural assessment. Relationships between composition, microstructure and properties are established for 3d transition metal MPEAs, including the roles of Al, Cr and Cu. Critical evaluation shows that commercial austenitic stainless steels and nickel alloys with 3 or more principal elements are MPEAs, as well as some established functional materials. Mechanical properties of 3d transition metal CCAs are equivalent to commercial austenitic stainless steels and nickel alloys, while some refractory metal CCAs show potential to extend the service strength and/or temperature of nickel superalloys. Detailed analyses of microstructures and properties allow two major HEA hypotheses to be resolved. Although the ‘entropy effect’ is not supported by the present data, it has nevertheless made an enduring contribution by inspiring a clearer understanding of the importance of configurational entropy on phase stability. The ‘sluggish diffusion’ hypothesis is also not supported by available data, but it motivates re-evaluation of a classical concept of metallic diffusion. Building on recent published work, the CCA field has expanded to include materials with metallic, ionic or covalent bonding. It also includes microstructures with any number of phases and any type of phases. Finally, the MPEA field is shown to include both structural and functional materials applications. A significant number of future efforts are recommended, with an emphasis on developing high-throughput experiments and computations for structural materials. The review concludes with a brief description of major accomplishments of the field and insights gained from the first 12 years of research. The field has lost none of its potency and continues to pose new questions and offer new possibilities. The vast range of complex compositions and microstructures remains the most compelling motivation for future studies.	\N	Acta Materialia	\N	\N	2016	122	\N	448-511	10.1016/j.actamat.2016.08.081	\N	\N	https://doi.org/10.1016/j.actamat.2016.08.081	D.B. Miracle, O.N. Senkov. (2016). A critical review of high entropy alloys and related concepts. Acta Materialia. https://doi.org/10.1016/j.actamat.2016.08.081	en	public	published	t	2026-08-17 11:35:11.558369+08	openalex_oa_curated	2026-08-17 11:35:11.558369+08	2026-08-17 11:35:11.558369+08	\N	\N	\N	\N
506	5	LIT-000506	High-entropy alloy: challenges and prospects	\N	paper	High-entropy alloys (HEAs) are presently of great research interest in materials science and engineering. Unlike conventional alloys, which contain one and rarely two base elements, HEAs comprise multiple principal elements, with the possible number of HEA compositions extending considerably more than conventional alloys. With the advent of HEAs, fundamental issues that challenge the proposed theories, models, and methods for conventional alloys also emerge. Here, we provide a critical review of the recent studies aiming to address the fundamental issues related to phase formation in HEAs. In addition, novel properties of HEAs are also discussed, such as their excellent specific strength, superior mechanical performance at high temperatures, exceptional ductility and fracture toughness at cryogenic temperatures, superparamagnetism, and superconductivity. Due to their considerable structural and functional potential as well as richness of design, HEAs are promising candidates for new applications, which warrants further studies.	\N	Materials Today	\N	\N	2015	19	6	349-362	10.1016/j.mattod.2015.11.026	\N	\N	https://doi.org/10.1016/j.mattod.2015.11.026	Y.F. Ye, Q. Wang, Jian Lü, C.T. Liu, Yong Yang. (2015). High-entropy alloy: challenges and prospects. Materials Today. https://doi.org/10.1016/j.mattod.2015.11.026	en	public	published	t	2026-08-17 11:35:11.576266+08	openalex_oa_curated	2026-08-17 11:35:11.576266+08	2026-08-17 11:35:11.576266+08	\N	\N	\N	\N
507	5	LIT-000507	Accelerated exploration of multi-principal element alloys with solid solution phases	\N	paper	Recent multi-principal element, high entropy alloy (HEA) development strategies vastly expand the number of candidate alloy systems, but also pose a new challenge--how to rapidly screen thousands of candidate alloy systems for targeted properties. Here we develop a new approach to rapidly assess structural metals by combining calculated phase diagrams with simple rules based on the phases present, their transformation temperatures and useful microstructures. We evaluate over 130,000 alloy systems, identifying promising compositions for more time-intensive experimental studies. We find the surprising result that solid solution alloys become less likely as the number of alloy elements increases. This contradicts the major premise of HEAs--that increased configurational entropy increases the stability of disordered solid solution phases. As the number of elements increases, the configurational entropy rises slowly while the probability of at least one pair of elements favouring formation of intermetallic compounds increases more rapidly, explaining this apparent contradiction.	\N	Nature Communications	\N	\N	2015	6	1	6529-6529	10.1038/ncomms7529	\N	\N	https://doi.org/10.1038/ncomms7529	O.N. Senkov, Jonathan D. Miller, D.B. Miracle, C. Woodward. (2015). Accelerated exploration of multi-principal element alloys with solid solution phases. Nature Communications. https://doi.org/10.1038/ncomms7529	en	public	published	t	2026-08-17 11:35:11.583983+08	openalex_oa_curated	2026-08-17 11:35:11.583983+08	2026-08-17 11:35:11.583983+08	\N	\N	\N	\N
508	5	LIT-000508	Science and technology in high-entropy alloys	\N	paper	\N	\N	Science China Materials	\N	\N	2018	61	1	2-22	10.1007/s40843-017-9195-8	\N	\N	https://doi.org/10.1007/s40843-017-9195-8	Weiran Zhang, Peter K. Liaw, Yong Zhang. (2018). Science and technology in high-entropy alloys. Science China Materials. https://doi.org/10.1007/s40843-017-9195-8	en	public	published	t	2026-08-17 11:35:11.591391+08	openalex_oa_curated	2026-08-17 11:35:11.591391+08	2026-08-17 11:35:11.591391+08	\N	\N	\N	\N
509	5	LIT-000509	Mechanical properties of high-entropy alloys with emphasis on face-centered cubic alloys	\N	paper	\N	\N	Progress in Materials Science	\N	\N	2018	102	\N	296-345	10.1016/j.pmatsci.2018.12.003	\N	\N	https://doi.org/10.1016/j.pmatsci.2018.12.003	Zezhou Li, Shiteng Zhao, Robert O. Ritchie, Marc A. Meyers. (2018). Mechanical properties of high-entropy alloys with emphasis on face-centered cubic alloys. Progress in Materials Science. https://doi.org/10.1016/j.pmatsci.2018.12.003	en	public	published	t	2026-08-17 11:35:11.595918+08	openalex_oa_curated	2026-08-17 11:35:11.595918+08	2026-08-17 11:35:11.595918+08	\N	\N	\N	\N
510	5	LIT-000510	Decomposition of the single-phase high-entropy alloy CrMnFeCoNi after prolonged anneals at intermediate temperatures	\N	paper	\N	\N	Acta Materialia	\N	\N	2016	112	\N	40-52	10.1016/j.actamat.2016.04.005	\N	\N	https://doi.org/10.1016/j.actamat.2016.04.005	F. Otto, A. Dlouhý, K.G. Pradeep, M. Kuběnová, Dierk Raabe, Gunther Eggeler, E.P. George. (2016). Decomposition of the single-phase high-entropy alloy CrMnFeCoNi after prolonged anneals at intermediate temperatures. Acta Materialia. https://doi.org/10.1016/j.actamat.2016.04.005	en	public	published	t	2026-08-17 11:35:11.603296+08	openalex_oa_curated	2026-08-17 11:35:11.603296+08	2026-08-17 11:35:11.603296+08	\N	\N	\N	\N
56	2	LIT-000056	EFSOP® SYSTEM TECHNOLOGY FOR REAL-TIME WATER DETECTION IN EAF STEELMAKING	\N	paper	When water enters the EAF, some chemically dissociates to H 2 while some remains as H 2 O vapor. Depending on operating conditions the levels of combustible gases (CO and H 2 ) and H 2 O are continually changing throughout the course of any individual heat and on a heat-toheat basis. The EFSOP system has been implemented in more than 80 installations as a powerful tool to reduce furnace operation costs but with water detection technology the off gas technology is a valuable solution to improve safety. This paper describes the latest results when using Tenova Goodfellow's new standalone water detection technology that for the first time provides real-time analysis of both H 2 O vapor and H 2 from start-to-end of a heat. It involves a newly designed water cooled probe and heated line that eliminates condensation during off-gas sampling and an analyzer equipped with a proprietary system for analyzing both H 2 O vapor and H 2 .	When water enters the EAF, some chemically dissociates to H 2 while some remains as H 2 O vapor. Depending on operating conditions the levels of combustible gases (CO and H 2 ) and H 2 O are continually changing throughout the course of any individual heat and on a heat-toheat basis. The EFSOP system has been implemented in more than 80 installations as a powerful tool to reduce furnace operation costs but with water detection technology the off gas technology is a valuable solution to improve safety. This paper describes the latest results when using Tenova Goodfellow's new standalone water detection technology that for the first time provides real-time analysis of both H 2 O vapor and H 2 from start-to-end of a heat. It involves a newly designed water cooled probe and heated line that eliminates condensation during off-gas sampling and an analyzer equipped with a proprietary system for analyzing both H 2 O vapor and H 2 .	ABM Proceedings	\N	\N	2014	\N	\N	2352-2361	10.5151/1982-9345-24504	\N	\N	https://doi.org/10.5151/1982-9345-24504	Vazquez Armando. (2014). EFSOP® SYSTEM TECHNOLOGY FOR REAL-TIME WATER DETECTION IN EAF STEELMAKING. ABM Proceedings. 2352-2361. https://doi.org/10.5151/1982-9345-24504.	en	public	published	f	2026-07-28 10:26:05.659962+08	crossref_import	2026-07-28 10:26:05.659962+08	2026-07-30 15:07:28.273257+08	\N	\N	\N	\N
51	2	LIT-000051	Effect of Direct Reduced Iron Proportion in Metallic Charge on Technological Parameters of EAF Steelmaking Process	\N	paper	The data obtained from industrial heats carried out in 185-ton electric arc furnace (EAF) were used to study the effect of direct reduced iron (DRI) percentage in metallic charge on the different steelmaking parameters and consumption figures. The present study carried out in a wide range of DRI percentage, 0-90% of metallic charge, and the results have been statistically analyzed to correlate the percentage of DRI with the different consumption figures of electric energy, oxygen, coke and fluxing materials. In addition, the influence of DRI percentage on contents of tramp and detrimental elements affecting on steel quality has been also investigated. The results reveal improving the steel quality by increasing DRI percentage, as the tramp elements (Cu, Sn, Ni, Cr) and detrimental elements (P, S) and also nitrogen, all decrease by increasing the percentage of DRI in the metallic charge. On the other hand, the increase in DRI percentage leads to increase in the consumptions (per ton of liquid steel) of electric energy, oxygen, coke and fluxing materials. Furthermore, the metallic yield decreases and the power on time and hence the tap-to-tap time increase as DRI percentage increases. With using higher DRI percentage in the charge, the yield strength and ultimate tensile strength of produced hot rolled bars of low carbon steel slightly decrease whereas elongation increases.	The data obtained from industrial heats carried out in 185-ton electric arc furnace (EAF) were used to study the effect of direct reduced iron (DRI) percentage in metallic charge on the different steelmaking parameters and consumption figures. The present study carried out in a wide range of DRI percentage, 0-90% of metallic charge, and the results have been statistically analyzed to correlate the percentage of DRI with the different consumption figures of electric energy, oxygen, coke and fluxing materials. In addition, the influence of DRI percentage on contents of tramp and detrimental elements affecting on steel quality has been also investigated. The results reveal improving the steel quality by increasing DRI percentage, as the tramp elements (Cu, Sn, Ni, Cr) and detrimental elements (P, S) and also nitrogen, all decrease by increasing the percentage of DRI in the metallic charge. On the other hand, the increase in DRI percentage leads to increase in the consumptions (per ton of liquid steel) of electric energy, oxygen, coke and fluxing materials. Furthermore, the metallic yield decreases and the power on time and hence the tap-to-tap time increase as DRI percentage increases. With using higher DRI percentage in the charge, the yield strength and ultimate tensile strength of produced hot rolled bars of low carbon steel slightly decrease whereas elongation increases.	International Journal of Science and Research (IJSR)	\N	\N	2016	5	2	2016-2024	10.21275/v5i2.nov161550	\N	\N	https://doi.org/10.21275/v5i2.nov161550	(2016). Effect of Direct Reduced Iron Proportion in Metallic Charge on Technological Parameters of EAF Steelmaking Process. International Journal of Science and Research (IJSR). 5(2). 2016-2024. https://doi.org/10.21275/v5i2.nov161550.	en	public	published	f	2026-07-28 10:26:05.636135+08	crossref_import	2026-07-28 10:26:05.636135+08	2026-08-17 11:35:52.301794+08	\N	\N	\N	\N
129	2	LIT-000129	Treatments and Recycling of Metallurgical Slags	\N	book	Steelmaking plants continuously strive to reduce the environmental load in the steelmaking process, resulting in the recycling of energy, water, and other byproducts. In this chapter, techniques for the treatment and recycling of metallurgical slags are described. Metallurgical slags are considered secondary raw materials and are used or added during the process to improve steelmaking practice. Steelmaking slag added into ladle slags makes it possible to minimize slag line wear. BOF-converter slags are also applied in buildup, foaming, or slag splashing practices carried out to prolong the lifespan of refractory lining. Also, EAF slags are commonly used to avoid refractory wear and decrease energy consumption. It is known that cement concrete is one of the most common building materials. Blast furnace crystallized slags are used in cement production, in different percentages. In this sense, understanding the properties of slags is a prerequisite to apply them in different functions. This chapter deals with the measurement and modeling of thermochemical properties of slags, thermophysical properties, and interproperty correlations. Different experimental tests applied in slag characterization are also detailed.	Steelmaking plants continuously strive to reduce the environmental load in the steelmaking process, resulting in the recycling of energy, water, and other byproducts. In this chapter, techniques for the treatment and recycling of metallurgical slags are described. Metallurgical slags are considered secondary raw materials and are used or added during the process to improve steelmaking practice. Steelmaking slag added into ladle slags makes it possible to minimize slag line wear. BOF-converter slags are also applied in buildup, foaming, or slag splashing practices carried out to prolong the lifespan of refractory lining. Also, EAF slags are commonly used to avoid refractory wear and decrease energy consumption. It is known that cement concrete is one of the most common building materials. Blast furnace crystallized slags are used in cement production, in different percentages. In this sense, understanding the properties of slags is a prerequisite to apply them in different functions. This chapter deals with the measurement and modeling of thermochemical properties of slags, thermophysical properties, and interproperty correlations. Different experimental tests applied in slag characterization are also detailed.	Recovery and Utilization of Metallurgical Solid Waste	\N	\N	2019	\N	\N	\N	10.5772/intechopen.80595	\N	\N	https://doi.org/10.5772/intechopen.80595	Brandaleze Elena, Benavidez Edgardo, Santini Leandro. (2019). Treatments and Recycling of Metallurgical Slags. Recovery and Utilization of Metallurgical Solid Waste. https://doi.org/10.5772/intechopen.80595.	en	public	published	f	2026-07-28 10:26:08.790194+08	crossref_import	2026-07-28 10:26:08.790194+08	2026-07-30 15:08:21.945203+08	\N	\N	\N	\N
96	2	LIT-000096	Progress and Future of Breakthrough Low-carbon Steelmaking Technology (ULCOS) of EU	\N	paper	The CO<sub>2</sub> emitted by iron and steel industry accounts for 6% of the global anthropogenic CO<sub>2</sub> emission. As the control of CO<sub>2</sub> emission becomes increasingly stringent all over the world, the iron and steel industry now is facing an unprecedented crisis. And now even the most advanced technologies for reducing carbon emission have reached the bottleneck, so many countries in the world are striving to develop the breakthrough technologies for significantly reducing the carbon emission. The current progress and future research of steelmaking program with ultra-low CO<sub>2</sub> emission in Europe are stated, among which TGR-BF, HIsarna, ULCORED, ULCOWIN and ULCOLYSIS are considered to be the most promising technologies. Combined with the technology of carbon capture and storage, CO<sub>2</sub> emission can be reduced by as much as 80%. Compared with the traditional technologies, investment cost and operating cost are much lower.	The CO<sub>2</sub> emitted by iron and steel industry accounts for 6% of the global anthropogenic CO<sub>2</sub> emission. As the control of CO<sub>2</sub> emission becomes increasingly stringent all over the world, the iron and steel industry now is facing an unprecedented crisis. And now even the most advanced technologies for reducing carbon emission have reached the bottleneck, so many countries in the world are striving to develop the breakthrough technologies for significantly reducing the carbon emission. The current progress and future research of steelmaking program with ultra-low CO<sub>2</sub> emission in Europe are stated, among which TGR-BF, HIsarna, ULCORED, ULCOWIN and ULCOLYSIS are considered to be the most promising technologies. Combined with the technology of carbon capture and storage, CO<sub>2</sub> emission can be reduced by as much as 80%. Compared with the traditional technologies, investment cost and operating cost are much lower.	International Journal of Mineral Processing and Extractive Metallurgy	\N	\N	2018	3	2	15	10.11648/j.ijmpem.20180302.11	\N	\N	https://doi.org/10.11648/j.ijmpem.20180302.11	Junjie Yan. (2018). Progress and Future of Breakthrough Low-carbon Steelmaking Technology (ULCOS) of EU. International Journal of Mineral Processing and Extractive Metallurgy. 3(2). 15. https://doi.org/10.11648/j.ijmpem.20180302.11.	en	public	published	t	2026-07-28 10:26:07.845946+08	crossref_import	2026-07-28 10:26:07.845946+08	2026-07-30 15:08:07.530355+08	\N	\N	\N	\N
157	3	LIT-000157	Foreign Investment, State Capitalism, and National Development in Borneo: Rethinking Brunei–China Economic Relations	\N	paper	Faced with dwindling oil and gas reserves, Brunei has been hard-pressed to diversify its reliance on hydrocarbon. China has emerged as an attractive prospect to the Brunei government, especially since the launch of the Belt and Road Initiative. This article analyses a few major Chinese projects in Brunei and postulates three interrelated arguments. Firstly, Chinese investors have targeted Brunei's natural resources and fiscal incentives. These firms have minimal interest in the Sultanate's small domestic market as they eye the export sector. Secondly, these projects have been orchestrated by China's provincially-owned state-owned enterprises (SOE) and private firms, instead of centrally- controlled SOEs. State support has generally been channelled to these projects in an at-arm's length manner. Thirdly, while Brunei is relatively skilled in attracting Chinese investors to further its own political economic goals, at least in the short-run, it is uncertain whether such capital exports have helped in ameliorating the structural limits of the country’s economy.	\N	Journal of Current Southeast Asian Affairs	\N	\N	2023	\N	\N	\N	10.1177/18681034231186441	\N	\N	https://doi.org/10.1177/18681034231186441	Guanie Lim, Chang Yau Hoon, Kaili Zhao. (2023). Foreign Investment, State Capitalism, and National Development in Borneo: Rethinking Brunei–China Economic Relations. Journal of Current Southeast Asian Affairs. https://doi.org/10.1177/18681034231186441.	en	public	published	t	2026-07-30 16:18:37.082695+08	openalex_import	2026-07-30 16:18:37.082695+08	2026-07-30 16:18:37.082695+08	\N	\N	\N	\N
158	3	LIT-000158	PLC 在钢铁冶金企业电气自动化控制中应用	\N	paper	本文围绕PLC技术在钢铁冶金电气自动化控制中的应用展开。先介绍PLC技术原理与优点，其在钢铁冶 金中可实现实时参数监测与控制、电动设备与执行器控制、计时与定时控制。具体技术实现涵盖数据采集存储报警、 联网通信及与其他系统协同。PLC在钢铁冶金企业应用意义重大，能提高生产效率，实现生产流程精准高效运行；提 升产品质量，精确把控生产参数；降低成本，减少人力依赖、优化资源利用并降低设备故障率，助力企业可持续发展。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0806-1	\N	\N	https://doi.org/10.37155/2717-5197-0806-1	陈文豪, 刚晓祥. (2026). PLC 在钢铁冶金企业电气自动化控制中应用. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0806-1.	en	public	published	f	2026-07-30 16:18:37.096329+08	openalex_import	2026-07-30 16:18:37.096329+08	2026-07-30 16:18:37.096329+08	\N	\N	\N	\N
159	3	LIT-000159	冶金机械设备管理与维护策略研究	\N	paper	1. 来稿要真实性、科学性和科学性，资料可靠真实，数据准确详实，逻辑严密、文字精炼。 2. 来稿文责自负。所有作者应对稿件内容和署名无异议，稿件内容不得抄袭或重复发表。 3. 文章题目要简短精炼，准确概括文章中心内容，不超过20字。各级标题的编码方法为：第一级标题用一、二、三……依次编码；第二级用标题（一）（二）（三）……依次编码；第三级用1，2，3……依次编码。示例如下： 一、第一级标题 （一）第二级标题 （二）第二级标题 1. 第三级标题 2. 第三级标题 二、第一级标题 4. 来稿必须附有100-250字的摘要，一般应包括：目的、方法、结果和结论。需提供3-5个关键词，用分号隔开。 5. 英文标题、摘要、关键词及作者单位务必附在标题页。 6. 来稿必须附有第一作者和通讯作者的简介，包括真实姓名、出生年月、性别、民族、籍贯、工作单位、职务、职称、学位、研究方向等（研究生须注明博士研究生或硕士研究生）；其他作者附真实姓名、工作单位、职务、职称、邮编等。 7. 已被录用稿件原则上不允许更改作者顺序，或增删作者等。 8. 来稿正文字数一般以3000-6000字为宜 （不包括题目、作者信息、图表、参考文献）。 9. 文章格式一般包括：题目、作者及单位、通讯作者地址、邮编、内容摘要、关键词、正文、参考文献等。 10. 参考文献格式采用顺序编码制，请按文中出现的先后顺序编号；在文中引文出现的地方以阿拉伯数字按序编码并用方括号括起来上标；在文末列出参考文献需与正文中的标注序号一一对应。参考文献不少于8条。 1）著作类：[序号]作者．书名[M]．出版地：出版社，出版年，页码． 2）报纸、期刊论文类：[序号]作者．文章题目．报纸名/刊名[N/J]．年代（期、版次）：起止页码． 3）电子文献：[序号]作者．电子文献题目[EB/OL]．电子文献出处或可获得地址，发表日期/引用日期． 4）学位论文：[序号]作者．论文题目[D]：[硕士或博士学位论文]．保存地：保存单位，年份． 5）论文集中的析出文献：[序号]析出文献作者．析出文献题名[A]．原文献作者．原文献题名[C]．出版地：出版者，出版年．析出文献起止页码． 6）专利：[序号]专利申请者．专利名称[P]．国别，专利号．出版日期． 7）技术标准：[序号]起草责任者．标准编号．标准名称[S]．出版地： 出版社，出版年． 11. 参考文献中的标点符号以英文半角符号书写，字体请用Times New Roman。各类参考文献的标识符号是：专著[M]、论文集[C]、期刊文章[J]、报纸文章[N]、学位论文[D]、报告[R]、标准[S]、专利[P]、论文集中的析出文献[A]、各种未定义的文献[Z]。 12. 图表要求：文中表格建议采用三线表，表名置于表上方居中；文中图像要清晰可编辑，将图名置于图下方居中；图表如使用缩略语，需在图表注中说明。图表编号一律用阿拉伯数字，图表标号依次排列，如表1、表2、表3，图1、图2、图3。 13. 计量单位请参照中华人民共和国法定计量单位最新标准。外文字符必须分清大、小写，正、斜体，黑、白体，上下角标应区别明显（必要时可旁注说明）。 14. 缩略词在文中第一次出现时应给予明确定义。中英文缩略词都应在全文中统一。 15. 稿件必须采用Word格式随邮件的附件发送或在线提交稿件。 16. 来稿请注明通讯作者的详细联系地址、邮编、邮箱、联系电话。 17. 来稿如为研究课题或课题/项目/基金支持论文，请注明课题名称、审批机关、基金项目名称、年度及其项目编号。多项基金项目应依次列出，其间以分号“；”隔开。 18. 编辑部对来稿有删修权，不同意删修的稿件请在来稿中声明。 19. 所有来稿均不退，请作者自留底稿。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0807-43	\N	\N	https://doi.org/10.37155/2717-5197-0807-43	亮 陆. (2026). 冶金机械设备管理与维护策略研究. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0807-43.	en	public	published	f	2026-07-30 16:18:37.100455+08	openalex_import	2026-07-30 16:18:37.100455+08	2026-07-30 16:18:37.100455+08	\N	\N	\N	\N
160	3	LIT-000160	动力电池铝箔的性能衰减机理及工艺改进	\N	paper	针对动力电池用 A1100 铝箔在室温贮存过程中存在延伸率显著衰减的难题，论文通过力学性能测试、X射线衍射、扫描电镜和热力学计算等手段，对比分析了出厂放置不同时间材料的力学性能和显微组织的变化。结果表明A1100铝箔在室温放置5天后延伸率相比放置2天下降了约 14.5%。进一步的微结构表征和热力学计算分析可知，室温放置过程中，残余应力作用下Si原子扩散加快形成原子偏聚，促进了α-AlFeSi向β-AlFeSi转变及亚结构的粗化。基于所分析的性能衰减机理，提出了加大轧制变形量和提升一级退火温度的工艺优化方案。采用改进工艺，A1100铝箔经室温放置5天后的抗拉强度为 263.8±3.7 MPa (传统工艺：247.8±0.8 MPa)，延伸率为 6.4±0.4% (传统工艺：4.1±0.2 %)，相比传统工艺材料综合性能显著提升。本研究为动力电池铝箔工业生产中的性能一致性与稳定性调控提供了有效的工艺路线。	\N	Modern Engineering and Application	\N	\N	2026	\N	\N	\N	10.61784/mea2005	\N	\N	https://doi.org/10.61784/mea2005	諝跃 赵, 南军 晏, 昌文 陈. (2026). 动力电池铝箔的性能衰减机理及工艺改进. Modern Engineering and Application. https://doi.org/10.61784/mea2005.	zh	public	published	f	2026-07-30 16:18:37.10395+08	openalex_import	2026-07-30 16:18:37.10395+08	2026-07-30 16:18:37.10395+08	\N	\N	\N	\N
161	3	LIT-000161	机械设计和机械制造技术研究	\N	paper	随着科技飞速发展，机械领域迎变革。本文聚焦机械设计与机械制造技术展开研究。首先对机械设计和 机械制造技术进行概述，接着阐述机械设计的多种方法，包括传统经验设计法、计算机辅助设计、优化设计法及模块 化设计法。随后详细介绍机械制造技术的工艺流程，涵盖产品设计、工艺规划等多个环节。最后探讨机械设计与机械 制造技术的创新发展趋势，指出智能化、绿色化、精密化、集成化是其重要方向，旨在为该领域的发展提供全面的理 论参考。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0810-6	\N	\N	https://doi.org/10.37155/2717-5197-0810-6	臻 卢. (2026). 机械设计和机械制造技术研究. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0810-6.	en	public	published	f	2026-07-30 16:18:37.107642+08	openalex_import	2026-07-30 16:18:37.107642+08	2026-07-30 16:18:37.107642+08	\N	\N	\N	\N
164	3	LIT-000164	攀西力马河镁铁-超镁铁岩浆演化与镍成矿: 来自矿物化学的证据	\N	paper	四川会理力马河镍矿是我国典型的岩浆铜镍硫化物矿床,其成岩成矿作用与晚海西期扬子西缘地幔柱活动密切相关,然而关于镁铁-超镁铁质岩浆演化过程中镍的富集机制问题尚缺乏统一认识。本研究运用电子探针与LA-ICP-MS技术,系统分析了力马河岩体不同岩相中橄榄石与辉石的化学组成,用以解析岩浆源区和演化过程与镍富集成矿的成因联系,并综合对比了攀西地区及我国典型岩浆硫化物型矿床岩石矿物学特征。研究结果显示,力马河岩体母岩浆源自深部石榴子石橄榄岩地幔,其镁铁单元与超镁铁单元分别具有拉斑玄武质岩浆和高镁玄武质岩浆特征。在岩浆演化过程中,力马河岩体橄榄石高Li含量说明其经历了明显的中-上地壳物质混染,推断发生了外源硫触发硫化物熔离。力马河岩体与邻区关河岩体(不含镍矿)的成矿差异主要源于硫化物熔离阶段:力马河岩体为早期熔离,这种早期熔离机制有效地富集了金属元素,促成高品位矿床;关河岩体属晚期熔离,仅致低品位矿化。因此,该区与镍成矿相关的岩浆主要源于深部石榴子石橄榄岩地幔,地壳硫的加入诱发岩浆演化早期硫化物熔离,上述条件与过程的耦合构成了攀西地区大型岩浆铜镍硫化物矿床成矿的关键控制因素。	\N	Acta Petrologica Sinica	\N	\N	2026	\N	\N	\N	10.18654/1000-0569/2026.06.11	\N	\N	https://doi.org/10.18654/1000-0569/2026.06.11	BingLiang LIU, Zheng Zhao, NaXin GUO, Chenhao Li. (2026). 攀西力马河镁铁-超镁铁岩浆演化与镍成矿: 来自矿物化学的证据. Acta Petrologica Sinica. https://doi.org/10.18654/1000-0569/2026.06.11.	en	public	published	f	2026-07-30 16:18:37.122319+08	openalex_import	2026-07-30 16:18:37.122319+08	2026-07-30 16:18:37.122319+08	\N	\N	\N	\N
165	3	LIT-000165	烧结过程温度场模拟及矿相演变规律研究	\N	paper	\N	\N	工程学研究与实用	\N	\N	2026	\N	\N	\N	10.37155/2717-5316-0709-74	\N	\N	https://doi.org/10.37155/2717-5316-0709-74	Zhu Quanzheng. (2026). 烧结过程温度场模拟及矿相演变规律研究. 工程学研究与实用. https://doi.org/10.37155/2717-5316-0709-74.	en	public	published	f	2026-07-30 16:18:37.126098+08	openalex_import	2026-07-30 16:18:37.126098+08	2026-07-30 16:18:37.126098+08	\N	\N	\N	\N
166	3	LIT-000166	Recent Progress in the preparation, properties, and applications of carbon nanotube/copper composite conductors	\N	paper	在“双碳”战略驱动下，航空航天、新能源汽车与先进电子器件对导体材料提出了高强高导协同、高电流承载能力及宽温域可靠服役的多维性能要求。碳纳米管因其准一维结构、超高载流容量、低密度及优异力学性能，成为构建新一代复合导体的理想材料。近年来，研究者围绕碳纳米管/铜复合导体的界面结构调控、分级构型设计及先进制备技术开展了系统研究，在电导率、力学性能、载流等方面取得显著突破。本文综述了粉末冶金、电沉积、物理/化学气相沉积等导体制备方法，对比分析了不同工艺下复合导体的导电、力学、载流性能，并阐述其在高强结构材料、轻量化导体、高可靠性微电子互连、电极材料等领域的应用潜力。在此基础上，指出当前研究仍面临碳纳米管分散与结构可控性、碳纳米管与铜的有效界面构筑、宏观结构设计与性能协同优化、规模化制备与成本控制等方面的诸多挑战，展望未来应通过精准界面工程、多尺度结构协同设计与工程化制备技术的深度融合，发展兼具高导电、高强韧、高可靠性的新一代碳纳米管/铜复合导体，为下一代高效、轻质、可持续的电气与电子系统提供关键材料支撑。	\N	Chinese Science Bulletin (Chinese Version)	\N	\N	2026	\N	\N	\N	10.1360/csb-2026-0648	\N	\N	https://doi.org/10.1360/csb-2026-0648	Jing Zhang, Dandan Liu, Yanzhao Chou, Cheng Chen, Shengjin Yue, Qingwen Li. (2026). Recent Progress in the preparation, properties, and applications of carbon nanotube/copper composite conductors. Chinese Science Bulletin (Chinese Version). https://doi.org/10.1360/csb-2026-0648.	en	public	published	f	2026-07-30 16:18:37.127952+08	openalex_import	2026-07-30 16:18:37.127952+08	2026-07-30 16:18:37.127952+08	\N	\N	\N	\N
167	3	LIT-000167	BIM 技术在暖通空调设计中的高效应用	\N	paper	\N	\N	工程学研究与实用	\N	\N	2026	\N	\N	\N	10.37155/2717-5316-0707-27	\N	\N	https://doi.org/10.37155/2717-5316-0707-27	李美晨. (2026). BIM 技术在暖通空调设计中的高效应用. 工程学研究与实用. https://doi.org/10.37155/2717-5316-0707-27.	en	public	published	f	2026-07-30 16:18:37.13577+08	openalex_import	2026-07-30 16:18:37.13577+08	2026-07-30 16:18:37.13577+08	\N	\N	\N	\N
168	3	LIT-000168	机械设计制造及其自动化的应用分析	\N	paper	当前制造业向智能化、高精度方向转型，机械设计制造及其自动化技术成为核心驱动力。本文围绕机械 设计制造及其自动化技术展开研究，剖析了其核心原理与多系统协同机制，阐述数字化设计、精密加工、自动化控制 及智能制造集成等关键技术。随后结合航空航天、汽车、电子、新能源装备制造及智能制造领域，分析机械设计制造 及其自动化技术在各领域的具体应用场景，包括结构设计、部件加工、装配检测等环节。研究表明，该技术能提升生 产精度与效率，推动多行业升级。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0805-33	\N	\N	https://doi.org/10.37155/2717-5197-0805-33	薛之广. (2026). 机械设计制造及其自动化的应用分析. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0805-33.	en	public	published	f	2026-07-30 16:18:37.138398+08	openalex_import	2026-07-30 16:18:37.138398+08	2026-07-30 16:18:37.138398+08	\N	\N	\N	\N
169	3	LIT-000169	广东大宝山斑岩成矿系统的年代学特征、成矿环境与找矿方向	\N	paper	广东大宝山是南岭地区规模最大的在产铜矿山。然而,大宝山斑岩系统属于还原性还是氧化性成矿环境的问题尚未开展研究。本文通过热液金红石原位U-Pb测年结果(159±13Ma),厘定了大宝山斑岩型铜矿化的时间,认为铜成矿于中晚侏罗世。通过分析花岗闪长斑岩的全岩主微量元素组成,并与江西德兴、西藏甲玛相对比,发现大宝山成矿岩体不具备埃达克质岩特征,且显示低Al<sub>2</sub>O<sub>3</sub>、低P<sub>2</sub>O<sub>5</sub>、高Zr、高Y、高Yb、低Sr/Y、低V/Sc、低La/Yb和低(Eu<sub>N</sub>/Eu<sup>*</sup>)/Yb<sub>N</sub>等地球化学特征。这些差异指示大宝山较德兴和甲玛的成矿岩浆具有更低含水量和更还原的性质。锆石Ti温度计算结果显示,船肚花岗闪长岩和大宝山花岗闪长斑岩的结晶温度分别为644~736℃和661~736℃,与甲玛和德兴成矿斑岩相当。根据锆石氧逸度计估算,船肚花岗闪长岩锆石的△FMQ值为-0.1~+1.2,大宝山花岗闪长斑岩锆石的△FMQ值为+0.18~+1.01。这一数值范围与白乃庙还原性斑岩系统基本重叠,但显著低于甲玛和德兴等典型氧化性系统。总体上,大宝山成矿岩浆体系具有低氧逸度特征,与其广泛发育磁黄铁矿、缺乏氧化矿物子晶(如赤铁矿)的流体包裹体和少见硬石膏、磁铁矿等氧化矿物的地质现象相吻合,也佐证了大宝山的还原性成矿环境。建议今后找矿工作应围绕花岗闪长(斑)岩体展开,重点勘查大宝山花岗闪长斑岩东北侧区域。	\N	Acta Petrologica Sinica	\N	\N	2026	\N	\N	\N	10.18654/1000-0569/2026.06.16	\N	\N	https://doi.org/10.18654/1000-0569/2026.06.16	ChenHui ZHAO, DengHong WANG, ChengHui WANG, Wusheng Liu, Xiong ZHANG, Junxue Jiang, TingJie LI, Xifei Xu. (2026). 广东大宝山斑岩成矿系统的年代学特征、成矿环境与找矿方向. Acta Petrologica Sinica. https://doi.org/10.18654/1000-0569/2026.06.16.	en	public	published	f	2026-07-30 16:18:37.140049+08	openalex_import	2026-07-30 16:18:37.140049+08	2026-07-30 16:18:37.140049+08	\N	\N	\N	\N
170	3	LIT-000170	汽车防撞横梁冲压工艺研究及模具设计探讨	\N	paper	随着全球汽车工业对安全性、轻量化和成本效益的持续追求，作为车身被动安全核心部件之一的汽车防 撞横梁（Bumper Beam），其制造技术面临着前所未有的挑战与机遇。本文以高强度钢板（HSS）和先进高强钢（AHSS） 为主要研究对象，系统性地探讨了汽车防撞横梁的冲压成形工艺。首先，深入剖析了防撞横梁的结构特点、功能需求 及其材料选择；其次，针对高强度材料在冲压过程中易出现的回弹、开裂、起皱等典型缺陷，详细阐述了工艺参数优 化、成形路径规划及回弹补偿策略；在此基础上，重点论述了冲压模具的设计原则、关键结构（如拉延模、修边冲孔模） 的创新方案，并引入了CAE仿真技术在模具设计与验证中的核心作用。本研究旨在为提升防撞横梁的制造质量、缩短 开发周期、降低生产成本提供一套系统化的理论与实践参考。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0809-7	\N	\N	https://doi.org/10.37155/2717-5197-0809-7	程阿苗, 毅 王, 张玲玲. (2026). 汽车防撞横梁冲压工艺研究及模具设计探讨. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0809-7.	en	public	published	f	2026-07-30 16:18:37.14649+08	openalex_import	2026-07-30 16:18:37.14649+08	2026-07-30 16:18:37.14649+08	\N	\N	\N	\N
173	3	LIT-000173	冶金设计中总图设计的核心要点研究	\N	paper	在钢铁冶金设计项目中，需要根据项目选址、项目布局和项目运营完成总图设计，冶金企业的钢铁生产效率、绿色发展、运营成本等都与总图设计息息相关。钢铁冶金行业本身用地规模大，采用的施工工艺较为复杂，且需要采取有效措施加强施工现场的安全环保管理，要有效降低钢铁冶金企业的能耗、优化布局、提升生产效率，企业就必须根据钢铁冶金项目的实际情况优化钢铁冶金总图设计，以求提高企业的生产效率，降低运营成本，推动钢铁冶金企业的长期可持续发展。在绿色发展和智能发展的背景下，钢铁冶金企业面对绿色转型和智能化转型的新要求，需进一步优化其总图设计，鉴于此，本文根据钢铁冶金设计的实际情况，深入剖析了总图设计的核心要点，旨在从绿色化、智能化方向出发探索钢铁冶金总图设计的优化路径。	\N	工程技术前沿杂志	\N	\N	2026	\N	\N	\N	10.66128/jaet202603.4	\N	\N	https://doi.org/10.66128/jaet202603.4	意 潘. (2026). 冶金设计中总图设计的核心要点研究. 工程技术前沿杂志. https://doi.org/10.66128/jaet202603.4.	en	public	published	t	2026-07-30 16:18:37.160934+08	openalex_import	2026-07-30 16:18:37.160934+08	2026-07-30 16:18:37.160934+08	\N	\N	\N	\N
174	3	LIT-000174	冶金行业安全事故案例分析及其教训总结	\N	paper	\N	\N	工程管理与技术探讨	\N	\N	2026	\N	\N	\N	10.37155/2717-5189-0807-48	\N	\N	https://doi.org/10.37155/2717-5189-0807-48	孙明传. (2026). 冶金行业安全事故案例分析及其教训总结. 工程管理与技术探讨. https://doi.org/10.37155/2717-5189-0807-48.	en	public	published	f	2026-07-30 16:18:37.162847+08	openalex_import	2026-07-30 16:18:37.162847+08	2026-07-30 16:18:37.162847+08	\N	\N	\N	\N
175	3	LIT-000175	冶金铁路无人调车机械系统的路径规划与控制研究	\N	paper	1. 来稿要真实性、科学性和科学性，资料可靠真实，数据准确详实，逻辑严密、文字精炼。 2. 来稿文责自负。所有作者应对稿件内容和署名无异议，稿件内容不得抄袭或重复发表。 3. 文章题目要简短精炼，准确概括文章中心内容，不超过20字。各级标题的编码方法为：第一级标题用一、二、三……依次编码；第二级用标题（一）（二）（三）……依次编码；第三级用1，2，3……依次编码。示例如下： 一、第一级标题 （一）第二级标题 （二）第二级标题 1. 第三级标题 2. 第三级标题 二、第一级标题 4. 来稿必须附有100-250字的摘要，一般应包括：目的、方法、结果和结论。需提供3-5个关键词，用分号隔开。 5. 英文标题、摘要、关键词及作者单位务必附在标题页。 6. 来稿必须附有第一作者和通讯作者的简介，包括真实姓名、出生年月、性别、民族、籍贯、工作单位、职务、职称、学位、研究方向等（研究生须注明博士研究生或硕士研究生）；其他作者附真实姓名、工作单位、职务、职称、邮编等。 7. 已被录用稿件原则上不允许更改作者顺序，或增删作者等。 8. 来稿正文字数一般以3000-6000字为宜 （不包括题目、作者信息、图表、参考文献）。 9. 文章格式一般包括：题目、作者及单位、通讯作者地址、邮编、内容摘要、关键词、正文、参考文献等。 10. 参考文献格式采用顺序编码制，请按文中出现的先后顺序编号；在文中引文出现的地方以阿拉伯数字按序编码并用方括号括起来上标；在文末列出参考文献需与正文中的标注序号一一对应。参考文献不少于8条。 1）著作类：[序号]作者．书名[M]．出版地：出版社，出版年，页码． 2）报纸、期刊论文类：[序号]作者．文章题目．报纸名/刊名[N/J]．年代（期、版次）：起止页码． 3）电子文献：[序号]作者．电子文献题目[EB/OL]．电子文献出处或可获得地址，发表日期/引用日期． 4）学位论文：[序号]作者．论文题目[D]：[硕士或博士学位论文]．保存地：保存单位，年份． 5）论文集中的析出文献：[序号]析出文献作者．析出文献题名[A]．原文献作者．原文献题名[C]．出版地：出版者，出版年．析出文献起止页码． 6）专利：[序号]专利申请者．专利名称[P]．国别，专利号．出版日期． 7）技术标准：[序号]起草责任者．标准编号．标准名称[S]．出版地： 出版社，出版年． 11. 参考文献中的标点符号以英文半角符号书写，字体请用Times New Roman。各类参考文献的标识符号是：专著[M]、论文集[C]、期刊文章[J]、报纸文章[N]、学位论文[D]、报告[R]、标准[S]、专利[P]、论文集中的析出文献[A]、各种未定义的文献[Z]。 12. 图表要求：文中表格建议采用三线表，表名置于表上方居中；文中图像要清晰可编辑，将图名置于图下方居中；图表如使用缩略语，需在图表注中说明。图表编号一律用阿拉伯数字，图表标号依次排列，如表1、表2、表3，图1、图2、图3。 13. 计量单位请参照中华人民共和国法定计量单位最新标准。外文字符必须分清大、小写，正、斜体，黑、白体，上下角标应区别明显（必要时可旁注说明）。 14. 缩略词在文中第一次出现时应给予明确定义。中英文缩略词都应在全文中统一。 15. 稿件必须采用Word格式随邮件的附件发送或在线提交稿件。 16. 来稿请注明通讯作者的详细联系地址、邮编、邮箱、联系电话。 17. 来稿如为研究课题或课题/项目/基金支持论文，请注明课题名称、审批机关、基金项目名称、年度及其项目编号。多项基金项目应依次列出，其间以分号“；”隔开。 18. 编辑部对来稿有删修权，不同意删修的稿件请在来稿中声明。 19. 所有来稿均不退，请作者自留底稿。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0810-64	\N	\N	https://doi.org/10.37155/2717-5197-0810-64	牛传辉. (2026). 冶金铁路无人调车机械系统的路径规划与控制研究. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0810-64.	en	public	published	f	2026-07-30 16:18:37.164404+08	openalex_import	2026-07-30 16:18:37.164404+08	2026-07-30 16:18:37.164404+08	\N	\N	\N	\N
176	3	LIT-000176	新能源汽车动力电池系统技术发展趋势探究	\N	paper	新能源汽车产业蓬勃发展，动力电池技术至关重要。材料体系围绕正负极等核心组件多向突破，为产 业发展拓宽空间。系统集成技术优化有无模组化、轻量化与模块化协同、热管理系统升级等方向。智能管理系统 （BMS）朝高精度估算预测、智能化与网联化融合、无线化与集成化架构演进。回收利用与梯次利用技术中，高效拆 解与分选、高价值材料再生技术升级、梯次利用价值最大化是关键，共同推动动力电池技术进步与产业可持续发展。	\N	工程管理与技术探讨	\N	\N	2026	\N	\N	\N	10.37155/2717-5189-0808-73	\N	\N	https://doi.org/10.37155/2717-5189-0808-73	勇 王. (2026). 新能源汽车动力电池系统技术发展趋势探究. 工程管理与技术探讨. https://doi.org/10.37155/2717-5189-0808-73.	en	public	published	f	2026-07-30 16:18:37.167259+08	openalex_import	2026-07-30 16:18:37.167259+08	2026-07-30 16:18:37.167259+08	\N	\N	\N	\N
177	3	LIT-000177	热处理对激光选区熔化316H不锈钢力学性能的影响	\N	paper	激光选区熔化技术可实现不锈钢复杂结构件的近终形成形，在核电、化工等高端装备领域具有重要应用价值。316H 型奥氏体不锈钢因其优异的高温强度和耐腐蚀性，已被广泛应用于极端环境中的关键零部件。然而，激光选区熔化过程具有极高的温度梯度和冷却速度，极易导致零件内部产生残余应力、气孔缺陷和各向异性柱状晶结构，导致其力学性能不稳定。热处理作为增材制造过程中组织结构调控和力学性能提升的重要手段，通过合理的热处理工艺可以有效消除残余应力、促进等轴化和优化沉淀相分布。因此，开展热处理对 316 H 不锈钢激光选区熔化力学性能影响规律的系统研究，对促进 316 H 不锈钢在高端装备中的可靠应用具有重要的工程意义和理论价值。	\N	工程管理	\N	\N	2026	\N	\N	\N	10.32629/jpm.v7i5.8922	\N	\N	https://doi.org/10.32629/jpm.v7i5.8922	浩东 严. (2026). 热处理对激光选区熔化316H不锈钢力学性能的影响. 工程管理. https://doi.org/10.32629/jpm.v7i5.8922.	zh	public	published	f	2026-07-30 16:18:37.168867+08	openalex_import	2026-07-30 16:18:37.168867+08	2026-07-30 16:18:37.168867+08	\N	\N	\N	\N
178	3	LIT-000178	工业碳锁定的空间关联格局及其驱动机制	\N	paper	【目的】工业体系的强空间关联性及其跨区域延伸的产业链，进一步强化了工业碳锁定，深入研究工业碳锁定的驱动机制，这直接关系到工业低碳转型和“双碳”目标的实现。【方法】本文基于2011—2021年中国30个省份的面板数据，运用社会网络分析刻画工业碳锁定的空间关联网络特征，采用极度梯度提升（XGBoost）算法识别工业碳锁定的核心驱动因素，并通过指数随机图模型（ERGM），实证检验其对工业碳锁定空间关联网络的影响效果。【结果】①工业碳锁定空间关联网络虽然随时间变化呈现出复杂的多线程特征，但具有较强的稳定性和韧性，不利于打破工业碳锁定。②经济欠发达地区，特别是新疆、青海、云南、甘肃、内蒙古等地区在工业碳锁定网络中扮演重要纽带角色，具有较强的信息接收和传递能力，以其为核心的“核心-边缘”结构高度稳定。③数字赋能、绿色金融发展、对外开放水平提升、全国统一大市场建立与产业结构升级是削弱工业碳锁定空间关联的核心动力因素，各因素的作用强度依次递减。【结论】工业碳锁定空间关联网络结构稳定，欠发达地区的枢纽作用突出。应构建碳减排共同体、深化数字化转型、推进市场化改革与绿色金融创新，形成区域协同、技术驱动、市场引导、资金保障的绿色低碳发展新格局。	\N	资源科学	\N	\N	2026	\N	\N	\N	10.18402/resci.2026.05.03	\N	\N	https://doi.org/10.18402/resci.2026.05.03	Yucheng LIU, Luxin YANG. (2026). 工业碳锁定的空间关联格局及其驱动机制. 资源科学. https://doi.org/10.18402/resci.2026.05.03.	en	public	published	f	2026-07-30 16:18:37.171108+08	openalex_import	2026-07-30 16:18:37.171108+08	2026-07-30 16:18:37.171108+08	\N	\N	\N	\N
179	3	LIT-000179	热阴极电子束冷床炉预热过程控制	\N	paper	热阴极电子束冷床炉预热过程的精确控制是提升钛合金铸锭成分均匀性与冶金质量的核心环节。本文系 统分析了预热过程中铝元素挥发的动力学行为及其对铸锭成分偏析和冶金缺陷的影响机制，揭示了高温高真空环境下 元素挥发控制的技术难点。通过构建电子束功率分段控制、时间参数精确管理、设备状态协同优化及原料铝含量动态 补偿的综合性控制策略，实现了预热工艺的精准调控。实际应用表明，该策略显著降低了铸锭纵向铝含量极差，提高 了组织一致性与产品成品率，为高端钛合金材料的稳定制备提供了关键技术支撑。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0808-2	\N	\N	https://doi.org/10.37155/2717-5197-0808-2	吴云鸽. (2026). 热阴极电子束冷床炉预热过程控制. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0808-2.	en	public	published	f	2026-07-30 16:18:37.17358+08	openalex_import	2026-07-30 16:18:37.17358+08	2026-07-30 16:18:37.17358+08	\N	\N	\N	\N
182	3	LIT-000182	冶金炼钢转炉机械设备维修管理探讨	\N	paper	随着钢铁行业智能化转型加速推进，冶金炼钢转炉作为核心生产设备，其机械设备的稳定运行直接关系 到生产效率与产品质量。本文聚焦冶金炼钢转炉机械设备维修管理展开探讨。首先阐述了其重要性，包括保障生产连 续性、延长设备使用寿命、降低生产成本以及保障生产安全。接着剖析了现存问题，如管理意识不足、管理体系不完善、 维修技术落后、润滑管理不到位和备件管理混乱等。最后针对性地提出维修管理策略，涵盖强化管理意识、完善管理体系、 提升维修技术、优化润滑管理、加强备件管理以及构建信息化管理系统等方面，旨在为冶金炼钢转炉机械设备的高效 维修管理提供参考。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0806-41	\N	\N	https://doi.org/10.37155/2717-5197-0806-41	张向斌. (2026). 冶金炼钢转炉机械设备维修管理探讨. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0806-41.	en	public	published	f	2026-07-30 16:18:48.421735+08	openalex_import	2026-07-30 16:18:48.421735+08	2026-07-30 16:18:48.421735+08	\N	\N	\N	\N
185	3	LIT-000185	全流程自动化连铸装备在高合金钢生产中的铸坯质量提升研究	\N	paper	本文聚焦全流程自动化连铸装备在高合金钢生产中对铸坯质量的提升。高合金钢因化学成分复杂，连 铸生产易出现表面、内部及洁净度缺陷，传统工艺局限多。全流程自动化连铸装备针对160mm×160mm、200mm× 200mm两种方坯生产需求，通过构建自动化体系、应用过程检测与数据融合技术、数字化孪生技术等，从表面质量改善、 内部组织均匀性提升、洁净度控制三方面提升铸坯质量，可使铸坯表面缺陷率降低62%、内部非金属夹杂物含量降低 53%，有效降低缺陷率与非金属夹杂物含量，满足高端应用需求，推动高合金钢连铸生产智能化发展。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0809-77	\N	\N	https://doi.org/10.37155/2717-5197-0809-77	易靖松. (2026). 全流程自动化连铸装备在高合金钢生产中的铸坯质量提升研究. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0809-77.	en	public	published	f	2026-07-30 16:18:48.445298+08	openalex_import	2026-07-30 16:18:48.445298+08	2026-07-30 16:18:48.445298+08	\N	\N	\N	\N
186	3	LIT-000186	轧钢产品表面质量控制及优化方法	\N	paper	\N	\N	工程学研究与实用	\N	\N	2026	\N	\N	\N	10.37155/2717-5316-0708-11	\N	\N	https://doi.org/10.37155/2717-5316-0708-11	郑传昱, 智 高, 郑海涛, 林 何, 苏志诚. (2026). 轧钢产品表面质量控制及优化方法. 工程学研究与实用. https://doi.org/10.37155/2717-5316-0708-11.	en	public	published	f	2026-07-30 16:18:48.448351+08	openalex_import	2026-07-30 16:18:48.448351+08	2026-07-30 16:18:48.448351+08	\N	\N	\N	\N
187	3	LIT-000187	汽车配件的生产工艺及其质量控制研究	\N	paper	1. 来稿要真实性、科学性和科学性，资料可靠真实，数据准确详实，逻辑严密、文字精炼。 2. 来稿文责自负。所有作者应对稿件内容和署名无异议，稿件内容不得抄袭或重复发表。 3. 文章题目要简短精炼，准确概括文章中心内容，不超过20字。各级标题的编码方法为：第一级标题用一、二、三……依次编码；第二级用标题（一）（二）（三）……依次编码；第三级用1，2，3……依次编码。示例如下： 一、第一级标题 （一）第二级标题 （二）第二级标题 1. 第三级标题 2. 第三级标题 二、第一级标题 4. 来稿必须附有100-250字的摘要，一般应包括：目的、方法、结果和结论。需提供3-5个关键词，用分号隔开。 5. 英文标题、摘要、关键词及作者单位务必附在标题页。 6. 来稿必须附有第一作者和通讯作者的简介，包括真实姓名、出生年月、性别、民族、籍贯、工作单位、职务、职称、学位、研究方向等（研究生须注明博士研究生或硕士研究生）；其他作者附真实姓名、工作单位、职务、职称、邮编等。 7. 已被录用稿件原则上不允许更改作者顺序，或增删作者等。 8. 来稿正文字数一般以3000-6000字为宜 （不包括题目、作者信息、图表、参考文献）。 9. 文章格式一般包括：题目、作者及单位、通讯作者地址、邮编、内容摘要、关键词、正文、参考文献等。 10. 参考文献格式采用顺序编码制，请按文中出现的先后顺序编号；在文中引文出现的地方以阿拉伯数字按序编码并用方括号括起来上标；在文末列出参考文献需与正文中的标注序号一一对应。参考文献不少于8条。 1）著作类：[序号]作者．书名[M]．出版地：出版社，出版年，页码． 2）报纸、期刊论文类：[序号]作者．文章题目．报纸名/刊名[N/J]．年代（期、版次）：起止页码． 3）电子文献：[序号]作者．电子文献题目[EB/OL]．电子文献出处或可获得地址，发表日期/引用日期． 4）学位论文：[序号]作者．论文题目[D]：[硕士或博士学位论文]．保存地：保存单位，年份． 5）论文集中的析出文献：[序号]析出文献作者．析出文献题名[A]．原文献作者．原文献题名[C]．出版地：出版者，出版年．析出文献起止页码． 6）专利：[序号]专利申请者．专利名称[P]．国别，专利号．出版日期． 7）技术标准：[序号]起草责任者．标准编号．标准名称[S]．出版地： 出版社，出版年． 11. 参考文献中的标点符号以英文半角符号书写，字体请用Times New Roman。各类参考文献的标识符号是：专著[M]、论文集[C]、期刊文章[J]、报纸文章[N]、学位论文[D]、报告[R]、标准[S]、专利[P]、论文集中的析出文献[A]、各种未定义的文献[Z]。 12. 图表要求：文中表格建议采用三线表，表名置于表上方居中；文中图像要清晰可编辑，将图名置于图下方居中；图表如使用缩略语，需在图表注中说明。图表编号一律用阿拉伯数字，图表标号依次排列，如表1、表2、表3，图1、图2、图3。 13. 计量单位请参照中华人民共和国法定计量单位最新标准。外文字符必须分清大、小写，正、斜体，黑、白体，上下角标应区别明显（必要时可旁注说明）。 14. 缩略词在文中第一次出现时应给予明确定义。中英文缩略词都应在全文中统一。 15. 稿件必须采用Word格式随邮件的附件发送或在线提交稿件。 16. 来稿请注明通讯作者的详细联系地址、邮编、邮箱、联系电话。 17. 来稿如为研究课题或课题/项目/基金支持论文，请注明课题名称、审批机关、基金项目名称、年度及其项目编号。多项基金项目应依次列出，其间以分号“；”隔开。 18. 编辑部对来稿有删修权，不同意删修的稿件请在来稿中声明。 19. 所有来稿均不退，请作者自留底稿。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0808-6	\N	\N	https://doi.org/10.37155/2717-5197-0808-6	颉 李, Jiale Lu. (2026). 汽车配件的生产工艺及其质量控制研究. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0808-6.	en	public	published	f	2026-07-30 16:18:48.453305+08	openalex_import	2026-07-30 16:18:48.453305+08	2026-07-30 16:18:48.453305+08	\N	\N	\N	\N
188	3	LIT-000188	炼钢过程中夹杂物的形态控制与去除	\N	paper	\N	\N	工程管理与技术探讨	\N	\N	2026	\N	\N	\N	10.37155/2717-5189-0810-36	\N	\N	https://doi.org/10.37155/2717-5189-0810-36	王晓枫. (2026). 炼钢过程中夹杂物的形态控制与去除. 工程管理与技术探讨. https://doi.org/10.37155/2717-5189-0810-36.	en	public	published	f	2026-07-30 16:18:48.458912+08	openalex_import	2026-07-30 16:18:48.458912+08	2026-07-30 16:18:48.458912+08	\N	\N	\N	\N
189	3	LIT-000189	电机机座加工工艺与加工精度分析	\N	paper	电机机座作为电机的关键结构部件，不仅承担着支撑定子铁心、端盖等内部组件的功能，还直接影响电 机的散热性能、振动噪声水平及整体运行稳定性。其加工质量，尤其是关键尺寸和形位公差的精度，直接决定了电机 的装配精度、运行效率和使用寿命。本文系统阐述了电机机座的结构特点与功能要求，深入分析了当前主流的加工工 艺流程，并对影响加工精度的关键因素进行了全面剖析。在此基础上，提出了优化加工工艺、提升加工精度的有效策略， 并结合现代制造技术的发展趋势，展望了电机机座智能制造的未来方向。研究结果对提高电机产品质量、降低制造成 本具有重要的理论指导和工程应用价值。	\N	Gong cheng ji shu yu zhi liang guan li =	\N	\N	2026	\N	\N	\N	10.37155/3041-0827-0207-5	\N	\N	https://doi.org/10.37155/3041-0827-0207-5	沈会艾. (2026). 电机机座加工工艺与加工精度分析. Gong cheng ji shu yu zhi liang guan li =. https://doi.org/10.37155/3041-0827-0207-5.	en	public	published	f	2026-07-30 16:18:48.46219+08	openalex_import	2026-07-30 16:18:48.46219+08	2026-07-30 16:18:48.46219+08	\N	\N	\N	\N
190	3	LIT-000190	水利工程设备监造中的无损检测技术应用	\N	paper	水利工程设备质量直接关乎工程安全与运行稳定性，监造环节是质量管控的关键。本文聚焦无损检测技 术在水利工程设备监造中的应用，先明确水利工程关键设备类型及监造重点，分析监造对检测技术的核心要求与无损 检测适配性；再梳理超声、射线等常用无损检测技术核心要点；最后探讨该技术在原材料、制造过程、装配与出厂等 监造环节的具体应用。研究旨在为水利工程设备监造提供科学的无损检测技术应用依据，提升监造质量与效率。	\N	工程施工新技术	\N	\N	2026	\N	\N	\N	10.37155/2811-0609-0507-55	\N	\N	https://doi.org/10.37155/2811-0609-0507-55	贝 许. (2026). 水利工程设备监造中的无损检测技术应用. 工程施工新技术. https://doi.org/10.37155/2811-0609-0507-55.	en	public	published	f	2026-07-30 16:18:48.465168+08	openalex_import	2026-07-30 16:18:48.465168+08	2026-07-30 16:18:48.465168+08	\N	\N	\N	\N
191	3	LIT-000191	机械工程材料与热加工工艺	\N	paper	为契合高端制造产业对机械装备性能的升级需求，分析材料与加工工艺的内在关联，本文围绕机械工程 材料与热加工工艺的核心关联展开研究，系统梳理材料的分类、关键性能及热加工工艺的基础理论与分类，深入分析 金属与非金属材料的热加工工艺及应用机理，探讨热加工工艺与材料性能的影响规律及适配性设计路径，预判行业未 来发展趋势。研究结合材料特性与工艺原理，明确二者协同优化的核心逻辑，为机械工程领域材料选型、工艺优化及 性能提升提供理论参考，助力行业向高性能、智能化、绿色化方向转型，满足高端制造对材料与加工技术的需求。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0809-54	\N	\N	https://doi.org/10.37155/2717-5197-0809-54	孙宏伟. (2026). 机械工程材料与热加工工艺. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0809-54.	en	public	published	f	2026-07-30 16:18:48.467705+08	openalex_import	2026-07-30 16:18:48.467705+08	2026-07-30 16:18:48.467705+08	\N	\N	\N	\N
192	3	LIT-000192	工程机械齿轮加工与热处理工艺研究	\N	paper	1. 来稿要真实性、科学性和科学性，资料可靠真实，数据准确详实，逻辑严密、文字精炼。 2. 来稿文责自负。所有作者应对稿件内容和署名无异议，稿件内容不得抄袭或重复发表。 3. 文章题目要简短精炼，准确概括文章中心内容，不超过20字。各级标题的编码方法为：第一级标题用一、二、三……依次编码；第二级用标题（一）（二）（三）……依次编码；第三级用1，2，3……依次编码。示例如下： 一、第一级标题 （一）第二级标题 （二）第二级标题 1. 第三级标题 2. 第三级标题 二、第一级标题 4. 来稿必须附有100-250字的摘要，一般应包括：目的、方法、结果和结论。需提供3-5个关键词，用分号隔开。 5. 英文标题、摘要、关键词及作者单位务必附在标题页。 6. 来稿必须附有第一作者和通讯作者的简介，包括真实姓名、出生年月、性别、民族、籍贯、工作单位、职务、职称、学位、研究方向等（研究生须注明博士研究生或硕士研究生）；其他作者附真实姓名、工作单位、职务、职称、邮编等。 7. 已被录用稿件原则上不允许更改作者顺序，或增删作者等。 8. 来稿正文字数一般以3000-6000字为宜 （不包括题目、作者信息、图表、参考文献）。 9. 文章格式一般包括：题目、作者及单位、通讯作者地址、邮编、内容摘要、关键词、正文、参考文献等。 10. 参考文献格式采用顺序编码制，请按文中出现的先后顺序编号；在文中引文出现的地方以阿拉伯数字按序编码并用方括号括起来上标；在文末列出参考文献需与正文中的标注序号一一对应。参考文献不少于8条。 1）著作类：[序号]作者．书名[M]．出版地：出版社，出版年，页码． 2）报纸、期刊论文类：[序号]作者．文章题目．报纸名/刊名[N/J]．年代（期、版次）：起止页码． 3）电子文献：[序号]作者．电子文献题目[EB/OL]．电子文献出处或可获得地址，发表日期/引用日期． 4）学位论文：[序号]作者．论文题目[D]：[硕士或博士学位论文]．保存地：保存单位，年份． 5）论文集中的析出文献：[序号]析出文献作者．析出文献题名[A]．原文献作者．原文献题名[C]．出版地：出版者，出版年．析出文献起止页码． 6）专利：[序号]专利申请者．专利名称[P]．国别，专利号．出版日期． 7）技术标准：[序号]起草责任者．标准编号．标准名称[S]．出版地： 出版社，出版年． 11. 参考文献中的标点符号以英文半角符号书写，字体请用Times New Roman。各类参考文献的标识符号是：专著[M]、论文集[C]、期刊文章[J]、报纸文章[N]、学位论文[D]、报告[R]、标准[S]、专利[P]、论文集中的析出文献[A]、各种未定义的文献[Z]。 12. 图表要求：文中表格建议采用三线表，表名置于表上方居中；文中图像要清晰可编辑，将图名置于图下方居中；图表如使用缩略语，需在图表注中说明。图表编号一律用阿拉伯数字，图表标号依次排列，如表1、表2、表3，图1、图2、图3。 13. 计量单位请参照中华人民共和国法定计量单位最新标准。外文字符必须分清大、小写，正、斜体，黑、白体，上下角标应区别明显（必要时可旁注说明）。 14. 缩略词在文中第一次出现时应给予明确定义。中英文缩略词都应在全文中统一。 15. 稿件必须采用Word格式随邮件的附件发送或在线提交稿件。 16. 来稿请注明通讯作者的详细联系地址、邮编、邮箱、联系电话。 17. 来稿如为研究课题或课题/项目/基金支持论文，请注明课题名称、审批机关、基金项目名称、年度及其项目编号。多项基金项目应依次列出，其间以分号“；”隔开。 18. 编辑部对来稿有删修权，不同意删修的稿件请在来稿中声明。 19. 所有来稿均不退，请作者自留底稿。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0809-55	\N	\N	https://doi.org/10.37155/2717-5197-0809-55	贾俊豪, 丁树猛, 何玉林, 王娜娜. (2026). 工程机械齿轮加工与热处理工艺研究. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0809-55.	en	public	published	f	2026-07-30 16:18:48.470499+08	openalex_import	2026-07-30 16:18:48.470499+08	2026-07-30 16:18:48.470499+08	\N	\N	\N	\N
193	3	LIT-000193	浅谈冶金机械及自动化	\N	paper	\N	\N	工程学研究与实用	\N	\N	2026	\N	\N	\N	10.37155/2717-5316-0707-2	\N	\N	https://doi.org/10.37155/2717-5316-0707-2	卢登攀, 高丙江. (2026). 浅谈冶金机械及自动化. 工程学研究与实用. https://doi.org/10.37155/2717-5316-0707-2.	en	public	published	f	2026-07-30 16:18:48.477792+08	openalex_import	2026-07-30 16:18:48.477792+08	2026-07-30 16:18:48.477792+08	\N	\N	\N	\N
194	3	LIT-000194	Effect of Different Annealing Processes on the Mechanical Properties of Tungsten-Copper Alloys	\N	paper	In this study, tungsten-copper (W-Cu) alloys prepared by the infiltration method were used as the research object to systematically investigate the effects of two key parameters in the annealing process, namely annealing temperature and holding time, on their microstructure and mechanical properties. The specimens were subjected to annealing heat treatment using a vacuum tube furnace, and two sets of parallel annealing process schemes were designed by the single-factor control variable method: the first scheme fixed the holding time at 1 h and set annealing temperatures of 740, 790, 840, 890, and 940 ℃ to form a temperature gradient, while the second scheme fixed the annealing temperature at 790 ℃ and set holding times of 0.5, 1, 2, 3, and 4 h to form a time gradient. The microstructure characterization and mechanical property testing of the specimens were carried out using a metallographic microscope, X-ray diffractometer (XRD), Vickers hardness tester, high-temperature vacuum electronic tensile testing machine, and high-temperature electronic universal testing machine (for three-point bending tests). The results show that the as-prepared specimens contain a large number of incompletely filled pores, resulting in poor mechanical properties; after annealing at 890 ℃ for 1 h or 790 ℃ for 2 h, the pores are almost completely filled and the distribution of the copper phase tends to be uniform, whereas annealing at 940 ℃ for 1 h or 790 ℃ for 4 h leads to the formation of microcracks and copper grain coarsening. The hardness reaches a peak value of 344.5 HV after annealing at 790 ℃ for 2 h, which is 10.5% higher than that of the as-prepared specimen; the bending strength reaches a peak value of 1 079.5 MPa after annealing at 840 ℃ for 1 h, representing a 60% improvement compared with the as-prepared specimen; after annealing at 790 ℃ for 1 h, the residual stress is almost completely released and the copper phase exhibits the best plasticity, at which point the fracture deflection reaches a peak value of 0.21 mm (123% higher than that of the as-prepared specimen) and the fracture energy also reaches a peak value of 11.98 mJ/mm<sup>2</sup>, showing a remarkable 340% increase compared with the as-prepared specimen. It can be concluded that both annealing temperature and holding time have significant effects on the properties of tungsten-copper alloys.	\N	He'nan kexue	\N	\N	2026	\N	\N	\N	10.3724/j.issn.1004-3918.2026.094	\N	\N	https://doi.org/10.3724/j.issn.1004-3918.2026.094	Yi ZHANG, Chunlong Tian, Yi Wang, Yong YANG. (2026). Effect of Different Annealing Processes on the Mechanical Properties of Tungsten-Copper Alloys. He'nan kexue. https://doi.org/10.3724/j.issn.1004-3918.2026.094.	en	public	published	f	2026-07-30 16:18:48.483761+08	openalex_import	2026-07-30 16:18:48.483761+08	2026-07-30 16:18:48.483761+08	\N	\N	\N	\N
195	3	LIT-000195	钢筋混凝土结构建筑建材的碳排放影响因素研究	\N	paper	\N	\N	工程管理与技术探讨	\N	\N	2026	\N	\N	\N	10.37155/2717-5189-0808-60	\N	\N	https://doi.org/10.37155/2717-5189-0808-60	亮 赵. (2026). 钢筋混凝土结构建筑建材的碳排放影响因素研究. 工程管理与技术探讨. https://doi.org/10.37155/2717-5189-0808-60.	en	public	published	t	2026-07-30 16:18:48.494627+08	openalex_import	2026-07-30 16:18:48.494627+08	2026-07-30 16:18:48.494627+08	\N	\N	\N	\N
223	3	LIT-000223	绿色氧化技术在有机合成中的研究现状与环境效益	\N	paper	氧化反应作为有机合成化学中构建分子骨架、引入官能团的核心转化，在医药、农药等领域应用广泛。 但传统氧化方法依赖高毒性、高腐蚀性的化学计量氧化剂，或产生大量有害副产物，威胁生态环境与人类健康。在可 持续发展理念和环保法规推动下，发展高效、安全、环境友好的绿色氧化技术成为有机合成领域重要研究方向。本文 综述近年来绿色氧化技术进展，重点阐述以分子氧和过氧化氢为终端氧化剂的催化氧化体系、电化学氧化、光催化氧 化及生物催化氧化等前沿策略。分析各类技术的反应机理、催化剂设计等情况，探讨其相比传统方法在提升原子经济 性、减少废弃物、降低能耗及增强安全性等方面的环境效益。最后展望其挑战与未来趋势，为有机合成工业转型提供 参考。	\N	现代工程项目管理	\N	\N	2026	\N	\N	\N	10.37155/2811-0625-0507-62	\N	\N	https://doi.org/10.37155/2811-0625-0507-62	通 刘. (2026). 绿色氧化技术在有机合成中的研究现状与环境效益. 现代工程项目管理. https://doi.org/10.37155/2811-0625-0507-62.	en	public	published	f	2026-07-30 16:19:09.34317+08	openalex_import	2026-07-30 16:19:09.34317+08	2026-07-30 16:19:09.34317+08	\N	\N	\N	\N
196	3	LIT-000196	煤炭产品碳足迹评估研究综述	\N	paper	煤炭作为支撑中国国民经济发展的主体能源，精准核算煤炭产品全生命周期碳足迹是推动煤炭产业链低碳转型的基础与前提，也是支撑中国碳足迹管理体系建设和应对国际涉碳贸易壁垒的必然要求。本文梳理了煤炭产品的生命周期过程及主要排放源，基于文献调研系统综述了煤炭产品碳足迹评估研究的现状，并对比了2000—2024年发表的22项基于生命周期评价的煤炭碳足迹研究，发现不同研究开展煤炭碳足迹评估时采用的功能单位、系统边界、数据来源等具有很强的不一致性。对比分析发现，不同国家（地区）的煤炭碳足迹差异显著，例如，部分研究中澳大利亚的“从摇篮到大门”煤炭碳足迹（31.2 kg CO2e/t）显著低于印度尼西亚（314.0 kg CO2e/t）和中国（部分研究高达499.0 kg CO2e/t）的案例；此外，煤炭“从摇篮到大门”的碳足迹（19.8~835.0 kg CO2e/t）与“从摇篮到坟墓”的碳足迹（1526.4~2988.1 kg CO2e/t）差异巨大。碳足迹结果的差异一方面来源于研究对象本身的不同，另一方面也会受研究方法差异的影响。本文进一步对比分析了不同研究的功能单位、系统边界、清单数据来源、影响评价方法等可能影响碳足迹评估结果的关键问题与假设。在此基础上，从煤炭产品碳足迹评估的方法规范性、过程透明性、数据可获得性、样本代表性等方面提出了现有研究的不足和完善中国煤炭产品碳足迹评估方法的建议，为推进中国煤炭产品碳足迹核算规则标准的编制和碳足迹管理体系的建设提供了科学支撑。	\N	资源科学	\N	\N	2026	\N	\N	\N	10.18402/resci.2026.05.04	\N	\N	https://doi.org/10.18402/resci.2026.05.04	Guosong Ma, Maosheng DUAN. (2026). 煤炭产品碳足迹评估研究综述. 资源科学. https://doi.org/10.18402/resci.2026.05.04.	en	public	published	f	2026-07-30 16:18:48.497156+08	openalex_import	2026-07-30 16:18:48.497156+08	2026-07-30 16:18:48.497156+08	\N	\N	\N	\N
197	3	LIT-000197	基于公铁联运的沥青集装箱多式联运路径优化研究	\N	paper	随着“一带一路”倡议与西部陆海新通道建设推进，构建高效、绿色、低成本的现代物流体系成为区域 高质量发展的关键。针对沥青传统运输存在损耗高、成本高、效率低等问题，本文以云南交投集团现代物流有限公司（以 下简称本公司）的“沥青集装箱海铁公多式联运试点项目”为研究对象，系统提出基于公铁联运的路径优化方案。研 究结合项目背景与战略目标，通过市场分析与需求预测论证其可行性，并从设备选型、服务采购、组织运营等方面构 建完整优化模型，辅以财务分析与风险评估量化效益。结果表明，“一箱到底”的海铁公联运模式可显著降低综合物 流成本、缩短运输周期、实现全程零损耗，有效提升企业竞争力与品牌影响力。该研究为大宗液体化工品多式联运提 供了可复制、可推广的实践范式。	\N	工程学研究与实用	\N	\N	2026	\N	\N	\N	10.37155/2717-5316-0710-80	\N	\N	https://doi.org/10.37155/2717-5316-0710-80	强 杨. (2026). 基于公铁联运的沥青集装箱多式联运路径优化研究. 工程学研究与实用. https://doi.org/10.37155/2717-5316-0710-80.	en	public	published	f	2026-07-30 16:18:48.500872+08	openalex_import	2026-07-30 16:18:48.500872+08	2026-07-30 16:18:48.500872+08	\N	\N	\N	\N
198	3	LIT-000198	国土空间规划视域下资源型城市绿色发展：理论逻辑、现实困境与实现路径	\N	paper	资源型城市绿色发展是生态文明建设的关键议题。本文构建“动力—载体—目标”三维分析框架，阐释国土空间规划视域下资源型城市绿色发展的理论逻辑、现实困境与实现路径。研究发现，资源型城市面临“高碳锁定—就业刚性—生态容量不足”三重困境，新质生产力通过技术梯度扩散、要素空间黏性重构与制度跨尺度耦合三重机制赋能绿色发展，协同创新网络、要素配置优化、跨尺度制度协同与包容性增长推进构成四维度实现路径。	\N	人文与社会科学学刊	\N	\N	2026	\N	\N	\N	10.70693/rwsk.v2i7.640	\N	\N	https://doi.org/10.70693/rwsk.v2i7.640	董桂彬. (2026). 国土空间规划视域下资源型城市绿色发展：理论逻辑、现实困境与实现路径. 人文与社会科学学刊. https://doi.org/10.70693/rwsk.v2i7.640.	zh	public	published	f	2026-07-30 16:18:48.503095+08	openalex_import	2026-07-30 16:18:48.503095+08	2026-07-30 16:18:48.503095+08	\N	\N	\N	\N
199	3	LIT-000199	空分技术在化工生产与煤化工中的应用及发展趋势	\N	paper	空分技术以空气组分物理性质差异为基础，通过低温蒸馏等手段实现气体分离，在化工生产中有着广泛 应用。本文阐述空分技术基础与工艺流程，分析其在基础化工原料制备、工艺过程支持及产品提纯加工等方面的应用， 探讨空分设备在煤气化、煤液化及煤化工联产系统中的应用。同时，指出空分技术与设备在技术升级、煤化工适配性 改进及绿色低碳转型方面的发展趋势。空分技术持续创新，为化工产业高质量发展提供有力支撑，推动行业向高效、 绿色方向迈进。	\N	Gong cheng ji shu yu zhi liang guan li =	\N	\N	2026	\N	\N	\N	10.37155/3041-0827-0207-52	\N	\N	https://doi.org/10.37155/3041-0827-0207-52	徐世安, 林 石, 凯 乐. (2026). 空分技术在化工生产与煤化工中的应用及发展趋势. Gong cheng ji shu yu zhi liang guan li =. https://doi.org/10.37155/3041-0827-0207-52.	en	public	published	t	2026-07-30 16:18:48.5061+08	openalex_import	2026-07-30 16:18:48.5061+08	2026-07-30 16:18:48.5061+08	\N	\N	\N	\N
200	3	LIT-000200	关于建筑材料中耐火材料的发展及技术特点分析	\N	paper	\N	\N	城市建筑与发展	\N	\N	2024	\N	\N	\N	10.37155/2717-557x-0516-14	\N	\N	https://doi.org/10.37155/2717-557x-0516-14	于 乔, 唐天晟. (2024). 关于建筑材料中耐火材料的发展及技术特点分析. 城市建筑与发展. https://doi.org/10.37155/2717-557x-0516-14.	zh	public	published	f	2026-07-30 16:18:48.509861+08	openalex_import	2026-07-30 16:18:48.509861+08	2026-07-30 16:18:48.509861+08	\N	\N	\N	\N
201	3	LIT-000201	Research Progresses on Sources, Accumulation Processes, and Influencing Factors of Cadmium in the Soil-rice System	\N	paper	Soil cadmium contamination has emerged as a prominent environmental issue affecting the safe production of rice and human health in China. As a staple crop, rice (<italic>Oryza sativa</italic> L.) exhibits a strong capacity for cadmium accumulation, readily transferring and concentrating cadmium from the soil into its grains. This leads to excessive cadmium levels in rice, posing a threat to human health through the food chain. This paper provides a systematic review of cadmium sources, accumulation processes, and influencing factors within the soil-rice system. It first clarifies the primary sources of cadmium in this system, identifying atmospheric deposition and industrial mining activities as the main anthropogenic sources. Weathering of carbonate rocks and black shales contributes to elevated background cadmium levels in the soils of southwest China. It then explains the pathways through which cadmium enters rice plants via root and leaf uptake, exploring key stages and mechanisms of cadmium migration and accumulation in grains. Among these processes, transporters such as <italic>OsHMA3</italic>, <italic>OsNramp5</italic>, and <italic>OsZIP7</italic> play crucial roles in regulating cadmium absorption and transport processes in rice plants. Furthermore, this paper focuses on discussing the primary factors affecting cadmium uptake, highlighting that variations in soil pH, Eh, and cadmium speciation significantly impact rice cadmium uptake and transport. Finally, it outlines future research directions, aiming to provide theoretical foundations and references for the remediation of cadmium-polluted farmland and the safe production of rice.	\N	EARTH AND ENVIRONMENT	\N	\N	2026	\N	\N	\N	10.3724/ee.1672-9250.2026.54.150	\N	\N	https://doi.org/10.3724/ee.1672-9250.2026.54.150	Huahui CHEN, Lu Qiao, Haiyan HU, Yizhang LIU, Ping LI. (2026). Research Progresses on Sources, Accumulation Processes, and Influencing Factors of Cadmium in the Soil-rice System. EARTH AND ENVIRONMENT. https://doi.org/10.3724/ee.1672-9250.2026.54.150.	en	public	published	f	2026-07-30 16:18:48.512436+08	openalex_import	2026-07-30 16:18:48.512436+08	2026-07-30 16:18:48.512436+08	\N	\N	\N	\N
202	3	LIT-000202	高强钢在大型集装箱船船体结构中的应用与焊接性能评估	\N	paper	\N	\N	工程施工新技术	\N	\N	2026	\N	\N	\N	10.37155/2811-0609-0510-32	\N	\N	https://doi.org/10.37155/2811-0609-0510-32	任精玲. (2026). 高强钢在大型集装箱船船体结构中的应用与焊接性能评估. 工程施工新技术. https://doi.org/10.37155/2811-0609-0510-32.	en	public	published	t	2026-07-30 16:18:48.520006+08	openalex_import	2026-07-30 16:18:48.520006+08	2026-07-30 16:18:48.520006+08	\N	\N	\N	\N
203	3	LIT-000203	煤气回收作业人员的安全培训与操作规范研究	\N	paper	煤气（主要指高炉煤气、转炉煤气和焦炉煤气）作为钢铁、化工等行业的重要二次能源，在回收利用过 程中蕴含着巨大的安全风险。煤气回收作业环境复杂、介质易燃易爆且具有剧毒性，一旦发生泄漏、爆炸或中毒事 故，极易造成群死群伤的重大安全事故。因此，对煤气回收作业人员开展系统化、专业化、常态化的安全培训，并建 立科学严谨的操作规范体系，是保障企业安全生产、维护员工生命健康、实现绿色低碳发展的关键举措。本文在分析 煤气回收工艺特点及典型危险源的基础上，深入探讨当前安全培训与操作规范中存在的主要问题，进而从培训内容体 系构建、培训方式创新、操作规程标准化、应急处置能力提升以及安全文化建设等多个维度，提出一套系统性的优化 策略，旨在为相关行业提供理论参考与实践指导。	\N	工程管理与技术探讨	\N	\N	2026	\N	\N	\N	10.37155/2717-5189-0810-15	\N	\N	https://doi.org/10.37155/2717-5189-0810-15	波 薛. (2026). 煤气回收作业人员的安全培训与操作规范研究. 工程管理与技术探讨. https://doi.org/10.37155/2717-5189-0810-15.	en	public	published	f	2026-07-30 16:18:48.522674+08	openalex_import	2026-07-30 16:18:48.522674+08	2026-07-30 16:18:48.522674+08	\N	\N	\N	\N
204	3	LIT-000204	有色冶金行业大气多污染物全过程控制耦合技术	\N	paper	随着我国生态文明建设的深入推进和“双碳”战略目标的提出，有色冶金行业作为高能耗、高排放的重 点工业领域，其大气污染治理面临前所未有的挑战。传统末端治理模式已难以满足日益严格的环保标准与资源高效利 用需求。本文系统分析了有色冶金典型工艺（如铜冶炼、铅锌冶炼、铝电解等）中SO₂、NOₓ、颗粒物、重金属（As、 Pb、Hg、Cd等）、二噁英及氟化物等多污染物的产生特征与协同生成机制；在此基础上，提出“源头削减—过程控制— 末端深度净化—资源化利用”四位一体的全过程控制理念，并重点阐述了基于多污染物协同脱除、能量梯级利用与副 产物资源化的耦合技术体系。最后，对有色冶金大气污染控制技术的发展趋势进行了展望，为行业绿色高质量发展提 供理论支撑与技术参考。	\N	工程施工新技术	\N	\N	2026	\N	\N	\N	10.37155/2811-0609-0509-56	\N	\N	https://doi.org/10.37155/2811-0609-0509-56	吴联盟. (2026). 有色冶金行业大气多污染物全过程控制耦合技术. 工程施工新技术. https://doi.org/10.37155/2811-0609-0509-56.	en	public	published	f	2026-07-30 16:18:58.274739+08	openalex_import	2026-07-30 16:18:58.274739+08	2026-07-30 16:18:58.274739+08	\N	\N	\N	\N
205	3	LIT-000205	城市更新项目中机电拆除探讨	\N	paper	1. 来稿要真实性、科学性和科学性，资料可靠真实，数据准确详实，逻辑严密、文字精炼。 2. 来稿文责自负。所有作者应对稿件内容和署名无异议，稿件内容不得抄袭或重复发表。 3. 文章题目要简短精炼，准确概括文章中心内容，不超过20字。各级标题的编码方法为：第一级标题用一、二、三……依次编码；第二级用标题（一）（二）（三）……依次编码；第三级用1，2，3……依次编码。示例如下： 一、第一级标题 （一）第二级标题 （二）第二级标题 1. 第三级标题 2. 第三级标题 二、第一级标题 4. 来稿必须附有100-250字的摘要，一般应包括：目的、方法、结果和结论。需提供3-5个关键词，用分号隔开。 5. 英文标题、摘要、关键词及作者单位务必附在标题页。 6. 来稿必须附有第一作者和通讯作者的简介，包括真实姓名、出生年月、性别、民族、籍贯、工作单位、职务、职称、学位、研究方向等（研究生须注明博士研究生或硕士研究生）；其他作者附真实姓名、工作单位、职务、职称、邮编等。 7. 已被录用稿件原则上不允许更改作者顺序，或增删作者等。 8. 来稿正文字数一般以3000-6000字为宜 （不包括题目、作者信息、图表、参考文献）。 9. 文章格式一般包括：题目、作者及单位、通讯作者地址、邮编、内容摘要、关键词、正文、参考文献等。 10. 参考文献格式采用顺序编码制，请按文中出现的先后顺序编号；在文中引文出现的地方以阿拉伯数字按序编码并用方括号括起来上标；在文末列出参考文献需与正文中的标注序号一一对应。参考文献不少于8条。 1）著作类：[序号]作者．书名[M]．出版地：出版社，出版年，页码． 2）报纸、期刊论文类：[序号]作者．文章题目．报纸名/刊名[N/J]．年代（期、版次）：起止页码． 3）电子文献：[序号]作者．电子文献题目[EB/OL]．电子文献出处或可获得地址，发表日期/引用日期． 4）学位论文：[序号]作者．论文题目[D]：[硕士或博士学位论文]．保存地：保存单位，年份． 5）论文集中的析出文献：[序号]析出文献作者．析出文献题名[A]．原文献作者．原文献题名[C]．出版地：出版者，出版年．析出文献起止页码． 6）专利：[序号]专利申请者．专利名称[P]．国别，专利号．出版日期． 7）技术标准：[序号]起草责任者．标准编号．标准名称[S]．出版地： 出版社，出版年． 11. 参考文献中的标点符号以英文半角符号书写，字体请用Times New Roman。各类参考文献的标识符号是：专著[M]、论文集[C]、期刊文章[J]、报纸文章[N]、学位论文[D]、报告[R]、标准[S]、专利[P]、论文集中的析出文献[A]、各种未定义的文献[Z]。 12. 图表要求：文中表格建议采用三线表，表名置于表上方居中；文中图像要清晰可编辑，将图名置于图下方居中；图表如使用缩略语，需在图表注中说明。图表编号一律用阿拉伯数字，图表标号依次排列，如表1、表2、表3，图1、图2、图3。 13. 计量单位请参照中华人民共和国法定计量单位最新标准。外文字符必须分清大、小写，正、斜体，黑、白体，上下角标应区别明显（必要时可旁注说明）。 14. 缩略词在文中第一次出现时应给予明确定义。中英文缩略词都应在全文中统一。 15. 稿件必须采用Word格式随邮件的附件发送或在线提交稿件。 16. 来稿请注明通讯作者的详细联系地址、邮编、邮箱、联系电话。 17. 来稿如为研究课题或课题/项目/基金支持论文，请注明课题名称、审批机关、基金项目名称、年度及其项目编号。多项基金项目应依次列出，其间以分号“；”隔开。 18. 编辑部对来稿有删修权，不同意删修的稿件请在来稿中声明。 19. 所有来稿均不退，请作者自留底稿。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0808-45	\N	\N	https://doi.org/10.37155/2717-5197-0808-45	支作伟. (2026). 城市更新项目中机电拆除探讨. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0808-45.	en	public	published	f	2026-07-30 16:18:58.282711+08	openalex_import	2026-07-30 16:18:58.282711+08	2026-07-30 16:18:58.282711+08	\N	\N	\N	\N
206	3	LIT-000206	X射线荧光光谱分析法在矿石检测中的应用与实践	\N	paper	X射线荧光光谱（XRF）技术基于X射线激发物质产生特征荧光的原理实现成分分析，具有非破坏性特 点。其仪器分波长色散型和能量色散型，近年技术进展显著。XRF在矿石检测中应用广泛，涵盖成分分析、品位评 估、勘探资源评估及环境监测等场景。实践需做好样品制备、基体效应校正等工作。通过铜金属矿区、稀土矿分析等 案例及便携式XRF实用性验证，表明XRF技术能提升矿石检测效率与精度，降低生产成本，助力矿业发展。	\N	工程学研究与实用	\N	\N	2026	\N	\N	\N	10.37155/2717-5316-0705-44	\N	\N	https://doi.org/10.37155/2717-5316-0705-44	宦玮, 冀佳怡. (2026). X射线荧光光谱分析法在矿石检测中的应用与实践. 工程学研究与实用. https://doi.org/10.37155/2717-5316-0705-44.	en	public	published	f	2026-07-30 16:18:58.289248+08	openalex_import	2026-07-30 16:18:58.289248+08	2026-07-30 16:18:58.289248+08	\N	\N	\N	\N
207	3	LIT-000207	浅谈土壤环境质量影响状况及成因分析	\N	paper	土壤是生态系统重要组成部分,对生态系统健康循环有着重要作用,随着经济发展,越 来越多土壤遭受污染,人类身体健康受到巨大威胁,因此做好土壤治理修复至关重要 。通过对污染土壤修复,降低污染物排放和转移,对于构建健康可持续生态系统至关 重要。本文主要对土壤环境质量污染成因以及土壤修复策略开展讨论。	\N	生态环境与保护	\N	\N	2026	\N	\N	\N	10.32629/eep.v9i4.3144	\N	\N	https://doi.org/10.32629/eep.v9i4.3144	政 杨, 纯 唐, 龙 刘, 刚 武, 婷婷 田. (2026). 浅谈土壤环境质量影响状况及成因分析. 生态环境与保护. https://doi.org/10.32629/eep.v9i4.3144.	zh	public	published	f	2026-07-30 16:18:58.29662+08	openalex_import	2026-07-30 16:18:58.29662+08	2026-07-30 16:18:58.29662+08	\N	\N	\N	\N
208	3	LIT-000208	固体废物处理与资源化利用途径探索	\N	paper	\N	\N	工程管理与技术探讨	\N	\N	2026	\N	\N	\N	10.37155/2717-5189-0809-62	\N	\N	https://doi.org/10.37155/2717-5189-0809-62	翔 李. (2026). 固体废物处理与资源化利用途径探索. 工程管理与技术探讨. https://doi.org/10.37155/2717-5189-0809-62.	en	public	published	f	2026-07-30 16:18:58.30439+08	openalex_import	2026-07-30 16:18:58.30439+08	2026-07-30 16:18:58.30439+08	\N	\N	\N	\N
209	3	LIT-000209	采矿工程废弃物资源化利用途径与环境效益评价	\N	paper	随着全球矿产资源需求的持续增长，采矿活动产生的工程废弃物（主要包括废石、尾矿和煤矸石等）数量 急剧攀升，已成为制约矿业可持续发展的关键瓶颈。本文系统梳理了采矿工程废弃物的主要类型及其环境风险特征，深 入探讨了当前主流的资源化利用技术路径，包括在建筑材料、充填采空区、有价元素回收、土壤改良与生态修复以及新 兴高值化利用等领域的应用。在此基础上，构建了一个涵盖资源节约、污染减排、生态修复和经济效益四个维度的综合 环境效益评价体系。科学、高效的资源化利用不仅能显著降低废弃物的环境足迹，还能创造可观的经济价值，是实现矿 业绿色低碳转型的核心策略。本文研究旨在为我国乃至全球矿业的可持续发展提供理论参考与实践指导。	\N	城市建筑与发展	\N	\N	2026	\N	\N	\N	10.37155/2717-557x-0707-18	\N	\N	https://doi.org/10.37155/2717-557x-0707-18	宋晓彬. (2026). 采矿工程废弃物资源化利用途径与环境效益评价. 城市建筑与发展. https://doi.org/10.37155/2717-557x-0707-18.	en	public	published	f	2026-07-30 16:18:58.307159+08	openalex_import	2026-07-30 16:18:58.307159+08	2026-07-30 16:18:58.307159+08	\N	\N	\N	\N
256	3	LIT-000256	水利水电工程防渗技术研究	\N	paper	水利水电工程渗漏问题直接威胁工程安全与功能发挥，是工程建设与运维的核心防控要点。本文针对水 利水电工程渗漏成因及危害展开分析，明确地质、设计、施工及运维为主要成因，渗漏危害涵盖安全、功能、经济及 生态多维度。系统探讨坝基、坝体、渠道及边坡防渗关键技术要点，阐述新型防渗材料的应用规范。研究旨在为水利 水电工程防渗设计、施工及材料选型提供技术参考，助力提升工程防渗效果与长效稳定性，保障工程安全高效运行。	\N	水利电力技术与应用	\N	\N	2026	\N	\N	\N	10.37155/2717-5251-0809-62	\N	\N	https://doi.org/10.37155/2717-5251-0809-62	石书苹. (2026). 水利水电工程防渗技术研究. 水利电力技术与应用. https://doi.org/10.37155/2717-5251-0809-62.	en	public	published	f	2026-07-30 16:19:18.347022+08	openalex_import	2026-07-30 16:19:18.347022+08	2026-07-30 16:19:18.347022+08	\N	\N	\N	\N
210	3	LIT-000210	矿化过程中铁-稀土组合的成因机理讨论与展望	\N	paper	稀土元素是现代社会实现绿色能源转型的关键金属,全球对稀土的需求日益增加。矿化过程中,铁和稀土元素经常共生,指示稀土具有亲铁性。本文定义"铁-稀土组合"概念,描述铁和稀土元素共同富集的矿化体,并将其分为三类:(1)伴生稀土的铁矿,如铁氧化物铜金(IOCG)矿床、铁氧化物磷灰石(IOA)矿床和Bastn&#228;s型Fe-REE矿床(一类特殊的矽卡岩矿床);(2)铁和稀土均有经济价值或经济价值潜力的矿化体,如钛铁磷灰岩、部分碳酸岩矿床(白云鄂博、Yangibana)和海洋富稀土沉积物;(3)稀土矿中铁-稀土共同富集的地质体,如过碱性花岗岩矿床中赤铁矿化的富稀土矿石和离子吸附型稀土矿中铁-稀土共同富集的层位。目前资料表明,这些"铁-稀土组合"赋存全球约一半稀土资源。本文综述并探讨了矿化过程中"铁-稀土组合"的成因机理。经归纳,铁-稀土共同富集的地质过程包括:成矿岩浆热液体系的源区同时富集铁和稀土;富铁/铁磷酸盐熔体-硅酸盐熔体不混溶过程稀土倾向分配进入富铁熔体;铁和稀土在碳酸岩岩浆演化过程均为不相容元素而逐渐富集;热液交代和风化过程释放稀土元素并形成铁(氢)氧化物;海底热液柱活动形成铁(氢)氧化物并吸附稀土等。通过综述和归纳,铁-稀土共同富集的机理主要在于:(1)岩浆体系中,富Fe和Ca、Mg、P、Ti元素的熔体通常聚合度较低,稀土倾向进入低聚合度熔体;(2)热液交代和风化过程中,铁(氢)氧化物的形成常伴随稀土从含稀土矿物中释放,并且能增加容矿孔隙以及矿物比表面积或反应面积;(3)大洋沉积环境和风化壳中,铁(氢)氧化物比表面积大,容易吸附稀土离子。未来可开展如下研究完善铁-稀土共同富集理论:剖析热液交代成矿过程中矿物和铁-稀土元素变化;开展岩浆-蒸发岩/碳酸盐岩反应和盐熔/流体铁-稀土溶解度实验;开展铁矿浆-碳酸岩熔体不混溶以及富铁碳酸岩熔体结晶分异实验;探究Fe和Ca、Mg、P、Ti含量对碳酸盐/硅酸盐熔体稀土溶解度的影响;评估海洋"铁-稀土组合"俯冲循环效应;检验岩浆热液体系中铁(氢)氧化物能否吸附磷和稀土;验证富铁或铁磷酸盐熔体玻璃溶解与富铁-稀土沉积物的关系。	\N	Acta Petrologica Sinica	\N	\N	2026	\N	\N	\N	10.18654/1000-0569/2026.07.16	\N	\N	https://doi.org/10.18654/1000-0569/2026.07.16	Shengchao Yan, Bo Wan, XY Li. (2026). 矿化过程中铁-稀土组合的成因机理讨论与展望. Acta Petrologica Sinica. https://doi.org/10.18654/1000-0569/2026.07.16.	en	public	published	f	2026-07-30 16:18:58.309591+08	openalex_import	2026-07-30 16:18:58.309591+08	2026-07-30 16:18:58.309591+08	\N	\N	\N	\N
211	3	LIT-000211	Research Progress on Replacing Phenol-Based Extractants in the Rubidium and Cesium Separation and Recovery	\N	paper	铷(Rb)和铯(Cs)作为重要的稀有碱金属资源，在航空航天、新能源、电子信息及国防军工等高科技领域具有不可替代的战略价值。然而，二者与大量化学性质相近的钾、钠等离子共存于盐湖卤水和矿石浸出液中，分离提取难度极大。溶剂萃取法是当前铷铯分离的主流技术，其中以4-叔丁基-2-(α-甲基苄基)苯酚(t-BAMBP)为代表的取代苯酚类萃取剂，凭借其基于“体积效应”的卓越选择性、快速的反应动力学和良好的循环性能，成为该领域的核心萃取剂。文章系统综述了以t-BAMBP为核心的取代苯酚类萃取剂在铷、铯分离领域的研究进展。首先，梳理了铷铯资源的分布、性质与应用现状；其次，详细阐述了萃取化学的基础，系统分析了萃取热力学与动力学机理；再次，重点介绍了从单级条件优化到多级逆流连续萃取的工艺开发策略，特别关注了针对高钾/钠背景溶液的强化分离技术；并探讨了稀释剂筛选、协同萃取体系设计、萃取剂合成与回收以及工艺过程中“固相化合物”问题在内的工艺优化与创新；最后，对比分析了不同技术路线的优缺点，对该领域未来的研究方向如绿色协同体系开发、萃取剂结构设计以及多技术耦合进行了展望。Rubidium (Rb) and cesium (Cs), as important rare alkali metal resources, have irreplaceable strategic value in high-tech fields such as aerospace, new energy, electronic information, and the national defense and military industry. However, they are often associated with large amounts of chemically similar ions such as potassium and sodium in salt lake brine and ore leachate, making their separation and extraction extremely difficult. Solvent extraction is the current mainstream technology for rubidium-cesium separation. Among the various extractants, substituted phenols represented by 4-tert-butyl-2-(α-methylbenzyl)phenol (t-BAMBP) have become the core choice in this field due to their outstanding selectivity based on the “volume effect,” rapid reaction kinetics, and good recycling performance. This paper systematically reviews the research progress on substituted phenol extractants, with a focus on t-BAMBP. The article first outlines the distribution, properties, and current applications of rubidium and cesium resources; Second, it elaborates on the fundamentals of extraction chemistry and systematically analyzes the thermodynamic and kinetic mechanisms of extraction; Third, it focuses on process development strategies ranging from single-stage condition optimization to multi-stage counter-current continuous extraction, with particular attention to specific separation techniques for high potassium/sodium background solutions; Subsequently, it discusses process optimization and innovations, including diluent selection, design of synergistic extraction systems, synthesis and recovery of extractants, and the issue of “third phase” or solid precipitate formation in the process; Finally, it compares the advantages and disadvantages of different technological routes and looks ahead to future research directions in this field, such as the development of green synergistic systems, extractant structure design, and multi-technology coupling.	\N	Material Sciences	\N	\N	2026	\N	\N	\N	10.12677/ms.2026.167165	\N	\N	https://doi.org/10.12677/ms.2026.167165	甜甜 张. (2026). Research Progress on Replacing Phenol-Based Extractants in the Rubidium and Cesium Separation and Recovery. Material Sciences. https://doi.org/10.12677/ms.2026.167165.	zh	public	published	f	2026-07-30 16:18:58.31357+08	openalex_import	2026-07-30 16:18:58.31357+08	2026-07-30 16:18:58.31357+08	\N	\N	\N	\N
212	3	LIT-000212	碰撞造山带地壳多层次熔融: 对秦岭造山带三叠纪地壳演化与多金属成矿的启示	\N	paper	本文以秦岭造山带三叠纪花岗岩为研究对象,揭示了碰撞造山过程中地壳多层次熔融的完整序列:早期以石英闪长岩为主,主要分布在秦岭造山带西段,代表下地壳基性岩高压熔融形成埃达克质岩石,岩浆性质为还原性,与金矿的形成密切相关;中期的岩浆重要分布于秦岭造山带中段,以花岗闪长岩和二长花岗岩为主,岩石大部分显示埃达克质花岗岩的地球化学属性,发育暗色微粒包体,以五龙岩体和东江口岩体最为典型,代表中下地壳熔融与幔源岩浆混合形成花岗闪长岩,与金、钼矿化密切相关;晚期的岩石类型主要为高Si花岗岩,主要分布在东段,岩浆分异程度较高,代表中上地壳变质沉积岩浅部熔融形成过高Si花岗岩,与区内的W-Mo-Be矿化密切相关。该过程阐明了华北和扬子板块俯冲碰撞的不同阶段的岩浆响应,从早期到晚期,在造山带西段到东段以从深部高压基性岩熔融到浅部变质沉积岩熔融的动力学转换,而且地壳熔融深度与不同性质金属成矿存在耦合关系:造山带西段早期埃达克质岩浆控制金矿化,中段中阶段壳幔混合岩浆主导金、钼矿化,东段晚阶段高Si花岗质岩浆流体驱动钨-钼-铍矿化。这揭示了秦岭造山带地壳多层次熔融的时空规律与岩浆-成矿响应,为碰撞造山带壳幔物质结构演化与成矿规律研究提供了范式。	\N	Acta Petrologica Sinica	\N	\N	2026	\N	\N	\N	10.18654/1000-0569/2026.07.02	\N	\N	https://doi.org/10.18654/1000-0569/2026.07.02	S. F. Lai, JiangFeng QIN, RenZhi ZHU, Min LIU. (2026). 碰撞造山带地壳多层次熔融: 对秦岭造山带三叠纪地壳演化与多金属成矿的启示. Acta Petrologica Sinica. https://doi.org/10.18654/1000-0569/2026.07.02.	en	public	published	f	2026-07-30 16:18:58.319541+08	openalex_import	2026-07-30 16:18:58.319541+08	2026-07-30 16:18:58.319541+08	\N	\N	\N	\N
214	3	LIT-000214	Critical Challenges and Recent Advances in the Commercialization of Lithium-Rich Layered Cathodes	\N	paper	富锂层状正极材料由于其独特的阴离子氧化还原机制，其理论比容量可超过300 mAh·g-1，被视为下一代高能量密度锂离子电池最具潜力的正极材料。然而，LRLO材料在实际应用中仍面临严重的容量、电压衰减、循环稳定性差以及与产业化配套协议的脱节等问题。本文阐述了该领域近期的突出进展，重点从前驱体工程、化成激活协议及实际应用中的放电深度（DOD）三个核心维度展开讨论。首先，揭示了前驱体（碳酸盐vs氢氧化物）通过改变一次颗粒堆积密度（PSD）决定材料结构稳定性的深层机制；其次，阐明了初始循环化成电压对晶体配位环境（O4-O5转变）及过渡金属迁移的调控作用；最后，针对实际工况中低放电深度（LDOD）导致的异常容量衰减，探讨了氧化态晶格氧积累的影响。研究发现这些问题是因为晶格氧的不可逆氧化还原及其伴随的复杂结构演化。本文归纳总结了富锂材料在结构演化与界面稳定性方面的最新成果，并分析了其科学意义，为加速富锂正极材料的产业化进程提供了从基础研究到应用策略的全面展望。	\N	Chinese Science Bulletin (Chinese Version)	\N	\N	2026	\N	\N	\N	10.1360/csb-2026-0653	\N	\N	https://doi.org/10.1360/csb-2026-0653	Zongliang Dai, Yu Qiao. (2026). Critical Challenges and Recent Advances in the Commercialization of Lithium-Rich Layered Cathodes. Chinese Science Bulletin (Chinese Version). https://doi.org/10.1360/csb-2026-0653.	en	public	published	f	2026-07-30 16:18:58.33485+08	openalex_import	2026-07-30 16:18:58.33485+08	2026-07-30 16:18:58.33485+08	\N	\N	\N	\N
215	3	LIT-000215	The Practices, Challenges, and Prospects of Artificial Intelligence Driving Low-Carbon Transformation in China&amp;rsquo;s Iron and Steel Industry	\N	paper	钢铁行业是国民经济发展的支柱行业，也是我国能源消耗与碳排放的重点领域。目前，钢铁行业面临传统技术减排空间逐渐收窄、边际成本快速上升等挑战。AI技术的引入为钢铁行业的深度脱碳变革提供了可行的智能化解决方案。本文重点探讨AI技术推动钢铁行业低碳转型的机理、应用场景及实践现状，围绕炼铁、炼钢、轧钢等核心工序，分析AI技术在能效提升、环境监测网络构建、碳/污染物排放动态预测与调控、以及资源循环利用等方面的应用价值与前景。结果表明，AI技术在提升钢铁企业碳减排效率、生产过程稳定性等方面具有较好的效果，但实际落地过程中仍面临技术、数据、成本、政策标准等多维度的障碍。未来，钢铁行业的深度脱碳需系统整合氢基冶金、碳捕集利用与封存等前沿技术。AI作为重要的技术工具，通过数字化表征冶金过程并优化其能耗与碳排放，推动钢铁行业低碳化转型。	\N	Journal of Energy and Climate Change	\N	\N	2026	\N	\N	\N	10.3724/j.issn.2097-4981.jecc-2025-0388	\N	\N	https://doi.org/10.3724/j.issn.2097-4981.jecc-2025-0388	Mao Xu, Zongguo Wen, Kai Zheng, Zhixing Pan, Zhenghao Liang. (2026). The Practices, Challenges, and Prospects of Artificial Intelligence Driving Low-Carbon Transformation in China&amp;rsquo;s Iron and Steel Industry. Journal of Energy and Climate Change. https://doi.org/10.3724/j.issn.2097-4981.jecc-2025-0388.	en	public	published	f	2026-07-30 16:19:09.27219+08	openalex_import	2026-07-30 16:19:09.27219+08	2026-07-30 16:19:09.27219+08	\N	\N	\N	\N
216	3	LIT-000216	低温压力容器的焊接制造	\N	paper	1. 来稿要真实性、科学性和科学性，资料可靠真实，数据准确详实，逻辑严密、文字精炼。 2. 来稿文责自负。所有作者应对稿件内容和署名无异议，稿件内容不得抄袭或重复发表。 3. 文章题目要简短精炼，准确概括文章中心内容，不超过20字。各级标题的编码方法为：第一级标题用一、二、三……依次编码；第二级用标题（一）（二）（三）……依次编码；第三级用1，2，3……依次编码。示例如下： 一、第一级标题 （一）第二级标题 （二）第二级标题 1. 第三级标题 2. 第三级标题 二、第一级标题 4. 来稿必须附有100-250字的摘要，一般应包括：目的、方法、结果和结论。需提供3-5个关键词，用分号隔开。 5. 英文标题、摘要、关键词及作者单位务必附在标题页。 6. 来稿必须附有第一作者和通讯作者的简介，包括真实姓名、出生年月、性别、民族、籍贯、工作单位、职务、职称、学位、研究方向等（研究生须注明博士研究生或硕士研究生）；其他作者附真实姓名、工作单位、职务、职称、邮编等。 7. 已被录用稿件原则上不允许更改作者顺序，或增删作者等。 8. 来稿正文字数一般以3000-6000字为宜 （不包括题目、作者信息、图表、参考文献）。 9. 文章格式一般包括：题目、作者及单位、通讯作者地址、邮编、内容摘要、关键词、正文、参考文献等。 10. 参考文献格式采用顺序编码制，请按文中出现的先后顺序编号；在文中引文出现的地方以阿拉伯数字按序编码并用方括号括起来上标；在文末列出参考文献需与正文中的标注序号一一对应。参考文献不少于8条。 1）著作类：[序号]作者．书名[M]．出版地：出版社，出版年，页码． 2）报纸、期刊论文类：[序号]作者．文章题目．报纸名/刊名[N/J]．年代（期、版次）：起止页码． 3）电子文献：[序号]作者．电子文献题目[EB/OL]．电子文献出处或可获得地址，发表日期/引用日期． 4）学位论文：[序号]作者．论文题目[D]：[硕士或博士学位论文]．保存地：保存单位，年份． 5）论文集中的析出文献：[序号]析出文献作者．析出文献题名[A]．原文献作者．原文献题名[C]．出版地：出版者，出版年．析出文献起止页码． 6）专利：[序号]专利申请者．专利名称[P]．国别，专利号．出版日期． 7）技术标准：[序号]起草责任者．标准编号．标准名称[S]．出版地： 出版社，出版年． 11. 参考文献中的标点符号以英文半角符号书写，字体请用Times New Roman。各类参考文献的标识符号是：专著[M]、论文集[C]、期刊文章[J]、报纸文章[N]、学位论文[D]、报告[R]、标准[S]、专利[P]、论文集中的析出文献[A]、各种未定义的文献[Z]。 12. 图表要求：文中表格建议采用三线表，表名置于表上方居中；文中图像要清晰可编辑，将图名置于图下方居中；图表如使用缩略语，需在图表注中说明。图表编号一律用阿拉伯数字，图表标号依次排列，如表1、表2、表3，图1、图2、图3。 13. 计量单位请参照中华人民共和国法定计量单位最新标准。外文字符必须分清大、小写，正、斜体，黑、白体，上下角标应区别明显（必要时可旁注说明）。 14. 缩略词在文中第一次出现时应给予明确定义。中英文缩略词都应在全文中统一。 15. 稿件必须采用Word格式随邮件的附件发送或在线提交稿件。 16. 来稿请注明通讯作者的详细联系地址、邮编、邮箱、联系电话。 17. 来稿如为研究课题或课题/项目/基金支持论文，请注明课题名称、审批机关、基金项目名称、年度及其项目编号。多项基金项目应依次列出，其间以分号“；”隔开。 18. 编辑部对来稿有删修权，不同意删修的稿件请在来稿中声明。 19. 所有来稿均不退，请作者自留底稿。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0808-15	\N	\N	https://doi.org/10.37155/2717-5197-0808-15	全莲菊, 超 郭. (2026). 低温压力容器的焊接制造. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0808-15.	en	public	published	t	2026-07-30 16:19:09.29938+08	openalex_import	2026-07-30 16:19:09.29938+08	2026-07-30 16:19:09.29938+08	\N	\N	\N	\N
217	3	LIT-000217	欧盟 CBAM 实施对中国出口企业的挑战与应对	\N	paper	\N	\N	工程学研究与实用	\N	\N	2026	\N	\N	\N	10.37155/2717-5316-0710-31	\N	\N	https://doi.org/10.37155/2717-5316-0710-31	华正江, 郑乔康, 陈彦旭. (2026). 欧盟 CBAM 实施对中国出口企业的挑战与应对. 工程学研究与实用. https://doi.org/10.37155/2717-5316-0710-31.	en	public	published	f	2026-07-30 16:19:09.307923+08	openalex_import	2026-07-30 16:19:09.307923+08	2026-07-30 16:19:09.307923+08	\N	\N	\N	\N
218	3	LIT-000218	压力容器焊接技术分析	\N	paper	压力容器是工业生产核心设备，焊接质量直接决定其安全运行。本文围绕压力容器焊接技术展开分析， 介绍了压力容器的定义、分类及焊接核心要求，阐述了焊条、焊丝、焊剂等常用焊接材料的类型、特性及匹配原则， 详解了手工电弧焊、埋弧焊等常用工艺的技术要点，分析了裂纹、气孔等常见焊接缺陷的形成机理及检测技术。研究 表明，合理选择焊接材料、规范执行焊接工艺、强化缺陷检测，能有效提升焊接质量。本文研究可为压力容器焊接施工、 质量控制提供理论参考与实践指导。	\N	工程施工新技术	\N	\N	2026	\N	\N	\N	10.37155/2811-0609-0509-72	\N	\N	https://doi.org/10.37155/2811-0609-0509-72	韩志扬. (2026). 压力容器焊接技术分析. 工程施工新技术. https://doi.org/10.37155/2811-0609-0509-72.	en	public	published	f	2026-07-30 16:19:09.315668+08	openalex_import	2026-07-30 16:19:09.315668+08	2026-07-30 16:19:09.315668+08	\N	\N	\N	\N
219	3	LIT-000219	WK-35 电铲底架梁裂纹分析与焊接修复工艺	\N	paper	1. 来稿要真实性、科学性和科学性，资料可靠真实，数据准确详实，逻辑严密、文字精炼。 2. 来稿文责自负。所有作者应对稿件内容和署名无异议，稿件内容不得抄袭或重复发表。 3. 文章题目要简短精炼，准确概括文章中心内容，不超过20字。各级标题的编码方法为：第一级标题用一、二、三……依次编码；第二级用标题（一）（二）（三）……依次编码；第三级用1，2，3……依次编码。示例如下： 一、第一级标题 （一）第二级标题 （二）第二级标题 1. 第三级标题 2. 第三级标题 二、第一级标题 4. 来稿必须附有100-250字的摘要，一般应包括：目的、方法、结果和结论。需提供3-5个关键词，用分号隔开。 5. 英文标题、摘要、关键词及作者单位务必附在标题页。 6. 来稿必须附有第一作者和通讯作者的简介，包括真实姓名、出生年月、性别、民族、籍贯、工作单位、职务、职称、学位、研究方向等（研究生须注明博士研究生或硕士研究生）；其他作者附真实姓名、工作单位、职务、职称、邮编等。 7. 已被录用稿件原则上不允许更改作者顺序，或增删作者等。 8. 来稿正文字数一般以3000-6000字为宜 （不包括题目、作者信息、图表、参考文献）。 9. 文章格式一般包括：题目、作者及单位、通讯作者地址、邮编、内容摘要、关键词、正文、参考文献等。 10. 参考文献格式采用顺序编码制，请按文中出现的先后顺序编号；在文中引文出现的地方以阿拉伯数字按序编码并用方括号括起来上标；在文末列出参考文献需与正文中的标注序号一一对应。参考文献不少于8条。 1）著作类：[序号]作者．书名[M]．出版地：出版社，出版年，页码． 2）报纸、期刊论文类：[序号]作者．文章题目．报纸名/刊名[N/J]．年代（期、版次）：起止页码． 3）电子文献：[序号]作者．电子文献题目[EB/OL]．电子文献出处或可获得地址，发表日期/引用日期． 4）学位论文：[序号]作者．论文题目[D]：[硕士或博士学位论文]．保存地：保存单位，年份． 5）论文集中的析出文献：[序号]析出文献作者．析出文献题名[A]．原文献作者．原文献题名[C]．出版地：出版者，出版年．析出文献起止页码． 6）专利：[序号]专利申请者．专利名称[P]．国别，专利号．出版日期． 7）技术标准：[序号]起草责任者．标准编号．标准名称[S]．出版地： 出版社，出版年． 11. 参考文献中的标点符号以英文半角符号书写，字体请用Times New Roman。各类参考文献的标识符号是：专著[M]、论文集[C]、期刊文章[J]、报纸文章[N]、学位论文[D]、报告[R]、标准[S]、专利[P]、论文集中的析出文献[A]、各种未定义的文献[Z]。 12. 图表要求：文中表格建议采用三线表，表名置于表上方居中；文中图像要清晰可编辑，将图名置于图下方居中；图表如使用缩略语，需在图表注中说明。图表编号一律用阿拉伯数字，图表标号依次排列，如表1、表2、表3，图1、图2、图3。 13. 计量单位请参照中华人民共和国法定计量单位最新标准。外文字符必须分清大、小写，正、斜体，黑、白体，上下角标应区别明显（必要时可旁注说明）。 14. 缩略词在文中第一次出现时应给予明确定义。中英文缩略词都应在全文中统一。 15. 稿件必须采用Word格式随邮件的附件发送或在线提交稿件。 16. 来稿请注明通讯作者的详细联系地址、邮编、邮箱、联系电话。 17. 来稿如为研究课题或课题/项目/基金支持论文，请注明课题名称、审批机关、基金项目名称、年度及其项目编号。多项基金项目应依次列出，其间以分号“；”隔开。 18. 编辑部对来稿有删修权，不同意删修的稿件请在来稿中声明。 19. 所有来稿均不退，请作者自留底稿。	\N	机械与电子控制工程	\N	\N	2026	\N	\N	\N	10.37155/2717-5197-0806-48	\N	\N	https://doi.org/10.37155/2717-5197-0806-48	李鹏飞, 宋春东, 马志强, 宇 赵. (2026). WK-35 电铲底架梁裂纹分析与焊接修复工艺. 机械与电子控制工程. https://doi.org/10.37155/2717-5197-0806-48.	en	public	published	f	2026-07-30 16:19:09.321445+08	openalex_import	2026-07-30 16:19:09.321445+08	2026-07-30 16:19:09.321445+08	\N	\N	\N	\N
220	3	LIT-000220	工业固废再生骨料在绿色公路基层中的环境与力学性能研究	\N	paper	资源约束趋紧与环境污染加剧，推动交通基础设施绿色低碳转型成国家战略要点。工业固废大规模堆存 占用土地、潜藏生态风险，公路建设对天然砂石骨料高强度消耗加剧资源枯竭与生态退化。将工业固废资源化制备 再生骨料用于公路基层，是实现“以废代材、减污降碳”协同增效的关键。本文梳理钢渣等典型工业固废再生骨料特 性，剖析其在公路基层应用的力学性能形成机制与环境安全控制原理，通过对比分析论证不同因素对基层材料综合性 能的影响规律，指出标准体系等方面存在的关键科学问题。研究表明，科学配比与工艺调控下，工业固废再生骨料能 满足绿色公路基层要求，前景广阔。未来应强化多源固废协同利用理论，构建评价模型，加快标准化与政策引导。	\N	现代交通与路桥建设	\N	\N	2026	\N	\N	\N	10.37155/2811-0633-0505-35	\N	\N	https://doi.org/10.37155/2811-0633-0505-35	峰 高, 许雪峰, 武宏伟. (2026). 工业固废再生骨料在绿色公路基层中的环境与力学性能研究. 现代交通与路桥建设. https://doi.org/10.37155/2811-0633-0505-35.	en	public	published	f	2026-07-30 16:19:09.330952+08	openalex_import	2026-07-30 16:19:09.330952+08	2026-07-30 16:19:09.330952+08	\N	\N	\N	\N
221	3	LIT-000221	公路修建技术中材料和能源的节约	\N	paper	公路修建中材料与能源节约是行业可持续发展的关键。本文围绕核心技术路径展开，材料节约涵盖优化 设计、高性能材料应用、本地化替代、施工损耗控制及再生循环利用；能源节约包括机械能效提升、低能耗工艺创 新、临时设施节能设计、能源监控管理及清洁能源应用。同时提出设计与规划阶段的节约策略，强调材料与能源协同 技术的重要性，通过智能化手段强化节约效益，并构建节约型技术标准体系。为公路建设资源高效利用提供理论支撑 与实践指导。	\N	工程施工新技术	\N	\N	2026	\N	\N	\N	10.37155/2811-0609-0508-60	\N	\N	https://doi.org/10.37155/2811-0609-0508-60	郝齐崇. (2026). 公路修建技术中材料和能源的节约. 工程施工新技术. https://doi.org/10.37155/2811-0609-0508-60.	en	public	published	f	2026-07-30 16:19:09.335332+08	openalex_import	2026-07-30 16:19:09.335332+08	2026-07-30 16:19:09.335332+08	\N	\N	\N	\N
222	3	LIT-000222	新能源交通工程的发展与应用	\N	paper	\N	\N	现代交通与路桥建设	\N	\N	2026	\N	\N	\N	10.37155/2811-0633-0504-12	\N	\N	https://doi.org/10.37155/2811-0633-0504-12	朱青旭. (2026). 新能源交通工程的发展与应用. 现代交通与路桥建设. https://doi.org/10.37155/2811-0633-0504-12.	en	public	published	f	2026-07-30 16:19:09.339169+08	openalex_import	2026-07-30 16:19:09.339169+08	2026-07-30 16:19:09.339169+08	\N	\N	\N	\N
225	3	LIT-000225	Research Progress on Environmentally Friendly Water-Based Drilling Fluid Additives	\N	paper	随着油气勘探开发不断向深部地层推进，超深井等复杂井的占比持续上升，井下工况愈发严苛，对水基钻井液的性能要求不断提高。与此同时，生态环保力度持续加大，相关法律法规日趋完善，传统钻井液处理剂因污染性强，已难以适配绿色发展需求。在此背景下，研发环保型水基钻井液处理剂对保障深井高效钻进，推动油气勘探绿色环保可持续发展具有重要意义。文章综述了水基钻井液中常见环保型处理剂(包括降滤失剂、抑制剂、润滑剂与降粘剂)的研究进展，总结了目前此类处理剂的常用改性原料及其合成方法，分析了各项性能，并系统评价了环保处理剂的未来发展趋势。With oil and gas exploration and development continuously advancing into deeper formations, the proportion of complex wells, such as ultra-deep wells, continues to rise. Downhole conditions are becoming increasingly harsh, and the performance requirements for water-based drilling fluids are continuously increasing. At the same time, ecological and environmental protection efforts are being strengthened, and relevant laws and regulations are becoming increasingly comprehensive. Traditional drilling fluid additives, due to their strong pollution, can no longer meet the demands of green development. In this context, the development of environmentally friendly water-based drilling fluid additives is of great significance for ensuring efficient deep well drilling and promoting the green, environmentally friendly, and sustainable development of oil and gas exploration. This paper reviews the research progress of several common environmentally friendly water-based drilling fluid additives (including fluid loss reducers, inhibitors, lubricants, and viscosity reducers). It summarizes the commonly used modified raw materials for these environmentally friendly additives and their synthesis methods, analyzes the various properties of the additives, and systematically evaluates the future development trends of environmentally friendly additives.	\N	Mine Engineering	\N	\N	2026	\N	\N	\N	10.12677/me.2026.144100	\N	\N	https://doi.org/10.12677/me.2026.144100	瑞 郭. (2026). Research Progress on Environmentally Friendly Water-Based Drilling Fluid Additives. Mine Engineering. https://doi.org/10.12677/me.2026.144100.	zh	public	published	f	2026-07-30 16:19:09.353503+08	openalex_import	2026-07-30 16:19:09.353503+08	2026-07-30 16:19:09.353503+08	\N	\N	\N	\N
226	3	LIT-000226	沿海港口码头结构耐久性防护措施探析	\N	paper	沿海港口作为国家对外开放的门户和物流枢纽，其基础设施的安全性与耐久性直接关系到区域经济的可持续发展。然而，海洋环境具有高温、高湿、高盐雾以及潮汐冲刷等极端特征，导致港口码头混凝土结构极易遭受氯离子侵蚀、碳化、冻融破坏及钢筋锈蚀等多重灾害，严重缩短了结构的使用寿命并增加了全生命周期成本。本文旨在系统综述沿海港口码头结构耐久性的退化机理，深入剖析当前主流的防护技术措施及其适用性。文章首先探讨了海洋环境下混凝土材料劣化的物理化学机制；其次，详细阐述了高性能混凝土配制、防腐涂层保护、阴极保护、表面改性及结构优化设计等关键防护技术的应用现状与优缺点；再次，结合工程实践案例，分析了不同防护策略在延长结构寿命、降低维护成本方面的实际效果；最后，展望了智能化监测、自修复材料及绿色防护技术在未来的应用前景。研究表明，构建“材料本征提升 + 多重防护协同 + 全周期智能运维”的综合防护体系，是应对海洋严苛环境、保障港口码头结构长期安全服役的根本途径。	\N	工程管理	\N	\N	2026	\N	\N	\N	10.32629/jpm.v7i5.8887	\N	\N	https://doi.org/10.32629/jpm.v7i5.8887	启迪 李. (2026). 沿海港口码头结构耐久性防护措施探析. 工程管理. https://doi.org/10.32629/jpm.v7i5.8887.	zh	public	published	f	2026-07-30 16:19:09.364281+08	openalex_import	2026-07-30 16:19:09.364281+08	2026-07-30 16:19:09.364281+08	\N	\N	\N	\N
227	3	LIT-000227	石油化工配管中高温材料耐腐蚀性提升技术探讨	\N	paper	\N	\N	工程管理与技术探讨	\N	\N	2026	\N	\N	\N	10.37155/2717-5189-0810-58	\N	\N	https://doi.org/10.37155/2717-5189-0810-58	张睿哲, 龚德鑫. (2026). 石油化工配管中高温材料耐腐蚀性提升技术探讨. 工程管理与技术探讨. https://doi.org/10.37155/2717-5189-0810-58.	en	public	published	f	2026-07-30 16:19:09.369245+08	openalex_import	2026-07-30 16:19:09.369245+08	2026-07-30 16:19:09.369245+08	\N	\N	\N	\N
228	3	LIT-000228	Toward Net Zero Emissions in the Road Transport Sector in China	\N	paper	Road transport accounts for 70% of the transport sector’s emissions in China. Compared to the aviation and maritime sectors, the road transport sector is relatively easy to decarbonize and enjoys new opportunities such as vehicle electrification. There is momentum in China focusing on a “fossil fuel ban” as the main driving force to achieve net-zero emissions by 2050. This research aims to quantify the emission reduction potential of vehicle electrification and what role integrated measures such as mode shifts in passenger and freight transport, fuel economy standards, and urban planning can play in China’s efforts to attain net-zero CO2 emissions in the road transport sector.	\N		\N	\N	2019	\N	\N	\N	10.46830/wriwp.19.00039	\N	\N	https://doi.org/10.46830/wriwp.19.00039	Lulu Xue, Yana Jin, Rujie Yu, Yong Liu, Huanhuan Ren. (2019). Toward Net Zero Emissions in the Road Transport Sector in China. https://doi.org/10.46830/wriwp.19.00039.	zh	public	published	f	2026-07-30 16:19:09.375227+08	openalex_import	2026-07-30 16:19:09.375227+08	2026-07-30 16:19:09.375227+08	\N	\N	\N	\N
229	3	LIT-000229	连续退火炉自动控制系统研究	\N	paper	\N	\N	现代工程项目管理	\N	\N	2026	\N	\N	\N	10.37155/2811-0625-0505-8	\N	\N	https://doi.org/10.37155/2811-0625-0505-8	杜芸芸. (2026). 连续退火炉自动控制系统研究. 现代工程项目管理. https://doi.org/10.37155/2811-0625-0505-8.	en	public	published	f	2026-07-30 16:19:09.389927+08	openalex_import	2026-07-30 16:19:09.389927+08	2026-07-30 16:19:09.389927+08	\N	\N	\N	\N
230	3	LIT-000230	火力发电汽轮机供水水质处理技术创新与应用	\N	paper	\N	\N	工程施工新技术	\N	\N	2026	\N	\N	\N	10.37155/2811-0609-0507-61	\N	\N	https://doi.org/10.37155/2811-0609-0507-61	锐 张, 庞驰宸. (2026). 火力发电汽轮机供水水质处理技术创新与应用. 工程施工新技术. https://doi.org/10.37155/2811-0609-0507-61.	en	public	published	f	2026-07-30 16:19:09.395665+08	openalex_import	2026-07-30 16:19:09.395665+08	2026-07-30 16:19:09.395665+08	\N	\N	\N	\N
231	3	LIT-000231	地质样品中铬及铬同位素的分析	\N	paper	铬(Cr)作为第四周期第ⅥB族的过渡金属元素,在地质样品中分布广泛,其地球化学行为与岩浆演化、热液活动及表生风化等过程密切相关。准确测定地质样品中Cr的含量、赋存状态及同位素组成,对矿产勘查、成矿机制解析、环境演化示踪及污染溯源具有重要意义。本文系统梳理了近年来地质样品中Cr及其同位素分析技术的研究进展。样品前处理方面,综述了敞开酸溶、高压密闭、半密闭酸溶及微波消解等方法的原理、优势与局限,指出微波消解对易挥发元素Cr的回收率提升尤为显著。总Cr含量测定方面,对比了分光光度法、原子吸收光谱法、电感耦合等离子体发射光谱法、电感耦合等离子体质谱法及激光剥蚀电感耦合等离子体质谱法的适用场景与技术特点。形态分析方面,总结了基于化学提取、色谱-质谱联用及X射线吸收光谱等技术的Cr形态分离与表征方法。同位素分析方面,重点介绍了Cr的分离纯化技术(阳离子交换法、阴离子交换法及阴阳离子联用技术)及高精度质谱测定方法。最后,展望了未来Cr分析技术向高灵敏度、高选择性、低样品消耗及原位在线分析方向发展的趋势,为地质样品中Cr的研究提供了技术参考。	\N	Acta Petrologica Sinica	\N	\N	2026	\N	\N	\N	10.18654/1000-0569/2026.08.20	\N	\N	https://doi.org/10.18654/1000-0569/2026.08.20	Jing WANG, WenJun LI, BingYu GAO, ShouQian ZHAO. (2026). 地质样品中铬及铬同位素的分析. Acta Petrologica Sinica. https://doi.org/10.18654/1000-0569/2026.08.20.	en	public	published	t	2026-07-30 16:19:09.402192+08	openalex_import	2026-07-30 16:19:09.402192+08	2026-07-30 16:19:09.402192+08	\N	\N	\N	\N
235	3	LIT-000235	热解炉富氧干馏运行优化及荒煤气提质实践	\N	paper	\N	\N	工程学研究与实用	\N	\N	2026	\N	\N	\N	10.37155/2717-5316-0709-27	\N	\N	https://doi.org/10.37155/2717-5316-0709-27	上官国青, 张成杰. (2026). 热解炉富氧干馏运行优化及荒煤气提质实践. 工程学研究与实用. https://doi.org/10.37155/2717-5316-0709-27.	en	public	published	f	2026-07-30 16:19:09.45153+08	openalex_import	2026-07-30 16:19:09.45153+08	2026-07-30 16:19:09.45153+08	\N	\N	\N	\N
236	3	LIT-000236	冶金工程中低碳炼铁技术的工艺优化与碳排放分析	\N	paper	冶金工程中低碳炼铁技术通过原料结构优化（如提高球团矿比例、生物质炭替代化石燃料）、能源系统 升级（高炉煤气余热回收、氢能-电能耦合供能）、反应过程精准控制（动态调控高炉参数、提升氢气利用率）及数 字化赋能（数字孪生仿真、AI碳流监测）实现工艺优化。技术革新使高炉炼铁吨铁碳排放降低94.9kg，直接还原技术 减排潜力达75%-85%，全流程协同优化可实现25%以上直接减排，推动行业向低碳、高效方向转型。	\N	Gong cheng ji shu yu zhi liang guan li =	\N	\N	2026	\N	\N	\N	10.37155/3041-0827-0202-39	\N	\N	https://doi.org/10.37155/3041-0827-0202-39	朱锋涛. (2026). 冶金工程中低碳炼铁技术的工艺优化与碳排放分析. Gong cheng ji shu yu zhi liang guan li =. https://doi.org/10.37155/3041-0827-0202-39.	en	public	published	f	2026-07-30 16:19:09.456327+08	openalex_import	2026-07-30 16:19:09.456327+08	2026-07-30 16:19:09.456327+08	\N	\N	\N	\N
238	3	LIT-000238	面向“双碳”目标的铜冶炼清洁生产技术路径优化	\N	paper	\N	\N	工程施工新技术	\N	\N	2026	\N	\N	\N	10.37155/2811-0609-0509-61	\N	\N	https://doi.org/10.37155/2811-0609-0509-61	潘金科. (2026). 面向“双碳”目标的铜冶炼清洁生产技术路径优化. 工程施工新技术. https://doi.org/10.37155/2811-0609-0509-61.	en	public	published	f	2026-07-30 16:19:09.461838+08	openalex_import	2026-07-30 16:19:09.461838+08	2026-07-30 16:19:09.461838+08	\N	\N	\N	\N
239	3	LIT-000239	能源动力产业的绿色低碳环保技术与应用分析	\N	paper	能源动力产业是国民经济的基础性支柱产业，也是碳排放的主要来源。在“双碳”目标推动下，能源动力产业正面临从高碳向低碳、粗放向高效、传统向智能转型的发展过程。本文将利用2025—2026年最新数据和示范案例，从清洁化、规模化、智能化三个维度探究能源动力产业的绿色低碳环保技术及其应用体系。其中，清洁化方面探讨煤电清洁燃烧与碳捕集利用与封存（CCUS）技术取得重大突破；规模化方面探索氢能与新型储能产业快速崛起；智能化方面探析数字孪生、智慧电厂与虚拟电厂技术等在优化能源系统中的巨变作用。技术创新和产业应用相融合，将改变能源动力产业现有的局面，为全球推进绿色低碳提供可资借鉴的中国案例。	\N	社会发展与科技创新	\N	\N	2026	\N	\N	\N	10.64649/yh.shfzykjcx.issn3078-8994.202605005	\N	\N	https://doi.org/10.64649/yh.shfzykjcx.issn3078-8994.202605005	建东 张. (2026). 能源动力产业的绿色低碳环保技术与应用分析. 社会发展与科技创新. https://doi.org/10.64649/yh.shfzykjcx.issn3078-8994.202605005.	zh	public	published	f	2026-07-30 16:19:09.464062+08	openalex_import	2026-07-30 16:19:09.464062+08	2026-07-30 16:19:09.464062+08	\N	\N	\N	\N
240	3	LIT-000240	Prevalence and distribution patterns of drug resistance in <i>Mycobacterium tuberculosis</i> to first-line antituberculosis drugs in Urumqi, China	\N	paper	ABSTRACT This study aimed to investigate the epidemic status and distribution characteristics of drug-resistant Mycobacterium tuberculosis in Urumqi. From January 2019 to July 2024, all sputum culture-positive Mycobacterium tuberculosis strains were collected in Urumqi. Using the traditional solid-state proportion method for drug-sensitivity testing, we determined the resistance of Mycobacterium tuberculosis to first-line antituberculosis (TB) drugs. The epidemic status and distribution characteristics of first-line antituberculosis drug-resistant Mycobacterium tuberculosis were analyzed using R statistical software (version 3.6.1). Among the 1,241 culture-positive Mycobacterium tuberculosis strains included in this analysis, 973 (78.40%) were smear positive. The overall proportion of non-tuberculous mycobacteria was 2.5%. The overall prevalence of drug-resistant tuberculosis (DR-TB) was 18.93%, with a prevalence of 17.78% in new cases and 24.40% in retreatment cases, respectively. In this survey, the overall prevalence was 10.91% (132 out of 1,210) for mono-drug-resistant tuberculosis, 3.72% (45 out of 1,210) for polydrug-resistant tuberculosis, and 4.30% (52 out of 1,210) for multidrug-resistant tuberculosis. Moreover, the patterns of resistance to first-line anti-TB drugs were highly diverse. The drug-resistance rate among retreatment tuberculosis patients in Urumqi remains notably high. Thus, enhancing drug-resistance surveillance in these patients is critical for effective tuberculosis prevention and control in the region. IMPORTANCE The result of this study indicated that DR-TB is a serious public health problem in Urumqi. Resistance drugs distributed type to first-line anti-TB drugs are very broad in Urumqi. Any resistance to anti-TB drugs in new cases is more than in retreatment cases.	\N	Microbiology Spectrum	\N	\N	2025	\N	\N	\N	10.1128/spectrum.01370-25	\N	\N	https://doi.org/10.1128/spectrum.01370-25	Jiandong Yang, Pengwei Lou, Weisheng Zhang, Yanggui Chen, Yaoqin Lu, Na Xue, Peisheng Wang, Kai Wang. (2025). Prevalence and distribution patterns of drug resistance in <i>Mycobacterium tuberculosis</i> to first-line antituberculosis drugs in Urumqi, China. Microbiology Spectrum. https://doi.org/10.1128/spectrum.01370-25.	en	public	published	f	2026-07-30 16:19:09.467678+08	openalex_import	2026-07-30 16:19:09.467678+08	2026-07-30 16:19:09.467678+08	\N	\N	\N	\N
258	3	LIT-000258	水利水电施工中混凝土施工技术的应用	\N	paper	\N	\N	工程学研究与实用	\N	\N	2026	\N	\N	\N	10.37155/2717-5316-0705-4	\N	\N	https://doi.org/10.37155/2717-5316-0705-4	朱彩艳. (2026). 水利水电施工中混凝土施工技术的应用. 工程学研究与实用. https://doi.org/10.37155/2717-5316-0705-4.	en	public	published	f	2026-07-30 16:19:18.359525+08	openalex_import	2026-07-30 16:19:18.359525+08	2026-07-30 16:19:18.359525+08	\N	\N	\N	\N
243	3	LIT-000243	提金尾渣资源综合化利用研究	\N	paper	针对某河南黄金冶炼公司产生的提金尾渣资源综合化利用难题，研发出了一种适应该冶炼厂的高效制备硫酸亚铁的生产工艺。通过研究酸浸-还原-结晶-重结晶-除杂过程，建立了“两段逆流酸浸”的新工艺方法。结果显示：在硫酸浓度为68%、液固比为2:1、温度为90℃，搅拌速度600r/min的条件下，一级酸浸3h，与二级逆流酸浸工艺相结合，该公司尾渣中铁的总浸出率可达91.58%；通过构建铁粉-硫酸的协同还原方法，在pH为1-3、60℃条件下可以实现三价铁选择性还原为二价铁，还原率达64.17%；通过优化结晶工艺，再结合50g/L硫化钠深度除杂，最终得到的硫酸亚铁产品符合GB/T 23937-2009标准。这个工艺较传统方法使得铁回收率提高11.58%，酸耗降低15.7%，为提金尾渣的高效利用提供了可靠的支撑。	\N	工程技术前沿	\N	\N	2025	\N	\N	\N	10.63887/fet.2025.1.8.11	\N	\N	https://doi.org/10.63887/fet.2025.1.8.11	林峰, 赵房楠, 吴永胜, 何少杰, 张战毅. (2025). 提金尾渣资源综合化利用研究. 工程技术前沿. https://doi.org/10.63887/fet.2025.1.8.11.	zh	public	published	f	2026-07-30 16:19:18.299525+08	openalex_import	2026-07-30 16:19:18.299525+08	2026-07-30 16:19:18.299525+08	\N	\N	\N	\N
246	3	LIT-000246	高炉型钛渣中二氧化钛的活度	\N	paper	本文利用Ti比Si易溶于Sn和Sn中不溶解碳及碳化物这些有利特性,以Sn为溶剂金属,用"熔渣-金属"化学平衡法以及参考渣实验技术,在1480℃下直接测定了高炉型钛渣中TiO2的活度。由熔化自由能法对TiO2-SiO2二元系作了热力学分析,提出了修正的"阳离子随机混合模型",有效相互作用能为正的36.7kJ着重探讨了TiO2-SiO2-CaO三元系中TiO2活度的变化规律,在实验渣范围内测得TiO2活度在0,01～0.06之间,TiO2活度系数在。0.1～0.3之间,在1BM-AT微机上用"等高线绘制程序"绘制TiO2等活度图及等活度系数图。实验还研究了以等摩尔分数MgO代替CaO时、A12O3(10Wt%)作为添加剂时TiO2活度系数(γTiO2)的变化规律,结果表明,MgO使γTiO2减小,而A12O3使γTiO2增大,估算得到SiO2的活度系数在0.5-0.95之间,对高炉偏酸性渣冶炼钒钦磁铁矿渣铁界面进行了热力学分析,指出在酸性渣中,TiO2的过还原受到了限制,SiO2传递氧、氧化Ti(C.N)和低价铁的能力比SiO2在碱性渣中的强,从热力学的观点,认为偏酸性渣冶炼钒钦磁铁矿能进一步挖掘高炉生产的潜力,是综合利用矿产资源的合理途径。	\N	Chinese Journal of Applied Chemistry	\N	\N	1987	\N	\N	\N	10.3724/j.issn.1000-0518.1987.4.81	\N	\N	https://doi.org/10.3724/j.issn.1000-0518.1987.4.81	希琳 董. (1987). 高炉型钛渣中二氧化钛的活度. Chinese Journal of Applied Chemistry. https://doi.org/10.3724/j.issn.1000-0518.1987.4.81.	ja	public	published	f	2026-07-30 16:19:18.312309+08	openalex_import	2026-07-30 16:19:18.312309+08	2026-07-30 16:19:18.312309+08	\N	\N	\N	\N
259	3	LIT-000259	水利施工中输水隧洞施工	\N	paper	\N	\N	城市建筑与发展	\N	\N	2026	\N	\N	\N	10.37155/2717-557x-0704-8	\N	\N	https://doi.org/10.37155/2717-557x-0704-8	王军帅. (2026). 水利施工中输水隧洞施工. 城市建筑与发展. https://doi.org/10.37155/2717-557x-0704-8.	en	public	published	f	2026-07-30 16:19:18.361715+08	openalex_import	2026-07-30 16:19:18.361715+08	2026-07-30 16:19:18.361715+08	\N	\N	\N	\N
247	3	LIT-000247	高炉型钛渣中二氧化钛的活度	\N	paper	本文利用Ti比Si易溶于Sn和Sn中不溶解碳及碳化物这些有利特性,以Sn为溶剂金属,用"熔渣-金属"化学平衡法以及参考渣实验技术,在1480℃下直接测定了高炉型钛渣中TiO2的活度。由熔化自由能法对TiO2-SiO2二元系作了热力学分析,提出了修正的"阳离子随机混合模型",有效相互作用能为正的36.7kJ着重探讨了TiO2-SiO2-CaO三元系中TiO2活度的变化规律,在实验渣范围内测得TiO2活度在0,01～0.06之间,TiO2活度系数在。0.1～0.3之间,在1BM-AT微机上用"等高线绘制程序"绘制TiO2等活度图及等活度系数图。实验还研究了以等摩尔分数MgO代替CaO时、A12O3(10Wt%)作为添加剂时TiO2活度系数(γTiO2)的变化规律,结果表明,MgO使γTiO2减小,而A12O3使γTiO2增大,估算得到SiO2的活度系数在0.5-0.95之间,对高炉偏酸性渣冶炼钒钦磁铁矿渣铁界面进行了热力学分析,指出在酸性渣中,TiO2的过还原受到了限制,SiO2传递氧、氧化Ti(C.N)和低价铁的能力比SiO2在碱性渣中的强,从热力学的观点,认为偏酸性渣冶炼钒钦磁铁矿能进一步挖掘高炉生产的潜力,是综合利用矿产资源的合理途径。	\N	Chinese Journal of Applied Chemistry	\N	\N	1987	\N	\N	\N	10.3724/j.issn.1000-0518.1987.4.8181	\N	\N	https://doi.org/10.3724/j.issn.1000-0518.1987.4.8181	希琳 董. (1987). 高炉型钛渣中二氧化钛的活度. Chinese Journal of Applied Chemistry. https://doi.org/10.3724/j.issn.1000-0518.1987.4.8181.	ja	public	published	f	2026-07-30 16:19:18.316067+08	openalex_import	2026-07-30 16:19:18.316067+08	2026-07-30 16:19:18.316067+08	\N	\N	\N	\N
248	3	LIT-000248	冶金废水深度处理及资源化回用工艺在矿山项目中的应用	\N	paper	\N	\N	现代工程项目管理	\N	\N	2026	\N	\N	\N	10.37155/2811-0625-0506-24	\N	\N	https://doi.org/10.37155/2811-0625-0506-24	宇 张. (2026). 冶金废水深度处理及资源化回用工艺在矿山项目中的应用. 现代工程项目管理. https://doi.org/10.37155/2811-0625-0506-24.	en	public	published	f	2026-07-30 16:19:18.319175+08	openalex_import	2026-07-30 16:19:18.319175+08	2026-07-30 16:19:18.319175+08	\N	\N	\N	\N
249	3	LIT-000249	铜渣选矿工艺的现状与发展趋势研究	\N	paper	铜渣作为铜冶炼的副产品，其组成复杂多变，但富含多种有价金属和矿物成分，具有显著利用价值。当 前铜渣选矿工艺主要包括磁选、浮选、重选等，这些工艺在提高资源回收率方面发挥着重要作用。然而，受铜渣成 分、粒度分布、磨矿细度、药剂种类和操作条件等多种因素的影响，选矿效果存在差异。随着技术进步和环保要求的 提高，铜渣选矿工艺正朝着技术创新、综合利用、环保要求和经济效益提升的方向发展，以实现更高效、更环保的有 价金属回收和资源化利用。	\N	工程施工新技术	\N	\N	2025	\N	\N	\N	10.37155/2811-0609-0415-71	\N	\N	https://doi.org/10.37155/2811-0609-0415-71	李宗鑫. (2025). 铜渣选矿工艺的现状与发展趋势研究. 工程施工新技术. https://doi.org/10.37155/2811-0609-0415-71.	zh	public	published	f	2026-07-30 16:19:18.322323+08	openalex_import	2026-07-30 16:19:18.322323+08	2026-07-30 16:19:18.322323+08	\N	\N	\N	\N
250	3	LIT-000250	产教融合背景下AIGC赋能建筑工程专业教学模式的实践——以《建筑材料》课程为例	\N	paper	在教育数字化与人工智能快速发展背景下，AIGC凭借技术优势为课程改革提供助力。《建筑材料》是建筑专业核心基础课，但传统教学存在实操受限、理论理解难、产教脱节等问题，难以适配新质生产力人才培养需求。本文聚焦产教融合背景下AIGC融入该课程的改革实践，搭建“技术-教学-评价”一体化框架，探索二者深度融合路径，为同类课程数字化与产教融合改革提供参考。	\N	教育研究	\N	\N	2026	\N	\N	\N	10.32629/er.v9i6.7192	\N	\N	https://doi.org/10.32629/er.v9i6.7192	美又 王. (2026). 产教融合背景下AIGC赋能建筑工程专业教学模式的实践——以《建筑材料》课程为例. 教育研究. https://doi.org/10.32629/er.v9i6.7192.	zh	public	published	f	2026-07-30 16:19:18.32585+08	openalex_import	2026-07-30 16:19:18.32585+08	2026-07-30 16:19:18.32585+08	\N	\N	\N	\N
251	3	LIT-000251	高层建筑工程施工中桩基础施工技术	\N	paper	\N	\N	工程施工新技术	\N	\N	2026	\N	\N	\N	10.37155/2811-0609-0507-71	\N	\N	https://doi.org/10.37155/2811-0609-0507-71	张来福. (2026). 高层建筑工程施工中桩基础施工技术. 工程施工新技术. https://doi.org/10.37155/2811-0609-0507-71.	en	public	published	f	2026-07-30 16:19:18.329269+08	openalex_import	2026-07-30 16:19:18.329269+08	2026-07-30 16:19:18.329269+08	\N	\N	\N	\N
253	3	LIT-000253	智慧水利在水利水电工程管理中的应用研究	\N	paper	\N	\N	水利电力技术与应用	\N	\N	2026	\N	\N	\N	10.37155/2717-5251-0805-31	\N	\N	https://doi.org/10.37155/2717-5251-0805-31	李永周. (2026). 智慧水利在水利水电工程管理中的应用研究. 水利电力技术与应用. https://doi.org/10.37155/2717-5251-0805-31.	en	public	published	f	2026-07-30 16:19:18.33862+08	openalex_import	2026-07-30 16:19:18.33862+08	2026-07-30 16:19:18.33862+08	\N	\N	\N	\N
254	3	LIT-000254	钻孔灌注桩在水利水电工程施工中的应用探讨	\N	paper	本文聚焦钻孔灌注桩在水利水电工程中的应用。首先阐述其技术特性，如桩身直径灵活、桩长可深入持 力层、施工扰动小等，以及抗承载能力强、抗渗性能优、地质适应性广等应用优势。接着介绍施工核心要点，涵盖前 期准备、成孔工艺、钢筋笼制作安装等。随后分析质量控制关键环节，包括泥浆、混凝土浇筑、孔底沉渣控制。最后 探讨常见问题及应对措施，如孔壁坍塌、断桩、桩位偏差等问题的成因与解决办法。旨在为钻孔灌注桩在水利水电工 程中的科学应用提供全面指导，提升工程质量与安全性。	\N	工程施工新技术	\N	\N	2026	\N	\N	\N	10.37155/2811-0609-0508-45	\N	\N	https://doi.org/10.37155/2811-0609-0508-45	唐仕兴. (2026). 钻孔灌注桩在水利水电工程施工中的应用探讨. 工程施工新技术. https://doi.org/10.37155/2811-0609-0508-45.	en	public	published	f	2026-07-30 16:19:18.341177+08	openalex_import	2026-07-30 16:19:18.341177+08	2026-07-30 16:19:18.341177+08	\N	\N	\N	\N
255	3	LIT-000255	盾构法隧道施工在水利工程建设中的应用	\N	paper	\N	\N	工程施工新技术	\N	\N	2026	\N	\N	\N	10.37155/2811-0609-0507-43	\N	\N	https://doi.org/10.37155/2811-0609-0507-43	赵梓豪. (2026). 盾构法隧道施工在水利工程建设中的应用. 工程施工新技术. https://doi.org/10.37155/2811-0609-0507-43.	en	public	published	f	2026-07-30 16:19:18.344457+08	openalex_import	2026-07-30 16:19:18.344457+08	2026-07-30 16:19:18.344457+08	\N	\N	\N	\N
260	3	LIT-000260	Calculation, Verification, And Empirical Analysis of Energy Transition Willingness Among High-Energy-Consuming Enterprises	\N	paper	社会各界关于能源转型的重要性已基本达成共识，但对企业能源转型测度的工作还有待开展。因此，聚焦于微观层面能源转型的测度难题，运用文本大数据挖掘技术从能源转型意愿视角构建了一套新的企业能源转型意愿词谱。首先运用改进的LDA模型对近三年能源政策文件文本进行识别，初步构建企业能源转型意愿词谱；然后提出一种文本识别算法对2007-2023年高耗能上市公司年报文本进行词谱词频统计，过滤和优化形成最终企业能源转型意愿词谱。理论分析和交叉数据检验均验证了企业能源转型意愿词谱的科学可靠性。在此基础上，实证检验了能源转型意愿对高耗能企业高质量发展的影响。研究表明：（1）能源转型意愿对高耗能企业高质量发展具有显著的推动作用。（2）能源转型意愿可以通过企业ESG表现和颠覆性技术创新两种机制推动高耗能企业高质量发展。（3）能源转型意愿对高耗能企业高质量发展的促进效应在非国有企业、传统能源类与非能源类中更为显著。	\N	Journal of Energy and Climate Change	\N	\N	2026	\N	\N	\N	10.3724/j.issn.2097-4981.jecc-2026-0025	\N	\N	https://doi.org/10.3724/j.issn.2097-4981.jecc-2026-0025	Hongfei Chen, Dongxiao Niu. (2026). Calculation, Verification, And Empirical Analysis of Energy Transition Willingness Among High-Energy-Consuming Enterprises. Journal of Energy and Climate Change. https://doi.org/10.3724/j.issn.2097-4981.jecc-2026-0025.	en	public	published	f	2026-07-30 16:19:18.367985+08	openalex_import	2026-07-30 16:19:18.367985+08	2026-07-30 16:19:18.367985+08	\N	\N	\N	\N
262	3	LIT-000262	Preparation and Performance Study of Nano-Iron Oxide@Carbon Cloth Composites	\N	paper	本文以硝酸铁和碳布为原料采用水热法合成纳米氧化铁@碳布复合材料以替代传统散粉类吸附剂去除水中氟离子。研究了初始氟离子浓度、溶液初始pH值和吸附温度等因素对纳米氧化铁@碳布复合材料的除氟性能的影响。采用X射线衍射(XRD)、扫描电子显微镜(SEM)和能谱仪分析(EDS)等方法来对纳米氧化铁@碳布复合材料的形态结构等进行表征。研究表明，向50 mL初始浓度为10 mg/L的氟化钠溶液中加入1 cm2纳米氧化铁@碳布复合材料，用HCl和NaOH溶液调节氟离子溶液pH值到7.0，在常温条件下以160 r/min的速度磁力搅拌120 min，处理后氟离子浓度为6.06 mg/L，去除率为39.4%。纳米氧化铁@碳布复合材料对氟离子的吸附过程符合准二级动力学模型，表明纳米氧化铁@碳布复合材料吸附氟离子是一个以化学吸附为主的复杂过程。In this paper, iron nitrate and carbon cloth were used as raw materials to synthesize nano iron oxide@carbon cloth composites by hydrothermal method. The composite was to replace traditional loose powder adsorbents for fluoride ions in water removal. The effects of initial fluoride ion concentration, initial pH and adsorption temperature on the fluoride removal efficiency of nano-iron oxide@carbon cloth composites were studied. X-ray diffraction (XRD), scanning electron microscopy (SEM) and energy dispersive spectroscopy (EDS) were used to characterize the morphology, structure and composition of nano-iron oxide@carbon cloth composites. 1 cm2 nano iron oxide@carbon cloth composite material was added to 50 mL of sodium fluoride solution with an initial concentration of 10 mg/L, and the pH value of the fluoride ion solution was adjusted to 7.0 with HCl and NaOH solution. The results showed that the fluoride ion concentration dropped to 6.06 mg/L, resulting in the removal efficiency of 39.4% after treatment with magnetic stirring at a speed of 160 r/min for 120 min at room temperature. The adsorption process of fluoride ions by nano-iron oxide@carbon cloth composites conformed to be the quasi-second-order kinetic model, indicating that the adsorption of fluoride ions by nano-iron oxide@carbon cloth composites was a complex process dominated by chemical adsorption.	\N	Advances in Material Chemistry	\N	\N	2026	\N	\N	\N	10.12677/amc.2026.143032	\N	\N	https://doi.org/10.12677/amc.2026.143032	永丹 侯. (2026). Preparation and Performance Study of Nano-Iron Oxide@Carbon Cloth Composites. Advances in Material Chemistry. https://doi.org/10.12677/amc.2026.143032.	zh	public	published	t	2026-07-30 16:19:18.38511+08	openalex_import	2026-07-30 16:19:18.38511+08	2026-07-30 16:19:18.38511+08	\N	\N	\N	\N
263	4	LIT-000263	Thermodynamics of low-dimensional trapped Fermi gases	\N	paper	The effects of low dimensionality on the thermodynamics of a Fermi gas trapped by isotropic power law potentials are analyzed. Particular attention is given to different characteristic temperatures that emerge, at low dimensionality, in the thermodynamic functions of state and in the thermodynamic susceptibilities (isothermal compressibility and specific heat). An energy-entropy argument that physically favors the relevance of one of these characteristic temperatures, namely, the non vanishing temperature at which the chemical potential reaches the Fermi energy value, is presented. Such an argument allows to interpret the nonmonotonic dependence of the chemical potential on temperature, as an indicator of the appearance of a thermodynamic regime, where the equilibrium states of a trapped Fermi gas are characterized by larger fluctuations in energy and particle density as is revealed in the corresponding thermodynamics susceptibilities.	\N	arXiv cond-mat.quant-gas, cond-mat.stat-mech	\N	\N	2016	\N	\N	\N	10.1155/2017/3060348	\N	\N	http://arxiv.org/abs/1612.02496v1	Francisco J. Sevilla. (2016). Thermodynamics of low-dimensional trapped Fermi gases. arXiv preprint. 1612.02496v1. https://doi.org/10.1155/2017/3060348.	en	public	published	f	2026-07-30 16:24:25.851003+08	arxiv_import	2026-07-30 16:24:25.851003+08	2026-07-30 16:24:25.851003+08	\N	\N	\N	\N
264	4	LIT-000264	Thermodynamic Phase Stability, Structural, Mechanical, Optoelectronic, and Thermoelectric Properties of the III-V Semiconductor AlSb for Energy Conversion Applications	\N	paper	This study presents a first principles investigation of the structural, thermodynamic, electronic, optical and thermoelectric properties of aluminum antimonide (AlSb) in its cubic (F-43m) and hexagonal (P63mc) phases. Both structures are dynamically and mechanically stable, as confirmed by phonon calculations and the Born Huang criteria. The lattice constants obtained using the SCAN and PBEsol functionals show good agreement with experimental data. The cubic phase exhibits a direct band gap of 1.66 to 1.78 eV, while the hexagonal phase shows a band gap of 1.48 to 1.59 eV, as confirmed by mBJ and HSE06 calculations. Under external pressure, the band gap decreases in the cubic phase and increases in the hexagonal phase due to different s p orbital hybridization mechanisms. The optical absorption coefficient reaches 1e6 cm-1, which is comparable to or higher than values reported for other III V semiconductors. The Seebeck coefficient exceeds 1500 microV per K under intrinsic conditions, and the thermoelectric performance improves above 600 K due to enhanced phonon scattering and lattice anharmonicity. The calculated formation energies (-1.316 eV for F-43m and -1.258 eV for P63mc) confirm that the cubic phase is thermodynamically more stable. The hexagonal phase exhibits higher anisotropy and lower lattice stiffness, which is favorable for thermoelectric applications. These results demonstrate the strong interplay between crystal symmetry, phonon behavior and charge transport, and provide useful guidance for the design of AlSb based materials for optoelectronic and energy conversion technologies.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2025	\N	\N	\N	10.1016/j.ctta.2025.100255	\N	\N	http://arxiv.org/abs/2512.22277v2	Iskandar Raufov, Dilshod Nematov, Saidjafar Murodzoda, Sakhidod Sattorzoda, Anushervon Ashurov. (2025). Thermodynamic Phase Stability, Structural, Mechanical, Optoelectronic, and Thermoelectric Properties of the III-V Semiconductor AlSb for Energy Conversion Applications. arXiv preprint. 2512.22277v2. https://doi.org/10.1016/j.ctta.2025.100255.	en	public	published	f	2026-07-30 16:24:25.861601+08	arxiv_import	2026-07-30 16:24:25.861601+08	2026-07-30 16:24:25.861601+08	\N	\N	\N	\N
265	4	LIT-000265	XY-Ashkin-Teller Phase Diagram in d=3	\N	paper	The phase diagram of the Ashkin-Tellerized XY model in spatial dimension $d=3$ is calculated by renormalization-group theory. In this system, each site has two spins, each spin being an XY spin, that is having orientation continuously varying in 2πradians. Nearest-neighbor sites are coupled by two-spin and four-spin interactions. The phase diagram has ordered phases that are ferromagnetic and antiferromagnetic in each of the spins, and phases that are ferromagnetic and antiferromagnetic in the multiplicative spin variable. The phase diagram exhibits two symmetrically situated reverse bifurcation points of the phase boundaries. The renormalization-group flows are in terms of the doubly composite Fourier coefficients of the exponentiated energy of nearest-neighbor spins.	\N	arXiv cond-mat.stat-mech	\N	\N	2025	\N	\N	\N	10.1016/j.physa.2025.130715	\N	\N	http://arxiv.org/abs/2503.23739v1	Alpar Turkoglu, A. Nihat Berker. (2025). XY-Ashkin-Teller Phase Diagram in d=3. arXiv preprint. 2503.23739v1. https://doi.org/10.1016/j.physa.2025.130715.	en	public	published	f	2026-07-30 16:24:25.866694+08	arxiv_import	2026-07-30 16:24:25.866694+08	2026-07-30 16:24:25.866694+08	\N	\N	\N	\N
266	4	LIT-000266	Dynamics and Thermodynamics of a model with long-range interactions	\N	paper	The dynamics and the thermodynamics of particles/spins interacting via long-range forces display several unusual features with respect to systems with short-range interactions. The Hamiltonian Mean Field (HMF) model, a Hamiltonian system of N classical inertial spins with infinite-range interactions represents a paradigmatic example of this class of systems. The equilibrium properties of the model can be derived analytically in the canonical ensemble: in particular the model shows a second order phase transition from a ferromagnetic to a paramagnetic phase. Strong anomalies are observed in the process of relaxation towards equilibrium for a particular class of out-of-equilibrium initial conditions. In fact the numerical simulations show the presence of quasi-stationary state (QSS), i.e. metastable states which become stable if the thermodynamic limit is taken before the infinite time limit. The QSS differ strongly from Boltzmann-Gibbs equilibrium states: they exhibit negative specific heat, vanishing Lyapunov exponents and weak mixing, non-Gaussian velocity distributions and anomalous diffusion, slowly-decaying correlations and aging. Such a scenario provides strong hints for the possible application of Tsallis generalized thermostatistics. The QSS have been recently interpreted as a spin-glass phase of the model. This link indicates another promising line of research, which is not alternative to the previous one.	\N	arXiv cond-mat.stat-mech	\N	\N	2004	\N	\N	\N	10.1007/s00161-003-0170-0	\N	\N	http://arxiv.org/abs/cond-mat/0410213v1	Alessandro Pluchino, Vito Latora, Andrea Rapisarda. (2004). Dynamics and Thermodynamics of a model with long-range interactions. arXiv preprint. cond-mat/0410213v1. https://doi.org/10.1007/s00161-003-0170-0.	en	public	published	f	2026-07-30 16:24:25.870339+08	arxiv_import	2026-07-30 16:24:25.870339+08	2026-07-30 16:24:25.870339+08	\N	\N	\N	\N
267	4	LIT-000267	Exploration of the phase diagram of 5D anisotropic SU(2) gauge theory	\N	paper	In this paper we attempt a non-perturbative study of the five dimensional, anisotropic SU(2) gauge theory on the lattice using Monte-Carlo techniques. Our goal is the exploration of the phase diagram, define the various phases and the critical boundary lines. Three phases appear, two of them are continuations of the Strong and the Weak coupling phases of pure 4d SU(2) to non-zero coupling $β^{'}$ in the fifth transverse direction and they are separated by a crossover transition, while the third phase is a 5D Coulombic phase. We provide evidence that the phase transition between the 5D Coulomb phase and the Weak coupling phase is a second order phase transition. Assuming that this result is not altered when increasing the lattice volume we give a first estimate of the associated critical exponents. This opens the possibility for a continuum effective five dimensional field theory.	\N	arXiv hep-lat, hep-ph, hep-th	\N	\N	2010	\N	\N	\N	10.1016/j.nuclphysb.2012.05.002	\N	\N	http://arxiv.org/abs/1007.4442v2	K. Farakos, S. Vrentzos. (2010). Exploration of the phase diagram of 5D anisotropic SU(2) gauge theory. arXiv preprint. 1007.4442v2. https://doi.org/10.1016/j.nuclphysb.2012.05.002.	en	public	published	f	2026-07-30 16:24:25.873454+08	arxiv_import	2026-07-30 16:24:25.873454+08	2026-07-30 16:24:25.873454+08	\N	\N	\N	\N
300	4	LIT-000300	Improved efficiency of planar light converters based on Al2O3-YAG:Ce eutectic crystals: Physical Trends and Limits	\N	paper	A theoretical model of a crystalline converter of white light with internal scattering medium is proposed. Obtained are the expressions for estimation of the light converter efficiency depending on its optical parameters (refractive index and coefficients of absorption at the wavelengths of the incident and re-emitted light), as well as on the geometrical dimensions and the scattering indicatrix of the optical system. The physical limits of improvement of the converter efficiency due to strong internal scattering, are established. Realized are the theoretical and experimental estimations of the efficiency of the light converter based on the crystals of Al2O3-YAG:Ce eutectic alloy which amounts to 16%. This is twice as high in comparison with the efficiency of the light converter based on YAG:Ce single crystal.	\N	arXiv physics.optics, cond-mat.mtrl-sci, physics.app-ph	\N	\N	2021	\N	\N	\N	arxiv.2105.08259	\N	\N	http://arxiv.org/abs/2105.08259v1	S. V. Naydenov, O. M. Vovk, Yu. V. Siryk, S. V. Nizhankovskyi, I. M. Pritula. (2021). Improved efficiency of planar light converters based on Al2O3-YAG:Ce eutectic crystals: Physical Trends and Limits. arXiv preprint. 2105.08259v1.	en	public	published	f	2026-07-30 16:26:20.18663+08	arxiv_import	2026-07-30 16:26:20.18663+08	2026-07-30 16:26:20.18663+08	\N	\N	\N	\N
268	4	LIT-000268	Phase Composition of AlTiNbMoV, AlTiNbTaZr and AlTiNbMoCr Refractory Complex Concentrated Alloys: A Correlation of Predictions and Experiment	\N	paper	Designing complex concentrated alloys (CCA), also known as high entropy alloys (HEA), requires reliable and accessible thermodynamic predictions due to vast space of possible compositions. Numerous semiempirical parameters have been developed for phase predictions over the years. However, in this paper we show that none of these parameters is a robust indicator of phase content in various refractory CCA. CALPHAD proved to be a more powerful tool for phase predictions, however, the predictions face several limitations. AlTiNbMoV, AlTiNbTaZr and AlTiNbMoCr alloys were prepared using blended elemental powder metallurgy. Their phase and chemical composition were investigated by the means of scanning electron microscopy, energy-dispersive X-ray spectroscopy and X-ray diffraction. Apart from the minor contamination phases (Al2O3 and Ti(C,N,O)), AlTiNbMoV and AlTiNbMoCr exhibited single-phase solid solution microstructure at the homogenization temperature of 1400 °C, while Al3Zr5 based intermetallics were present in the AlTiNbTaZr alloy. None of the simple semiempirical parameter was able to predict phase content correctly in all three alloys. Predictions by CALPHAD (TCHEA4 database) were able to predict the phases with limited accuracy only. Critical limitation of the TCHEA4 database is that only binary and ternary phase diagrams are assessed and some more complex phases cannot be predicted.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2024	\N	\N	\N	10.1007/s11661-024-07595-2	\N	\N	http://arxiv.org/abs/2409.20119v2	Jiří Kozlík, František Lukáč, Mariano Casas Luna, Kristián Šalata, Josef Stráský, Jozef Veselý, Eliška Jača, Tomáš Chráska. (2024). Phase Composition of AlTiNbMoV, AlTiNbTaZr and AlTiNbMoCr Refractory Complex Concentrated Alloys: A Correlation of Predictions and Experiment. arXiv preprint. 2409.20119v2. https://doi.org/10.1007/s11661-024-07595-2.	en	public	published	f	2026-07-30 16:25:44.770369+08	arxiv_import	2026-07-30 16:25:44.770369+08	2026-07-30 16:25:44.770369+08	\N	\N	\N	\N
269	4	LIT-000269	Crystal Shapes and Phase Equilibria: A Common Mathematical Basis	\N	paper	Geometrical constructions, such as the tangent construction on the molar free energy for determining whether a particular composition of a solution, is stable, are related to similar tangent constructions on the orientation-dependent interfacial energy for determining stable interface orientations and on the orientation dependence of the crystal growth rate which tests whether a particular orientation appears on a growing crystal. Subtle differences in the geometric constructions for the three fields arise from the choice of a metric (unit of measure). Using results from studies of extensive and convex functions we demonstrate that there is a common mathematical structure for these three disparate topics, and use this to find new uses for well-known graphical methods for all three topics. Thus the use of chemical potentials for solution thermodynamics is very similar to known vector formulations for surface thermodynamics, and the method of characteristics which tracks the interfaces of growing crystals; the Gibbs-Duhem equation is analogous to the Cahn-Hoffman equation. The Wulff construction for equilibrium crystal shapes can be modified to construct a ``phase shape'' from solution free energies that is a potentially useful method of numerical calculations of phase diagrams from known thermodynamical data.	\N	arXiv cond-mat.mtrl-sci, cond-mat.str-el	\N	\N	2007	\N	\N	\N	arxiv.cond-mat/0703564	\N	\N	http://arxiv.org/abs/cond-mat/0703564v1	J. W. Cahn, W. C. Carter. (2007). Crystal Shapes and Phase Equilibria: A Common Mathematical Basis. arXiv preprint. cond-mat/0703564v1.	en	public	published	f	2026-07-30 16:25:44.802389+08	arxiv_import	2026-07-30 16:25:44.802389+08	2026-07-30 16:25:44.802389+08	\N	\N	\N	\N
270	4	LIT-000270	Sparking mashups to form multifunctional alloy nanoparticles	\N	paper	Synthesizing unconventional alloys remains challenging owing to seamless interactions between kinetics and thermodynamics. High entropy alloys (HEAs), for example, draw a fundamentally new concept to enable exploring unknown regions in phase diagrams. The exploration, however, is hindered by traditional metallurgies based on liquid-solid transformation. Vapor-solid transformation that is permissible on pressure-temperature phase diagrams, offers the most kinetically efficient pathway to form any desired alloy (e.g., HEA). Here, we report that a technique called "sparking mashups", which involves a rapidly quenched vapor source and induces unrestricted mixing for alloying 55 distinct types of ultrasmall nanoparticles (NPs) with controllable compositions. Unlike the precursor feed in wet chemistry, a microseconds-long oscillatory spark controls the vapour composition, which is eventually retained in the alloy NPs. The resulting NPs range from binary to HEAs with marked thermal stability at room temperature. We show that a nanosize-effect ensures such thermal stability and mimics the role of mixing entropy in HEAs. This discovery contradicts the traditional "smaller is less stable" view while enabling the elemental combinations that have never been alloyed to date. We even break the miscibility limits by mixing bulk-immiscible systems in alloy NPs. As powerful examples, we demonstrate the alloy NPs as both high-performance fuel-cell catalysts and building blocks for three-dimensional (3D) nanoprinting to construct HEA nanostructure arrays of various architectures and compositions. Our results form the basis of new rules for guiding HEA-NP synthesis and advancing catalysis and 3D printing to new frontiers.	\N	arXiv physics.app-ph, cond-mat.mtrl-sci, physics.chem-ph	\N	\N	2019	\N	\N	\N	arxiv.1909.08147	\N	\N	http://arxiv.org/abs/1909.08147v2	Jicheng Feng, Dong Chen, Peter V. Pikhitsa, Yoon-ho Jung, Jun Yang, Mansoo Choi. (2019). Sparking mashups to form multifunctional alloy nanoparticles. arXiv preprint. 1909.08147v2.	en	public	published	f	2026-07-30 16:25:44.811388+08	arxiv_import	2026-07-30 16:25:44.811388+08	2026-07-30 16:25:44.811388+08	\N	\N	\N	\N
271	4	LIT-000271	Towards the ab initio based theory of the phase transformations in iron and steel	\N	paper	Despite of the appearance of numerous new materials, the iron based alloys and steels continue to play an essential role in modern technology. The properties of a steel are determined by its structural state (ferrite, cementite, pearlite, bainite, martensite, and their combination) that is formed under thermal treatment as a result of the shear lattice reconstruction "gamma" (fcc) -&gt; "alpha" (bcc) and carbon diffusion redistribution. We present a review on a recent progress in the development of a quantitative theory of the phase transformations and microstructure formation in steel that is based on an ab initio parameterization of the Ginzburg-Landau free energy functional. The results of computer modeling describe the regular change of transformation scenario under cooling from ferritic (nucleation and diffusion-controlled growth of the "alpha" phase to martensitic (the shear lattice instability "gamma" -&gt; "alpha"). It has been shown that the increase in short-range magnetic order with decreasing the temperature plays a key role in the change of transformation scenarios. Phase-field modeling in the framework of a discussed approach demonstrates the typical transformation patterns.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2017	\N	\N	\N	10.1134/S0031918X16130032	\N	\N	http://arxiv.org/abs/1707.04287v1	I. K. Razumov, Yu. N. Gornostyrev, M. I. Katsnelson. (2017). Towards the ab initio based theory of the phase transformations in iron and steel. arXiv preprint. 1707.04287v1. https://doi.org/10.1134/S0031918X16130032.	en	public	published	f	2026-07-30 16:25:44.825218+08	arxiv_import	2026-07-30 16:25:44.825218+08	2026-07-30 16:25:44.825218+08	\N	\N	\N	\N
272	4	LIT-000272	Phase transformation in steel alloys for magnetocaloric applications; Fe$_{85-x}$Cr$_{15}$Ni$_{x}$ and Fe$_{85-x}$Cr$_{15}$Mn$_{x}$ as prototypes	\N	paper	We here show by first principles theory that it is possible to achieve a structural and magnetic phase transition in common steel alloys like Fe$_{85}$Cr$_{15}$, by alloying with Ni or Mn. The predicted phase transition is from the ferromagnetic body centered cubic (bcc) phase to the paramagnetic face centered cubic (fcc) phase. The relatively high average magnetic moment of $\\sim1.4μ_{B}$/atom predicted at the transition suggests that stainless steel potentially can present a magnetocaloric effect strong enough to make these alloys good candidates for refrigeration applications operating at and around room temperature.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2012	\N	\N	\N	arxiv.1201.4176	\N	\N	http://arxiv.org/abs/1201.4176v1	P. Souvatzis, E. K. Delczeg-Czirjak, L. Vitos, O. Eriksson. (2012). Phase transformation in steel alloys for magnetocaloric applications; Fe$_{85-x}$Cr$_{15}$Ni$_{x}$ and Fe$_{85-x}$Cr$_{15}$Mn$_{x}$ as prototypes. arXiv preprint. 1201.4176v1.	en	public	published	f	2026-07-30 16:25:44.834252+08	arxiv_import	2026-07-30 16:25:44.834252+08	2026-07-30 16:25:44.834252+08	\N	\N	\N	\N
273	4	LIT-000273	Nanoscale mapping of phase-transformation pathways in medium-Mn TRIP steel by multimodal STEM	\N	paper	The mechanical response of third-generation advanced high-strength steels is governed by phase transformations at the nanoscale, yet the coupled evolution of chemistry and crystallography remains poorly resolved. Here we apply a correlative scanning transmission electron microscopy approach that enables simultaneous mapping of lattice structure, crystallographic orientation, and phase distribution at 10 nanometre resolution in a medium-manganese TRIP steel. We combine nano-beam electron diffraction and energy-dispersive X-ray spectroscopy maps to characterize an industrial medium-manganese steel containing 7.15 weight percent Mn. Tensile testing of a rolled steel sample was performed, and lamellae were extracted from deformed and undeformed regions. Manganese-resolved energy-dispersive X-ray spectroscopy provides a chemical fingerprint that, when combined with nano-beam electron diffraction based phase segmentation, enables robust ferrite-martensite separation and phase-resolved lattice-parameter refinement. The phase fractions of ferrite, austenite, and martensite are quantified together with their corresponding lattice parameters, accompanied by measurable shifts in grain-size distributions and crystallographic texture in the deformed regions. Kernel average misorientation maps reveal systematically lower local misorientation in ferrite than in martensite. This multimodal workflow provides a transferable framework for quantitative, phase-resolved analysis of complex multiphase alloys at the nanoscale.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2026	\N	\N	\N	arxiv.2601.22407	\N	\N	http://arxiv.org/abs/2601.22407v1	Marc Raventós-Tato, S. Leila Panahi, Núria Bagués, David Frómeta, Oleg Usoltsev, Núria Cuadrado, Joaquín Otón. (2026). Nanoscale mapping of phase-transformation pathways in medium-Mn TRIP steel by multimodal STEM. arXiv preprint. 2601.22407v1.	en	public	published	f	2026-07-30 16:26:05.01541+08	arxiv_import	2026-07-30 16:26:05.01541+08	2026-07-30 16:26:05.01541+08	\N	\N	\N	\N
274	4	LIT-000274	A Theoretical Investigation of Orientation Relationships and Transformation Strains in Steels	\N	paper	The identification of orientation relationships (ORs) plays a crucial rôle in the understanding of solid phase transformations. In steels, the most common models of ORs are the ones by Nishiyama-Wassermann (NW) and Kurdjumov-Sachs (KS). The defining feature of these and other OR models is the matching of directions and planes in the parent face-centred cubic $γ$-phase to ones in the product body-centred cubic/tetragonal $α/α'$-phase. In this paper a novel method that identifies transformation strains with ORs is introduced and used to develop a new strain-based approach to phase transformation models in steels. Using this approach, it is shown that the transformation strains that leave a close packed plane in the $γ$-phase and a close packed direction within that plane unrotated are precisely those giving rise to the NW and KS ORs when a cubic product phase is considered. Further, it is outlined how, by choosing different pairs of unrotated planes and directions, other common ORs such as the ones by Pitsch (PT) and Greninger-Troiano (GT) can be derived. One of the advantages of our approach is that it leads to a natural generalisation of the NW, KS and other ORs for different ratios of tetragonality $r$ of the product bct $α'$-phase. These generalised ORs predict a sharpening of the transformation textures with increasing tetragonality and are thus in qualitative agreement with experiments on steels with varying alloy concentration.	\N	arXiv cond-mat.mtrl-sci, math-ph	\N	\N	2016	\N	\N	\N	10.1107/S2053273316020350	\N	\N	http://arxiv.org/abs/1604.05270v2	Anton Muehlemann, Konstantinos Koumatos. (2016). A Theoretical Investigation of Orientation Relationships and Transformation Strains in Steels. arXiv preprint. 1604.05270v2. https://doi.org/10.1107/S2053273316020350.	en	public	published	f	2026-07-30 16:26:05.029084+08	arxiv_import	2026-07-30 16:26:05.029084+08	2026-07-30 16:26:05.029084+08	\N	\N	\N	\N
275	4	LIT-000275	Pressure-Induced Martensitic Phase Transformation and Microstructure Evolution in nanograined $\\text{Fe}\\text{-}7\\%\\text{Mn}$ Alloy	\N	paper	The Fe-Mn-based alloys are receiving immense attention due to their applications in the third generation of advanced high-strength steels, owing to their high strength and ductility. A detailed in situ high-pressure structural phase transformation and microstructural evolution in nanograined $\\text{Fe}\\text{-}7\\%\\text{Mn}$ alloy has been performed using the axial synchrotron X-ray diffraction technique. The ambient BCC phase of $\\text{Fe}\\text{-}7\\%\\text{Mn}$ undergoes pressure-driven structural PT to the HCP phase at 11.4 GPa. Both BCC and HCP phases coexist up to 15.9 GPa; thereafter, they transform into a pure HCP phase, which remains stable up to the maximum pressure of 30.3 GPa. The XRD study reveals that the $(110)_{\\mathrm{b}}$ dense crystallographic plane of the BCC lattice transforms into a densely packed $(002)_{\\mathrm{h}}$ peak of the HCP lattice following the orientational relationship $(110)_{\\mathrm{b}} \\parallel (0001)_{\\mathrm{h}}$ via diffusionless $ \\mathrm{Burger's} $ martensitic crystallographic PT pathway. The evolution of crystallite size and microstrain with pressure shows a distinct change during the structural PT. The microstrain exhibits a sharp anomaly at around 10 GPa, suggesting that the microstructural changes precede the structural PT.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2026	\N	\N	\N	arxiv.2601.08202	\N	\N	http://arxiv.org/abs/2601.08202v1	Mrinmay Sahu, Sorb Yesudhas, Valery I. Levitas, Dean Smith. (2026). Pressure-Induced Martensitic Phase Transformation and Microstructure Evolution in nanograined $\\text{Fe}\\text{-}7\\%\\text{Mn}$ Alloy. arXiv preprint. 2601.08202v1.	en	public	published	f	2026-07-30 16:26:05.033841+08	arxiv_import	2026-07-30 16:26:05.033841+08	2026-07-30 16:26:05.033841+08	\N	\N	\N	\N
276	4	LIT-000276	Grain-level effects on in-situ deformation-induced phase transformations in a complex-phase steel using 3DXRD and EBSD	\N	paper	A novel complex-phase steel alloy is conceived with a deliberately unstable austenite, $γ$, phase that enables the deformation-induced martensitic transformations (DIMT) to be explored at low levels of plastic strain. The DIMT was thus explored, in-situ and non-destructively, using both far-field Three-Dimensional X-Ray Diffraction (3DXRD) and Electron Back-Scatter Diffraction (EBSD). Substantial $α'$ martensite formation was observed under 10% applied strain with EBSD, and many $\\varepsilon$ grain formation events were captured with 3DXRD, indicative of the indirect transformation of martensite via the reaction $γ\\rightarrow \\varepsilon \\rightarrow α'$. Using $\\varepsilon$ grain formation as a direct measurement of $γ$ grain stability, the influence of several microstructural properties, such as grain size, orientation and neighbourhood configuration, on $γ$ stability have been identified. Larger $γ$ grains were found to be less stable than smaller grains. Any $γ$ grains oriented with {100} parallel to the loading direction preferentially transformed with lower stresses. Parent $\\varepsilon$-forming $γ$ grains possessed a neighbourhood with increased ferritic/martensitic volume fraction. This finding shows, unambiguously, that $α$/$α'$ promotes $\\varepsilon$ formation in neighbouring grains. The minimum strain work criterion model for $\\varepsilon$ variant prediction was also evaluated, which worked well for most grains. However, $\\varepsilon$-forming grains with a lower stress were less well predicted by the model, indicating crystal-level behaviour must be considered for accurate $\\varepsilon$ formation. The findings from this work are considered key for the future design of alloys where the deformation response can be controlled by tailoring microstructure and local or macroscopic crystal orientations.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2023	\N	\N	\N	10.1016/j.actamat.2023.119608	\N	\N	http://arxiv.org/abs/2311.03088v2	James A. D. Ball, Claire Davis, Carl Slater, Himanshu Vashishtha, Mohammed Said, Louis Hébrard, Florian Steinhilber, Jonathan P. Wright, Thomas Connolley, Stefan Michalik, David M. Collins. (2023). Grain-level effects on in-situ deformation-induced phase transformations in a complex-phase steel using 3DXRD and EBSD. arXiv preprint. 2311.03088v2. https://doi.org/10.1016/j.actamat.2023.119608.	en	public	published	f	2026-07-30 16:26:05.038357+08	arxiv_import	2026-07-30 16:26:05.038357+08	2026-07-30 16:26:05.038357+08	\N	\N	\N	\N
277	4	LIT-000277	Spatially resolved in-situ characterisation of competing martensitic transformation pathways during nanoscratch in 316H Stainless Steel	\N	paper	Localised surface deformation beneath frictional contacts generates a tribolayer whose microstructure and properties differ from the bulk. In austenitic stainless steels, this tribolayer forms through two competing martensitic transformation pathways. Here, these pathways are isolated in 316H stainless steel using in-situ synchrotron X-ray nanodiffractometry combined with nanoscratch testing, which together yield spatial maps of the evolving strain field beneath a single sliding asperity. Finite element modelling interprets the resulting distribution of martensitic phases, revealing a pressure driven pathway selection where hydrostatic compression ahead of the contact suppresses $α'$ formation and favours the $γ\\rightarrow \\varepsilon$ transformation, while lateral sliding relieves this constraint and introduces a shear strain driving $\\varepsilon \\rightarrow α'$ , producing an overall sequential $γ\\rightarrow \\varepsilon \\rightarrow α'$ pathway in the tribolayer. Where hydrostatic constraint persists, $\\varepsilon$-martensite is retained; where material piles up and is unconstrained above the surface, the transformation proceeds directly to $α'$. The $γ$-austenite adjacent to $α'$- martensite shows elevated dislocation density, indicating that $α'$ formation is accommodated by plastic deformation in the surrounding matrix. This distinction could explain differences in galling performance among iron-based and cobalt-based hardfacing alloys, where the $\\varepsilon$-martensite forming cobalt alloys offer superior galling resistance. The methodology presented resolves transient microstructural states inaccessible to static measurements of macroscale, multiple asperity contacts, establishing a route to mechanistic insight across tribological phenomena more broadly.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2026	\N	\N	\N	arxiv.2607.19239	\N	\N	http://arxiv.org/abs/2607.19239v1	A. Kareer, R. W. Kerr, D. Craven, A. V. Davydok, C. Krywka, D. M. Collins. (2026). Spatially resolved in-situ characterisation of competing martensitic transformation pathways during nanoscratch in 316H Stainless Steel. arXiv preprint. 2607.19239v1.	en	public	published	f	2026-07-30 16:26:05.051048+08	arxiv_import	2026-07-30 16:26:05.051048+08	2026-07-30 16:26:05.051048+08	\N	\N	\N	\N
278	4	LIT-000278	A level-set formulation to simulate diffusive solid/solid phase transformation in polycrystalline metallic materials -- Application to austenite decomposition in steels	\N	paper	Numerous full-field numerical methods exist concerning the digital description of polycrystalline materials and the modeling of their evolution during thermomechanical treatments. However, these strategies are globally dedicated to the modeling of recrystallization and grain growth for single-phase materials, or to the modeling of phase transformations without considering recrystallization and related phenomena. A generalized numerical framework capable of making predictions in a multi-phase polycrystalline context while respecting the concomitance of the different microstructural mechanisms is thus of prime interest. A novel finite element level-set based full-field numerical formulation is proposed to principally simulate diffusive solid-solid phase transformation at the mesoscopic scale in the context of two-phase metallic alloys. A global kinetic framework, capable of accounting for other concomitant mechanisms such as recrystallization and grain growth is considered in this numerical model. The proposed numerical framework is shown to be promising through a couple of illustrative 1D and 2D test cases in the context of austenite decomposition in steels and compared with ThermoCalc estimations.	\N	arXiv cs.CE, cond-mat.mtrl-sci	\N	\N	2022	\N	\N	\N	arxiv.2208.09434	\N	\N	http://arxiv.org/abs/2208.09434v1	Nitish Chandrappa, Marc Bernacki. (2022). A level-set formulation to simulate diffusive solid/solid phase transformation in polycrystalline metallic materials -- Application to austenite decomposition in steels. arXiv preprint. 2208.09434v1.	en	public	published	f	2026-07-30 16:26:05.057879+08	arxiv_import	2026-07-30 16:26:05.057879+08	2026-07-30 16:26:05.057879+08	\N	\N	\N	\N
279	4	LIT-000279	The superite phase and phase transition inducing multiscale solidification microstructures and segregations in steels	\N	paper	Based on classical concept, solidification of alloys is a direct transition from liquid phase to solid phase, by which dendrites and dendritic segregation are produced. Through in-situ and real time morphology observation and XRD test during solidification of three steels, a new superite phase featured as statistically oriented tiny structures was identified, and a general liquid-superite-solid phase transformation process is revealed. In the early solidification stage, the liquid alloys transit to dendrites composed of superite phase. Initiated from the boundaries of dendritic arms or dendrite grains, the superite phase transits to austenite grains within an initial dendritic arm, and expels solute elements to the residual superite phase. Mixed multi-phase microstructures are subsequently produced from the residual enriched superite phase. Here, although three steels exhibit different phase proportion and phase constitution in the superite-solid transition, they all follow above general transition mode. Multiscale microstructures and segregations are produced in the transition from superite to solid. These new findings change the basic understanding about the solidification of alloys, rediscover the formation mechanism on segregations and multiscale solidification microstructures, including dendrite pattern, solid dendritic arm, dendritic segregation, the mixed multi-phase microstructures, eutectic, inclusions and precipitate. These new findings are also crucial to the control of solidification microstructures and segregation in metals.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2026	\N	\N	\N	arxiv.2605.08620	\N	\N	http://arxiv.org/abs/2605.08620v1	Xiaoping Ma, Dianzhong Li, Zhuo Zhao, Saichao Cao, Donghao Pei, Pei Wang, Yuxi Tao, Paixian Fu, Hongwei Liu, Xiuhong Kang. (2026). The superite phase and phase transition inducing multiscale solidification microstructures and segregations in steels. arXiv preprint. 2605.08620v1.	en	public	published	f	2026-07-30 16:26:05.061933+08	arxiv_import	2026-07-30 16:26:05.061933+08	2026-07-30 16:26:05.061933+08	\N	\N	\N	\N
280	4	LIT-000280	Designing order-disorder transformation in high-entropy ferritic steels	\N	paper	Order-disorder transformations hold an essential place in chemically complex high-entropy ferritic-steels (HEFSs) due to their critical technological application. The chemical inhomogeneity arising from mixing of multi-principal elements of varying chemistry can drive property altering changes at the atomic scale, in particular short-range order. Using density-functional theory based linear-response theory, we predict the effect of compositional tuning on the order-disorder transformation in ferritic steels -focusing on Cr-Ni-Al-Ti-Fe HEFSs. We show that Ti content in Cr-Ni-Al-Ti-Fe solid solutions can be tuned to modify short-range order that changes the order-disorder path from BCC-B2 (Ti atomic-fraction = 0) to BCC-B2-L21 (Ti atomic-faction $&gt;$ 0) consistent with existing experiments. Our study suggests that tuning degree of SRO through compositional variation can be used as an effective means to optimize phase selection in technologically useful alloys.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2021	\N	\N	\N	10.1557/s43578-021-00336-w	\N	\N	http://arxiv.org/abs/2108.04110v1	Singh, Prashant, Johnson, Duane D. (2021). Designing order-disorder transformation in high-entropy ferritic steels. arXiv preprint. 2108.04110v1. https://doi.org/10.1557/s43578-021-00336-w.	en	public	published	f	2026-07-30 16:26:05.072513+08	arxiv_import	2026-07-30 16:26:05.072513+08	2026-07-30 16:26:05.072513+08	\N	\N	\N	\N
371	4	LIT-000371	Exploring Hydride Formation in Stainless Steel Revisits Theory of Hydrogen Embrittlement	\N	paper	Various mechanisms have been proposed for hydrogen embrittlement, but the causation of hydrogen-induced material degradation has remained unclear. This work shows hydrogen embrittlement due to phase instability (decomposition). In-situ diffraction measurements revealed metastable hydrides formed in stainless steel, typically declared as a non-hydride forming material. Hydride formation is possible by increasing the hydrogen chemical potential during electrochemical charging and low defect formation energy of hydrogen interstitials. Our findings demonstrate that hydrogen-induced material degradation can only be understood if measured in situ and in real-time during the embrittlement process.	\N	arXiv cond-mat.mtrl-sci, hep-lat, physics.comp-ph	\N	\N	2022	\N	\N	\N	arxiv.2209.09516	\N	\N	http://arxiv.org/abs/2209.09516v1	Cem Örnek, Alfred Larsson, Mubashir Mansoor, Fan Zhang, Gary S Harlow, Robin Kroll, Francesco Carlà, Hadeel Hussain, Bora C Derin, Ulf Kivisäkk, Dirk L Engelberg, Edvin Lundgren, Jinshan Pan. (2022). Exploring Hydride Formation in Stainless Steel Revisits Theory of Hydrogen Embrittlement. arXiv preprint. 2209.09516v1.	en	public	published	f	2026-07-30 16:27:00.885324+08	arxiv_import	2026-07-30 16:27:00.885324+08	2026-07-30 16:27:00.885324+08	\N	\N	\N	\N
281	4	LIT-000281	The role of austenite twins on variant selection during bainitic decomposition of a low carbon (0.06 wt%) steel	\N	paper	Thermomechanical Controlled Processing (TMCP) is widely used to control the microstructure and properties of linepipe or high strength low alloy steels (HSLA). These steels are often joined by welding and used in demanding environments such as the Arctic. In these materials, the thermal path the steel experiences is critical for understanding microstructural evolution during processing. A key step is the solid-state phase transformation during cooling from the high-temperature austenite to the room-temperature microstructure which significantly influences the final mechanical properties. We used 3D electron backscatter diffraction (EBSD) to explore the relationship between the austenite phase and the room temperature microstructure. A significant result for the present work is the collection, and analysis, of data from a large volume (150 x 150 x 100 um3, with a (200 nm)3 voxel size) which enables analysis of a complete prior austenite grain. This grain is twinned, allowing us to analyse the variants at the twin boundary in this grain, which offers new insights into the mechanisms of the transformation to the low temperature phase by highlighting the significant of the twin boundaries on the variants present. This suggests opportunities to engineer novel microstructures by controlling the high-temperature grain boundary character.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2026	\N	\N	\N	arxiv.2603.07378	\N	\N	http://arxiv.org/abs/2603.07378v2	Ruth M. Birch, Ben Britton, Warren J Poole. (2026). The role of austenite twins on variant selection during bainitic decomposition of a low carbon (0.06 wt%) steel. arXiv preprint. 2603.07378v2.	en	public	published	f	2026-07-30 16:26:05.077161+08	arxiv_import	2026-07-30 16:26:05.077161+08	2026-07-30 16:26:05.077161+08	\N	\N	\N	\N
282	4	LIT-000282	Design of a V-Ti-Ni alloy with superelastic nano-precipitates	\N	paper	Stress-induced martensitic transformations enable metastable alloys to exhibit enhanced strain hardening capacity, leading to improved formability and toughness. As is well-known from transformation-induced plasticity (TRIP) steels, however, the resulting martensite can limit ductility and fatigue life due to its intrinsic brittleness. In this work, we explore an alloy design strategy that utilizes stress-induced martensitic transformations but does not retain the martensite phase. This strategy is based on the introduction of superelastic nano-precipitates, which exhibit reverse transformation after initial stress-induced forward transformation. To this end, utilizing ab-initio simulations and thermodynamic calculations we designed and produced a V45Ti30Ni25 (at%) alloy. In this alloy, TiNi is present as nano-precipitates uniformly distributed within a ductile V-rich base-centered cubic (bcc) beta matrix, as well as being present as a larger matrix phase. We characterized the microstructure of the produced alloy using various scanning electron microscopy (SEM) and transmission electron microscopy (TEM) methods. The bulk mechanical properties of the alloy are demonstrated through tensile tests, and the reversible transformation in each of the TiNi morphologies were confirmed by in-situ TEM micro-pillar compression experiments, in-situ high-energy diffraction synchrotron cyclic tensile tests, indentation experiments, and differential scanning calorimetry experiments. The observed transformation pathways and variables impacting phase stability are critically discussed	\N	arXiv cond-mat.mtrl-sci	\N	\N	2021	\N	\N	\N	10.1016/j.actamat.2020.07.023	\N	\N	http://arxiv.org/abs/2103.13978v2	J. -L. Zhang, J. L. Cann, S. B. Maisel, K. Qu, E. Plancher, H. Springer, E. Povoden-Karadeniz, P. Gao, Y. Ren, B. Grabowski, C. C. Tasan. (2021). Design of a V-Ti-Ni alloy with superelastic nano-precipitates. arXiv preprint. 2103.13978v2. https://doi.org/10.1016/j.actamat.2020.07.023.	en	public	published	f	2026-07-30 16:26:05.081556+08	arxiv_import	2026-07-30 16:26:05.081556+08	2026-07-30 16:26:05.081556+08	\N	\N	\N	\N
283	4	LIT-000283	Physics-Informed Machine Learning for Steel Development: A Computational Framework and CCT Diagram Modelling	\N	paper	Machine learning (ML) has emerged as a powerful tool for accelerating the computational design and production of materials. In materials science, ML has primarily supported large-scale discovery of novel compounds using first-principles data and digital twin applications for optimizing manufacturing processes. However, applying general-purpose ML frameworks to complex industrial materials such as steel remains a challenge. A key obstacle is accurately capturing the intricate relationship between chemical composition, processing parameters, and the resulting microstructure and properties. To address this, we introduce a computational framework that combines physical insights with ML to develop a physics-informed continuous cooling transformation (CCT) model for steels. Our model, trained on a dataset of 4,100 diagrams, is validated against literature and experimental data. It demonstrates high computational efficiency, generating complete CCT diagrams with 100 cooling curves in under 5 seconds. It also shows strong generalizability across alloy steels, achieving phase classification F1 scores above 88% for all phases. For phase transition temperature regression, it attains mean absolute errors (MAE) below 20 °C across all phases except bainite, which shows a slightly higher MAE of 27 °C. This framework can be extended with additional generic and customized ML models to establish a universal digital twin platform for heat treatment. Integration with complementary simulation tools and targeted experiments will further support accelerated materials design workflows.	\N	arXiv cs.LG, cond-mat.mtrl-sci, physics.comp-ph	\N	\N	2025	\N	\N	\N	arxiv.2512.03050	\N	\N	http://arxiv.org/abs/2512.03050v1	Peter Hedström, Victor Lamelas Cubero, Jón Sigurdsson, Viktor Österberg, Satish Kolli, Joakim Odqvist, Ziyong Hou, Wangzhong Mu, Viswanadh Gowtham Arigela. (2025). Physics-Informed Machine Learning for Steel Development: A Computational Framework and CCT Diagram Modelling. arXiv preprint. 2512.03050v1.	en	public	published	t	2026-07-30 16:26:05.089718+08	arxiv_import	2026-07-30 16:26:05.089718+08	2026-07-30 16:26:05.089718+08	\N	\N	\N	\N
284	4	LIT-000284	Yield strength insensitivity in a dual-phase high entropy alloy after prolonged high temperature annealing	\N	paper	Recent studies of FeMnCoCr-based high entropy alloys have demonstrated uncommon deformation behaviors such as transformation-induced plasticity, which were largely believed to be restricted to select families of steels. Coupled with the potential for entropy stabilization of high symmetry phases at high temperatures, this system represents a promising class of materials for structural applications in extreme environments. Yet, transformation-induced plasticity mechanisms are notably sensitive to microstructure parameters and the literature offers examples of deleterious decomposition of high entropy alloys under heat treatment, which raises concerns of resiliency in mechanical performance. Here, we evaluate the evolution of microstructure and mechanical properties of a FeMnCoCr high entropy alloy after prolonged heat treatment at high temperature. Microstructures are found to retain their characteristic austenite/martensite features, with parent face-centered cubic grains partitioned by hexagonal close-packed laths after heat treatment at 1200 C for up to 48 hours. Results of mechanical testing reveal an unusual insensitivity of this alloy to grain growth-induced weakening effects. Namely, the yield strengths of FeMnCoCr samples are observed to remain constant across all heat treatment conditions, despite a near four-fold increase in the grain size. Close examination of post-heat treatment microstructures reveals a dramatic decrease in the inter-lath spacing at longer durations, which segments parent austenite grains. This crystal partitioning counteracts conventional grain growth-induced weakening by introducing additional barriers for dislocation pile-up. These results offer new insights into the mechanical resiliency of this transformation-induced plasticity high entropy alloy under prolonged high temperature heat treatment.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2021	\N	\N	\N	10.1016/j.msea.2021.141586	\N	\N	http://arxiv.org/abs/2103.05567v2	Junaid Ahmed, Matthew Daly. (2021). Yield strength insensitivity in a dual-phase high entropy alloy after prolonged high temperature annealing. arXiv preprint. 2103.05567v2. https://doi.org/10.1016/j.msea.2021.141586.	en	public	published	t	2026-07-30 16:26:05.099462+08	arxiv_import	2026-07-30 16:26:05.099462+08	2026-07-30 16:26:05.099462+08	\N	\N	\N	\N
285	4	LIT-000285	Coupling Physics in Machine Learning to Predict Properties of High-temperatures Alloys	\N	paper	High-temperature alloy design requires a concurrent consideration of multiple mechanisms at different length scales. We propose a workflow that couples highly relevant physics into machine learning (ML) to predict properties of complex high-temperature alloys with an example of the 9-12 wt.% Cr steels yield strength. We have incorporated synthetic alloy features that capture microstructure and phase transformations into the dataset. Identified high impact features that affect yield strength of 9Cr from correlation analysis agree well with the generally accepted strengthening mechanism. As part of the verification process, the consistency of sub-datasets has been extensively evaluated with respect to temperature and then refined for the boundary conditions of trained ML models. The predicted yield strength of 9Cr steels using the ML models is in excellent agreement with experiments. The current approach introduces physically meaningful constraints in interrogating the trained ML models to predict properties of hypothetical alloys when applied to data-driven materials.	\N	arXiv cond-mat.mtrl-sci, physics.comp-ph	\N	\N	2020	\N	\N	\N	10.1038/s41524-020-00407-2	\N	\N	http://arxiv.org/abs/2004.05424v2	Jian Peng, Yukinori Yamamoto, Jeffrey A. Hawk, Edgar Lara-Curzio, Dongwon Shin. (2020). Coupling Physics in Machine Learning to Predict Properties of High-temperatures Alloys. arXiv preprint. 2004.05424v2. https://doi.org/10.1038/s41524-020-00407-2.	en	public	published	f	2026-07-30 16:26:05.102721+08	arxiv_import	2026-07-30 16:26:05.102721+08	2026-07-30 16:26:05.102721+08	\N	\N	\N	\N
286	4	LIT-000286	Cyclic Re-austenitization of Copper-bearing High-Strength Low-Alloy Steels Fabricated by Laser Powder Bed Fusion	\N	paper	For the first time, cyclic re-austenitization is carried out for additively manufactured high-strength low-alloy (HSLA) steels in order to refine the microstructure by reducing the prior austenite grain (PAG) size. In this work, HSLA-100 steels processed using laser powder bed fusion (LPBF) technique are subjected to several cycles of re-austenitization using quenching dilatometry. Microstructure characterization for every cycle revealed the presence of bainite, martensite and martensite/austenite (M/A) islands. From the analysis of the dilatometry curves and extensive microstructure characterization, it was found that till the 2nd cycle of re-austenitization, both PAG size and martensite start (Ms) temperature get reduced, while the amount of bainite transformed decreased and the retained austenite content increased. Concomitantly, the highest microhardness along with peak nanohardness of the constituent phases was achieved at the 2nd cycle. Conversely, from the 3rd cycle, the microhardness, as well as the nanohardness of the constituent phases, are found to decrease due to an increase in the PAG size. This behavior is in contrast to the general tendency where a saturation limit is reached after the peak refinement is achieved. It is found that retained austenite can act as a pinning particle to obstruct the PAG boundary movement and its fraction is found to decrease from the 3rd cycle. Hence, the increase in PAG size after the 3rd cycle can be attributed to the destabilization of effective pinning particles to hinder the PAG boundary movement during the re-austenitization.	\N	arXiv cond-mat.mtrl-sci, physics.app-ph	\N	\N	2020	\N	\N	\N	10.1016/j.matchar.2020.110437	\N	\N	http://arxiv.org/abs/2006.07552v1	Soumya Sridar, Yunhao Zhao, Wei Xiong. (2020). Cyclic Re-austenitization of Copper-bearing High-Strength Low-Alloy Steels Fabricated by Laser Powder Bed Fusion. arXiv preprint. 2006.07552v1. https://doi.org/10.1016/j.matchar.2020.110437.	en	public	published	f	2026-07-30 16:26:05.107873+08	arxiv_import	2026-07-30 16:26:05.107873+08	2026-07-30 16:26:05.107873+08	\N	\N	\N	\N
287	4	LIT-000287	Interplay between diffusive and displacive phase transformations: TTT diagrams and microstructures	\N	paper	Materials which can undergo extremely fast displacive transformations as well as very slow diffusive transformations are studied using a Ginzburg-Landau framework to understand the physics behind microstructure formation and time-temperature-transformation (TTT) diagrams. This simple model captures the essential features of alloys such as steels and predicts the formation of mixed microstructures by an interplay between diffusive and displacive mechanisms. The intrinsic volume changes associated with the transformations stabilize mixed microstructures such as martensite-retained austenite (responsible for the existence of a martensite finish temperature) and martensite-pearlite. keywords: phase-field, spinodal decomposition, pearlite, martensite, steel, elastic compatibility	\N	arXiv cond-mat.mtrl-sci	\N	\N	2006	\N	\N	\N	10.1103/PhysRevLett.97.055701	\N	\N	http://arxiv.org/abs/cond-mat/0605577v1	Mathieu Bouville, Rajeev Ahluwalia. (2006). Interplay between diffusive and displacive phase transformations: TTT diagrams and microstructures. arXiv preprint. cond-mat/0605577v1. https://doi.org/10.1103/PhysRevLett.97.055701.	en	public	published	t	2026-07-30 16:26:05.112315+08	arxiv_import	2026-07-30 16:26:05.112315+08	2026-07-30 16:26:05.112315+08	\N	\N	\N	\N
288	4	LIT-000288	Solute diffusion calculation in Fe-Si and Fe-Cr-Si multicomponent alloys	\N	paper	Diffusion plays a key role in microstructure evolution at multicomponent alloys: diffusion controls the kinetics of phase transformations and alloy homogenization. This study aims at developing computationally efficient approaches to estimate the solute diffusion coefficients in two-component systems. We consider silicon as the solute example because it is highly used in industrial steels. We demonstrate that the silicon jump frequency may be calculated with the bond potential instead of the more computationally expensive machine learning potential in Fe-Si and Fe-Cr-Si alloys. We show that the silicon jump frequency can be estimated from thermodynamic simulations for the bond potential without kinetic simulations. The silicon correlation factor slightly depends on silicon concentration and can be approximately estimated by the analytical nine-frequency model.	\N	arXiv cond-mat.mtrl-sci, physics.comp-ph	\N	\N	2024	\N	\N	\N	arxiv.2411.02053	\N	\N	http://arxiv.org/abs/2411.02053v1	Timofei Miryashkin, Ivan Novoselov, Alexey Yanilkin. (2024). Solute diffusion calculation in Fe-Si and Fe-Cr-Si multicomponent alloys. arXiv preprint. 2411.02053v1.	en	public	published	f	2026-07-30 16:26:05.115839+08	arxiv_import	2026-07-30 16:26:05.115839+08	2026-07-30 16:26:05.115839+08	\N	\N	\N	\N
289	4	LIT-000289	Parent grain reconstruction from partially or fully transformed microstructures in MTEX	\N	paper	A versatile generic framework for parent grain reconstruction from fully or partially transformed child microstructures was integrated into the open-source crystallographic toolbox MTEX. The framework extends traditional parent grain reconstruction, phase transformation and variant analysis to all parent-child crystal symmetry combinations. The inherent versatility of the universally applicable parent grain reconstruction methods, and the ability to conduct in-depth variant analysis are showcased via example workflows that can be programmatically modified by users to suit their specific applications. This is highlighted by three applications namely, $α$-to-$γ$ reconstruction in a lath martensitic steel, $α$-to-$β$ reconstruction in a Ti alloy, and a two-step reconstruction from $α$-to-$\\varepsilon$-to-$γ$ in a twinning and transformation -induced plasticity steel. Advanced orientation relationship discovery and analysis options, including variant analysis, is demonstrated via the add-on function library, ORTools.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2021	\N	\N	\N	arxiv.2104.14603	\N	\N	http://arxiv.org/abs/2104.14603v1	Frank Niessen, Tuomo Nyyssönen, Azdiar A. Gazder, Ralf Hielscher. (2021). Parent grain reconstruction from partially or fully transformed microstructures in MTEX. arXiv preprint. 2104.14603v1.	en	public	published	f	2026-07-30 16:26:05.120692+08	arxiv_import	2026-07-30 16:26:05.120692+08	2026-07-30 16:26:05.120692+08	\N	\N	\N	\N
290	4	LIT-000290	Kinetic Theory of the Overlapping Phase Transformations	\N	paper	Often a number of precipitation processes in steels and alloys occur simultaneously (they have the same origin in time) albeit at different rates. Consequently, isothermic transformations are accompanied, in this case, by the occurrence of second processes of precipitation that influence the changes of the macroscopic parameter chosen for the kinetic study while first processes are occurring. In this context a set-up is presented that addresses the issue of characterization of nucleation and growth mechanisms of the individual processes. Soft and hard interferences of processes are considered. The present approach is based on the Avrami model and allows computing the kinetic parameters (n, k) of the different precipitation processes in isothermic phase reactions.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2003	\N	\N	\N	arxiv.cond-mat/0301391	\N	\N	http://arxiv.org/abs/cond-mat/0301391v1	E. Valencia-Morales, N. J. Galeano-Alvarez, J. Vega-Leyva, C. E. Villar, J. Hernandez-Ruiz. (2003). Kinetic Theory of the Overlapping Phase Transformations. arXiv preprint. cond-mat/0301391v1.	en	public	published	f	2026-07-30 16:26:05.12564+08	arxiv_import	2026-07-30 16:26:05.12564+08	2026-07-30 16:26:05.12564+08	\N	\N	\N	\N
291	4	LIT-000291	HVAF Spraying of NiTi Coatings: Microstructure, Phase Transformation and Shape Memory Behavior	\N	paper	Depositing various coatings on surface of engineering components with the aim to improve their performance concerning wear, corrosion, friction and thermal protection is already a standard practice. Depositing metallic NiTi shape memory alloy coatings may be a viable alternative for hard ceramic coatings. NiTi coatings offer additional benefits originating from unique functional thermomechanical properties. However, fabrication of thick NiTi coatings turned out to be difficult. Standard electroplating and laser cladding methods are not suitable for NiTi the most widely used plasma spray methods tend to produce chemically inhomogeneous coatings that do not transform martensitically, cold sprayed NiTi coatings suffer from poor adhesion to the substrates. In this work we report on first ever successful fabrication of thick NiTi coatings (100-300 um) that display functional thermomechanical properties and simultaneously show very good adherence to the substrate. We used high velocity air fuel thermal spray method to fabricate NiTi coatings deposited on mild steel using four different sets of processing parameters. Chemical composition, porosity, microstructure, phase transformation and functional thermomechanical properties of the NiTi coatings were evaluated. Although the coatings contain inhomogeneous microstructure, voids, oxide particles, high density of dislocation defects and internal stress, they undergo martensitic transformation upon cooling and or mechanical loading. As sprayed NiTi coatings need to be annealed to display functional thermomechanical properties. Despite their limited tensile strength, the coatings displayed thermal actuation in 3 point bending tests and shape memory effects in nanoindentation and scratch tests.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2026	\N	\N	\N	arxiv.2607.01997	\N	\N	http://arxiv.org/abs/2607.01997v1	Sneha Samal, Shrikant Joshi, Stefan Björklund, Mohit Chandra, Akhil Bhardwaj, Jaromír Kopeček, Stanislav Habr, Lukáš Václavek Jan Tomáštík, Ondřej Tyc, Petr Šittner. (2026). HVAF Spraying of NiTi Coatings: Microstructure, Phase Transformation and Shape Memory Behavior. arXiv preprint. 2607.01997v1.	en	public	published	f	2026-07-30 16:26:05.129898+08	arxiv_import	2026-07-30 16:26:05.129898+08	2026-07-30 16:26:05.129898+08	\N	\N	\N	\N
292	4	LIT-000292	Effect of Magneto-Mechanical Synergism in the Process-Structure Correlation in Fe-C Alloys: A Phase-Field Modeling Approach	\N	paper	Applied magnetic fields can alter phase equilibria and kinetics in steels; however, quantitatively resolving how magnetic, chemical, and elastic driving forces jointly influence the microstructure remains challenging. We develop a quantitative magneto-mechanically coupled phase-field model for the Fe-C system that couples a CALPHAD-based chemical free energy with demagnetization-field magnetostatics and microelasticity. The model reproduces single- and multi-particle evolution during the alpha to gamma inverse transformation at 1023 K under external fields up to 20 T, including ellipsoidal morphologies observed experimentally at 8 T. Chemically driven growth is isotropic; a magnetic interaction introduces an anisotropic driving force that elongates gamma precipitates along the field into ellipsoids, while elastic coherency promotes faceting, yielding elongated cuboidal or ``brick-like" particles under combined magneto-elastic coupling. Growth kinetics increase with C content, and decrease with field strength and misfit strain. Multi-particle simulations reveal dipolar interaction-mediated coalescence for field-parallel neighbors and ripening for field-perpendicular neighbors. Incorporating field-dependent diffusivity from experiment slows kinetics as expected; a first-principles-motivated anisotropic diffusivity correction is estimated to be small (&lt;2%). These results establish a process-structure link for magnetically assisted heat treatments of Fe-C alloys and provide guidance for microstructure control via chemo-magneto-mechanical synergism.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2025	\N	\N	\N	arxiv.2511.21854	\N	\N	http://arxiv.org/abs/2511.21854v1	Soumya Bandyopadhyay, Sourav Chatterjee, Dallas R. Trinkle, Richard G. Hennig, Victoria Miller, Michael S. Kesler, Michael R. Tonks. (2025). Effect of Magneto-Mechanical Synergism in the Process-Structure Correlation in Fe-C Alloys: A Phase-Field Modeling Approach. arXiv preprint. 2511.21854v1.	en	public	published	f	2026-07-30 16:26:05.136303+08	arxiv_import	2026-07-30 16:26:05.136303+08	2026-07-30 16:26:05.136303+08	\N	\N	\N	\N
293	4	LIT-000293	Effective structural unit analysis in hexagonal close packed alloys -- reconstruction of parent beta microstructures &amp; crystal orientation post processing analysis	\N	paper	Materials with an allotropic phase transformation can result in the formation of microstructures where grains have orientation relationships (ORs) determined by the transformation history. These microstructures influence the final material properties. In zirconium alloys, there is a solid-state body centred cubic (BCC) to hexagonal close packed (HCP) phase transformation, where the crystal orientations of the HCP phase can be related to the parent BCC structure via the Burgers orientation relationship (BOR). In the present work, we adapt a reconstruction code developed for steels which uses a Markov Chain clustering algorithm to analyse electron backscatter diffraction (EBSD) maps and apply this to the HCP and BCC BOR. This algorithm is released as open-source code (via github, as ParentBOR). The algorithm enables new post processing of the original and reconstructed data set to analyse the variants of the HCP alpha-phase that are present and understand shared crystal planes and shared lattice directions within each parent beta grain, and we anticipate that this assists in understanding the transformation related deformation properties of the final microstructure. Finally, we compare the ParentBOR code with recently released reconstruction codes implemented in MTEX to reveal differences and similarities in how the microstructure is described.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2021	\N	\N	\N	arxiv.2104.10648	\N	\N	http://arxiv.org/abs/2104.10648v2	Ruth Birch, Thomas Benjamin Britton. (2021). Effective structural unit analysis in hexagonal close packed alloys -- reconstruction of parent beta microstructures &amp; crystal orientation post processing analysis. arXiv preprint. 2104.10648v2.	en	public	published	f	2026-07-30 16:26:05.142592+08	arxiv_import	2026-07-30 16:26:05.142592+08	2026-07-30 16:26:05.142592+08	\N	\N	\N	\N
294	4	LIT-000294	Phase-field analysis of quenching and partitioning in a polycrystalline Fe-C system under constrained-carbon equilibrium condition	\N	paper	Mechanical properties of steels are significantly enhanced by retained austenite. Particularly, it has been shown that a recently developed heat-treatment technique called Quenching and Partitioning (Q\\&amp;P) stabilises austenite effectively. In the present work, the phase-field approach is adopted to simulate the phase transformation and carbon diffusion, which respectively accompanies the quenching and partitioning process of the polycrystalline Fe-C system. By incorporating the chemical driving-force from the CALPHAD database, the elastic phase-field model, which recovers the sharp-interface solutions, simulates the martensite (alpha') transformation at three different quenching temperatures. The resulting martensite volume-fractions are in complete agreement with the analytical predictions. For the first time, in this study, the constrained carbon equilibrium (CCE) condition is introduced in the polycrystalline set-up to yield the predicted partitioning endpoints. Under the CCE condition, the carbon partitioning in two alloys of varying composition is analysed through the phase-field model which employs chemical potential as the dynamic variable. The volume fraction and distribution of retained austenite is determined from the carbon distribution and its temporal evolution during the partitioning is investigated. It is identified that in the initial stages of partitioning carbon gets accumulated in the austenite ($γ$) along the $γα'$-interface, owing to the substantial difference in the diffusivities and CCE endpoints. This accumulation stabilises the austenite adjacent to the interface. However, depending on the martensite volume-fraction and the alloy composition, the evolution of the stabilised austenite varies. Furthermore, the influence of the phase distribution on the kinetics of the temporal evolution of retained austenite is elucidated.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2018	\N	\N	\N	10.1016/j.commatsci.2018.12.023	\N	\N	http://arxiv.org/abs/1812.04306v1	P G Kubendran Amos, Ephraim Schoof, Nick Streichan, Daniel Schneider, Britta Nestler. (2018). Phase-field analysis of quenching and partitioning in a polycrystalline Fe-C system under constrained-carbon equilibrium condition. arXiv preprint. 1812.04306v1. https://doi.org/10.1016/j.commatsci.2018.12.023.	en	public	published	f	2026-07-30 16:26:05.146793+08	arxiv_import	2026-07-30 16:26:05.146793+08	2026-07-30 16:26:05.146793+08	\N	\N	\N	\N
301	4	LIT-000301	Impact of Leakage for Electricity Generation by Pyroelectric Converter	\N	paper	Pyroelectric energy converter is a functional capacitor using pyroelectric material as the dielectric layer. Utilizing the first-order phase transformation of the material, the pyroelectric device can generate adequate electricity within small temperature fluctuations. However, most pyroelectric capacitors are leaking during energy conversion. In this paper, we analyze the thermodynamics of pyroelectric energy conversion with consideration of the electric leakage. Our thermodynamic model is verified by experiments using three phase-transforming ferroelectric materials with different pyroelectric properties and leakage behaviors. We demonstrate that the impact of leakage for electric generation is prominent, and sometimes may be confused with the actual power generation by pyroelectricity. We discover an ideal material candidate, (Ba,Ca)(Ti,Zr,Ce)O$_3$, which exhibits large pyroelectric current and extremely low leakage current. The pyroelectric converter made of this material generates 1.95 $μ$A/cm$^2$ pyroelectric current density and 0.2 J/cm$^3$ pyroelectric work density even after 1389 thermodynamic conversion cycles.	\N	arXiv physics.app-ph, cond-mat.mtrl-sci	\N	\N	2020	\N	\N	\N	10.1103/PhysRevApplied.14.064079	\N	\N	http://arxiv.org/abs/2009.06890v1	Chenbo Zhang, Zhuohui Zeng, Zeyuan Zhu, Mostafa Karami, Xian Chen. (2020). Impact of Leakage for Electricity Generation by Pyroelectric Converter. arXiv preprint. 2009.06890v1. https://doi.org/10.1103/PhysRevApplied.14.064079.	en	public	published	t	2026-07-30 16:26:20.192217+08	arxiv_import	2026-07-30 16:26:20.192217+08	2026-07-30 16:26:20.192217+08	\N	\N	\N	\N
295	4	LIT-000295	Phase field model for coupled displacive and diffusive microstructural processes under thermal loading	\N	paper	A non-isothermal phase field model that captures both displacive and diffusive phase transformations in a unified framework is presented. The model is developed in a formal thermodynamic setting, which provides guidance on admissible constitutive relationships and on the coupling of the numerous physical processes that are active. Phase changes are driven by temperature-dependent free-energy functions that become non-convex below a transition temperature. Higher-order spatial gradients are present in the model to account for phase boundary energy, and these terms necessitate the introduction of non-standard terms in the energy balance equation in order to satisfy the classical entropy inequality point-wise. To solve the resulting balance equations, a Galerkin finite element scheme is elaborated. To deal rigorously with the presence of high-order spatial derivatives associated with surface energies at phase boundaries in both the momentum and mass balance equations, some novel numerical approaches are used. Numerical examples are presented that consider boundary cooling of a domain at different rates, and these results demonstrate that the model can qualitatively reproduce the evolution of microstructural features that are observed in some alloys, especially steels. The proposed model opens a number of interesting possibilities for simulating and controlling microstructure pattern development under combinations of thermal and mechanical loading.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2010	\N	\N	\N	10.1016/j.jmps.2011.04.017	\N	\N	http://arxiv.org/abs/1010.1871v2	Mirko Maraldi, Garth N. Wells, Luisa Molari. (2010). Phase field model for coupled displacive and diffusive microstructural processes under thermal loading. arXiv preprint. 1010.1871v2. https://doi.org/10.1016/j.jmps.2011.04.017.	en	public	published	f	2026-07-30 16:26:05.152612+08	arxiv_import	2026-07-30 16:26:05.152612+08	2026-07-30 16:26:05.152612+08	\N	\N	\N	\N
296	4	LIT-000296	Thermodynamics and its Prediction and CALPHAD Modeling: Review, State of the Art, and Perspectives	\N	paper	Thermodynamics is a science concerning the state of a system, whether it is stable, metastable, or unstable. The combined law of thermodynamics derived by Gibbs about 150 years ago laid the foundation of thermodynamics. In Gibbs combined law, the entropy production due to internal processes was not included, and the 2nd law was thus practically removed from the Gibbs combined law, so it is only applicable to systems under equilibrium. Gibbs further derived the classical statistical thermodynamics in terms of the probability of configurations in a system. With the quantum mechanics (QM) developed, the QM-based statistical thermodynamics was established and connected to classical statistical thermodynamics at the classical limit as shown by Landau. The development of density function theory (DFT) by Kohn and co-workers enabled the QM prediction of properties of the ground state of a system. On the other hand, the entropy production due to internal processes in non-equilibrium systems was studied separately by Onsager and Prigogine and co-workers. The digitization of thermodynamics was developed by Kaufman in the framework of the CALPHAD modeling of individual phases. Our recently termed zentropy theory integrates DFT and statistical mechanics through the replacement of the internal energy of each individual configuration by its DFT-predicted free energy. Furthermore, through the combined law of thermodynamics with the entropy production as a function of internal degrees of freedom, it is shown that the kinetic coefficient matrix of independent internal processes is diagonal with respect to the conjugate potentials in the combined law, and the cross phenomena represented by the phenomenological Onsager reciprocal relationships are due to the dependence of the conjugate potential of the molar quantity in a flux on nonconjugate potentials.	\N	arXiv cond-mat.stat-mech, cond-mat.mtrl-sci	\N	\N	2023	\N	\N	\N	10.1016/j.calphad.2023.102580	\N	\N	http://arxiv.org/abs/2301.02132v5	Zi-Kui Liu. (2023). Thermodynamics and its Prediction and CALPHAD Modeling: Review, State of the Art, and Perspectives. arXiv preprint. 2301.02132v5. https://doi.org/10.1016/j.calphad.2023.102580.	en	public	published	f	2026-07-30 16:26:05.156955+08	arxiv_import	2026-07-30 16:26:05.156955+08	2026-07-30 16:26:05.156955+08	\N	\N	\N	\N
297	4	LIT-000297	A Sublattice Phase-Field Model for Direct CALPHAD Database Coupling	\N	paper	The phase-field method has been established as a de facto standard for simulating the microstructural evolution of materials. In quantitative modeling the assessment and compilation of thermodynamic/kinetic data is largely dominated by the CALPHAD approach, which has produced a large set of experimentally and computationally generated Gibbs free energy and atomic mobility data in a standardized format: the thermodynamic database (TDB) file format. Harnessing this data for the purpose of phase-field modeling is an ongoing effort encompassing a wide variety of approaches. In this paper, we aim to directly link CALPHAD data to the phase-field method, without intermediate fitting or interpolation steps. We introduce a model based on the Kim-Kim-Suzuki (KKS) approach. This model includes sublattice site fractions and can directly utilize data from TDB files. Using this approach, we demonstrate the model on the U-Zr and Mo-Ni-Re systems.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2021	\N	\N	\N	10.1016/j.commatsci.2021.110466	\N	\N	http://arxiv.org/abs/2103.16603v3	D. Schwen, C. Jiang, L. K. Aagesen. (2021). A Sublattice Phase-Field Model for Direct CALPHAD Database Coupling. arXiv preprint. 2103.16603v3. https://doi.org/10.1016/j.commatsci.2021.110466.	en	public	published	f	2026-07-30 16:26:05.159978+08	arxiv_import	2026-07-30 16:26:05.159978+08	2026-07-30 16:26:05.159978+08	\N	\N	\N	\N
298	4	LIT-000298	Recycling End-of-life Polycarbonate in Steelmaking; $\\textit{Ab Initio}$ Study of Carbon Dissolution in Molten Iron	\N	paper	The scarcity of fossil fuels as carbon resources has motivated the steelmaking industry to search for new carbon sources such as end-of-life polymeric products. Using $\\textit{ab initio}$ molecular dynamics simulation, we demonstrate that 41% of polycarbonate's carbon content is readily dissolved in molten iron's interface at $T$ = 1823 K which is comparable to graphite with $\\sim$ 58% carbon content dissolution. More importantly, we demonstrate that polycarbonate's hydrogen content does not dissolve in molten iron but rather escape in gaseous form. Therefore, waste polycarbonate constitutes a feasible carbon source for steelmaking.	\N	arXiv cond-mat.mtrl-sci, cond-mat.other, cond-mat.soft	\N	\N	2022	\N	\N	\N	10.1021/ie4031105	\N	\N	http://arxiv.org/abs/2204.08706v1	M. Hussein N. Assadi, Veena Sahajwalla. (2022). Recycling End-of-life Polycarbonate in Steelmaking; $\\textit{Ab Initio}$ Study of Carbon Dissolution in Molten Iron. arXiv preprint. 2204.08706v1. https://doi.org/10.1021/ie4031105.	en	public	published	f	2026-07-30 16:26:20.173032+08	arxiv_import	2026-07-30 16:26:20.173032+08	2026-07-30 16:26:20.173032+08	\N	\N	\N	\N
299	4	LIT-000299	Modelling a new, low CO2 emissions, hydrogen steelmaking process	\N	paper	In an effort to develop breakthrough technologies that enable drastic reduction in CO2 emissions from steel industry (ULCOS project), the reduction of iron ore by pure hydrogen in a direct reduction shaft furnace was investigated. After experimental and modelling studies, a 2D, axisymmetrical steady-state model called REDUCTOR was developed to simulate a counter-current moving bed reactor in which hematite pellets are reduced by pure hydrogen. This model is based on the numerical solution of the local mass, energy and momentum balances of the gas and solid species by the finite volume method. A single pellet sub-model was included in the global furnace model to simulate the successive reactions (hematite-&gt;magnetite -&gt;wustite-&gt;iron) involved in the process, using the concept of additive reaction times. The different steps of mass transfer and possible iron sintering at the grain scale were accounted for. The kinetic parameters were derived from reduction experiments carried out in a thermobalance furnace, at different conditions, using small hematite cubes shaped from industrial pellets. Solid characterizations were also performed to further understand the microstrutural evolution. First results have shown that the use of hydrogen accelerates the reduction in comparison to CO reaction, making it possible to design a hydrogen-operated shaft reactor quite smaller than current MIDREX and HYL. Globally, the hydrogen steelmaking route based on this new process is technically and environmentally attractive. CO2 emissions would be reduced by more than 80%. Its future is linked to the emergence of the hydrogen economy.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2014	\N	\N	\N	10.1016/j.jclepro.2012.07.045	\N	\N	http://arxiv.org/abs/1402.1715v1	Andrea Ranzani Da Costa, D. Wagner, Fabrice Patisson. (2014). Modelling a new, low CO2 emissions, hydrogen steelmaking process. arXiv preprint. 1402.1715v1. https://doi.org/10.1016/j.jclepro.2012.07.045.	en	public	published	f	2026-07-30 16:26:20.182743+08	arxiv_import	2026-07-30 16:26:20.182743+08	2026-07-30 16:26:20.182743+08	\N	\N	\N	\N
302	4	LIT-000302	Thermo-optic refraction based switchable optical mode converter	\N	paper	The temporally switchable optical mode conversion is crucial for optical communication and computing applications. This research demonstrates such optically switchable mode converter driven by thermo-optic refraction. The MoS2 nanofluid is used as a medium where the thermal microlens is created by a focused laser beam (pump). The convective thermal plume generated above the focal point of the pump beam within the nanofluid acts as an astigmatic thermal lens. It is discovered that mode conversion of the Laguerre-Gaussian (LG) to the Hermite-Gaussian (HG) beam (vice versa) takes place upon passing through the thermal lens. The topological charge of the LG beam can be easily determined using the proposed mode converter. The mode transformation is explained theoretically as the Fourier components of the LG beam undergoing different optical paths while propagating through the convective plume.	\N	arXiv physics.optics, cond-mat.mtrl-sci, physics.app-ph	\N	\N	2021	\N	\N	\N	10.1016/j.jqsrt.2021.107867	\N	\N	http://arxiv.org/abs/2108.04647v1	Pritam P Shetty, Dmitrii N Maksimov, Mahalingam Babu, Sudhakara Reddy Bongu, Jayachandra Bingi. (2021). Thermo-optic refraction based switchable optical mode converter. arXiv preprint. 2108.04647v1. https://doi.org/10.1016/j.jqsrt.2021.107867.	en	public	published	f	2026-07-30 16:26:20.197852+08	arxiv_import	2026-07-30 16:26:20.197852+08	2026-07-30 16:26:20.197852+08	\N	\N	\N	\N
303	4	LIT-000303	Low work function thin film growth for high efficiency thermionic energy converter: Coupled Kelvin probe and photoemission study of potassium oxide	\N	paper	Recent researches in thermal energy harvesting have revealed the remarkable efficiency of thermionic energy converters comprising very low work function electrodes. From room temperature and above, this kind of converter could supply low power devices such as autonomous sensor networks. In this type of thermoelectric converters, current injection is mainly governed by a mechanism of thermionic emission at the hot electrode which explains the interest for low work function coating materials. In particular, alkali metal oxides have been identified as excellent candidates for coating converter electrodes. This paper is devoted to the synthesis and characterization of potassium peroxide K2O2 onto silicon surfaces. To determine optimal synthesis conditions of K2O2, we present diagrams showing the different oxides as a function of temperature and oxygen pressure from which phase stability characteristics can be determined. From the experimental standpoint, we present results on the synthesis of potassium oxide under ultra high vacuum and controlled temperature. The resulting surface is characterized in situ by means of photoemission spectroscopy (PES) and contact potential difference (CPD) measurements. A work function of 1.35 eV is measured which and the expected efficiency of the corresponding converter is discussed. It is generally assumed that the decrease of the work function in the alkali/oxygen/ silicon system, is attributed to the creation of a surface dipole resulting from a charge transfer between the alkali metal and oxygen.	\N	arXiv cond-mat.mtrl-sci, physics.app-ph	\N	\N	2019	\N	\N	\N	10.1002/pssa.201300136	\N	\N	http://arxiv.org/abs/1910.05166v1	François Morini, Emmanuel Dubois, Jean-François Robillard, Stéphane Monfray, Thomas Skotnicki. (2019). Low work function thin film growth for high efficiency thermionic energy converter: Coupled Kelvin probe and photoemission study of potassium oxide. arXiv preprint. 1910.05166v1. https://doi.org/10.1002/pssa.201300136.	en	public	published	f	2026-07-30 16:26:20.204466+08	arxiv_import	2026-07-30 16:26:20.204466+08	2026-07-30 16:26:20.204466+08	\N	\N	\N	\N
304	4	LIT-000304	Piezoresistance in chemically synthesized polypyrrole thin films	\N	paper	The resistance of chemically synthesized polypyrrole (PPy) thin films is investigated as a function of the pressure of various gases as well as of the film thickness. A physical, piezoresistive response is found to coexist with a chemical response if the gas is chemically active, like, e.g., oxygen. The piezoresistance is studied separately by exposing the films to the chemically inert gases such as nitrogen and argon. We observe that the character of the piezoresistive response is a function not only of the film thickness, but also of the pressure. Films of a thickness below 70 nm show a decreasing resistance as pressure is applied, while for thicker films, the piezoresistance is positive. Moreover, in some films of thickness of about 70 nm, the piezoresistive response changes from negative to positive as the gas pressure is increased above 500 mbars. This behavior is interpreted in terms of a total piezoresistance which is composed of a surface and a bulk component, each of which contributes in a characteristic way. These results suggest that in polypyrrole, chemical sensing and piezoresistivity can coexist, which needs to be kept in mind when interpreting resistive responses of such sensors.	\N	arXiv cond-mat.mtrl-sci, cond-mat.soft	\N	\N	2009	\N	\N	\N	arxiv.0908.3840	\N	\N	http://arxiv.org/abs/0908.3840v1	S. Barnoss, H. Shanak, C. Bof Bufon, T. Heinzel. (2009). Piezoresistance in chemically synthesized polypyrrole thin films. arXiv preprint. 0908.3840v1.	en	public	published	f	2026-07-30 16:26:20.209527+08	arxiv_import	2026-07-30 16:26:20.209527+08	2026-07-30 16:26:20.209527+08	\N	\N	\N	\N
305	4	LIT-000305	Transport properties of chemically synthesized polypyrrole thin films	\N	paper	The electronic transport in polypyrrole thin films synthesized chemically from the vapor phase is studied as a function of temperature as well as of electric and magnetic fields. We find distinct differences in comparison to the behavior of both polypyrrole films prepared by electrochemical growth as well as of the bulk films obtained from conventional chemical synthesis. For small electric fields F, a transition from Efros-Shklovskii variable range hopping to Arrhenius activated transport is observed at 30 K. High electric fields induce short range hopping. The characteristic hopping distance is found to be proportional to F^(-1/2). The magnetoresistance R(B) is independent of F below a critical magnetic field, above which F counteracts the magnetic field induced localization.	\N	arXiv cond-mat.dis-nn, cond-mat.mtrl-sci	\N	\N	2007	\N	\N	\N	10.1103/PhysRevB.76.245206	\N	\N	http://arxiv.org/abs/0707.2711v1	C. C. Bof Bufon, T. Heinzel. (2007). Transport properties of chemically synthesized polypyrrole thin films. arXiv preprint. 0707.2711v1. https://doi.org/10.1103/PhysRevB.76.245206.	en	public	published	f	2026-07-30 16:26:20.213381+08	arxiv_import	2026-07-30 16:26:20.213381+08	2026-07-30 16:26:20.213381+08	\N	\N	\N	\N
306	4	LIT-000306	Could spectral converters really enhance photovoltaics?	\N	paper	Spectral converters have been proposed as a tool to achieve high efficiencies from Silicon photovoltaics(PV). Even though from the scientifical point of view it could be interesting to acomplish that, scientists should concentrate effort to invest in materials that can provide more return: in the case of spectral converters, they are very unlikely to have a place in flat-panel PV's. However, concentrated photovoltaics (CPV) technology may get a boost from such devices, an more attention should be driven to this goal.	\N	arXiv physics.app-ph, cond-mat.mtrl-sci	\N	\N	2018	\N	\N	\N	arxiv.1808.06456	\N	\N	http://arxiv.org/abs/1808.06456v1	Marcos Paulo Belançon. (2018). Could spectral converters really enhance photovoltaics?. arXiv preprint. 1808.06456v1.	en	public	published	f	2026-07-30 16:26:20.216701+08	arxiv_import	2026-07-30 16:26:20.216701+08	2026-07-30 16:26:20.216701+08	\N	\N	\N	\N
321	4	LIT-000321	Evaluation of the hydrogen solubility and diffusivity in proton-conducting oxides by converting the PSL values of a tritium imaging plate	\N	paper	Proton-conducting oxides have potential applications in hydrogen sensors, hydrogen pumps, and other electrochemical devices including the tritium purification and recovery systems of nuclear fusion reactors. Although the distribution of hydrogen (H) in such oxide materials is an important aspect, its precise measurement is difficult. In the present study, the hydrogen solubility and diffusivity behavior of BaZr0.9Y0.1O2.95 (BZY), BaZr0.955Y0.03Co0.015O2.97 (BZYC), and CaZr0.9In0.1O2.95 (CZI) were studied using tritiated heavy water vapor i.e., DTO (~2 kPa, tritium (T) = 0.1%) by converting the photostimulated luminescence (PSL) values of the imaging plate (IP). The samples were exposed to DTO vapor at 673 K for 2 h or at 873 K for 1 h. The disc-shaped oxide specimens (diameter ~7.5 mm; thickness ~2.3 mm; theoretical density (TD) &gt; 98 %) were prepared by conventional powder metallurgy. The IP images of the specimen surfaces of all the three materials T-exposed revealed that BZY showed the most uniform T distribution with the highest tritium activity. The cross-sectional T concentration profiles of the cut specimens showed that T diffused deeper into BZY and BZYC than into CZI. The hydrogen solubility and diffusivity in the CZI specimen were lower than that in the BZY and BZYC specimens. This suggested that barium zirconates were more favorable proton conductors than calcium zirconates.	\N	arXiv cond-mat.mtrl-sci, physics.chem-ph	\N	\N	2022	\N	\N	\N	10.1016/j.nme.2020.100875	\N	\N	http://arxiv.org/abs/2211.11531v1	M. Khalid Hossain, K. Hashizume, Y. Hatano. (2022). Evaluation of the hydrogen solubility and diffusivity in proton-conducting oxides by converting the PSL values of a tritium imaging plate. arXiv preprint. 2211.11531v1. https://doi.org/10.1016/j.nme.2020.100875.	en	public	published	f	2026-07-30 16:26:20.318627+08	arxiv_import	2026-07-30 16:26:20.318627+08	2026-07-30 16:26:20.318627+08	\N	\N	\N	\N
307	4	LIT-000307	Hybrid photovoltaic and electron-tunneling converters	\N	paper	Photon impingement is capable of liberating electrons in semiconductors. When the electron transport is primarily governed by temperature gradients, high irreversibilities will result, thus lowering converters' efficiencies. A fundamental study in the absence of photovoltaics\\cite{1} has achieved the reduction of these irreversibilities by considering entropy changes due to electron flows. Here we present an unreported mechanism that integrates photovoltaic conversion and electron tunneling. Photon-excited electrons that occupy energy levels beyond windowed limits are first imprisoned inside the cathode, then given opportunities to rapidly re-thermalize, and eventually allowed to enter the tunnel. Energies wasted by both the irreversibility and the recombination are minimized with respect to the transmission energy and the transmission window that characterize the tunnel. Upon application of this mechanism to high-concentration solar cells, the proposed hybrid model outperforms others. It further provides a guide for elevating efficiencies in future photon-to-electron converters typified by third-generation photovoltaic systems.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2014	\N	\N	\N	arxiv.1409.3300	\N	\N	http://arxiv.org/abs/1409.3300v1	Shanhe Su, Jincan Chen, Tien-Mo Shih. (2014). Hybrid photovoltaic and electron-tunneling converters. arXiv preprint. 1409.3300v1.	en	public	published	f	2026-07-30 16:26:20.219415+08	arxiv_import	2026-07-30 16:26:20.219415+08	2026-07-30 16:26:20.219415+08	\N	\N	\N	\N
308	4	LIT-000308	Spin convertance at magnetic interfaces	\N	paper	The exchange interaction between the conduction electrons and magnetic moments at magnetic interface leads to mutual conversion between electron spin current and magnon current. We introduce a concept of spin convertance which quantitatively measures the magnon current induced by electron spin accumulation and the spin current created by magnon accumulation at the interface. We predict the phenomena on charge and spin drag across a magnetic insulator spacer for several layered structures.	\N	arXiv cond-mat.mes-hall, cond-mat.mtrl-sci	\N	\N	2012	\N	\N	\N	10.1103/PhysRevB.86.214424	\N	\N	http://arxiv.org/abs/1210.2735v3	Steven S. -L. Zhang, Shufeng Zhang. (2012). Spin convertance at magnetic interfaces. arXiv preprint. 1210.2735v3. https://doi.org/10.1103/PhysRevB.86.214424.	en	public	published	f	2026-07-30 16:26:20.223755+08	arxiv_import	2026-07-30 16:26:20.223755+08	2026-07-30 16:26:20.223755+08	\N	\N	\N	\N
309	4	LIT-000309	Low-loss phase-change material based programmable mode converter for photonic computing	\N	paper	Phase-change materials (PCMs)-based integrated photonic memory offers a viable pathway for the development of neuromorphic computing chip. The sizable optical contrast in the telecom band between amorphous and crystalline phases of PCM, in particular, Ge2Sb2Te5 (GST), is used for multilevel programming. However, the high extinction coefficient k of crystalline GST leads to high optical loss, posing a serious challenge for scaling up the device array for practical use. In this work, we focus on the atomic understanding and application of the so-called low-loss PCM, Sb2Se3, through multiscale simulations. First, we elucidate the bonding origin of the wavelength dependent optical properties of amorphous and crystalline Sb2Se3 via ab initio calculations. Given the suppressed k in the telecom band, we design a programable mode converter (PMC) waveguide device that utilizes only the contrast in refractive index n between amorphous and crystalline Sb2Se3 to encode multiple optical levels per waveguide device. The finite-difference time-domain simulations show that a single PMC device can achieve 5-bit programming precision (32 levels) via direct laser writing, and the photonic tensor core formed by the PMC array could possibly be scaled to 128*128. Finally, a thorough comparison between low-loss PCM and conventional PCM is provided.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2026	\N	\N	\N	arxiv.2603.10667	\N	\N	http://arxiv.org/abs/2603.10667v1	Xueyang Shen, Ruixuan Chu, Ding Xu, Yuan Gao, Wen Zhou, Wei Zhang. (2026). Low-loss phase-change material based programmable mode converter for photonic computing. arXiv preprint. 2603.10667v1.	en	public	published	f	2026-07-30 16:26:20.227036+08	arxiv_import	2026-07-30 16:26:20.227036+08	2026-07-30 16:26:20.227036+08	\N	\N	\N	\N
310	4	LIT-000310	Glass engineering to enhance Si solar cells: a case study of Pr$^{3+}$-Yb$^{3+}$ codoped tellurite-tungstate as spectral converter	\N	paper	Spectral converters are known to increase photovoltaic energy conversion by minimizing losses due to fundamental non-absorption and thermalization processes, and have been suggested to surpass the Shockley-Queisser efficiency limit in single junction solar cells. Here we present a detailed spectroscopic study of photoluminescence in tellurite-tungstate glasses doped and codoped with $Pr^{3+}-Yb^{3+}$ and $Ag$ nanoparticles. The energy transfer mechanisms between $Pr^{3+}$ and $Yb^{3+}$ are discussed based on the near infrared emission under excitation at $442$ nm and on the upconversion emission under excitation at $980$ nm. Fluorescence quenching of $^2 F_{5/2}$ level of $Yb^{3+}$ is observed by increasing the concentration of $Pr^{3+}$, as well as by the addition of $Ag$ nanoparticles. In addition, a discussion on the potential of this glass to increase energy production in spectral converters is presented. The results suggest that the few undesirable energy transfer processes occurring in this material are difficult to be controlled or eliminated properly, resulting in intrinsic losses. This discussion is extended to the potential of glass science to enhance energy production in solar cells, showing that newer designs such as bifacial cells may facilitate the exploration of glasses other than soda-lime for mass production of solar cells. The focus on extending the lifespan by reducing UV induced degradation seems to be a more effective approach than the development of spectral converters for Si solar cells.	\N	arXiv cond-mat.mtrl-sci, physics.app-ph, physics.optics	\N	\N	2019	\N	\N	\N	10.1016/j.jnoncrysol.2019.119717	\N	\N	http://arxiv.org/abs/1909.12769v2	Maiara Mitiko Taniguchi, Vitor Santaella Zanuto, Pablo Portes, Luis Carlos Malacarne, Nelson Guilherme Astrath, Jorge Diego Marconi, Marcos Paulo Belançon. (2019). Glass engineering to enhance Si solar cells: a case study of Pr$^{3+}$-Yb$^{3+}$ codoped tellurite-tungstate as spectral converter. arXiv preprint. 1909.12769v2. https://doi.org/10.1016/j.jnoncrysol.2019.119717.	en	public	published	f	2026-07-30 16:26:20.234665+08	arxiv_import	2026-07-30 16:26:20.234665+08	2026-07-30 16:26:20.234665+08	\N	\N	\N	\N
311	4	LIT-000311	Atomically-Thin Tsumoite (BiTe) based All-Photonic-Isolator, Information Converter, and Logic-Gate	\N	paper	Two-dimensional tsumoite (BiTe), a polymorph of Bi2Te3, has emerged as a promising candidate for nonlinear photonic devices owing to its strong spin-orbit coupling, tunable bandgap, and high carrier mobility characteristics. This work presents a thorough examination of the third-order nonlinear optical response of BiTe dispersions using spatial self-phase modulation (SSPM) spectroscopy. The nonlinear refractive index (n2) and third-order nonlinear susceptibility are quantitatively derived from the diffraction ring patterns, demonstrating third-order nonlinear susceptibility values, similar to or surpassing those of advanced 2D materials. The temporal development and distortion of the SSPM rings are examined using the wind-chime model, and thermal factors influencing the SSPM pattern are analyzed. First-principles electronic band structure studies reveal that the elevated nonlinear susceptibility arises from band dispersion. Direct correlation between carrier transport and third-order nonlinear susceptibility is established. Utilizing these qualities, all photonic devices, including a photonic isolator based on a 2D BiTe-2D hBN heterostructure, are depicted to show asymmetric propagation. A photonic information converter and a logic gate are designed using the cross-phase modulation technique. These findings establish 2D BiTe nanostructure as a formidable nonlinear optical platform for advanced photonic signal processing and integrated photonic applications.	\N	arXiv physics.optics, cond-mat.mtrl-sci, cond-mat.soft	\N	\N	2026	\N	\N	\N	arxiv.2604.12003	\N	\N	http://arxiv.org/abs/2604.12003v1	Saswata Goswami, Caique Campos de Oliveira, Abhijith M. B., Varinder Pal, Vidya Kochat, Pulickel M. Ajayan, Samit K. Ray, Pedro A. S. Autreto, Chandra Sekhar Tiwary. (2026). Atomically-Thin Tsumoite (BiTe) based All-Photonic-Isolator, Information Converter, and Logic-Gate. arXiv preprint. 2604.12003v1.	en	public	published	f	2026-07-30 16:26:20.240221+08	arxiv_import	2026-07-30 16:26:20.240221+08	2026-07-30 16:26:20.240221+08	\N	\N	\N	\N
312	4	LIT-000312	Sustainable Next-generation Color Converters of P. harmala Seed Extracts for Solid-State Lighting	\N	paper	Traditional solid-state lighting relies on color converters with a serious environmental footprint. As an alternative, natural materials such as plant extracts could be employed if their low quantum yield (QYs) in liquid and solid states were higher. With this motivation, here, we investigate the optical features of P. harmala extract in water, develop its efficient color-converting solids using a facile, sustainable, and low-cost method, and integrate it with a light-emitting diode. To obtain a high-efficiency solid host for the P. harmala-based fluorophores, we optically and structurally compared two crystalline and two cellulose-based platforms. Structural characterizations indicate that sucrose crystals, cellulose-based cotton, and paper platforms allow fluorophores to be distributed relatively homogenously as opposed to the KCl crystals. Optical characterizations reveal that the extracted solution and the extract-embedded paper possess QYs of 75.6% and 44.7%, respectively, whereas the QYs of the cotton, sucrose, and KCl crystals remain below 10%. Subsequently, as a proof-of-concept demonstration, we integrate the as-prepared efficient solid of P. harmala for the first time with a light-emitting diode (LED) chip to produce a color-converting LED. The resulting blue-emitting LED achieves a luminous efficiency of 21.9 lm/Welect with CIE color coordinates of (0.139,0.070). With these results, we bring plant-based fluorescent biomolecules to the stage of solid-state lighting. We believe that they hold great promise as next-generation, environmentally friendly organic color converters for lighting applications.	\N	arXiv physics.optics, cond-mat.mtrl-sci	\N	\N	2023	\N	\N	\N	arxiv.2306.09703	\N	\N	http://arxiv.org/abs/2306.09703v1	Talha Erdem, Ali Orenc, Dilber Akcan, Fatih Duman, Zeliha Soran-Erdem. (2023). Sustainable Next-generation Color Converters of P. harmala Seed Extracts for Solid-State Lighting. arXiv preprint. 2306.09703v1.	en	public	published	f	2026-07-30 16:26:20.247878+08	arxiv_import	2026-07-30 16:26:20.247878+08	2026-07-30 16:26:20.247878+08	\N	\N	\N	\N
313	4	LIT-000313	Converting Faraday rotation into magnetization in europium chalcogenides	\N	paper	We present a simple semiclassical model to sustain that in europium chalcogenides (EuX), Faraday rotation (FR) in the transparency gap is proportional to the magnetization of the sample, irrespective of the material's magnetic phase, temperature, or applied magnetic field. The model is validated by FR and magnetization measurements in EuSe in the temperature interval 1.7-300K, covering all EuSe magnetic phases (paramagnetic, antiferromagnetic type I or type II, ferrimagnetic and ferromagnetic). Furthermore, by combining the semiclassical model with the explicit electronic energy structure of EuX, the proportionality coefficient between magnetization and FR is shown to be dependent only on the wavelength and the band gap. Due to its simplicity, the model has didactic value, moreover, it provides a working tool for converting FR into magnetization in EuX. Possible extension of the model to other intrinsic magnetic semiconductors is discussed.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2019	\N	\N	\N	10.1063/1.5116150	\N	\N	http://arxiv.org/abs/1908.04444v1	S. C. P. van Kooten, P. A. Usachev, X. Gratens, A. R. Naupa, V. A. Chitta, G. Springholz, A. B. Henriques. (2019). Converting Faraday rotation into magnetization in europium chalcogenides. arXiv preprint. 1908.04444v1. https://doi.org/10.1063/1.5116150.	en	public	published	f	2026-07-30 16:26:20.25375+08	arxiv_import	2026-07-30 16:26:20.25375+08	2026-07-30 16:26:20.25375+08	\N	\N	\N	\N
314	4	LIT-000314	Patterning perovskite colour converters for AR/VR microdisplays	\N	paper	Colour conversion offers the clearest path to achieve RGB colours in high resolution microdisplays for AR/VR. With resolutions beyond 5000 ppi (i.e. RGB pitch of 5 um), the thickness of the conversion layers is critical for efficiency and manufacturing. Perovskites outperform other conversion materials (quantum dots or phosphors) with their high absorption coefficients for blue light. In this contribution, we show how perovskite materials, engineered for high optical density and colour purity, can be patterned to produce colour converting pixels. We demonstrate patterning using three approaches (lift-off, negative photoresist and dry etch), and discuss their advantages and disadvantages. The results consolidate the choice of perovskites for AR/VR applications by demonstrating their robustness and compatibility with multiple patterning strategies suitable for high resolution microdisplays.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2025	\N	\N	\N	arxiv.2511.22182	\N	\N	http://arxiv.org/abs/2511.22182v1	Ruairi Baker, Maria Pervez, Angus Hawkey, Nobuya Sakai, Valerie Berryman-Bousquet, Bernard Wenger. (2025). Patterning perovskite colour converters for AR/VR microdisplays. arXiv preprint. 2511.22182v1.	en	public	published	f	2026-07-30 16:26:20.261633+08	arxiv_import	2026-07-30 16:26:20.261633+08	2026-07-30 16:26:20.261633+08	\N	\N	\N	\N
315	4	LIT-000315	Direct dry transfer of chemical vapor deposition graphene to polymeric substrates	\N	paper	We demonstrate the direct dry transfer of large area Chemical Vapor Deposition graphene to several polymers (low density polyethylene, high density polyethylene, polystyrene, polylactide acid and poly(vinylidenefluoride-co-trifluoroethylene) by means of only moderate heat and pressure, and the later mechanical peeling of the original graphene substrate. Simulations of the graphene-polymer interactions, rheological tests and graphene transfer at various experimental conditions show that controlling the graphene-polymer interface is the key to controlling graphene transfer. Raman spectroscopy and Optical Microscopy were used to identify and quantify graphene transferred to the polymer substrates. The results showed that the amount of graphene transferred to the polymer, from no-graphene to full graphene transfers, can be achieved by fine tuning the transfer conditions. As a result of the direct dry transfer technique, the graphene-polymer adhesion being stronger than graphene to Si/SiO2 wafer.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2014	\N	\N	\N	arxiv.1410.4857	\N	\N	http://arxiv.org/abs/1410.4857v1	Guilhermino J. M. Fechine, Inigo Martin-Fernandez, George Yiapanis, Ricardo V. Bof de Oliveira, Xiao Hu, Irene Yarovsky, Antonio H. Castro Neto, Barbaros Ozyilmaz. (2014). Direct dry transfer of chemical vapor deposition graphene to polymeric substrates. arXiv preprint. 1410.4857v1.	en	public	published	f	2026-07-30 16:26:20.270042+08	arxiv_import	2026-07-30 16:26:20.270042+08	2026-07-30 16:26:20.270042+08	\N	\N	\N	\N
322	4	LIT-000322	Effect of Pore Formation on Redox-Driven Phase Transformation	\N	paper	When solid-state redox-driven phase transformations are associated with mass loss, vacancies are produced that develop into pores. These pores can influence the kinetics of certain redox and phase transformation steps. We investigated the structural and chemical mechanisms in and at pores in a combined experimental-theoretical study, using the reduction of iron oxide by hydrogen as a model system. The redox product (water) accumulates inside the pores and shifts the local equilibrium at the already reduced material back towards re-oxidation into cubic-Fe1-xO (where x refers to Fe deficiency, space group Fm3-m). This effect helps to understand the sluggish reduction of cubic-Fe1-xO by hydrogen, a key process for future sustainable steelmaking.	\N	arXiv cond-mat.mtrl-sci, physics.comp-ph	\N	\N	2022	\N	\N	\N	10.1103/PhysRevLett.130.168001	\N	\N	http://arxiv.org/abs/2209.09069v2	Xuyang Zhou, Yang Bai, Ayman A. El-Zoka, Se-Ho Kim, Yan Ma, Christian H. Liebscher, Baptiste Gault, Jaber R. Mianroodi, Gerhard Dehm, Dierk Raabe. (2022). Effect of Pore Formation on Redox-Driven Phase Transformation. arXiv preprint. 2209.09069v2. https://doi.org/10.1103/PhysRevLett.130.168001.	en	public	published	t	2026-07-30 16:26:20.324792+08	arxiv_import	2026-07-30 16:26:20.324792+08	2026-07-30 16:26:20.324792+08	\N	\N	\N	\N
316	4	LIT-000316	Reorganization energy from charge transport measurements in a monolithically$-$integrated molecular device	\N	paper	Intermolecular charge transfer reactions are key processes in physical chemistry. The electron-transfer rates depend on a few system's parameters, such as temperature, electromagnetic field, distance between adsorbates and, especially, the molecular reorganization energy. This microscopic greatness is the energetic cost to rearrange each single$-$molecule and its surrounding environment when a charge is transferred. Reorganization energies are measured by electrochemistry and spectroscopy techniques as well as at the single-molecule limit using atomic force microscopy approaches, but not from temperature$-$dependent charge transport measurements nor in a monolithically$-$integrated molecular device. Nowadays self$-$rolling nanomembrane (rNM) devices, with strain$-$engineered mechanical properties, on$-$a$-$chip monolithic integration, and operable in distinct environments, overcome those challenges. Here, we investigate the charge transfer reactions occurring within a ca. 6 nm thick copper$-$phthalocyanine (CuPc) film employed as electrode-spacer in a monolithically integrated nanocapacitor. Employing the rNM technology allows us to measure the molecules' charge$-$transport dependence on temperature for different electric fields. Thereby, the CuPc reorganization energy is determined as (930 $\\pm$ 40) meV, whereas density functional theory (DFT) calculations support our findings with the atomistic picture of the CuPc charge transfer reaction. Our approach presents a consistent route towards electron transfer reaction characterization using current$-$voltage spectroscopy and provides insight into the role of the molecular reorganization energy when it comes to electrochemical nanodevices.	\N	arXiv cond-mat.mtrl-sci, cond-mat.mes-hall, physics.chem-ph	\N	\N	2023	\N	\N	\N	10.1002/smll.202103897	\N	\N	http://arxiv.org/abs/2312.02321v1	Leandro Merces, Graziâni Candiotto, Letícia M. M. Ferro, Anerise de Barros, Carlos V. S. Batista, Ali Nawaz, Antonio Riul, Rodrigo B. Capaz, Carlos C. Bof Bufon. (2023). Reorganization energy from charge transport measurements in a monolithically$-$integrated molecular device. arXiv preprint. 2312.02321v1. https://doi.org/10.1002/smll.202103897.	en	public	published	f	2026-07-30 16:26:20.27992+08	arxiv_import	2026-07-30 16:26:20.27992+08	2026-07-30 16:26:20.27992+08	\N	\N	\N	\N
317	4	LIT-000317	Converting normal insulators into topological insulators via tuning orbital levels	\N	paper	Tuning the spin-orbit coupling strength via foreign element doping and/or modifying bonding strength via strain engineering are the major routes to convert normal insulators to topological insulators. We here propose an alternative strategy to realize topological phase transition by tuning the orbital level. Following this strategy, our first-principles calculations demonstrate that a topological phase transition in some cubic perovskite-type compounds CsGeBr$_3$ and CsSnBr$_3$ could be facilitated by carbon substitutional doping. Such unique topological phase transition predominantly results from the lower orbital energy of the carbon dopant, which can pull down the conduction bands and even induce band inversion. Beyond conventional approaches, our finding of tuning the orbital level may greatly expand the range of topologically nontrivial materials.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2015	\N	\N	\N	10.1103/PhysRevB.92.205118	\N	\N	http://arxiv.org/abs/1511.00832v1	Wu-Jun Shi, Junwei Liu, Yong Xu, Shi-Jie Xiong, Jian Wu, Wenhui Duan. (2015). Converting normal insulators into topological insulators via tuning orbital levels. arXiv preprint. 1511.00832v1. https://doi.org/10.1103/PhysRevB.92.205118.	en	public	published	f	2026-07-30 16:26:20.291856+08	arxiv_import	2026-07-30 16:26:20.291856+08	2026-07-30 16:26:20.291856+08	\N	\N	\N	\N
318	4	LIT-000318	High-Density Polyethylene Degradation into Low Molecular Weight Gases at 1823 K: An Atomistic Simulation	\N	paper	Using molecular dynamics simulation, we present a comprehensive study of the volatile thermal degradation of high-density polyethylene (HDPE) across a temperature range of 300 K to 1823 K. We find that degradation at temperatures higher than $\\sim$ 1373 K generates significant quantities of reducing gases such as CH$_{\\text{n}}$ and hydrogen molecules which are beneficial to the steelmaking industry. Our results provide a new understanding of HDPE's phase transformation from solid to gas that occurs during superheating at steelmaking's electric arc furnace environment offering a new method for eliminating end-of-life HDPE from landfill.	\N	arXiv cond-mat.soft, cond-mat.mtrl-sci	\N	\N	2022	\N	\N	\N	10.1016/j.jaap.2014.09.022	\N	\N	http://arxiv.org/abs/2204.08253v1	Leyla Ramin, M. Hussein N. Assadi, Veena Sahajwalla. (2022). High-Density Polyethylene Degradation into Low Molecular Weight Gases at 1823 K: An Atomistic Simulation. arXiv preprint. 2204.08253v1. https://doi.org/10.1016/j.jaap.2014.09.022.	en	public	published	f	2026-07-30 16:26:20.298467+08	arxiv_import	2026-07-30 16:26:20.298467+08	2026-07-30 16:26:20.298467+08	\N	\N	\N	\N
319	4	LIT-000319	Converting vertical heat supply into horizontal motion for microtechnological pumping and autonomous waste heat recovery	\N	paper	The rapid advancement of high-performance computing infrastructure and its extended application produce an increasing amount of waste heat. This heat constitutes an unsustainable loss of energy as well as requires cooling solutions that transcend conventional thermal management. Here, we demonstrate a novel mechanism that converts vertical waste heat supply directly into horizontal fluid motion, enabling autonomous, self-powered pumping in microenvironments. Our approach is based on a concept that combines geometric symmetry breaking with heterogeneous thermal conductivities to induce local thermocapillary Marangoni flows. We provide an implementation of the concept as well as an experimental and numerical proof-of-concept, showing good agreement between the respective flow fields. The approach is scalable and operates under realistic areal heating conditions. It enables versatile pumping designs for microtechnological applications, lab-on-a-chip architectures, passive thermal management and heat-driven microfluidic systems.	\N	arXiv physics.flu-dyn, cond-mat.mtrl-sci	\N	\N	2026	\N	\N	\N	arxiv.2603.25626	\N	\N	http://arxiv.org/abs/2603.25626v1	Jan-Niklas Schäfer, Tillmann Carl, Kristin Kühl, Sonja Kiehren-Ehses, Jan Aurich, Georg von Freymann, Clarissa Schönecker. (2026). Converting vertical heat supply into horizontal motion for microtechnological pumping and autonomous waste heat recovery. arXiv preprint. 2603.25626v1.	en	public	published	f	2026-07-30 16:26:20.30362+08	arxiv_import	2026-07-30 16:26:20.30362+08	2026-07-30 16:26:20.30362+08	\N	\N	\N	\N
320	4	LIT-000320	Dust formation in electric arc furnace : birth of the particles	\N	paper	The characterization of Electric Arc Furnace (EAF) dust shows that bubble burst at the liquid steel surface is the principal source of dust emission. We have therefore developed an experimental device for studying this phenomenon. As in the case of the air-water system, the bubble-burst gives birth to two types of droplets: film drops and jet drops. The jet drop formation is observed with high-speed video. The film drop aerosol is collected on filters and then characterized by means of SEM, granulometric and gravimetric analyses. Results are presented and discussed. The quantification of both types of projections leads to the conclusion that the film drop projections represent the major source of dust. The amount of film drops greatly decreases with the parent bubble size. Under 4.5 mm in bubble diameter, no film drops are formed. Decreasing enough the bubble size would therefore represent an effective solution for reducing drastically the EAF dust emission.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2007	\N	\N	\N	10.1016/j.powtec.2005.05.006	\N	\N	http://arxiv.org/abs/0708.3034v1	A. G. Guézennec, J. C. Huber, F. Patisson, P. Sessiecq, J. P. Birat, D. Ablitzer. (2007). Dust formation in electric arc furnace : birth of the particles. arXiv preprint. 0708.3034v1. https://doi.org/10.1016/j.powtec.2005.05.006.	en	public	published	f	2026-07-30 16:26:20.312024+08	arxiv_import	2026-07-30 16:26:20.312024+08	2026-07-30 16:26:20.312024+08	\N	\N	\N	\N
323	4	LIT-000323	Green steel at its crossroads: hybrid hydrogen-based reduction of iron ores	\N	paper	Iron- and steelmaking cause ~7% of the global CO2 emissions, due to the use of carbon for the reduction of iron ores. Replacing carbon by hydrogen as the reductant offers a pathway to reduce emissions. However, production of hydrogen using renewable energy will remain a bottlenecks, because making the annual crude steel production of 1.8 billion tons sustainable requires a minimum amount of ~97 million tons of green hydrogen per year. Another fundamental aspect to make ironmaking sector more sustainable lies in an optimal utilization of green hydrogen and energy, thus reducing efforts for costly in-process hydrogen recycling. We therefore demonstrate here how the efficiency in hydrogen and energy consumption during iron ore reduction can be dramatically improved by the knowledge-based combination of two technologies: partially reducing the ore at low temperature via solid-state direct reduction (DR) to a kinetically defined degree, and subsequently melting and completely transforming it to iron under a reducing plasma (i.e. via hydrogen plasma reduction, HPR). Results suggest that an optimal transition point between these two technologies occurs where their efficiency in hydrogen utilization is equal. We found that the reduction of hematite through magnetite into wustite via DR is clean and efficient, but it gets sluggish and inefficient when iron forms at the outermost layers of the iron ore pellets. Conversely, HPR starts violent and unstable with arc delocalization, but proceeds smoothly and efficiently when processing semi-reduced oxides. We performed hybrid reduction experiments by partially reducing hematite pellets via DR at 700°C to 38% global reduction (using a standard thermogravimetry system) and subsequently transferring them to HPR, conducted with a gas mixture of Ar-10%H2 in an arc-melting furnace, to achieve conversion into liquid iron.	\N	arXiv cond-mat.mtrl-sci, physics.app-ph	\N	\N	2022	\N	\N	\N	arxiv.2201.13356	\N	\N	http://arxiv.org/abs/2201.13356v1	Isnaldi R. Souza Filho1, Hauke Springer, Yan Ma, Ankita Mahajan, Cauê C. da Silva, Michael Kulse, Dierk Raabe. (2022). Green steel at its crossroads: hybrid hydrogen-based reduction of iron ores. arXiv preprint. 2201.13356v1.	en	public	published	f	2026-07-30 16:26:20.334164+08	arxiv_import	2026-07-30 16:26:20.334164+08	2026-07-30 16:26:20.334164+08	\N	\N	\N	\N
324	4	LIT-000324	Correlating Chemical Reaction and Mass Transport in Hydrogen-based Direct Reduction of Iron Oxide	\N	paper	Steelmaking contributes 8% to the total CO2 emissions globally, primarily due to coal-based iron ore reduction. Clean hydrogen-based ironmaking has variable performance because the dominant gas-solid reduction mechanism is set by the defects and pores inside the mm-nm sized oxide particles that change significantly as the reaction progresses. While these governing dynamics are essential to establish continuous flow of iron and its ores through reactors, the direct link between agglomeration and chemistry is still contested due to missing measurements. In this work, we directly measure the connection between chemistry and agglomeration in the smallest iron oxides relevant to magnetite ores. Using synthesized spherical 10-nm magnetite particles reacting in H2, we resolve the formation and consumption of wüstite (FeO) - the step most commonly attributed to agglomeration. Using X-ray scattering and microscopy, we resolve crystallographic anisotropy in the rate of the initial reaction, which becomes isotropic as the material sinters. Complementing with imaging, we demonstrate how the particles self-assemble, subsequently react and sinter into ~100x oblong grains. Our insights into how morphologically uniform iron oxide particles react and agglomerate H2 reduction enable future size-dependent models to effectively describe the multiscale iron ore reduction.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2023	\N	\N	\N	10.1073/pnas.2305097120	\N	\N	http://arxiv.org/abs/2302.14215v2	Xueli Zheng, Subhechchha Paul, Lauren Moghimi, Yifan Wang, Rafael A. Vilá, Fan Zhang, Xin Gao, Junjing Deng, Yi Jiang, Xin Xiao, Chaolumen Wu, Louisa C. Greenburg, Yufei Yang, Yi Cui, Arturas Vailionis, Ivan Kuzmenko, Jan llavsky, Yadong Yin, Yi Cui, Leora Dresselhaus-Marais. (2023). Correlating Chemical Reaction and Mass Transport in Hydrogen-based Direct Reduction of Iron Oxide. arXiv preprint. 2302.14215v2. https://doi.org/10.1073/pnas.2305097120.	en	public	published	f	2026-07-30 16:26:20.341301+08	arxiv_import	2026-07-30 16:26:20.341301+08	2026-07-30 16:26:20.341301+08	\N	\N	\N	\N
325	4	LIT-000325	Chemo-Mechanical Phase-Field Modeling of Iron Oxide Reduction with Hydrogen	\N	paper	The reduction of iron ore with carbon-carriers is one of the largest sources of greenhouse gas emissions in the industry, motivating global activities to replace the coke-based blast furnace reduction by hydrogen-based direct reduction (HyDR). Iron oxide reduction with hydrogen has been widely investigated both experimentally and theoretically. The process includes multiple types of chemical reactions, solid state and defect-mediated diffusion (by oxygen and hydrogen species), several phase transformations, as well as massive volume shrinkage and mechanical stress buildup. In this work, a chemo-mechanically coupled phase-field (PF) model has been developed to explore the interplay between phase transformation, chemical reaction, species diffusion, large elasto-plastic deformation and microstructure evolution. Energetic constitutive relations of the model are based on the system free energy which is calibrated with the help of a thermodynamic database. The model has been first applied to the classical core-shell (wüstite-iron) structure. Simulations show that the phase transformation from wüstite to alpha-iron can result in high stress and rapidly decelerating reaction kinetics. Mechanical stresses can contribute elastic energy to the system, making phase transformation difficult. Thus slow reaction kinetics and low metallization are observed. However, if the stress becomes comparatively high, it can shift the shape of the free energy from a double-well to a single-well case and speed up the transformation. The model has been further applied to simulate an actual iron oxide specimen with its complex microstructure, characterized by electron microscopy. The simulation results show that isolated pores in the microstructure are filled with water vapor during reduction, an effect which influences the local reaction atmosphere and dynamics.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2021	\N	\N	\N	arxiv.2111.11538	\N	\N	http://arxiv.org/abs/2111.11538v1	Yang Bai, Jaber Rezaei Mianroodi, Yan Ma, Alisson Kwiatkowski da Silva, Bob Svendsen, Dierk Raabe. (2021). Chemo-Mechanical Phase-Field Modeling of Iron Oxide Reduction with Hydrogen. arXiv preprint. 2111.11538v1.	en	public	published	f	2026-07-30 16:26:20.356821+08	arxiv_import	2026-07-30 16:26:20.356821+08	2026-07-30 16:26:20.356821+08	\N	\N	\N	\N
326	4	LIT-000326	A Laboratory Study of the Reduction of Iron Oxides by Hydrogen	\N	paper	To reduce the emission of greenhouse gases by the steel industry, particularly for ironmaking, the production of DRI (Direct Reduced Iron) using hydrogen as the reducing gas instead of carbon monoxide is being considered. In this context, the reduction of pure hematite by hydrogen was studied at the laboratory scale, varying the experimental conditions and observing the rate and the course of the reaction. All the reduction experiments were performed in a thermobalance and supplementary characterization methods were used like scanning and transmission electron microscopy, X-ray diffraction, and Mössbauer spectrometry. The influence of rising temperature in the range 550-900 degrees C is to accelerate the reaction; no slowing down was observed, contrary to some literature conclusions. A series of experiments consisted in interrupting the runs before complete conversion, thus enabling the characterization of partially reduced samples. Interpretation confirms the occurrence of three successive and rather separate reduction steps, through magnetite and wustite to iron, and illustrates a clear structural evolution of the samples. Finally, the influence of the sample type was revealed comparing a regular powder, a nanopowder and a sintered sample. The regular powder proved to be the most reactive despite its larger grain size, due to a more porous final structure.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2008	\N	\N	\N	arxiv.0803.2831	\N	\N	http://arxiv.org/abs/0803.2831v1	D. Wagner, O. Devisme, F. Patisson, D. Ablitzer. (2008). A Laboratory Study of the Reduction of Iron Oxides by Hydrogen. arXiv preprint. 0803.2831v1.	en	public	published	f	2026-07-30 16:26:20.361782+08	arxiv_import	2026-07-30 16:26:20.361782+08	2026-07-30 16:26:20.361782+08	\N	\N	\N	\N
327	4	LIT-000327	The fate of water in hydrogen-based iron oxide reduction	\N	paper	Gas-solid reactions are cornerstones of many catalytic and redox processes that will underpin the energy and sustainability transition. The specific case of hydrogen-based iron oxide reduction is the foundation to render the global steel industry fossil-free, an essential target as iron production is the largest single industrial emitter of carbon dioxide. Our perception of gas-solid reactions has not only been limited by the availability of state-of-the-art techniques which can delve into the reacted solids in great structural and chemical detail, but we continue to miss an important reaction partner that defines the thermodynamics and kinetics of gas phase reactions: the gas molecules. In this investigation, we use the latest development in cryogenic atom probe tomography to study the quasi in-situ evolution of gas phase heavy water at iron-iron oxide interfaces resulting from the direct reduction of iron oxide by deuterium gas at 700°C. The findings provide new insights into the formation kinetics and location of water formed during hydrogen-based reduction of FeO, an its interaction with the ongoing redox reaction.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2023	\N	\N	\N	arxiv.2301.06391	\N	\N	http://arxiv.org/abs/2301.06391v1	Ayman A. El-Zoka, Leigh T. Stephenson, Se-Ho Kim, Baptiste Gault, Dierk Raabe. (2023). The fate of water in hydrogen-based iron oxide reduction. arXiv preprint. 2301.06391v1.	en	public	published	f	2026-07-30 16:26:20.364698+08	arxiv_import	2026-07-30 16:26:20.364698+08	2026-07-30 16:26:20.364698+08	\N	\N	\N	\N
328	4	LIT-000328	The Crystallization Behavior of Porous PLA Prepared by Modified Solvent Casting/Particulate Leaching Technique for Potential Use of Tissue Engineering Scaffold	\N	paper	The porous PLA foams potential for tissue engineering usage are prepared by a modified solvent casting/particulate leaching method with different crystallinity. Since in typical method the porogens are solved in the solution and flow with the polymers during the casting and the crystallinity behavior of PLA chains in the limited space cannot be tracked, in this work the processing is modified by diffusing the PLA solution into a steady salt stack. With a thermal treatment before leaching while maintaining the stable structure of the porogens stack, the crystallinity of porous foams is made possible to control. The characterizations indicate the crystallization of porous foams is in a manner of lower crystallibility than the bulk materials. Pores and caves of around 250μm size are obtained in samples with different crystallinity. The macro-structures are not much impaired by the crystallization nevertheless the morphological effect of the heating process is still obvious.	\N	arXiv cond-mat.mtrl-sci, cond-mat.soft	\N	\N	2014	\N	\N	\N	10.1016/j.matlet.2014.08.044	\N	\N	http://arxiv.org/abs/1404.3930v1	Ran Huang, Xiaomin Zhu, Haiyan Tu, Ajun Wan. (2014). The Crystallization Behavior of Porous PLA Prepared by Modified Solvent Casting/Particulate Leaching Technique for Potential Use of Tissue Engineering Scaffold. arXiv preprint. 1404.3930v1. https://doi.org/10.1016/j.matlet.2014.08.044.	en	public	published	f	2026-07-30 16:26:40.338435+08	arxiv_import	2026-07-30 16:26:40.338435+08	2026-07-30 16:26:40.338435+08	\N	\N	\N	\N
329	4	LIT-000329	Chemical leaching of Al-Cu-Co decagonal quasicrystals	\N	paper	In the present investigation, the chemical leaching of the poly-grain Al65Cu15Co20 and Al65Cu20Co15 decagonal quasicrystalline alloy have been studied. The polished surfaces of as-cast alloys were leached with 10 mole NaOH solution for 0.5- 8 hours. The x-ray diffraction, scanning electron microscopy and transmission electron microscopy techniques have been used for structural and microstructural characterization. Energy dispersive x-ray analysis has been carried out for chemical composition analysis. Chemical leaching exclusively removes the Al from the surfaces of the Al65Cu15Co20 and Al65Cu20Co15 decagonal quasicrystalline alloys, consequently by the formation of porous structure containing nano size particles of Cu, Co and their oxides have been observed. Al65Cu15Co20 exhibits high porosity in comparison to Al65Cu20Co15 alloy, however the size of the precipitated nano-particles i.e. Cu, Co, Cu2O and CuO were smaller in the case of Al65Cu20Co15 alloy. The energy dispersive X-ray analysis mapping suggests homogeneous distribution of Cu and Co found on the leached surface and the presence of oxygen was also detected.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2024	\N	\N	\N	arxiv.2412.20552	\N	\N	http://arxiv.org/abs/2412.20552v1	Shashank Shekhar Mishra, Thakur Prasad Yadav. (2024). Chemical leaching of Al-Cu-Co decagonal quasicrystals. arXiv preprint. 2412.20552v1.	en	public	published	f	2026-07-30 16:26:40.352352+08	arxiv_import	2026-07-30 16:26:40.352352+08	2026-07-30 16:26:40.352352+08	\N	\N	\N	\N
330	4	LIT-000330	In situ observation of thermally activated and localized Li leaching from lithiated graphite	\N	paper	Temperature is known to impact Li-ion battery performance and safety, however, understanding its effect on Li-ion batteries has largely been limited to uniform high or low temperatures. While the insights gathered from such research are important, much less information is available on the effects of non-uniform temperatures which more accurately reflect the environments that Li-ion batteries are exposed to in real world applications. In this paper, we characterize the impact of a microscale, temperature hotspot on a Li-ion battery using a combination of in situ micro-Raman spectroscopy, in situ optical microscopy and COMSOL Multiphysics thermal simulations. Our results show that mild temperature heterogeneity induced by the micro-Raman laser can cause lithium to locally leach out from different lithiated graphite phases (LiC6 and LiC12) in the absence of an applied current. The Li metal is found to be largely localized to the region heated by the micro-Raman laser and is not observed upon uniform heating to comparable temperatures suggesting that temperature heterogeneity is uniquely responsible for causing Li to leach out from lithiated graphite phases. A mechanism whereby localized temperature heterogeneity induced by the laser induces heterogeneity in the degree of lithiation across the graphite anode is proposed to explain the localized Li leaching. This study highlights the sensitivity of lithiated graphite phases to minor temperature heterogeneity in the absence of an applied current.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2024	\N	\N	\N	arxiv.2407.04902	\N	\N	http://arxiv.org/abs/2407.04902v1	Harrison Szeto, Vijay Kumar, Yangying Zhu. (2024). In situ observation of thermally activated and localized Li leaching from lithiated graphite. arXiv preprint. 2407.04902v1.	en	public	published	f	2026-07-30 16:26:40.358692+08	arxiv_import	2026-07-30 16:26:40.358692+08	2026-07-30 16:26:40.358692+08	\N	\N	\N	\N
331	4	LIT-000331	Inducing Stratification of Colloidal Mixtures with a Mixed Binary Solvent	\N	paper	Molecular dynamics simulations are used to demonstrate that a binary solvent can be used to stratify colloidal mixtures when the suspension is rapidly dried. The solvent consists of two components, one more volatile than the other. When evaporated at high rates, the more volatile component becomes depleted near the evaporation front and develops a negative concentration gradient from the bulk of the mixture to the liquid-vapor interface while the less volatile solvent is enriched in the same region and exhibit a positive concentration gradient. Such gradients can be used to drive a binary mixture of colloidal particles to stratify if one is preferentially attracted to the more volatile solvent and the other to the less volatile solvent. During solvent evaporation, the fraction of colloidal particles preferentially attracted to the less volatile solvent is enhanced at the evaporation front, whereas the colloidal particles having stronger attractions with the more volatile solvent are driven away from the interfacial region. As a result, the colloidal particles show a stratified distribution after drying, even if the two colloids have the same size.	\N	arXiv cond-mat.soft, cond-mat.mtrl-sci	\N	\N	2023	\N	\N	\N	arxiv.2310.20464	\N	\N	http://arxiv.org/abs/2310.20464v1	Binghan Liu, Gary S. Grest, Shengfeng Cheng. (2023). Inducing Stratification of Colloidal Mixtures with a Mixed Binary Solvent. arXiv preprint. 2310.20464v1.	en	public	published	f	2026-07-30 16:26:40.363075+08	arxiv_import	2026-07-30 16:26:40.363075+08	2026-07-30 16:26:40.363075+08	\N	\N	\N	\N
358	4	LIT-000358	From quantum mechanics to the physical metallurgy of steels	\N	paper	In the last decade there has been a breakthrough in the construction of theories leading to models for the simulation of atomic scale processes in steel. In this paper the theory is described and developed and used to demonstrate calculations of the diffusivity and trapping of hydrogen in iron and the structures of carbon vacancy complexes in steel.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2013	\N	\N	\N	arxiv.1310.3778	\N	\N	http://arxiv.org/abs/1310.3778v3	Anthony T Paxton. (2013). From quantum mechanics to the physical metallurgy of steels. arXiv preprint. 1310.3778v3.	en	public	published	f	2026-07-30 16:27:00.812737+08	arxiv_import	2026-07-30 16:27:00.812737+08	2026-07-30 16:27:00.812737+08	\N	\N	\N	\N
332	4	LIT-000332	Interfacial Phenomena of Solvent-diluted Block Copolymers	\N	paper	A phenomenological mean-field theory is used to investigate the properties of solvent-diluted di-block copolymers (BCP), in which the two BCP components (A and B) form a variety of phases that are diluted by a solvent (S). Using this approach, we model mixtures of di-block copolymers and a solvent and obtained the corresponding critical behavior. In the low solvent limit, we find how the critical point depends on the solvent density. Due to the non-linear nature of the coupling between the A/B and BCP/solvent concentrations, the A/B modulation induces modulations in the polymer-solvent relative concentration with a double wavenumber. The free boundary separating the polymer-rich phase from the solvent-rich one is studied in two situations. First, we show how the presence of a chemically patterned substrate leads to deformations of the BCP film/solvent interface, creation of terraces in lamellar BCP film and even formation of multi-domain droplets as induced by the patterned substrate. Our results are in agreement with previous self-consistent field theory calculations. Second, we compare the surface tension between parallel lamellae coexisting with a solvent phase with that of a perpendicular one, and show that the surface tension has a non-monotonic dependence on temperature. The anisotropic surface tension can lead to deformation of spherical BCP droplets into lens-shaped ones, together with re-orientation of the lamellae inside the droplet during the polymer/solvent phase separation process in agreement with experiment.	\N	arXiv cond-mat.soft, cond-mat.mtrl-sci, cond-mat.stat-mech	\N	\N	2013	\N	\N	\N	10.1021/ma401479f	\N	\N	http://arxiv.org/abs/1307.6952v2	Shai Cohen, David Andelman. (2013). Interfacial Phenomena of Solvent-diluted Block Copolymers. arXiv preprint. 1307.6952v2. https://doi.org/10.1021/ma401479f.	en	public	published	f	2026-07-30 16:26:40.367349+08	arxiv_import	2026-07-30 16:26:40.367349+08	2026-07-30 16:26:40.367349+08	\N	\N	\N	\N
333	4	LIT-000333	Uncertainty-Informed Screening for Safer Solvents Used in the Synthesis of Perovskite via Language Models	\N	paper	The challenge of accurately predicting toxicity of industrial solvents used in perovskite synthesis is a necessary undertaking but is limited by a lack of a targeted and structured toxicity data. This paper presents a novel framework that combines an automated data extraction using language models, and an uncertainty-informed prediction model to fill data gaps and improve prediction confidence. First, we have utilized and compared two approaches to automatically extract relevant data from a corpus of scientific literature on solvents used in perovskite synthesis: smaller bidirectional language models like BERT and ELMo are used for their repeatability and deterministic outputs, while autoregressive large language model (LLM) such as GPT-3.5 is used to leverage its larger training corpus and better response generation. Our novel 'prompting and verification' technique integrated with an LLM aims at targeted extraction and refinement, thereby reducing hallucination and improving the quality of the extracted data using the LLM. Next, the extracted data is fed into our pre-trained multi-task binary classification deep learning to predict the ED nature of extracted solvents. We have used a Shannon entropy-based uncertainty quantification utilizing the class probabilities obtained from the classification model to quantify uncertainty and identify data gaps in our predictions. This approach leads to the curation of a structured dataset for solvents used in perovskite synthesis and their uncertainty-informed virtual toxicity assessment. Additionally, chord diagrams have been used to visualize solvent interactions and prioritize those with potential hazards, revealing that 70% of the solvent interactions were primarily associated with two specific perovskites.	\N	arXiv physics.chem-ph, cond-mat.mtrl-sci	\N	\N	2024	\N	\N	\N	arxiv.2409.20512	\N	\N	http://arxiv.org/abs/2409.20512v1	Arpan Mukherjee, Deepesh Giri, Krishna Rajan. (2024). Uncertainty-Informed Screening for Safer Solvents Used in the Synthesis of Perovskite via Language Models. arXiv preprint. 2409.20512v1.	en	public	published	f	2026-07-30 16:26:40.371904+08	arxiv_import	2026-07-30 16:26:40.371904+08	2026-07-30 16:26:40.371904+08	\N	\N	\N	\N
334	4	LIT-000334	Unveiling the Role of Solvents in DBTTF:HATCN Ternary Cocrystals	\N	paper	Donor-acceptor (D:A) cocrystals offer a promising platform for next-generation optoelectronic applications, but the impact of residual solvent molecules on their properties remains an open question. We investigate six novel D:A cocrystals of dibenzotetrathiafulvalene (DBTTF) and 1,4,5,8,9,11-hexaazatriphenylenehexacarbo-nitrile (HATCN), prepared via solvent evaporation, yielding 1:1 molar ratios, and horizontal vapor deposition, resulting in solvent-free 3:2 cocrystals. Combining spectroscopy and density-functional theory (DFT) calculations, we find that, while the electronic and optical properties of the cocrystals are largely unaffected by solvent inclusion, the charge transfer mechanism is surprisingly complex. Raman spectroscopy reveals a consistent charge transfer of 0.11 $e$ across all considered structures, corroborated by DFT calculations on solvent-free systems. Partial charge analysis reveals that in solvated cocrystals, solvent molecules actively participate in the charge transfer process as primary electron acceptors. This involvement can perturb the expected D:A behavior, revealing a faceted charge-transfer mechanism in HATCN even beyond the established involvement of its cyano group. Overall, our study demonstrates that while solution-based methods preserve the intrinsic D:A characteristics, solvents can be leveraged as active electronic components, opening new avenues for material design.	\N	arXiv cond-mat.mtrl-sci, physics.chem-ph	\N	\N	2025	\N	\N	\N	arxiv.2509.09998	\N	\N	http://arxiv.org/abs/2509.09998v1	Ana M. Valencia, Lisa Schraut-May, Marie Siegert, Sebastian Hammer, Beatrice Cula, Alexandra Friedrich, Holger Helten, Jens Pflaum, Caterina Cocchi, Andreas Opitz. (2025). Unveiling the Role of Solvents in DBTTF:HATCN Ternary Cocrystals. arXiv preprint. 2509.09998v1.	en	public	published	f	2026-07-30 16:26:40.376626+08	arxiv_import	2026-07-30 16:26:40.376626+08	2026-07-30 16:26:40.376626+08	\N	\N	\N	\N
335	4	LIT-000335	Ions at electrochemical interfaces: from explicit to implicit molecular solvent descriptions	\N	paper	We investigate the interplay between electronic screening inside a metal and screening by a polar molecular solvent, focusing on their impact on the charge induced by an ion and the solvent structure at the interface. To that end, we consider atomistically resolved electrodes within the Thomas-Fermi model of screening and describe the molecular solvent either explicitly via classical molecular dynamics or implicitly using Molecular Density Functional Theory (MDFT). Specifically, we examine the effect of screening by tuning the Thomas-Fermi screening length $l_\\text{TF}$, the ion charge by considering Na$^+$ and Cl$^-$ and the solvent nature by studying water and acetonitrile. Consistently with our previous findings without solvent, $l_\\text{TF}$ significantly affects the charge distribution inside the metal. However, $l_\\text{TF}$ has no significant impact on the interfacial solvent structure, suggesting that its effect on the charge distribution induced inside the metal by the ion is essentially due to how the metal responds to the (same) external charge distribution, including the solvent, even though the coupling between both sides of the interface may play a secondary role. Furthermore, MDFT accurately reproduces fine details of the interfacial solvent structure around the ion at a fraction of the computational cost of MD simulations. These results highlight the relevance of MDFT as a powerful tool to model electrochemical systems at the molecular level.	\N	arXiv physics.chem-ph, cond-mat.mtrl-sci, physics.comp-ph	\N	\N	2025	\N	\N	\N	arxiv.2503.11361	\N	\N	http://arxiv.org/abs/2503.11361v1	Swetha Nair, Guillaume Jeanmairet, Benjamin Rotenberg. (2025). Ions at electrochemical interfaces: from explicit to implicit molecular solvent descriptions. arXiv preprint. 2503.11361v1.	en	public	published	f	2026-07-30 16:26:40.386082+08	arxiv_import	2026-07-30 16:26:40.386082+08	2026-07-30 16:26:40.386082+08	\N	\N	\N	\N
336	4	LIT-000336	The role of solvent interfacial structural ordering in maintaining stable graphene dispersions	\N	paper	Liquid phase exfoliation (LPE) is the most promising method for the low-cost, scalable production of two-dimensional nanosheets from their bulk counterparts. Extensive exfoliation occurs in most solvents due to the huge amount of energy introduced by sonication or shear mixing. However, the subsequent dispersion is not always stable, with extensive reaggregation occurring in some solvents. Identifying the optimal solvent for a particular layered material is difficult and requires a fundamental understanding of the mechanism involved in maintaining a stable dispersion. Here, we use molecular dynamics calculations to show that when graphene is immersed in a solvent, distinct solvation layers are formed irrespective of the choice of solvent and their formation is energetically favourable for all considered solvents. However, energetic considerations such as these do not explain the experimental solvent-dependence of the dispersion concentration. Instead, we find that solvents with high diffusion coefficients parallel to the graphene layer result in the lowest experimental concentration of graphene in solution. This can be explained by the enhanced ease of reaggregation in these solvents. Solvents with smaller diffusion coefficients result in higher experimental graphene concentrations as reaggregation is prevented. In the low diffusion limit, however, this relationship breaks down. We suggest that here the concentration of graphene in solution depends primarily on the separation efficiency of the initial exfoliation step. Based on this, we predict that the concentration of exfoliated graphene in solvents such as benzaldehyde and quinoline, which have low diffusion constants, can be increased dramatically by careful tuning of the experimental sonication parameters.	\N	arXiv cond-mat.mtrl-sci, cond-mat.mes-hall	\N	\N	2023	\N	\N	\N	arxiv.2310.17283	\N	\N	http://arxiv.org/abs/2310.17283v1	Urvesh Patil, Nuala M. Caffrey. (2023). The role of solvent interfacial structural ordering in maintaining stable graphene dispersions. arXiv preprint. 2310.17283v1.	en	public	published	f	2026-07-30 16:26:40.391821+08	arxiv_import	2026-07-30 16:26:40.391821+08	2026-07-30 16:26:40.391821+08	\N	\N	\N	\N
337	4	LIT-000337	Single crystal growth by the traveling solvent technique: A review	\N	paper	A description is given of the traveling solvent technique, which has been used for the crystal growth of both congruently and incongruently melting materials of many classes of intermetallic, chalcogenide, semiconductor and oxide materials. The use of a solvent, growth at lower temperatures and the zoning process, that are inherent ingredients of the method, can help to grow large, high structural quality, high purity crystals. In order to optimize this process, careful control of the various growth variables is imperative; however, this can be difficult to achieve due to the large number of independent experimental parameters that can be grouped under the broad headings growth conditions, characteristics of the material being grown, and experimental configuration, setup and design.This review attempts to describe the principles behind the traveling solvent technique and the various experimental variables. Guidelines are detailed to provide the information necessary to allow closer control of the crystal growth process through a systematic approach. Comparison is made between the traveling solvent technique and other crystal growth methods, in particular the more conventional stationary flux method. The use of optical heating is described in detail and successful traveling solvent growth by optical heating is reported for the first time for crystals of $Tl_5Te_3$, $Cd_3As_2$, and $FeSc_2S_4$ (using Te, Cd and FeS fluxes, respectively).	\N	arXiv cond-mat.mtrl-sci	\N	\N	2016	\N	\N	\N	10.1016/j.pcrysgrow.2016.03.001	\N	\N	http://arxiv.org/abs/1605.03592v1	S. M. Koohpayeh. (2016). Single crystal growth by the traveling solvent technique: A review. arXiv preprint. 1605.03592v1. https://doi.org/10.1016/j.pcrysgrow.2016.03.001.	en	public	published	f	2026-07-30 16:26:40.395725+08	arxiv_import	2026-07-30 16:26:40.395725+08	2026-07-30 16:26:40.395725+08	\N	\N	\N	\N
338	4	LIT-000338	Structure Formation in Soft Matter Solutions Induced by Solvent Evaporation	\N	paper	Solvent evaporation in soft matter solutions (solutions of colloidal particles, polymers and their mixtures) is an important process in material making and in printing and coating industries. The solvent evaporation process determines the structure of the materials, and strongly affects their performance. Solvent evaporation involves many physico-chemical processes: flow, diffusion, crystallization, gelation, glass transition, etc., and is quite complex. In this article, we report recent progresses in this important process, with a special focus on theoretical and simulation studies.	\N	arXiv cond-mat.soft, cond-mat.mtrl-sci	\N	\N	2017	\N	\N	\N	10.1002/adma.201703769	\N	\N	http://arxiv.org/abs/1708.03584v1	Jiajia Zhou, Xingkun Man, Ying Jiang, Masao Doi. (2017). Structure Formation in Soft Matter Solutions Induced by Solvent Evaporation. arXiv preprint. 1708.03584v1. https://doi.org/10.1002/adma.201703769.	en	public	published	t	2026-07-30 16:26:40.39897+08	arxiv_import	2026-07-30 16:26:40.39897+08	2026-07-30 16:26:40.39897+08	\N	\N	\N	\N
339	4	LIT-000339	Toward Reliable Ad-hoc Scientific Information Extraction: A Case Study on Two Materials Datasets	\N	paper	We explore the ability of GPT-4 to perform ad-hoc schema based information extraction from scientific literature. We assess specifically whether it can, with a basic prompting approach, replicate two existing material science datasets, given the manuscripts from which they were originally manually extracted. We employ materials scientists to perform a detailed manual error analysis to assess where the model struggles to faithfully extract the desired information, and draw on their insights to suggest research directions to address this broadly important task.	\N	arXiv cs.CL, cond-mat.mtrl-sci, cs.AI	\N	\N	2024	\N	\N	\N	10.18653/v1/2024.findings-acl.897	\N	\N	http://arxiv.org/abs/2406.05348v3	Satanu Ghosh, Neal R. Brodnik, Carolina Frey, Collin Holgate, Tresa M. Pollock, Samantha Daly, Samuel Carton. (2024). Toward Reliable Ad-hoc Scientific Information Extraction: A Case Study on Two Materials Datasets. arXiv preprint. 2406.05348v3. https://doi.org/10.18653/v1/2024.findings-acl.897.	en	public	published	f	2026-07-30 16:26:40.404207+08	arxiv_import	2026-07-30 16:26:40.404207+08	2026-07-30 16:26:40.404207+08	\N	\N	\N	\N
340	4	LIT-000340	Adsorption of common solvent molecules on graphene and MoS$_2$ from first-principles	\N	paper	Solvents are an essential element in the production and processing of two-dimensional (2D) materials. For example, the liquid phase exfoliation of layered materials requires a solvent to prevent the resulting monolayers from re-aggregating, while solutions of functional atoms and molecules are routinely used to modify the properties of the layers. It is generally assumed that these solvents do not interact strongly with the layer and so their effects can be neglected. Yet experimental evidence has suggested that explicit atomic-scale interactions between the solvent and layered material may play a crucial role in exfoliation and cause unintended electronic changes in the layer. Little is known about the precise nature of the interaction between the solvent molecules and the 2D layer. Here, we use density functional theory calculations to determine the adsorption configuration and binding energy of a variety of common solvent molecules, both polar and non-polar, on two of the most popular 2D materials, namely graphene and MoS$_2$. We show that these molecules are physisorbed on the surface with negligible charge transferred between them. We find that the adsorption strength of the different molecules is independent of the polar nature of the solvent. However, we show the molecules induce a significant charge rearrangement at the interface after adsorption as a result of polar bonds in the molecule.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2018	\N	\N	\N	10.1063/1.5042524	\N	\N	http://arxiv.org/abs/1806.07843v1	Urvesh Patil, Nuala M. Caffrey. (2018). Adsorption of common solvent molecules on graphene and MoS$_2$ from first-principles. arXiv preprint. 1806.07843v1. https://doi.org/10.1063/1.5042524.	en	public	published	f	2026-07-30 16:26:40.411889+08	arxiv_import	2026-07-30 16:26:40.411889+08	2026-07-30 16:26:40.411889+08	\N	\N	\N	\N
341	4	LIT-000341	Dispersing Nanoparticles in a Polymer Film via Solvent Evaporation	\N	paper	Large scale molecular dynamics simulations are used to study the dispersion of nanoparticles (NPs) in a polymer film during solvent evaporation. As the solvent evaporates, a dense polymer-rich skin layer forms at the liquid/vapor interface, which is either NP rich or poor depending on the strength of the NP/polymer interaction. When the NPs are strongly wet by the polymer, the NPs accumulate at the interface and form layers. However when the NPs are only partially wet by the polymer, most NPs are uniformly distributed in the bulk of the polymer film with the dense skin layer serving as a barrier to prevent the NPs from moving to the interface. Our results point to a possible route to employ less favorable NP/polymer interactions and fast solvent evaporation to uniformly disperse NPs in a polymer film, contrary to the common belief that strong NP/polymer attractions are needed to make NPs well dispersed in polymer nanocomposites.	\N	arXiv cond-mat.soft, cond-mat.mtrl-sci	\N	\N	2016	\N	\N	\N	10.1021/acsmacrolett.6b00263	\N	\N	http://arxiv.org/abs/1605.06408v1	Shengfeng Cheng, Gary S. Grest. (2016). Dispersing Nanoparticles in a Polymer Film via Solvent Evaporation. arXiv preprint. 1605.06408v1. https://doi.org/10.1021/acsmacrolett.6b00263.	en	public	published	f	2026-07-30 16:26:40.415272+08	arxiv_import	2026-07-30 16:26:40.415272+08	2026-07-30 16:26:40.415272+08	\N	\N	\N	\N
342	4	LIT-000342	Influence of solvent quality on polymer solutions: a Monte Carlo study of bulk and interfacial properties	\N	paper	The effect of solvent quality on dilute and semi-dilute regimes of polymers in solution is studied by means of Monte Carlo simulations. The equation of state, adsorptions near a hard wall, wall-polymer surface tension and effective depletion potentials are all calculated as a function of concentration and solvent quality. We find important differences between polymers in good and theta solvents. In the dilute regime, the physical properties for polymers in a theta solvent closely resemble those of ideal polymers. In the semi-dilute regime, however, significant differences are found.	\N	arXiv cond-mat.soft, cond-mat.mtrl-sci	\N	\N	2004	\N	\N	\N	10.1063/1.1756571	\N	\N	http://arxiv.org/abs/cond-mat/0403102v1	C. I. Addison, A. A. Louis, J-. P. Hansen. (2004). Influence of solvent quality on polymer solutions: a Monte Carlo study of bulk and interfacial properties. arXiv preprint. cond-mat/0403102v1. https://doi.org/10.1063/1.1756571.	en	public	published	f	2026-07-30 16:26:40.418752+08	arxiv_import	2026-07-30 16:26:40.418752+08	2026-07-30 16:26:40.418752+08	\N	\N	\N	\N
343	4	LIT-000343	Mean-Field-Theory for Polymers in Mixed Solvents Thermodynamic and Structural Properties	\N	paper	Theoretical aspects of polymers in mixed solvents are considered using the Edwards Hamiltonian formalism. Thermodynamic and structural properties are investigated and some predictions are made when the mixed solvent approaches criticality. Both the single and the many chain problems are examined. When the pure mixed solvent is near criticality, addition of a small amount of polymers shifts the criticality towards either enhanced compatibility or induced phase separation depending upon the value of the parameter describing the interaction asymmetry of the solvents with respect to the polymer. The polymer-solvent effective interaction parameter increases strongly when the solvent mixture approaches criticality. Accordingly, the apparent excluded volume parameter decreases and may vanish or even become negative. Consequently, the polymer undergoes a phase transition from a swollen state to an unperturbed state or even take a collapsed configuration. The effective potential acting on a test chain in strong solutions is calculated and the concept of Edwards screening discussed. Structural properties of ternary mixtures of polymers in mixed solvents are investigated within the Edwards Hamiltonian model. It is shown that the effective potential on a test chain in strong solutions could be written as an infinite series expansion of terms describing interactions via one chain, two chains etc. This summation can be performed following a similar scheme as in the Ornstein-Zernike series expansion.	\N	arXiv cond-mat.soft, cond-mat.mtrl-sci	\N	\N	1999	\N	\N	\N	arxiv.cond-mat/9901216	\N	\N	http://arxiv.org/abs/cond-mat/9901216v1	A. Negadi, A. Sans-Penninckx, M. Bemouna, T. A. Vilgis. (1999). Mean-Field-Theory for Polymers in Mixed Solvents Thermodynamic and Structural Properties. arXiv preprint. cond-mat/9901216v1.	en	public	published	f	2026-07-30 16:26:40.423029+08	arxiv_import	2026-07-30 16:26:40.423029+08	2026-07-30 16:26:40.423029+08	\N	\N	\N	\N
344	4	LIT-000344	Solvent Exfoliation of Electronic-Grade, Two-Dimensional Black Phosphorus	\N	paper	Solution dispersions of two-dimensional (2D) black phosphorus (BP), often referred to as phosphorene, are achieved by solvent exfoliation. These pristine, electronic-grade BP dispersions are produced with anhydrous, organic solvents in a sealed tip ultrasonication system, which circumvents BP degradation that would otherwise occur via solvated oxygen or water. Among conventional solvents, n-methyl-pyrrolidone (NMP) is found to provide stable, highly concentrated (~0.4 mg/mL) BP dispersions. Atomic force microscopy, scanning electron microscopy, transmission electron microscopy, Raman spectroscopy, and X-ray photoelectron spectroscopy show that the structure and chemistry of solvent-exfoliated BP nanosheets are comparable to mechanically exfoliated BP flakes. Additionally, residual NMP from the liquid-phase processing suppresses the rate of BP oxidation in ambient conditions. Solvent-exfoliated BP nanosheet field-effect transistors (FETs) exhibit ambipolar behavior with current on/off ratios and mobilities up to ~10000 and ~50 cm^2/(V*s), respectively. Overall, this study shows that stable, highly concentrated, electronic-grade 2D BP dispersions can be realized by scalable solvent exfoliation, thereby presenting opportunities for large-area, high-performance BP device applications.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2015	\N	\N	\N	10.1021/acsnano.5b01143	\N	\N	http://arxiv.org/abs/1505.00878v1	Joohoon Kang, Joshua D. Wood, Spencer A. Wells, Jae-Hyeok Lee, Xiaolong Liu, Kan-Sheng Chen, Mark C. Hersam. (2015). Solvent Exfoliation of Electronic-Grade, Two-Dimensional Black Phosphorus. arXiv preprint. 1505.00878v1. https://doi.org/10.1021/acsnano.5b01143.	en	public	published	f	2026-07-30 16:26:40.427984+08	arxiv_import	2026-07-30 16:26:40.427984+08	2026-07-30 16:26:40.427984+08	\N	\N	\N	\N
345	4	LIT-000345	Effect of Dynamic Surface Polarization on the Oxidative Stability of Solvents in Nonaqueous Li-O$_2$ Batteries	\N	paper	Polarization-induced renormalization of the frontier energy levels of interacting molecules and surfaces can cause significant shifts in the excitation and transport behavior of electrons. This phenomenon is crucial in determining the oxidative stability of nonaqeous electrolytes in high energy density electrochemical systems such as the Li-O$_2$ battery. On the basis of partially self-consistent first-principles ScGW0 calculations, we systematically study how the electronic energy levels of four commonly used solvent molecules, namely dimethylsulfoxide (DMSO), dimethoxyethane (DME), tetrahydrofuran (THF) and acetonitrile (ACN), renormalize when physisorbed on the different stable surfaces of Li$_2$O$_2$, the main discharge product. Using band level alignment arguments, we propose that the difference between the solvent's highest occupied molecular orbital (HOMO) level and the surface's valence band maximum (VBM) is a refined metric of oxidative stability. This metric and a previously used descriptor, solvent's gas phase HOMO level, agree quite well for physisorbed cases on pristine surfaces where ACN is oxidatively most stable followed by DME, THF and DMSO. However, this effect is intrinsically linked to the surface chemistry of solvent's interaction with the surfaces states and defects, and depends strongly on their nature. We conclusively show that the propensity of solvent molecules to oxidize will be significantly higher on Li$_2$O$_2$ surfaces with defects as compared to pristine surfaces. This suggests that the oxidatively stability of solvent is dynamic and is a strong function of surface electronic properties. Thus, while gas phase HOMO levels could be used for preliminary solvent candidate screening, a more refined picture of solvent stability requires mapping out the solvent stability as a function of the state of the surface under the operating conditions.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2017	\N	\N	\N	10.1103/PhysRevMaterials.1.045401	\N	\N	http://arxiv.org/abs/1705.03862v1	Abhishek Khetan, Heinz Pitsch, Venkatasubramanian Viswanathan. (2017). Effect of Dynamic Surface Polarization on the Oxidative Stability of Solvents in Nonaqueous Li-O$_2$ Batteries. arXiv preprint. 1705.03862v1. https://doi.org/10.1103/PhysRevMaterials.1.045401.	en	public	published	f	2026-07-30 16:26:40.434054+08	arxiv_import	2026-07-30 16:26:40.434054+08	2026-07-30 16:26:40.434054+08	\N	\N	\N	\N
346	4	LIT-000346	Sensing solvents with ultra-sensitive porous poly(ionic liquid) actuators	\N	paper	We introduced a new concept for fabricating solvent stimulus polymer actuators with unprecedented sensitivity and accuracy. This was accomplished by integrating porous architectures and electrostatic complexation gradients in a poly(ionic liquid) membrane that bears ionic liquid species for solvent sorption. In contact with 1.5 mol% of acetone molecules in water, the actuator membrane (1 mm x 20 mm x 30 um) bent into a closed loop. While the interaction between solvents and the polymer drives the actuation, the continuous gradient in complexation degree combined with the porous architecture optimizes the actuation, giving it a high sensitivity and even the ability to discriminate butanol solvent isomers. The membrane is also capable of cooperative actuation. The design concept is easy to implement and applicable to other polyelectrolyte systems, which substantially underpins their potentials in smart and sensitive signaling microrobotics/devices.	\N	arXiv cond-mat.soft, cond-mat.mtrl-sci	\N	\N	2016	\N	\N	\N	10.1002/adma.201500533	\N	\N	http://arxiv.org/abs/1609.01392v1	Qiang Zhao, Jan Heyda, Joachim Dzubiella, Karoline Täuber, John W. C. Dunlop, Jiayin Yuan. (2016). Sensing solvents with ultra-sensitive porous poly(ionic liquid) actuators. arXiv preprint. 1609.01392v1. https://doi.org/10.1002/adma.201500533.	en	public	published	f	2026-07-30 16:26:40.438918+08	arxiv_import	2026-07-30 16:26:40.438918+08	2026-07-30 16:26:40.438918+08	\N	\N	\N	\N
347	4	LIT-000347	Machine Learning for Polymer Chemical Resistance to Organic Solvents	\N	paper	Predicting the chemical resistance of polymers to organic solvents is a longstanding challenge in materials science, with significant implications for sustainable materials design and industrial applications. Here, we address the need for interpretable and generalizable frameworks to understand and predict polymer chemical resistance beyond conventional solubility models. We systematically analyze a large dataset of polymer solvent combinations using a data-driven approach. Our study reveals that polymer crystallinity and density, as well as solvent polarity, are key factors governing chemical resistance, and that these trends are consistent with established theoretical models. These findings provide a foundation for rational screening and design of polymer materials with tailored chemical resistance, advancing both fundamental understanding and practical applications.	\N	arXiv cond-mat.soft, cond-mat.mtrl-sci	\N	\N	2025	\N	\N	\N	arxiv.2509.05344	\N	\N	http://arxiv.org/abs/2509.05344v1	Shogo Kunieda, Mitsuru Yambe, Hiromori Murashima, Takeru Nakamura, Toshiaki Shintani, Hitoshi Kamijima, Yoshihiro Hayashi, Yosuke Hanawa, Ryo Yoshida. (2025). Machine Learning for Polymer Chemical Resistance to Organic Solvents. arXiv preprint. 2509.05344v1.	en	public	published	f	2026-07-30 16:26:40.444831+08	arxiv_import	2026-07-30 16:26:40.444831+08	2026-07-30 16:26:40.444831+08	\N	\N	\N	\N
348	4	LIT-000348	Effect of organic solvent on the cold sintering processing of SrFe12O19 platelet-based permanent magnets	\N	paper	In this work we have investigated the effect of the solvent during the processing of SrFe12O19 platelet-based permanent magnets by cold sintering process (CSP) plus a post-thermal treatment. Several organic solvents: glacial acetic acid, oleic acid and oleylamine have been analyzed, optimizing the CSP temperatures at 190-270 °C, under pressures of 375-670 MPa and 6-50 wt% of solvent. Modifications in the morphological and structural properties are identified depending on the solvent, which impacts on the magnetic response. Independently of the solvent, the mechanical integrity of ferrite magnets obtained by CSP is improved by a post-annealing at 1100 °C for 2 h, resulting in relative densities around 92 % with an average grain size of 1 μm and a fraction of SrFe12O19 phase &gt; 91 %. Hc &gt; 2.1 kOe and MS of 73 emu/g are obtained in the final sintered ceramic magnets, exhibiting the highest HC value of 2.8 kOe for the magnet sintered using glacial acetic acid.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2023	\N	\N	\N	10.1016/j.jeurceramsoc.2021.10.062	\N	\N	http://arxiv.org/abs/2309.15859v1	Aida Serrano, Eduardo García-Martín, Cecilia Granados-Miralles, Jesús López-Sánchez, Giulio Gorni, Adrián Quesada, José F. Fernández. (2023). Effect of organic solvent on the cold sintering processing of SrFe12O19 platelet-based permanent magnets. arXiv preprint. 2309.15859v1. https://doi.org/10.1016/j.jeurceramsoc.2021.10.062.	en	public	published	f	2026-07-30 16:26:40.453945+08	arxiv_import	2026-07-30 16:26:40.453945+08	2026-07-30 16:26:40.453945+08	\N	\N	\N	\N
349	4	LIT-000349	Solvent-antisolvent interactions in metal halide perovskites	\N	paper	The fabrication of metal halide perovskite films using the solvent-engineering method is increasingly common. In this method, the crystallisation of the perovskite layer is triggered by the application of an antisolvent during the spin-coating of a perovskite precursor solution. Herein, we introduce the current state of understanding of the processes involved in the crystallisation of perovskite layers formed by solvent engineering, focusing in particular on the role of antisolvent properties and solvent-antisolvent interactions. By considering the impact of the Hansen solubility parameters, we propose guidelines for selecting the appropriate antisolvent and outline open questions and future research directions for the fabrication of perovskite films by this method.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2024	\N	\N	\N	arxiv.2404.11637	\N	\N	http://arxiv.org/abs/2404.11637v1	Jose Roberto Bautista-Quijano, Oscar Telschow, Fabian Paulus, Yana Vaynzof. (2024). Solvent-antisolvent interactions in metal halide perovskites. arXiv preprint. 2404.11637v1.	en	public	published	f	2026-07-30 16:26:40.463929+08	arxiv_import	2026-07-30 16:26:40.463929+08	2026-07-30 16:26:40.463929+08	\N	\N	\N	\N
350	4	LIT-000350	Solvent-side observation on vibrational energy transfer by transient grating spectroscopy: Bridged azulene-anthracene	\N	paper	Transient grating acoustic spectroscopy has been applied to studies on the vibrational energy relaxation process of the electronic ground state of azulene, two 1-alkylazulenes, and five bridged azulene-anthracenes in three different solvents: 1,1,1-trichloro-1,2,2-trifluoroethane, acetonitrile, and xenon. The solute molecule was vibrationally excited by the photo-excitation of the auzlenyl group to the S1 state through the fast internal conversion, and the rate of solvent thermalization due to the vibrational energy relaxation was determined. The thermalization rates for 1-alkylazulenes and bridged azulene-anthracenes were faster than that of azulene. Based on the results of the thermalization rates of 1-alkylazulenes, we concluded that the acceleration of the energy dissipation from the azulenyl group induced the faster energy dissipation from the solute to the solvent. The vibrational normal mode analysis suggests that the density of the vibrational modes and anharmonic coupling between the vibrational modes induce the faster intramolecular energy redistribution. In xenon, the solvent thermalization rates were close to the energy dissipation rates of the solute molecule reported using transient absorption spectroscopy. On the other hand, in the chlorofluorocarbon, the ratio of the thermalization rate to the dissipation rate was a dependent of the molecular species, and especially faster solvent thermalization rate of 9-(6-(azulen-1-yl)hexyl)anthracene was predicted. The vibrational characteristics of this solvent are discussed in the relation to the vibrational modes and structures of the bridged compounds.	\N	arXiv cond-mat.mtrl-sci, physics.chem-ph, physics.optics	\N	\N	2014	\N	\N	\N	arxiv.1406.4164	\N	\N	http://arxiv.org/abs/1406.4164v1	Hiroki Fujiwara. (2014). Solvent-side observation on vibrational energy transfer by transient grating spectroscopy: Bridged azulene-anthracene. arXiv preprint. 1406.4164v1.	en	public	published	f	2026-07-30 16:26:40.471038+08	arxiv_import	2026-07-30 16:26:40.471038+08	2026-07-30 16:26:40.471038+08	\N	\N	\N	\N
351	4	LIT-000351	Numerical explorations of solvent borne adhesives: A lattice-based approach to morphology formation	\N	paper	The internal structure of adhesive tapes determines the effective mechanical properties. This holds true especially for blended systems, here consisting of acrylate and rubber phases. In this note, we propose a lattice-based model to study numerically the formation of internal morphologies within a four-component mixture (of discrete particles) where the solvent components evaporate. Mimicking numerically the interaction between rubber, acrylate, and two different types of solvents, relevant for the technology of adhesive tapes, we aim to obtain realistic distributions of rubber ball-shaped morphologies -- they play a key role in the overall functionality of those special adhesives. Our model incorporates the evaporation of both solvents and allows for tuning the strength of two essentially different solvent-solute interactions and of the temperature of the system.	\N	arXiv cond-mat.soft, cond-mat.mtrl-sci, cond-mat.stat-mech	\N	\N	2023	\N	\N	\N	arxiv.2305.17790	\N	\N	http://arxiv.org/abs/2305.17790v1	Vi Cecilia Erik Kronberg, Stela Andrea Muntean, Nils Hendrik Kröger, Adrian Muntean. (2023). Numerical explorations of solvent borne adhesives: A lattice-based approach to morphology formation. arXiv preprint. 2305.17790v1.	en	public	published	f	2026-07-30 16:26:40.476698+08	arxiv_import	2026-07-30 16:26:40.476698+08	2026-07-30 16:26:40.476698+08	\N	\N	\N	\N
352	4	LIT-000352	Ordered Phases of Diblock Copolymer Micelles in Selective Solvent	\N	paper	We propose a mean-field model to explore the equilibrium coupling between micelle aggregation and lattice choice in neutral copolymer and selective solvent mixtures. We find both thermotropic and lyotropic transitions from face-centered cubic to body-centered cubic ordered phases of spherical micelles, in agreement with experimental observations of these systems over a broad range of conditions. Stability of the non-closed packed phase can be attributed to two physical mechanisms: the large entropy of lattice phonons near crystal melting and the preference of the inter-micelle repulsions for the body-centered cubic structure when the lattice becomes sufficiently dense at higher solution concentrations. Both mechanisms are controlled by the decrease of micelle aggregation and subsequent increase of lattice density as solvent selectivity is reduced. These results shed new light on the relationship between micelle structure -- "crewcut" or "hairy" -- and long-range order in micelle solutions.	\N	arXiv cond-mat.soft, cond-mat.mtrl-sci	\N	\N	2005	\N	\N	\N	arxiv.cond-mat/0507429	\N	\N	http://arxiv.org/abs/cond-mat/0507429v2	Gregory M. Grason. (2005). Ordered Phases of Diblock Copolymer Micelles in Selective Solvent. arXiv preprint. cond-mat/0507429v2.	en	public	published	f	2026-07-30 16:26:40.482923+08	arxiv_import	2026-07-30 16:26:40.482923+08	2026-07-30 16:26:40.482923+08	\N	\N	\N	\N
353	4	LIT-000353	Effect of Rare-Earth Ions on an Electric Polarization Induced by the Phase Separation Domains in RMn2O5 (R = Er, Tb)	\N	paper	The effect of rare-earth ions (R = Er^{3+}, Tb^{3+}) with strong spin-orbit coupling on the dielectric properties and the electric polarization induced by local polar phase separation domains in RMn_2O_5 multiferroics has been studied. These parameters were found to be qualitatively distinguished from those studied before in GdMn_2O_5, in which Gd^{3+} ion in the ground ^8S_{7/2} state is weakly bounded with the lattice. It is shown that the properties of the polar phase separation domains, which form in the subsystem of Mn^{3+} and Mn^{4+} ions, are substantially dependent on the values of crystal fields, in which these domains exist.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2020	\N	\N	\N	10.1134/S1063783420020146	\N	\N	http://arxiv.org/abs/2002.05471v1	B. Kh. Khannanov, E. I. Golovenchits, V. A. Sanina. (2020). Effect of Rare-Earth Ions on an Electric Polarization Induced by the Phase Separation Domains in RMn2O5 (R = Er, Tb). arXiv preprint. 2002.05471v1. https://doi.org/10.1134/S1063783420020146.	en	public	published	f	2026-07-30 16:26:40.487034+08	arxiv_import	2026-07-30 16:26:40.487034+08	2026-07-30 16:26:40.487034+08	\N	\N	\N	\N
354	4	LIT-000354	Rare-earth chalcogenides: A large family of triangular lattice spin liquid candidate	\N	paper	Frustrated quantum magnets are expected to host many exotic quantum spin states like quantum spin liquid (QSL), and have attracted numerous interest in modern condensed matter physics. The discovery of the triangular lattice spin liquid candidate YbMgGaO$_4$ stimulated an increasing attention on the rare-earth-based frustrated magnets with strong spin-orbit coupling. Here we report the synthesis and characterization of a large family of rare-earth chalcogenides AReCh$_2$ (A = alkali or monovalent ions, Re = rare earth, Ch = O, S, Se). The family compounds share the same structure (R$\\bar{3}$m) as YbMgGaO$_4$, and antiferromagnetically coupled rare-earth ions form perfect triangular layers that are well separated along the $c$-axis. Specific heat and magnetic susceptibility measurements on NaYbO$_2$, NaYbS$_2$ and NaYbSe$_2$ single crystals and polycrystals, reveal no structural or magnetic transition down to 50mK. The family, having the simplest structure and chemical formula among the known QSL candidates, removes the issue on possible exchange disorders in YbMgGaO$_4$. More excitingly, the rich diversity of the family members allows tunable charge gaps, variable exchange coupling, and many other advantages. This makes the family an ideal platform for fundamental research of QSLs and its promising applications.	\N	arXiv cond-mat.str-el, cond-mat.mtrl-sci, cond-mat.supr-con	\N	\N	2018	\N	\N	\N	10.1088/0256-307X/35/11/117501	\N	\N	http://arxiv.org/abs/1809.03025v2	Weiwei Liu, Zheng Zhang, Jianting Ji, Yixuan Liu, Jianshu Li, Xiaoqun Wang, Hechang Lei, Gang Chen, Qingming Zhang. (2018). Rare-earth chalcogenides: A large family of triangular lattice spin liquid candidate. arXiv preprint. 1809.03025v2. https://doi.org/10.1088/0256-307X/35/11/117501.	en	public	published	f	2026-07-30 16:26:40.493911+08	arxiv_import	2026-07-30 16:26:40.493911+08	2026-07-30 16:26:40.493911+08	\N	\N	\N	\N
355	4	LIT-000355	Structural study of a rare earth-rich aluminoborosilicate glass containing various alkali and alkaline-earth modifier cations	\N	paper	A rare-earth rich aluminoborosilicate glass of composition (given in wt.%): 50.68 SiO2 - 4.25 Al2O3 - 8.50 B2O3 - 12.19 M2O - 4.84 M'O - 3.19 ZrO2 - 16.35 Nd2O3 (where M and M' are respectively an alkali and alkaline earth cation) is currently under study as potential nuclear waste form. In this work, we were interested in the structure of this glass in relation with the modifier cation type. Two different glass series were elaborated by changing separately the nature of the alkaline (M=Li, Na, K, Rb, Cs) and the alkaline-earth (M'=Mg, Ca, Sr, Ba) ions and different structural studies were intended to elucidate the local environment of the rare-earth and the network arrangement. Only slight effect was put in evidence on the covalency degree and the length of Nd-O linkage with a change of M or M', by optical spectroscopy and EXAFS measurements. Raman and MAS NMR (29Si, 27Al, 11B) spectroscopies showed a variation of the polymerization degree of the network with the size of the modifier cation. Finally, the most important feature of this glass composition is related to the AlO4- charge compensation which was proved to be uniquely assured by alkali cations.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2011	\N	\N	\N	arxiv.1104.1868	\N	\N	http://arxiv.org/abs/1104.1868v1	Arnaud Quintas, Daniel Caurant, Odile Majérus, Marion Lenoir, Jean-Luc Dussossoy, Thibault Charpentier, D. R. Neuville. (2011). Structural study of a rare earth-rich aluminoborosilicate glass containing various alkali and alkaline-earth modifier cations. arXiv preprint. 1104.1868v1.	en	public	published	f	2026-07-30 16:26:40.505541+08	arxiv_import	2026-07-30 16:26:40.505541+08	2026-07-30 16:26:40.505541+08	\N	\N	\N	\N
356	4	LIT-000356	Low-energy spin dynamics in rare-earth perovskite oxides	\N	paper	We review recent studies of spin dynamics in rare-earth orthorhombic perovskite oxides of the type $RM$O$_3$, where $R$ is a rare-earth ion and $M$ is a transition-metal ion, using single-crystal inelastic neutron scattering (INS). After a short introduction to the magnetic INS technique in general, the results of INS experiments on both transition-metal and rare-earth subsystems for four selected compounds (YbFeO$_3$, TmFeO$_3$, YFeO$_3$, YbAlO$_3$) are presented. We show that the spectrum of magnetic excitations consists of two types of collective modes that are well separated in energy: gapped magnons with a typical bandwidth of $&lt;$70 meV, associated with the antiferromagnetically (AFM) ordered transition-metal subsystem, and AFM fluctuations of $&lt;$5 meV within the rare-earth subsystem, with no hybridization of those modes. We discuss the high-energy conventional magnon excitations of the 3$d$ subsystem only briefly, and focus in more detail on the spectacular dynamics of the rare-earth sublattice in these materials. We observe that the nature of the ground state and the low-energy excitation strongly depends on the identity of the rare-earth ion. In the case of non-Kramers ions, the low-symmetry crystal field completely eliminates the degeneracy of the multiplet state, creating a rich magnetic field-temperature phase diagram. In the case of Kramers ions, the resulting ground state is at least a doublet, which can be viewed as an effective quantum spin-1/2. Equally important is the fact that in Yb-based materials the nearest-neighbor exchange interaction dominates in one direction, despite the three-dimensional nature of the orthoperovskite crystal structure. The observation of a fractional spinon continuum and quantum criticality in YbAlO$_3$ demonstrates that Kramers rare-earth based magnets can provide realizations of various aspects of quantum low-dimensional physics.	\N	arXiv cond-mat.str-el, cond-mat.mtrl-sci	\N	\N	2021	\N	\N	\N	10.1088/1361-648X/ac1367	\N	\N	http://arxiv.org/abs/2106.08378v1	A. Podlesnyak, S. Nikitin, G. Ehlers. (2021). Low-energy spin dynamics in rare-earth perovskite oxides. arXiv preprint. 2106.08378v1. https://doi.org/10.1088/1361-648X/ac1367.	en	public	published	f	2026-07-30 16:26:40.513656+08	arxiv_import	2026-07-30 16:26:40.513656+08	2026-07-30 16:26:40.513656+08	\N	\N	\N	\N
357	4	LIT-000357	Magnetic and electron transport properties of the rare-earth cobaltates, La0.7-xLnxCa0.3CoO3 (Ln = Pr, Nd, Gd and Dy) : A case of phase separation	\N	paper	Magnetic and electrical properties of four series of rare earth cobaltates of the formula La0.7-xLnxCa0.3CoO3 with Ln = Pr, Nd, Gd and Dy have been investigated. Compositions close to x = 0.0 contain large ferromagnetic clusters or domains, and show Brillouin-like behaviour of the field-cooled DC magnetization data with fairly high ferromagnetic Tc values, besides low electrical resistivities with near-zero temperature coefficients. The zero-field-cooled data generally show a non-monotonic behaviour with a peak at a temperatures slightly lower than Tc. The near x = 0.0 compositions show a prominent peak corresponding to the Tc in the AC-susceptibility data. The ferromagnetic Tc varies linearly with x or the average radius of the A-site cations, (rA). With increase in x or decrease in (rA), the magnetization value at any given temperature decreases markedly and the AC-susceptibility measurements show a prominent transition arising from small magnetic clusters with some characteristics of a spin-glass. Electrical resistivity increases with increase in x, showed a significant increase around a critical value of x or (rA), at which composition the small clusters also begin to dominate. These properties can be understood in terms of a phase separation scenario wherein large magnetic clusters give way to smaller ones with increase in x, with both types of clusters being present in certain compositions. The changes in magnetic and electrical properties occur parallely since the large ferromagnetic clusters are hole-rich and the small clusters are hole-poor. Variable-range hopping seems to occur at low temperatures in these cobaltates.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2004	\N	\N	\N	10.1088/0953-8984/16/45/018	\N	\N	http://arxiv.org/abs/cond-mat/0409288v2	Asish K. Kundu, K. Ramesha, Ram Seshadri, C. N. R. Rao. (2004). Magnetic and electron transport properties of the rare-earth cobaltates, La0.7-xLnxCa0.3CoO3 (Ln = Pr, Nd, Gd and Dy) : A case of phase separation. arXiv preprint. cond-mat/0409288v2. https://doi.org/10.1088/0953-8984/16/45/018.	en	public	published	f	2026-07-30 16:26:40.518387+08	arxiv_import	2026-07-30 16:26:40.518387+08	2026-07-30 16:26:40.518387+08	\N	\N	\N	\N
359	4	LIT-000359	Controlling Carbon Nanostructure Synthesis in Thermal Plasma Jet: Correlation of Process Parameters, Plasma Characteristics, and Product Morphology	\N	paper	Thermal plasma has emerged as an effective approach for producing carbon nanostructures without the need for specific catalysts nor substrates. While efforts have focused on the effect of process parameters such as reaction pressure, input power or carbon source, the intricate role and relationship with plasma characteristics like density and temperature are often overlooked due to the complexity of the environment. This study addresses this gap by establishing a correlation between process parameters, plasma characteristics, and product morphology, essential for controlling the growth of carbon nanostructures. We explored the impact of carbon precursor type (CH4 and C2H2), hydrogen, pressure, and flow rate on nanostructure formation. Using in situ optical emission spectroscopy (OES), we mapped the distribution of both temperature and dicarbon molecule (C2) density within the plasma jet. We demonstrate that the growth of low-density nanostructures, such as carbon nanohorns (CNHs), is favoured at dilute C2 local densities and high temperatures, while denser nanostructures, such as onion-like polyhedral graphitic nanocapsules (GNCs), are favoured at higher C2 densities and lower temperatures. The carbon density can be controlled by the flow rate and the pressure, which in turn significantly influence the nanostructure morphology, evolving from graphene nanoflakes (GNFs) to GNCs as either parameter increases. Increasing the H/C ratio from 1 to 8 resulted in a morphological transition from CNHs to GNFs. During the synthesis, the plasma jet temperature surpassed 3,000 K, with crystalline growth occurring 50 to 100 mm below the nozzle.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2025	\N	\N	\N	10.1016/j.carbon.2023.118605	\N	\N	http://arxiv.org/abs/2512.04880v1	Taki Aissou, Jerome Menneveux, Fanny Casteignau, Nadi Braidy, Jocelyn Veilleux. (2025). Controlling Carbon Nanostructure Synthesis in Thermal Plasma Jet: Correlation of Process Parameters, Plasma Characteristics, and Product Morphology. arXiv preprint. 2512.04880v1. https://doi.org/10.1016/j.carbon.2023.118605.	en	public	published	f	2026-07-30 16:27:00.821566+08	arxiv_import	2026-07-30 16:27:00.821566+08	2026-07-30 16:27:00.821566+08	\N	\N	\N	\N
360	4	LIT-000360	Site-dependent hydrogenation on graphdiyne	\N	paper	Graphene is one of the most important materials in science today due to its unique and remarkable electronic, thermal and mechanical properties. However in its pristine state, graphene is a gapless semiconductor, what limits its use in transistor electronics. In part due to the revolution created by graphene in materials science, there is a renewed interest in other possible graphene-like two-dimensional structures. Examples of these structures are graphynes and graphdiynes, which are two-dimensional structures, composed of carbon atoms in sp2 and sp-hybridized states. Graphdiynes (benzenoid rings connecting two acetylenic groups) were recently synthesized and some of them are intrinsically nonzero gap systems. These systems can be easily hydrogenated and the relative level of hydrogenation can be used to tune the band gap values. We have investigated, using fully reactive molecular dynamics (ReaxFF), the structural and dynamics aspects of the hydrogenation mechanisms of graphdiyne membranes. Our results showed that the hydrogen bindings have different atom incorporation rates and that the hydrogenation patterns change in time in a very complex way. The formation of correlated domains reported to hydrogenated graphene is no longer observed in graphdiyne cases.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2014	\N	\N	\N	10.1016/j.carbon.2014.05.088	\N	\N	http://arxiv.org/abs/1408.2705v1	P. A. S. Autreto, J. M. de Sousa, D. S. Galvao. (2014). Site-dependent hydrogenation on graphdiyne. arXiv preprint. 1408.2705v1. https://doi.org/10.1016/j.carbon.2014.05.088.	en	public	published	f	2026-07-30 16:27:00.829812+08	arxiv_import	2026-07-30 16:27:00.829812+08	2026-07-30 16:27:00.829812+08	\N	\N	\N	\N
361	4	LIT-000361	Revealing trends in catalytic activity of adatoms for hydrogen adsorption on carbon: a case study of graphene and carbon nanotube	\N	paper	The increasing demand for sustainable energy solutions necessitates advancements in hydrogen storage technologies. This study investigates the hydrogen adsorption characteristics of graphene and a (8,0) carbon nanotube (CNT) decorated with adatoms of various elements. Using molecular dynamics (MD) simulations and the universal interatomic potential 'PreFerred Potential' (PFP) implemented in the Matlantis framework, we explore the hydrogen storage capabilities of these doped carbon structures at 77K. We analyze the adsorption efficiency based on the position of adatoms (top, bridge, and hollow sites) and find that the group II elements, such as calcium and strontium, exhibit significant hydrogen uptake. Additionally, light elements like lithium and sodium demonstrate enhanced gravimetric hydrogen storage due to their low atomic mass. Our findings provide insights into the potential of doped graphene and CNTs for efficient hydrogen storage applications.	\N	arXiv cond-mat.mtrl-sci, cond-mat.mes-hall	\N	\N	2024	\N	\N	\N	10.1016/j.cartre.2025.100535	\N	\N	http://arxiv.org/abs/2412.11960v2	Thomas Leiner, David Holec. (2024). Revealing trends in catalytic activity of adatoms for hydrogen adsorption on carbon: a case study of graphene and carbon nanotube. arXiv preprint. 2412.11960v2. https://doi.org/10.1016/j.cartre.2025.100535.	en	public	published	f	2026-07-30 16:27:00.834004+08	arxiv_import	2026-07-30 16:27:00.834004+08	2026-07-30 16:27:00.834004+08	\N	\N	\N	\N
362	4	LIT-000362	Potential reversible hydrogen storage in Li-decorated carbon allotrope PAI-Graphene: A first-principles study	\N	paper	Two-dimensional porous carbon nanomaterials are proven to be promising hydrogen storage substrates as they possess high surface area, large number of active sites, low molecular mass, and hydrogen molecules can be adsorbed on both sides of these materials. By performing first-principles density functional theory-based calculations, we report ultrahigh reversible hydrogen uptake in lithium decorated 2D carbon allotrope PAI-graphene, which is formed of a regular pattern of polymerized as-indacenes (PAI). We found that a single unit cell of PAI-graphene can be decorated by 8 Li atoms, in which each Li atom can reversibly adsorb 4 hydrogen molecules, leading to 15.7 % of H uptake, remarkably higher than the DOE demand of 6.5 %. Li atom donates its valence 2s-electron to PAI-graphene and gets ionized. The adsorption energies of the various H2 attached to Li-atom are found to be suitable for reversible use during practical applications. Hydrogen molecules get attached to the ionized metal atom by electrostatic interactions. An energy barrier of 1.48 eV is present for the diffusion of Li atoms between the two most stable adsorption sites which justifies the absence of the clustering of Li atoms.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2023	\N	\N	\N	10.1016/j.ijhydene.2022.11.016	\N	\N	http://arxiv.org/abs/2312.01144v1	Vikram Mahamiya, Alok Shukla, Brahmananda Chakraborty. (2023). Potential reversible hydrogen storage in Li-decorated carbon allotrope PAI-Graphene: A first-principles study. arXiv preprint. 2312.01144v1. https://doi.org/10.1016/j.ijhydene.2022.11.016.	en	public	published	f	2026-07-30 16:27:00.837357+08	arxiv_import	2026-07-30 16:27:00.837357+08	2026-07-30 16:27:00.837357+08	\N	\N	\N	\N
363	4	LIT-000363	Hydrogen embrittlement of twinning-induced plasticity steels: contribution of segregation to twin boundaries	\N	paper	Metallic materials, especially steel, underpin transportation technologies. High-manganese twinning induced plasticity (TWIP) austenitic steels exhibit exceptional strength and ductility from twins, low-energy microstructural defects that form during plastic loading. Their high-strength could help light-weighting vehicles, and hence cut carbon emissions. TWIP steels are however very sensitive to hydrogen embrittlement that causes dramatic losses of ductility and toughness leading to catastrophic failure of engineering parts. Here, we examine the atomic-scale chemistry and interaction of hydrogen with twin boundaries in a model TWIP steel by using isotope-labelled atom probe tomography, using tritium to avoid overlap with residual hydrogen. We reveal co-segregation of tritium and, unexpectedly, oxygen to coherent twin boundaries, and discuss their combined role in the embrittlement of these promising steels.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2022	\N	\N	\N	10.1016/j.scriptamat.2022.115187	\N	\N	http://arxiv.org/abs/2211.09347v2	Heena Khanchandani, Rolf Rolli, Hans-Christian Schneider, Christoph Kirchlechner, Baptiste Gault. (2022). Hydrogen embrittlement of twinning-induced plasticity steels: contribution of segregation to twin boundaries. arXiv preprint. 2211.09347v2. https://doi.org/10.1016/j.scriptamat.2022.115187.	en	public	published	f	2026-07-30 16:27:00.840947+08	arxiv_import	2026-07-30 16:27:00.840947+08	2026-07-30 16:27:00.840947+08	\N	\N	\N	\N
364	4	LIT-000364	A new class of carbon stabilized austenitic steels resistant to hydrogen embrittlement	\N	paper	High strength steels are susceptible to H-induced failure, which is typically caused by the presence of diffusible H in the microstructure. The diffusivity of H in austenitic steels with fcc crystal structure is slow. The austenitic steels are hence preferred for applications in the hydrogen-containing atmospheres. However, the fcc structure of austenitic steels is often stabilized by the addition of Ni, Mn or N, which are relatively expensive alloying elements to use. Austenite can kinetically also be stabilized by using C. Here, we present an approach applied to a commercial cold work tool steel, where we use C to fully stabilize the fcc phase. This results in a microstructure consisting of only austenite and an M7C3 carbide. An exposure to H by cathodic hydrogen charging exhibited no significant influence on the strength and ductility of the C stabilized austenitic steel. While this material is only a prototype based on an existing alloy of different purpose, it shows the potential for low-cost H-resistant steels based on C stabilized austenite.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2023	\N	\N	\N	arxiv.2305.15290	\N	\N	http://arxiv.org/abs/2305.15290v3	Heena Khanchandani, Stefan Zeiler, Lucas Strobel, Mathias Goeken, Peter Felfer. (2023). A new class of carbon stabilized austenitic steels resistant to hydrogen embrittlement. arXiv preprint. 2305.15290v3.	en	public	published	f	2026-07-30 16:27:00.846256+08	arxiv_import	2026-07-30 16:27:00.846256+08	2026-07-30 16:27:00.846256+08	\N	\N	\N	\N
365	4	LIT-000365	Hydrogen Effect on Plastic Deformation and Fracture in Austenitic Stainless Steel	\N	paper	The effect of hydrogen on the fracture behaviour of austenitic stainless steel has been investigated in the past [1][2]. It has been reported that fracture initiates by void formation at inclusions and regions of enhanced strain localisation [3]. There is experimental evidence that supports the fact that hydrogen influences void nucleation, growth and coalescence during material fracture [4]. This work investigates the effect of hydrogen on void growth and coalescence in austenitic stainless steel. The effect of hydrogen on void growth and coalescence for different stress triaxialities has been examined by analysing the stress strain response of a single crystal representative volume element (RVE). The results show that the higher the stress triaxiality, the lower the equivalent stress required to yield. This response is found to be similar irrespective of whether the material is being exposed to hydrogen or not. Lower equivalent strain values to yield were experienced for higher stress triaxialities for both hydrogen free and hydrogenated samples. Hydrogen slowed down void growth at high stress triaxialities but promoted void growth as lower triaxialities. For lower triaxialities, the presence of hydrogen was found to initially inhibit void growth at low equivalent strain values. However, this effect reversed at higher equivalent strain values and hydrogen was found to promote void growth. The effect of hydrogen promoting or inhibiting void growth have been shown to increase in magnitude with increasing hydrogen concentration.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2019	\N	\N	\N	arxiv.1910.06603	\N	\N	http://arxiv.org/abs/1910.06603v1	Eugene Ogosi, Umair Bin Asim, Amir Siddiq, Mehmet Kartal. (2019). Hydrogen Effect on Plastic Deformation and Fracture in Austenitic Stainless Steel. arXiv preprint. 1910.06603v1.	en	public	published	f	2026-07-30 16:27:00.852293+08	arxiv_import	2026-07-30 16:27:00.852293+08	2026-07-30 16:27:00.852293+08	\N	\N	\N	\N
366	4	LIT-000366	Hydrogen trapping in sub-stoichiometric niobium and vanadium carbide precipitates in high-strength steels	\N	paper	High-strength steel is a structural metal crucial for load-bearing components yet is known to be highly susceptible to hydrogen embrittlement (HE). Vanadium (V) and niobium (Nb) containing precipitated carbides introduce strong hydrogen traps to immobilize hydrogen, thus mitigating HE. However, variations in intrinsic vacancy concentrations in these carbides affect hydrogen thermodynamics and kinetics but remain poorly understood. Employing first-principles calculations, hydrogen trapping and diffusion in V/Nb carbides were investigated. Hydrogen dissolution energies are composition-dependent, revealing a transition from reversible to irreversible trapping with increasing carbon vacancy content, prescribed by the strength of covalent bonds with neighboring V/Nb atoms. Meanwhile, the diffusion energy barrier decreases with increasing carbon vacancy content, attributed to changes in vacancy patterns within carbides. The findings contribute new and critical knowledge for understanding hydrogen trapping and diffusion in sub-stoichiometric V/Nb carbides, providing valuable guidance for process and composition innovation of high-strength alloy steels for better HE resistance.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2025	\N	\N	\N	arxiv.2505.14710	\N	\N	http://arxiv.org/abs/2505.14710v2	Xiaohan Bie, Baihua Ren, Xiao Zhou, Salim Brahimi, Stephen Yue, Jun Song. (2025). Hydrogen trapping in sub-stoichiometric niobium and vanadium carbide precipitates in high-strength steels. arXiv preprint. 2505.14710v2.	en	public	published	f	2026-07-30 16:27:00.857029+08	arxiv_import	2026-07-30 16:27:00.857029+08	2026-07-30 16:27:00.857029+08	\N	\N	\N	\N
372	4	LIT-000372	Hydrogenation of single-walled carbon nanotubes	\N	paper	Towards the development of a useful mechanism for hydrogen storage, we have studied the hydrogenation of single-walled carbon nanotubes with atomic hydrogen using core-level photoelectron spectroscopy and x-ray absorption spectroscopy. We find that atomic hydrogen creates C-H bonds with the carbon atoms in the nanotube walls and such C-H bonds can be com-pletely broken by heating to 600 oC. We demonstrate approximately 65+/-15 at % hydrogenation of carbon atoms in the single-walled carbon nanotubes which is equivalent to 5.1+/-1.2 weight % hydrogen capacity. We also show that the hydrogenation is a reversible process.	\N	arXiv cond-mat.mtrl-sci, cond-mat.soft	\N	\N	2005	\N	\N	\N	10.1103/PhysRevLett.95.225507	\N	\N	http://arxiv.org/abs/cond-mat/0510399v1	Anton Nikitin, Hirohito Ogasawara, David Mann, Reinhard Denecke, Zhiyong Zhang, Hongjie Dai, KJ Cho, Anders Nilsson. (2005). Hydrogenation of single-walled carbon nanotubes. arXiv preprint. cond-mat/0510399v1. https://doi.org/10.1103/PhysRevLett.95.225507.	en	public	published	f	2026-07-30 16:27:00.898023+08	arxiv_import	2026-07-30 16:27:00.898023+08	2026-07-30 16:27:00.898023+08	\N	\N	\N	\N
367	4	LIT-000367	Segregation at prior austenite grain boundaries: the competition between boron and hydrogen	\N	paper	The interaction between boron and hydrogen at grain boundaries has been investigated experimentally and numerically in boron-doped and boron-free martensitic steels using thermal desorption spectrometry (TDS) and ab initio calculations. The calculations show that boron and hydrogen are attracted to grain boundaries but boron can repel hydrogen. This behavior has also been observed using TDS measurements, with the disappearance of one peak when boron is incorporated into the microstructure. Additionally, the microstructure of both steels has been studied through electron backscattered diffraction, electron channeling contrast imaging, synchrotron X-ray measurements, and atom probe tomography. While they have a similar grain size, grain boundary distribution, and dislocation densities, a pronounced boron segregation into PAGBs is observed for boron-doped steels. Then, the equilibrium hydrogen concentration in different trapping sites has been evaluated using the Langmuir-McLean approximation. This thermodynamic model shows that the distribution of hydrogen is identical for all traps when the total hydrogen concentration is low for boron-free steel. However, when it increases, traps of the lowest segregation energies (mostly PAGBs) are firstly saturated, which promotes failure initiation at this defect type. This finding partially explains why PAGBs are the weakest microstructure feature when martensitic steels are exposed to hydrogen-containing environments.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2024	\N	\N	\N	10.1016/j.ijhydene.2024.11.166	\N	\N	http://arxiv.org/abs/2407.03763v3	Guillaume Hachet, Ali Tehranchi, Hao Shi, Manoj Prabhakar, Shaolou Wei, Katja Angenendt, Stefan Zaefferer, Baptiste Gault, Binhan Sun, Dirk Ponge, Dierk Raabe. (2024). Segregation at prior austenite grain boundaries: the competition between boron and hydrogen. arXiv preprint. 2407.03763v3. https://doi.org/10.1016/j.ijhydene.2024.11.166.	en	public	published	f	2026-07-30 16:27:00.861448+08	arxiv_import	2026-07-30 16:27:00.861448+08	2026-07-30 16:27:00.861448+08	\N	\N	\N	\N
368	4	LIT-000368	Natural liquid organic hydrogen carrier with low dehydrogenation energy: A first principles study	\N	paper	Liquid organic hydrogen carriers (LOHCs) represent a promising approach for hydrogen storage due to their favorable properties including stability and compatibility with the existing infrastructure. However, fossil-based LOHC molecules are not green or sustainable. Here we examined the possibility of using norbelladine and trisphaeridine, two typical structures of Amaryllidaceae alkaloids, as the LOHCs from the sustainable and renewable sources of natural products. Our first principles thermodynamics calculations reveal low reversibility for the reaction of norbelladine to/from perhydro-norbelladine because of the existence of stabler isomers of perhydro-norbelladine. On the other hand, trisphaeridine is found promising due to its high hydrogen storage capacity ($\\sim$5.9 wt\\%) and favorable energetics. Dehydrogenation of perhydro-trisphaeridine has an average standard enthalpy change of $\\sim$54 KJ/mol-H$_2$, similar to that of perhydro-\\textit{N}-ethylcarbazole, a typical LOHC known for its low dehydrogenation enthalpy. This work is a first exploration of Amaryllidaceae alkaloids for hydrogen storage and the results demonstrate, more generally, the potential of bio-based molecules as a new sustainable resource for future large-scale hydrogen storage.	\N	arXiv physics.chem-ph, cond-mat.mtrl-sci	\N	\N	2023	\N	\N	\N	10.1016/j.ijhydene.2020.08.143	\N	\N	http://arxiv.org/abs/2310.15510v1	Chunguang Tang, Shunxin Fei, G. David Lin, Yun Liu. (2023). Natural liquid organic hydrogen carrier with low dehydrogenation energy: A first principles study. arXiv preprint. 2310.15510v1. https://doi.org/10.1016/j.ijhydene.2020.08.143.	en	public	published	f	2026-07-30 16:27:00.868654+08	arxiv_import	2026-07-30 16:27:00.868654+08	2026-07-30 16:27:00.868654+08	\N	\N	\N	\N
369	4	LIT-000369	Impact of hydrogen incorporation on electronic and magnetic structure of X2CrNi18-9 stainless steel	\N	paper	Hydrogen absorption significantly alters the mechanical properties of steel. However, absorbed hydrogen also influences its electronic and magneto-structural properties, helping to interpret how hydrogen is incorporated. This study therefore investigates the influence of hydrogen incorporation on the electronic and magneto-structural properties of X2CrNi18-9 stainless steel in different microstructural states. Microstructural characterization included analytic electron microscopy mapping, X-ray diffraction and thermodynamic stability maps to evaluate grain size, dislocation density and chemical homogeneity. The electronic properties were characterized using the Seebeck coefficient, while the magneto-structural properties were investigated using diffuse neutron scattering and small-angle neutron scattering (SANS). Hydrogen incorporation showed clear changes in the Seebeck coefficients. Magnetic SANS in conjunction with diffuse neutron scattering indicates the existence of nanoscale inhomogeneities with the same fcc structure as the bulk, but with correlation lengths of a few nanometres. The size of these inhomogeneities increased with hydrogen incorporation, suggesting that hydrogen preferentially accumulates in their vicinity. However, no direct correlation between the electronic and magneto-structural properties and the dislocation density could be demonstrated. We suggest that studies such as these will lead in the medium term to the development of guidelines for material design to make steels more resistant to hydrogen.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2026	\N	\N	\N	arxiv.2601.21672	\N	\N	http://arxiv.org/abs/2601.21672v1	Torben Tappe, Louis Becker, Gaurav Kanu, Thomas F. Headen, Dirk Honecker, Gabi Schierning, Santiago Benito, Sebastian Weber, Klara Lünser, Sabrina Disch. (2026). Impact of hydrogen incorporation on electronic and magnetic structure of X2CrNi18-9 stainless steel. arXiv preprint. 2601.21672v1.	en	public	published	f	2026-07-30 16:27:00.872743+08	arxiv_import	2026-07-30 16:27:00.872743+08	2026-07-30 16:27:00.872743+08	\N	\N	\N	\N
370	4	LIT-000370	Hydrogen-induced hardening of a high-manganese twinning induced plasticity steel	\N	paper	High-manganese twinning-induced plasticity (TWIP) steels exhibit high strain hardening, high tensile strength, and high ductility, which make them attractive for structural applications. At low tensile strain rates, TWIP steels are prone to hydrogen embrittlement (HE). Here though, we study the hardening and strengthening resulting from electrochemical hydrogen-charging of a surface layer of a Fe-26.9Mn-0.28C (wt.%) TWIP steel. We observed a 20% increase in yield strength following the electrochemical hydrogen-charging, accompanied by a reduction in ductility from 75% to 10% at a tensile strain rate of 10-3s-1. The microstructural evolution during tensile deformation was examined at strain levels of 3%, 5% and 7% by electron backscatter diffraction (EBSD) and electron channeling contrast imaging (ECCI) to study the dislocation structure of the hardened region. As expected, the microstructure of the hydrogen-hardened and the uncharged regions of the material evolve differently. The uncharged areas show entangled dislocation structures, indicating slip from a limited number of potentially coplanar slip systems. In contrast, hydrogen segregated to the grain boundaries, revealed by the deuterium-labelled atom probe tomography, delays the dislocation nucleation by blocking dislocation sources at the grain boundaries. The charged areas hence first show the formation of cells, indicating dislocation entanglement from more non-coplanar slip systems. With increasing strain, these cells dissolve, and stacking faults and strain-induced ε-martensite are formed, promoted by the presence of hydrogen. The influence of hydrogen on dislocation structures and the overall deformation mechanism is discussed in details.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2022	\N	\N	\N	arxiv.2205.00697	\N	\N	http://arxiv.org/abs/2205.00697v4	Heena Khanchandani, Dirk Ponge, Stefan Zaefferer, Baptiste Gault. (2022). Hydrogen-induced hardening of a high-manganese twinning induced plasticity steel. arXiv preprint. 2205.00697v4.	en	public	published	t	2026-07-30 16:27:00.879648+08	arxiv_import	2026-07-30 16:27:00.879648+08	2026-07-30 16:27:00.879648+08	\N	\N	\N	\N
373	4	LIT-000373	In situ 2D visualization of hydrogen entry into Zn-coated steels in NaCl solutions: Roles of Zn dissolution and potential distribution	\N	paper	The hydrogen entry behavior of a partially Zn-coated steel sheet in NaCl solutions was investigated employing a polyaniline-based hydrogenochromic sensor, electrochemical hydrogen permeation tests, and potential measurements using a scanning Kelvin probe. While the Zn coating mitigated corrosion of the steel substrate, it simultaneously accelerated the hydrogen entry. The hydrogen entry occurred at the bare steel surface regions exposed to the NaCl solution, with the hydrogen flux exhibiting non-uniform distribution: higher near the dissolving Zn coating. While no significant differences in Zn dissolution behavior or galvanic current were observed between 0.1 and 0.01 M NaCl solutions, the total hydrogen flux decreased with decreasing Cl ion concentration. This reduction was attributed to a potential gradient induced by differences in electrolyte conductivity. The results demonstrate that potential distribution, rather than galvanic current, is a dominant factor influencing hydrogen entry under the investigated conditions.	\N	arXiv physics.chem-ph, cond-mat.mtrl-sci, physics.app-ph	\N	\N	2025	\N	\N	\N	10.1016/j.corsci.2025.113386	\N	\N	http://arxiv.org/abs/2506.18362v2	Hiroshi Kakinuma, Saya Ajito, Koki Okumura, Makoto Akahoshi, Yu Takabatake, Tomohiko Omura, Motomichi Koyama, Eiji Akiyama. (2025). In situ 2D visualization of hydrogen entry into Zn-coated steels in NaCl solutions: Roles of Zn dissolution and potential distribution. arXiv preprint. 2506.18362v2. https://doi.org/10.1016/j.corsci.2025.113386.	en	public	published	f	2026-07-30 16:27:00.90817+08	arxiv_import	2026-07-30 16:27:00.90817+08	2026-07-30 16:27:00.90817+08	\N	\N	\N	\N
374	4	LIT-000374	Atomic scale understanding of the role of hydrogen and oxygen segregation in the embrittlement of grain boundaries in a twinning induced plasticity steel	\N	paper	Twinning induced plasticity (TWIP) steels are high strength metallic materials with potential for structural components in e.g. automotive applications. However, they are prone to hydrogen embrittlement (HE) and galvanic corrosion. We investigated the susceptibility of a model Fe 27Mn 0.3C (wt%) TWIP steel towards HE and oxidation at the sub-nanometer scale by atom probe tomography. We measured segregation of hydrogen and oxygen at grain boundaries, which appears to be associated to a strong manganese depletion. Our study suggests a correlation between HE and oxidation mechanisms in TWIP steels, which we argue can combine to favor the previously reported hydrogen enhanced decohesion (HEDE) of grain boundaries.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2023	\N	\N	\N	arxiv.2302.06317	\N	\N	http://arxiv.org/abs/2302.06317v2	Heena Khanchandani, Baptiste Gault. (2023). Atomic scale understanding of the role of hydrogen and oxygen segregation in the embrittlement of grain boundaries in a twinning induced plasticity steel. arXiv preprint. 2302.06317v2.	en	public	published	f	2026-07-30 16:27:00.916589+08	arxiv_import	2026-07-30 16:27:00.916589+08	2026-07-30 16:27:00.916589+08	\N	\N	\N	\N
375	4	LIT-000375	N-doped graphitic carbon materials hybridized with transition metals (compounds) for hydrogen evolution reaction: Understanding the synergistic effect from atomistic level	\N	paper	The hybrid nanostructures of nitrogen doped carbon materials and nonprecious transition metals are among the most promising electrocatalysts to replace noble metal catalysts for renewable energy applications. However, the fundamental principles governing the catalytic activity of such hybrid materials remain elusive. Herein, we systematically explore the electrocatalytic properties of transition metals, transition metal oxides and carbides substrates covered by nitrogen-doped graphitic sheets for hydrogen evolution reaction (HER). Our first-principles calculations show that the graphitic sheet is prominently activated by the nitrogen doping and the coordinate bond with metal (compound) substrate through intralayer and interlayer charge transfer. Such hybrid materials can provide optimal binding capability for HER catalysis with Tafel barrier down to 1.0 eV. The HER activity can be correlated to the C pz band center, which is in turn governed by the electronic coupling strength between the graphitic sheet and metal substrate, thus paving a way to rational design of graphitic carbon/transition metal hybrid electrocatalysts of high performance.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2018	\N	\N	\N	10.1016/j.carbon.2018.03.043	\N	\N	http://arxiv.org/abs/1805.04231v1	Wei Pei, Si Zhou, Yizhen Bai, Jijun Zhao. (2018). N-doped graphitic carbon materials hybridized with transition metals (compounds) for hydrogen evolution reaction: Understanding the synergistic effect from atomistic level. arXiv preprint. 1805.04231v1. https://doi.org/10.1016/j.carbon.2018.03.043.	en	public	published	f	2026-07-30 16:27:00.919312+08	arxiv_import	2026-07-30 16:27:00.919312+08	2026-07-30 16:27:00.919312+08	\N	\N	\N	\N
376	4	LIT-000376	Laser Stimulated Grain Growth in 304 Stainless Steel Anodes for Reduced Hydrogen Outgassing	\N	paper	Metal anodes in high power source (HPS) devices erode during operation due to hydrogen outgassing and plasma formation, both of which are thermally driven phenomena generated by the electron beam impacting the anode s surface. This limits the lowest achievable pressure in an HPS device, which reduces its efficiency. Laser surface melting the 304 stainless steel anodes by a continuous wave fiber laser showed a reduction in hydrogen outgassing by a factor of ~4 under 50 keV electron bombardment, compared to that from untreated stainless steel. This is attributed to an increase in the grain size (from 40 - 3516 micrometer2), which effectively reduces the number of characterized grain boundaries that serve as hydrogen trapping sites, making such laser treated metals excellent candidates for use in vacuum electronics.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2018	\N	\N	\N	arxiv.1804.00165	\N	\N	http://arxiv.org/abs/1804.00165v1	D. Gortat, M. Sparkes, S. B. Fairchild, P. T. Murray, M. M. Cahay, T. C. Back, G. J. Gruen, N. P. Lockwood, W. O Neill. (2018). Laser Stimulated Grain Growth in 304 Stainless Steel Anodes for Reduced Hydrogen Outgassing. arXiv preprint. 1804.00165v1.	en	public	published	f	2026-07-30 16:27:00.924178+08	arxiv_import	2026-07-30 16:27:00.924178+08	2026-07-30 16:27:00.924178+08	\N	\N	\N	\N
377	4	LIT-000377	Hydrogen-induced fast fracture in a 1.5 GPa dual-phase steel	\N	paper	This study clarifies the hydrogen embrittlement (HE) behavior in a 1.5 GPa ferrite-martensite dual-phase (DP) steel. Hydrogen pre-charging (3.8 mass ppm diffusible hydrogen), followed by slow strain tensile testing (10-4 s-1), resulted in a brittle fracture at 900 MPa within the elastic regime. Fractographic studies indicated that surface crack initiation consists of intergranular and quasi-cleavage morphology; site-specific transmission electron microscopy (TEM) investigations revealed sub-surface secondary crack blunting by ferrite. A mixed-mode morphology consisting of ductile and brittle features was observed adjacent to crack initiation. It differs from the previous investigation of uncharged DP steel, wherein a predominant brittle fracture was observed. Following significant crack growth, the pre-charged specimen exhibited predominant brittle fracture; site-specific TEM and transmission Kikuchi diffraction studies revealed {100} ferrite cleavage cracking. Electron backscatter diffraction studies were performed on the cross-sectional cracks. We explain the HE via hydrogen-induced fast fracture mechanism. During loading, hydrogen diffuses to the prior austenite grain boundary, resulting in hydrogen-induced decohesion. Subsequent hydrogen diffusion to the crack tip promotes brittle fracture at high crack velocity (&gt;Vcrit). The high crack velocity effectively inhibits crack blunting via dislocation emission, ensuring sustained brittle crack growth even after hydrogen depletion at the crack tip, resulting in {100} ferrite cleavage cracking. Based on TEM observations, we explain the formation of river pattern features on the {100} cleavage surface.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2025	\N	\N	\N	arxiv.2509.06323	\N	\N	http://arxiv.org/abs/2509.06323v2	Rama Srinivas Varanasi, Motomichi Koyama, Shuya Chiba, Saya Ajito, Eiji Akiyama. (2025). Hydrogen-induced fast fracture in a 1.5 GPa dual-phase steel. arXiv preprint. 2509.06323v2.	en	public	published	f	2026-07-30 16:27:00.934038+08	arxiv_import	2026-07-30 16:27:00.934038+08	2026-07-30 16:27:00.934038+08	\N	\N	\N	\N
378	4	LIT-000378	Hydrogen storage in carbon derived from solid endosperm of coconut	\N	paper	Carbons are being widely investigated as hydrogen storage material owing to their light weight, fast hydrogen adsorption kinetics and cost effectiveness. However, these materials suffer from low hydrogen storage capacity, particularly at room temperature. The aim of the present study is to develop carbon-based material from natural bio-precursor which shows at least moderate hydrogen storage at room temperature. For this purpose, hydrogenation characteristics of carbon derived from solid endosperm of coconut is studied. Solid endosperm and its carbonized version have a native grown distribution of light elements like K (from KCl), Na, Mg, etc. The hydrogen storage measurements reveal that the as synthesized materials have good hydrogen adsorption and desorption capacity with fast kinetics. The synthesized material adsorbs 2.30 wt. % at room temperature and 8.00 wt.% at liquid nitrogen temperature under 70 atm pressure. The present work is likely to initiate research on native light metal bearing carbon derived from natural precursors.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2014	\N	\N	\N	arxiv.1409.7219	\N	\N	http://arxiv.org/abs/1409.7219v1	Viney Dixit, Ashish Bhatnagar, R. R. Shahi, T. P. Yadav, O. N. Srivastava. (2014). Hydrogen storage in carbon derived from solid endosperm of coconut. arXiv preprint. 1409.7219v1.	en	public	published	t	2026-07-30 16:27:00.939144+08	arxiv_import	2026-07-30 16:27:00.939144+08	2026-07-30 16:27:00.939144+08	\N	\N	\N	\N
379	4	LIT-000379	Microscopic conductivity of passive films on ferritic stainless steel for hydrogen fuel cells	\N	paper	Hydrogen fuel cells offer a clean and sustainable energy conversion solution. The bipolar separator plate, a critical component in fuel cells, plays a vital role in preventing reactant gas cross-contamination and facilitating efficient ion transport in a fuel cell. High chromium ferritic stainless steel with an artificially formed thin chromium oxide passive film has recently gained attention due to its superior electrical conductivity and corrosion resistance, making it a suitable material for separators. In this study, we investigate the microscopic electrical conductivity of the intrinsic passive oxide film on such ferritic stainless steel. Through advanced surface characterization techniques such as current sensing atomic force microscopy and scanning tunneling microscopy/spectroscopy, we discover highly conductive regions within the film that vary depending on location. These findings provide valuable insights into the behavior of the passive oxide film in fuel cells. By understanding the microscopic electrical properties, we can enhance the design and performance of separator materials in hydrogen fuel cells. Ultimately, this research contributes to a broader understanding of separator materials and supports the wider application of hydrogen fuel cells.	\N	arXiv cond-mat.mtrl-sci, physics.app-ph	\N	\N	2023	\N	\N	\N	10.1007/s40042-023-00878-8	\N	\N	http://arxiv.org/abs/2306.14513v1	Taemin Ahn, Tae-Hwan Kim. (2023). Microscopic conductivity of passive films on ferritic stainless steel for hydrogen fuel cells. arXiv preprint. 2306.14513v1. https://doi.org/10.1007/s40042-023-00878-8.	en	public	published	f	2026-07-30 16:27:00.945105+08	arxiv_import	2026-07-30 16:27:00.945105+08	2026-07-30 16:27:00.945105+08	\N	\N	\N	\N
380	4	LIT-000380	Solute hydrogen and deuterium observed at the near atomic scale in high-strength steel	\N	paper	Observing solute hydrogen (H) in matter is a formidable challenge, yet, enabling quantitative imaging of H at the atomic-scale is critical to understand its deleterious influence on the mechanical strength of many metallic alloys that has resulted in many catastrophic failures of engineering parts and structures. Here, we report on the APT analysis of hydrogen (H) and deuterium (D) within the nanostructure of an ultra-high strength steel with high resistance to hydrogen embrittlement. Cold drawn, severely deformed pearlitic steel wires (Fe-0.98C-0.31Mn-0.20Si-0.20Cr-0.01Cu-0.006P-0.007S wt.%, ε=3.1) contains cementite decomposed during the pre-deformation of the alloy and ferrite. We find H and D within the decomposed cementite, and at some interfaces with the surrounding ferrite. To ascertain the origin of the H/D signal obtained in APT, we explored a series of experimental workflows including cryogenic specimen preparation and cryogenic-vacuum transfer from the preparation into a state-of-the-art atom probe. Our study points to the critical role of the preparation, i.e. the possible saturation of H-trapping sites during electrochemical polishing, how these can be alleviated by the use of an outgassing treatment, cryogenic preparation and transfer prior to charging. Accommodation of large amounts of H in the under-stoichiometric carbide likely explains the resistance of pearlite against hydrogen embrittlement.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2020	\N	\N	\N	10.1016/j.actamat.2020.02.004	\N	\N	http://arxiv.org/abs/2008.00684v1	Andrew J. Breen, Leigh T. Stephenson, Binhan Sun, Yujiao Li, Olga Kasian, Dierk Raabe, Michael Herbig, Baptiste Gault. (2020). Solute hydrogen and deuterium observed at the near atomic scale in high-strength steel. arXiv preprint. 2008.00684v1. https://doi.org/10.1016/j.actamat.2020.02.004.	en	public	published	t	2026-07-30 16:27:00.94927+08	arxiv_import	2026-07-30 16:27:00.94927+08	2026-07-30 16:27:00.94927+08	\N	\N	\N	\N
381	4	LIT-000381	Multiscale Materials Modelling through Machine Learning: Hydrogen-Steel Interaction during Deformation	\N	paper	This short paper presents the potential of using machine learning to predict materials behaviour in the context of hydrogen interaction with steel. Effort has been made to understand the quality, and amount of data needed to get improved predictions. An approach known as physics informed machine learning has been adapted in a simplified way through data classification to show the improvement in predictions. Proposed model eliminates the requirement to solve complex materials constitutive models and can work for any length scale, in the present case it is used for single crystalline steel interacting with steel under different types of loading.	\N	arXiv cond-mat.mtrl-sci, cond-mat.mes-hall, cond-mat.stat-mech	\N	\N	2021	\N	\N	\N	arxiv.2110.10564	\N	\N	http://arxiv.org/abs/2110.10564v1	M. Amir Siddiq. (2021). Multiscale Materials Modelling through Machine Learning: Hydrogen-Steel Interaction during Deformation. arXiv preprint. 2110.10564v1.	en	public	published	f	2026-07-30 16:27:00.956108+08	arxiv_import	2026-07-30 16:27:00.956108+08	2026-07-30 16:27:00.956108+08	\N	\N	\N	\N
382	4	LIT-000382	Toxicity of Carbon Nanomaterials	\N	paper	The outstanding multidisciplinary applicability of nanomaterials has paved the path for the rapid advancement of nanoscience during the last few decades. Such technological progress subsequently results in an inevitable environmental exposure of nanomaterials. Presently, nanomaterials are employed in an extensive range of commercial products. Safe and sustainable incorporation of nanomaterials in industrial products requires a profound and comprehensive understanding of their potential toxicity. Among different nanomaterials, carbon nanomaterials marked its notable superiority toward the development of state-of-the-art nanotechnology due to the significant contribution of each of the carbon allotropes with varied dimensionality. The zero-dimensional fullerene, one-dimensional carbon nanotube, and two-dimensional graphene possess an exclusive combination of distinctive properties that are utilized in most of the nanotechnology-based products nowadays. However, potential risk factors are associated with the production and the use of carbon nanomaterials. Consequently, the number of studies regarding the assessment of the toxicity of these nanomaterials has increased rapidly in the past decade. This chapter will summarize the recent scientific efforts on the toxicity evaluation of different carbon nanomaterials.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2021	\N	\N	\N	10.1002/9783527830978.ch6	\N	\N	http://arxiv.org/abs/2109.13918v1	Arpita Adhikari, Joydip Sengupta. (2021). Toxicity of Carbon Nanomaterials. arXiv preprint. 2109.13918v1. https://doi.org/10.1002/9783527830978.ch6.	en	public	published	f	2026-07-30 16:27:00.959766+08	arxiv_import	2026-07-30 16:27:00.959766+08	2026-07-30 16:27:00.959766+08	\N	\N	\N	\N
383	4	LIT-000383	Encapsulating C59N azafullerene derivatives inside single-wall carbon nanotubes	\N	paper	Filling of single-wall carbon nanotubes with C59N azafullerene derivatives is reported from toluene solvent at ambient temperature. The filling is characterized by high resolution transmission electron microscopy and Raman spectroscopy. The filling efficiency is the same as for C60 fullerenes and the tube-azafullerene interaction is similar to the tube-C60 interaction. Vacuum annealing of the encapsulated azafullerene results in the growth of inner tubes, however no spectroscopic signature of nitrogen built in the inner walls is detected.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2006	\N	\N	\N	10.1002/pssb.200669200	\N	\N	http://arxiv.org/abs/cond-mat/0602636v1	F. Simon, H. Kuzmany, J. Bernardi, F. Hauke, A. Hirsch. (2006). Encapsulating C59N azafullerene derivatives inside single-wall carbon nanotubes. arXiv preprint. cond-mat/0602636v1. https://doi.org/10.1002/pssb.200669200.	en	public	published	f	2026-07-30 16:27:00.963418+08	arxiv_import	2026-07-30 16:27:00.963418+08	2026-07-30 16:27:00.963418+08	\N	\N	\N	\N
384	4	LIT-000384	Structural characterization of carbon nanotubes via the vibrational density of states	\N	paper	The electrical and chemical properties of carbon nanotubes vary significantly with different chirality and diameter, making the experimental determination of these structural properties important. Here, we show that the vibrational density of states (VDOS) contains information on the structure of carbon nanotubes, particularly at low frequencies. We show that the diameter and chirality of the nanotubes can be determined from the characteristic low frequency $L$ and $L'$ modes in the VDOS. For zigzag nanotubes, the $L$ peak splits into two peaks giving rise to another low energy $L"$ peak. The significant changes in the frequencies and relative intensities of these peaks open up a route to distinguish among structurally different nanotubes. A close study of different orientations of Stone-Wales defects with varying defect density reveals that different structural defects also leave distinct fingerprints in the VDOS, particularly in the $L$ and $L'$ modes. With our results, more structural information can be obtained from experiments which can directly measure the VDOS, such as inelastic electron and inelastic neutron spectroscopy.	\N	arXiv cond-mat.mtrl-sci, cond-mat.mes-hall	\N	\N	2017	\N	\N	\N	10.1016/j.carbon.2017.03.030	\N	\N	http://arxiv.org/abs/1703.03758v1	Albert J. Pool, Sandeep K. Jain, Gerard T. Barkema. (2017). Structural characterization of carbon nanotubes via the vibrational density of states. arXiv preprint. 1703.03758v1. https://doi.org/10.1016/j.carbon.2017.03.030.	en	public	published	f	2026-07-30 16:27:00.970132+08	arxiv_import	2026-07-30 16:27:00.970132+08	2026-07-30 16:27:00.970132+08	\N	\N	\N	\N
385	4	LIT-000385	Application of carbon nanomaterials in the electronic industry	\N	paper	Nanomaterials have much improved properties compared to their bulk counterparts, which promotes them as ideal material for applications in various industries. Among the various nanomaterials, different nanoallotropes of carbon, namely fullerene, carbon nanotubes, and graphene, are the most important as indicated by the fact that their discoverers gained prestigious awards such as Nobel Prize or Kavli Prize. Carbon forms different nano-allotropes by varying the nature of orbital hybridization. Since all nanoallotropes of carbon possess exotic physical and chemical properties, they are extensively used in different applications, especially in the electronic industry.	\N	arXiv physics.app-ph, cond-mat.mtrl-sci	\N	\N	2020	\N	\N	\N	10.1016/B978-0-12-821381-0.00017-X	\N	\N	http://arxiv.org/abs/2004.11629v1	Joydip Sengupta. (2020). Application of carbon nanomaterials in the electronic industry. arXiv preprint. 2004.11629v1. https://doi.org/10.1016/B978-0-12-821381-0.00017-X.	en	public	published	f	2026-07-30 16:27:00.975113+08	arxiv_import	2026-07-30 16:27:00.975113+08	2026-07-30 16:27:00.975113+08	\N	\N	\N	\N
386	4	LIT-000386	New DRIE-Patterned Electrets for Vibration Energy Harvesting	\N	paper	This paper is about a new manufacturing process aimed at developing stable SiO2/Si3N4 patterned electrets using a Deep Reactive Ion Etching (DRIE) step for an application in electret-based Vibration Energy Harvesters (e-VEH). This process consists in forming continuous layers of SiO2/Si3N4 electrets in order to limit surface conduction phenomena and is a new way to see the problem of electret patterning. Experimental results prove that patterned electrets charged by a positive corona discharge show excellent stability with high surface charge densities that may reach 5mC/m^2 on 1.1μm-thick layers, even with fine patterning and harsh temperature conditions (up to 250°C). This paves the way to new e-VEH designs and manufacturing processes.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2012	\N	\N	\N	10.1051/epjconf/20123302010	\N	\N	http://arxiv.org/abs/1205.2383v1	S. Boisseau, A. -B. Duret, J. -J. Chaillout, G. Despesse. (2012). New DRIE-Patterned Electrets for Vibration Energy Harvesting. arXiv preprint. 1205.2383v1. https://doi.org/10.1051/epjconf/20123302010.	en	public	published	t	2026-07-30 16:27:00.978185+08	arxiv_import	2026-07-30 16:27:00.978185+08	2026-07-30 16:27:00.978185+08	\N	\N	\N	\N
387	4	LIT-000387	Simulation of metal-oxide melt interaction in view of kinetics of chemical reactions in the interphase boundary	\N	paper	Thermodynamics analysis of oxidation-reduction reactions between metal melt and slag (1) provides answers to certain practical issues such as the path of specific chemical reactions, final (equilibrium) phase composition, and the elements that are reduced and oxidized at given physical parameters. Although considerable, this is obviously not enough to analyze real technological systems, because the required equilibrium cannot be normally achieved despite high temperatures of welding and metallurgical processes. Hence, a dynamic problem has to be resolved here, which is calculating phase composition as a function of time. This cannot be achieved without knowing the rates of element concentration changes in each and every phase, and also technological parameters of the process. Relevant studies are detailed in(2-19). This paper analyzes special kinetic features of physical and chemical processes in the metal and oxide melt interface.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2018	\N	\N	\N	arxiv.1810.10166	\N	\N	http://arxiv.org/abs/1810.10166v1	Michael Zinigrad. (2018). Simulation of metal-oxide melt interaction in view of kinetics of chemical reactions in the interphase boundary. arXiv preprint. 1810.10166v1.	en	public	published	t	2026-07-30 16:27:29.729325+08	arxiv_import	2026-07-30 16:27:29.729325+08	2026-07-30 16:27:29.729325+08	\N	\N	\N	\N
388	4	LIT-000388	Calculation of the equilibrium composition of metallic and oxide melts during their interaction	\N	paper	Thermodynamic equilibrium can be sometimes reached at the interaction between metal and oxide melts in high temperature welding and metallurgical processes. Calculation of equilibrium phase composition is also one of the stages (along with kinetics analysis) of building an end-to-end physical and chemical model of real processes. Developing a thermodynamic model of high temperature processes is described in many scientific sources (1-18). Thermodynamic patterns of oxidation-reduction reactions on the metal-slag melt interface are also taken into account when building phenomenological models of real welding, facing, and metallurgical processes (19-30). This paper deals with calculating an equilibrium phase composition for a specific reaction. A method proposed herein also takes into account an interaction among any number of chemical reactions in the metal-oxide melt interface that form an equilibrium phase composition	\N	arXiv cond-mat.mtrl-sci	\N	\N	2018	\N	\N	\N	arxiv.1810.10163	\N	\N	http://arxiv.org/abs/1810.10163v1	Michael Zinigrad. (2018). Calculation of the equilibrium composition of metallic and oxide melts during their interaction. arXiv preprint. 1810.10163v1.	en	public	published	f	2026-07-30 16:27:29.737102+08	arxiv_import	2026-07-30 16:27:29.737102+08	2026-07-30 16:27:29.737102+08	\N	\N	\N	\N
389	4	LIT-000389	Natural-mixing guided design of refractory high-entropy alloys with as-cast tensile ductility	\N	paper	Multi-principal-element metallic alloys have created a growing interest that is unprecedented in metallurgical history, in exploring the property limits of metals and the governing physical mechanisms. Refractory high-entropy alloys (RHEAs) have drawn particular attention due to their (i) high melting points and excellent softening-resistance, which are the two key requirements for high-temperature applications; and (ii) compositional space, which is immense even after considering cost and recyclability restrictions. However, RHEAs also exhibit intrinsic brittleness and oxidation-susceptibility, which remain as significant challenges for their processing and application. Here, utilizing natural-mixing characteristics amongst refractory elements, we designed a Ti38V15Nb23Hf24 RHEA that exhibits &gt;20% tensile ductility already at the as-cast state, and physicochemical stability at high-temperatures. Exploring the underlying deformation mechanisms across multiple length-scales, we observe that a rare beta prime precipitation strengthening mechanism governs its intriguing mechanical response. These results also reveal the effectiveness of natural-mixing tendencies in expediting HEA discovery.	\N	arXiv cond-mat.mtrl-sci, physics.app-ph	\N	\N	2019	\N	\N	\N	10.1038/s41563-020-0750-4	\N	\N	http://arxiv.org/abs/1911.10975v1	Shaolou Wei, Sang Jun Kim, Ji Yun Kang, Yong Zhang, Yongjie Zhang, Tadashi Furuhara, Eun Soo Park, Cemal Cem Tasan. (2019). Natural-mixing guided design of refractory high-entropy alloys with as-cast tensile ductility. arXiv preprint. 1911.10975v1. https://doi.org/10.1038/s41563-020-0750-4.	en	public	published	t	2026-07-30 16:27:29.73961+08	arxiv_import	2026-07-30 16:27:29.73961+08	2026-07-30 16:27:29.73961+08	\N	\N	\N	\N
390	4	LIT-000390	Improved room-temperature-selectivity between Nd and Fe in Nd recovery from Nd-Fe-B magnet	\N	paper	The sustainable society requires the recycling of rare metals. Rare earth Nd is one of rare metals, accompanying huge consumption especially in Nd-Fe-B magnets. Although the wet process using acid is in practical use in the in-plant recycle of sludge, higher selectivity between Nd and Fe at room temperature is desired. We have proposed a pretreatment of corrosion before the dissolution into HCl and the oxalic acid precipitation. The corrosion produces $γ$-FeOOH and a Nd hydroxide, which have high selectivity for HCl solution at room temperature. Nd can be recovered as Mn$_{2}$O$_{3}$-type Nd$_{2}$O$_{3}$. The estimated recovery-ratio of Nd reaches to 97\\%.	\N	arXiv cond-mat.mtrl-sci	\N	\N	2015	\N	\N	\N	arxiv.1511.00325	\N	\N	http://arxiv.org/abs/1511.00325v1	Yusuke Kataoka, Taisuke Ono, Masami Tsubota, Jiro Kitagawa. (2015). Improved room-temperature-selectivity between Nd and Fe in Nd recovery from Nd-Fe-B magnet. arXiv preprint. 1511.00325v1.	en	public	published	f	2026-07-30 16:27:29.747289+08	arxiv_import	2026-07-30 16:27:29.747289+08	2026-07-30 16:27:29.747289+08	\N	\N	\N	\N
511	5	LIT-000511	Corrosion of high entropy alloys	\N	paper	Abstract High entropy alloys represent a unique class of metal alloys, comprising nominally five or more elements in near equiatomic proportions. High entropy alloys have gained significant interest on the basis that the high configurational entropy of such alloy systems is purported to result in a single-phase solid solution structure. While such a single-phase structure can occur in unique systems, it is now appreciated that the definition of high entropy alloys can be broader, with systems comprising only four elements possible of forming single phases, and most five (or more) element systems actually being multi (&gt;2) phases. To this end, the notion of compositionally complex alloys is a more general description, with the concise review herein focusing on the corrosion of compositionally complex alloys (inclusive of high entropy alloys). It is noted that generally, in spite of complex compositions and in many cases complicated microstructural heterogeneity, compositionally complex alloys are nominally corrosion-resistant. This is discussed and aspects of the status and needs are presented.	\N	npj Materials Degradation	\N	\N	2017	1	1	\N	10.1038/s41529-017-0009-y	\N	\N	https://doi.org/10.1038/s41529-017-0009-y	Yao Qiu, S. Thomas, Mark A. Gibson, Hamish L. Fraser, N. Birbilis. (2017). Corrosion of high entropy alloys. npj Materials Degradation. https://doi.org/10.1038/s41529-017-0009-y	en	public	published	t	2026-08-17 11:35:11.611024+08	openalex_oa_curated	2026-08-17 11:35:11.611024+08	2026-08-17 11:35:11.611024+08	\N	\N	\N	\N
512	5	LIT-000512	Applications of CALPHAD modeling and databases in advanced lightweight metallic materials	\N	paper	\N	\N	Calphad	\N	\N	2018	62	\N	1-17	10.1016/j.calphad.2018.04.009	\N	\N	https://doi.org/10.1016/j.calphad.2018.04.009	Renhai Shi, Alan A. Luo. (2018). Applications of CALPHAD modeling and databases in advanced lightweight metallic materials. Calphad. https://doi.org/10.1016/j.calphad.2018.04.009	en	public	published	t	2026-08-17 11:35:11.617522+08	openalex_oa_curated	2026-08-17 11:35:11.617522+08	2026-08-17 11:35:11.617522+08	\N	\N	\N	\N
513	5	LIT-000513	Predicting the formation and stability of single phase high-entropy alloys	\N	paper	\N	\N	Acta Materialia	\N	\N	2015	104	\N	172-179	10.1016/j.actamat.2015.11.040	\N	\N	https://doi.org/10.1016/j.actamat.2015.11.040	D.J.M. King, Simon C. Middleburgh, A.G. McGregor, Michael B. Cortie. (2015). Predicting the formation and stability of single phase high-entropy alloys. Acta Materialia. https://doi.org/10.1016/j.actamat.2015.11.040	en	public	published	t	2026-08-17 11:35:11.621975+08	openalex_oa_curated	2026-08-17 11:35:11.621975+08	2026-08-17 11:35:11.621975+08	\N	\N	\N	\N
514	5	LIT-000514	Ab initio phase stabilities and mechanical properties of multicomponent alloys: A comprehensive review for high entropy alloys and compositionally complex alloys	\N	paper	Multicomponent alloys with multiple principal elements including high entropy alloys (HEAs) and compositionally complex alloys (CCAs) are attracting rapidly growing attention. The endless possibilities to explore new alloys and the hope for better combinations of materials properties have stimulated a remarkable number of research works in the last years. Most of these works have been based on experimental approaches, but ab initio calculations have emerged as a powerful approach that complements experiment and serves as a predictive tool for the identification and characterization of promising alloys. The theoretical ab initio modeling of phase stabilities and mechanical properties of multi-principal element alloys by means of density functional theory (DFT) is reviewed. A general thermodynamic framework is laid down that provides a bridge between the quantities accessible with DFT and the targeted thermodynamic and mechanical properties. It is shown how chemical disorder and various finite-temperature excitations can be modeled with DFT. Different concepts to study crystal and alloy phase stabilities, the impact of lattice distortions (a core effect of HEAs), magnetic transitions, and chemical short-range order are discussed along with specific examples. Strategies to study elastic properties, stacking fault energies, and their dependence on, e.g., temperature or alloy composition are illustrated. Finally, we provide an extensive compilation of multi-principal element alloys and various material properties studied with DFT so far (a set of over 500 alloy-property combinations).	\N	Materials Characterization	\N	\N	2018	147	\N	464-511	10.1016/j.matchar.2018.06.019	\N	\N	https://doi.org/10.1016/j.matchar.2018.06.019	Yuji Ikeda, Blazej Grabowski, Fritz Körmann. (2018). Ab initio phase stabilities and mechanical properties of multicomponent alloys: A comprehensive review for high entropy alloys and compositionally complex alloys. Materials Characterization. https://doi.org/10.1016/j.matchar.2018.06.019	en	public	published	t	2026-08-17 11:35:11.627178+08	openalex_oa_curated	2026-08-17 11:35:11.627178+08	2026-08-17 11:35:11.627178+08	\N	\N	\N	\N
515	5	LIT-000515	Phase stability in nanoscale material systems: extension from bulk phase diagrams	\N	paper	Phase diagrams of multi-component systems are critical for the development and engineering of material alloys for all technological applications. At nano dimensions, surfaces (and interfaces) play a significant role in changing equilibrium thermodynamics and phase stability. In this work, it is shown that these surfaces at small dimensions affect the relative equilibrium thermodynamics of the different phases. The CALPHAD approach for material surfaces (also termed "nano-CALPHAD") is employed to investigate these changes in three binary systems by calculating their phase diagrams at nano dimensions and comparing them with their bulk counterparts. The surface energy contribution, which is the dominant factor in causing these changes, is evaluated using the spherical particle approximation. It is first validated with the Au-Si system for which experimental data on phase stability of spherical nano-sized particles is available, and then extended to calculate phase diagrams of similarly sized particles of Ge-Si and Al-Cu. Additionally, the surface energies of the associated compounds are calculated using DFT, and integrated into the thermodynamic model of the respective binary systems. In this work we found changes in miscibilities, reaction compositions of about 5 at%, and solubility temperatures ranging from 100-200 K for particles of sizes 5 nm, indicating the importance of phase equilibrium analysis at nano dimensions.	\N	Nanoscale	\N	\N	2015	7	21	9868-9877	10.1039/c5nr01535a	\N	\N	https://doi.org/10.1039/c5nr01535a	Saurabh Bajaj, Michael Haverty, Raymundo Arróyave, William A. Goddard III FRSC, Sadasivan Shankar. (2015). Phase stability in nanoscale material systems: extension from bulk phase diagrams. Nanoscale. https://doi.org/10.1039/c5nr01535a	en	public	published	t	2026-08-17 11:35:11.632966+08	openalex_oa_curated	2026-08-17 11:35:11.632966+08	2026-08-17 11:35:11.632966+08	\N	\N	\N	\N
531	5	LIT-000531	Review on the Use of Alternative Carbon Sources in EAF Steelmaking	\N	paper	Steelmaking in the electric arc furnace (EAF), either scrap-based or based on hydrogen direct reduced iron, will in future contribute substantially to the reduction of CO2 emissions in the iron and steel industry. However, there still will be the need to introduce carbon into the EAF process either to carburize the steel or to create foaming slag to improve the energy efficiency of the melting process. So, to reach the emission reduction goals set around the world, it will be necessary to substitute fossil charge and injection carbon used in EAF steelmaking with alternative carbon sources. This review presents the recent research on carbon-neutral biomass-based and circular rubber or plastics-based carbon sources and their potential to substitute fossil charge or injection carbon in the EAF process. It also discusses the current state-of-the art and suggests further opportunities and needs for research and development to use alternative carbon sources to produce a really green and carbon neutral and/or fully circular steel.	\N	Metals	\N	\N	2021	11	2	222-222	10.3390/met11020222	\N	\N	https://doi.org/10.3390/met11020222	Thomas Echterhof. (2021). Review on the Use of Alternative Carbon Sources in EAF Steelmaking. Metals. https://doi.org/10.3390/met11020222	en	public	published	t	2026-08-17 11:35:12.899913+08	openalex_oa_curated	2026-08-17 11:35:12.899913+08	2026-08-17 11:35:12.899913+08	\N	\N	\N	\N
516	5	LIT-000516	Understanding the physical metallurgy of the CoCrFeMnNi high-entropy alloy: an atomistic simulation study	\N	paper	Abstract Although high-entropy alloys (HEAs) are attracting interest, the physical metallurgical mechanisms related to their properties have mostly not been clarified, and this limits wider industrial applications, in addition to the high alloy costs. We clarify the physical metallurgical reasons for the materials phenomena (sluggish diffusion and micro-twining at cryogenic temperatures) and investigate the effect of individual elements on solid solution hardening for the equiatomic CoCrFeMnNi HEA based on atomistic simulations (Monte Carlo, molecular dynamics and molecular statics). A significant number of stable vacant lattice sites with high migration energy barriers exists and is thought to cause the sluggish diffusion. We predict that the hexagonal close-packed (hcp) structure is more stable than the face-centered cubic (fcc) structure at 0 K, which we propose as the fundamental reason for the micro-twinning at cryogenic temperatures. The alloying effect on the critical resolved shear stress (CRSS) is well predicted by the atomistic simulation, used for a design of non-equiatomic fcc HEAs with improved strength, and is experimentally verified. This study demonstrates the applicability of the proposed atomistic approach combined with a thermodynamic calculation technique to a computational design of advanced HEAs.	\N	npj Computational Materials	\N	\N	2018	4	1	\N	10.1038/s41524-017-0060-9	\N	\N	https://doi.org/10.1038/s41524-017-0060-9	Won-Mi Choi, Yong Hee Jo, Seok Su Sohn, Sunghak Lee, Byeong‐Joo Lee. (2018). Understanding the physical metallurgy of the CoCrFeMnNi high-entropy alloy: an atomistic simulation study. npj Computational Materials. https://doi.org/10.1038/s41524-017-0060-9	en	public	published	t	2026-08-17 11:35:11.639652+08	openalex_oa_curated	2026-08-17 11:35:11.639652+08	2026-08-17 11:35:11.639652+08	\N	\N	\N	\N
517	5	LIT-000517	THE CALPHAD METHOD AND ITS ROLE IN MATERIAL AND PROCESS DEVELOPMENT	\N	paper	Successful design of materials and manufacturing processes requires the availability of reliable materials data. Commercial alloys usually contain a large number of elements, and the needed data for the design of new materials and processes are rarely available. The CALPHAD (CALculation of PHAse Diagrams) method enables the development of thermodynamic and property databases, that in conjunction with extrapolation methods of the descriptions of binary and ternary systems to higher-order systems, allow the calculation of data for higher-order systems. The results obtained from CALPHAD calculations have been shown to be invaluable in the design of new materials. This review presents an overview of the CALPHAD method, software tools and databases and gives examples of its application.	\N	Tecnologia em Metalurgia Materiais e Mineração	\N	\N	2016	13	1	3-15	10.4322/2176-1523.1059	\N	\N	https://doi.org/10.4322/2176-1523.1059	Ursula R. Kattner. (2016). THE CALPHAD METHOD AND ITS ROLE IN MATERIAL AND PROCESS DEVELOPMENT. Tecnologia em Metalurgia Materiais e Mineração. https://doi.org/10.4322/2176-1523.1059	en	public	published	t	2026-08-17 11:35:11.645729+08	openalex_oa_curated	2026-08-17 11:35:11.645729+08	2026-08-17 11:35:11.645729+08	\N	\N	\N	\N
518	5	LIT-000518	Machine-learning informed prediction of high-entropy solid solution formation: Beyond the Hume-Rothery rules	\N	paper	Abstract The empirical rules for the prediction of solid solution formation proposed so far in the literature usually have very compromised predictability. Some rules with seemingly good predictability were, however, tested using small data sets. Based on an unprecedented large dataset containing 1252 multicomponent alloys, machine-learning methods showed that the formation of solid solutions can be very accurately predicted (93%). The machine-learning results help identify the most important features, such as molar volume, bulk modulus, and melting temperature. As such a new thermodynamics-based rule was developed to predict solid–solution alloys. The new rule is nonetheless slightly less accurate (73%) but has roots in the physical nature of the problem. The new rule is employed to predict solid solutions existing in the three blocks, each of which consists of 9 elements. The predictions encompass face-centered cubic (FCC), body-centered cubic (BCC), and hexagonal closest packed (HCP) structures in a high throughput manner. The validity of the prediction is further confirmed by CALculations of PHAse Diagram (CALPHAD) calculations with high consistency (94%). Since the new thermodynamics-based rule employs only elemental properties, applicability in screening for solid solution high-entropy alloys is straightforward and efficient.	\N	npj Computational Materials	\N	\N	2020	6	1	\N	10.1038/s41524-020-0308-7	\N	\N	https://doi.org/10.1038/s41524-020-0308-7	Zongrui Pei, Junqi Yin, Jeffrey A. Hawk, David E. Alman, Michael C. Gao. (2020). Machine-learning informed prediction of high-entropy solid solution formation: Beyond the Hume-Rothery rules. npj Computational Materials. https://doi.org/10.1038/s41524-020-0308-7	en	public	published	t	2026-08-17 11:35:11.650074+08	openalex_oa_curated	2026-08-17 11:35:11.650074+08	2026-08-17 11:35:11.650074+08	\N	\N	\N	\N
519	5	LIT-000519	Secondary phases in AlxCoCrFeNi high-entropy alloys: An in-situ TEM heating study and thermodynamic appraisal	\N	paper	\N	\N	Acta Materialia	\N	\N	2017	131	\N	206-220	10.1016/j.actamat.2017.03.066	\N	\N	https://doi.org/10.1016/j.actamat.2017.03.066	Jiancun Rao, H. Diao, V. Ocelı́k, David I. Vainchtein, Chenyu Zhang, C. M. Kuo, Zijian Tang, Wenze Guo, Jonathan D. Poplawsky, Yun Zhou, Peter K. Liaw, J. Th. M. De Hosson. (2017). Secondary phases in AlxCoCrFeNi high-entropy alloys: An in-situ TEM heating study and thermodynamic appraisal. Acta Materialia. https://doi.org/10.1016/j.actamat.2017.03.066	en	public	published	t	2026-08-17 11:35:11.658776+08	openalex_oa_curated	2026-08-17 11:35:11.658776+08	2026-08-17 11:35:11.658776+08	\N	\N	\N	\N
520	5	LIT-000520	Understanding phase stability of Al-Co-Cr-Fe-Ni high entropy alloys	\N	paper	\N	\N	Materials & Design	\N	\N	2016	109	\N	425-433	10.1016/j.matdes.2016.07.073	\N	\N	https://doi.org/10.1016/j.matdes.2016.07.073	Chuan Zhang, Fan Zhang, Haoyan Diao, Michael C. Gao, Zhi Tang, Jonathan D. Poplawsky, Peter K. Liaw. (2016). Understanding phase stability of Al-Co-Cr-Fe-Ni high entropy alloys. Materials & Design. https://doi.org/10.1016/j.matdes.2016.07.073	en	public	published	t	2026-08-17 11:35:11.667941+08	openalex_oa_curated	2026-08-17 11:35:11.667941+08	2026-08-17 11:35:11.667941+08	\N	\N	\N	\N
532	5	LIT-000532	Development of Low Carbon Blast Furnace Operation Technology by using Experimental Blast Furnace	\N	paper	CO2 Ultimate Reduction System for Cool Earth 50 (COURSE50) successfully carried out operational trials with an experimental blast furnace in which the effect of the reaction-control by COG injection, top gas recycling, and use of high reducibility sinter on the carbon rate were determined. The conditions of the operational trials were designed by applying the mathematical blast furnace model that was developed. The results obtained in the operational trials indicate that the proportion of carbon direct reduction can be decreased while maintaining that of CO reduction, by the reaction-control by COG injection, top gas recycling, and use of high reducibility sinter. A reduction in the carbon rate of approximately 10% was achieved as predicted by the mathematical blast furnace model.	\N	ISIJ International	\N	\N	2022	62	12	2424-2432	10.2355/isijinternational.isijint-2022-117	\N	\N	https://doi.org/10.2355/isijinternational.isijint-2022-117	Kaoru Nakano, Hiroshi Sakai, Yutaka Ujisawa, Kazumoto Kakiuchi, Koki Nishioka, Kohei Sunahara, Yoshinori Matsukura, Hirokazu Yokoyama. (2022). Development of Low Carbon Blast Furnace Operation Technology by using Experimental Blast Furnace. ISIJ International. https://doi.org/10.2355/isijinternational.isijint-2022-117	en	public	published	t	2026-08-17 11:35:12.904434+08	openalex_oa_curated	2026-08-17 11:35:12.904434+08	2026-08-17 11:35:12.904434+08	\N	\N	\N	\N
521	5	LIT-000521	Revealing high-fidelity phase selection rules for high entropy alloys: A combined CALPHAD and machine learning study	\N	paper	We reveal high-fidelity new phase selection rules for high entropy alloys (HEAs) by combining CALPHAD calculations and the machine learning (ML) method. Employing Thermo-Calc and TCHEA3 database, we first generate more than 300,000 equilibrium phase data from 20 quinary families formed by the 8 elements of Al Co, Cr, Cu, Fe, Mn, Ni, and Ti, and choose initially 15 materials/physical descriptors. The eXtreme Gradient Boosting (XGBoost) method is then used to identify 5 most important descriptors that best delineate the single and mixed phases in the complex temperature-composition space of HEAs. The ML model trained by the 5 features is validated by 155 annealing experimental data points from 15 publications and then used to predict 213 new single-phase alloys with BCC and FCC structures of the alloy families of AlCrNiFeMn and AlCrCoNiFeTi. We also highlight the importance of equilibrium temperature and offer in-depth insights into the paradigm of composition-feature-phase of HEAs. On the basis of the 5 important features, we establish new phase selection rules for single FCC and BCC phases with a success rate above 90%, significantly outperforming all existing phase selection rules and providing a powerful tool for mapping single-phase in the complex temperature-composition space of HEAs.	\N	Materials & Design	\N	\N	2021	202	\N	109532-109532	10.1016/j.matdes.2021.109532	\N	\N	https://doi.org/10.1016/j.matdes.2021.109532	Yingzhi Zeng, Mengren Man, Kewu Bai, Yongwei Zhang. (2021). Revealing high-fidelity phase selection rules for high entropy alloys: A combined CALPHAD and machine learning study. Materials & Design. https://doi.org/10.1016/j.matdes.2021.109532	en	public	published	t	2026-08-17 11:35:11.673487+08	openalex_oa_curated	2026-08-17 11:35:11.673487+08	2026-08-17 11:35:11.673487+08	\N	\N	\N	\N
522	5	LIT-000522	Entropy-stabilized oxides	\N	paper	Configurational disorder can be compositionally engineered into mixed oxide by populating a single sublattice with many distinct cations. The formulations promote novel and entropy-stabilized forms of crystalline matter where metal cations are incorporated in new ways. Here, through rigorous experiments, a simple thermodynamic model, and a five-component oxide formulation, we demonstrate beyond reasonable doubt that entropy predominates the thermodynamic landscape, and drives a reversible solid-state transformation between a multiphase and single-phase state. In the latter, cation distributions are proven to be random and homogeneous. The findings validate the hypothesis that deliberate configurational disorder provides an orthogonal strategy to imagine and discover new phases of crystalline matter and untapped opportunities for property engineering.	\N	Nature Communications	\N	\N	2015	6	1	8485-8485	10.1038/ncomms9485	\N	\N	https://doi.org/10.1038/ncomms9485	Christina M. Rost, Edward Sachet, Trent Borman, Ali Moballegh, Elizabeth C. Dickey, Dong Hou, Jacob L. Jones, Stefano Curtarolo, Jon‐Paul Maria. (2015). Entropy-stabilized oxides. Nature Communications. https://doi.org/10.1038/ncomms9485	en	public	published	t	2026-08-17 11:35:11.678447+08	openalex_oa_curated	2026-08-17 11:35:11.678447+08	2026-08-17 11:35:11.678447+08	\N	\N	\N	\N
523	5	LIT-000523	Towards high strength cast Mg-RE based alloys: Phase diagrams and strengthening mechanisms	\N	paper	Mg-rare earth (RE) based systems provide several important commercial alloys and many alloy development opportunities for high strength applications, especially in aerospace and defense industries. The phase diagrams, microstructure, and strengthening mechanisms of these multicomponent systems are very complex and often not well understood in literature. We have calculated phase diagrams of important binary, ternary, and multicomponent RE-containing alloy systems, using CALPHAD (CALculation of PHAse Diagrams). Based on these phase diagrams, this paper offers a critical overview on phase equilibria and strengthening mechanisms in these alloy systems, including precipitation, long period stacking order (LPSO), and other intermetallic phases. This review also summarized several promising Mg-RE based cast alloys in comparison with commercial WE54 and WE43 alloys; and explored new strategies for future alloy development for high strength applications. It is pointed out that the combination of precipitation and LPSO phases can lead to superior strength and ductility in Mg-RE based cast alloys. The precipitates and LPSO phases can form a complex three-dimensional network that effectively impedes dislocation motion on the basal and non-basal planes. The LPSO phases can also prevent the coarsening of precipitates when they interact, thus providing good thermal stability at elevated temperatures. Future research is needed to determine how the combination of these two types of phases can be used in alloy design and industrial scale applications.	\N	Journal of Magnesium and Alloys	\N	\N	2022	10	6	1401-1427	10.1016/j.jma.2022.03.008	\N	\N	https://doi.org/10.1016/j.jma.2022.03.008	Janet Meier, Josh Caris, Alan A. Luo. (2022). Towards high strength cast Mg-RE based alloys: Phase diagrams and strengthening mechanisms. Journal of Magnesium and Alloys. https://doi.org/10.1016/j.jma.2022.03.008	en	public	published	t	2026-08-17 11:35:11.686561+08	openalex_oa_curated	2026-08-17 11:35:11.686561+08	2026-08-17 11:35:11.686561+08	\N	\N	\N	\N
524	5	LIT-000524	Homogenization of Al CoCrFeNi high-entropy alloys with improved corrosion resistance	\N	paper	\N	\N	Corrosion Science	\N	\N	2018	133	\N	120-131	10.1016/j.corsci.2018.01.030	\N	\N	https://doi.org/10.1016/j.corsci.2018.01.030	Yunzhu Shi, Liam Collins, Rui Feng, Chuan Zhang, Nina Balke, Peter K. Liaw, Bin Yang. (2018). Homogenization of Al CoCrFeNi high-entropy alloys with improved corrosion resistance. Corrosion Science. https://doi.org/10.1016/j.corsci.2018.01.030	en	public	published	t	2026-08-17 11:35:11.692261+08	openalex_oa_curated	2026-08-17 11:35:11.692261+08	2026-08-17 11:35:11.692261+08	\N	\N	\N	\N
525	5	LIT-000525	Hydrogen Ironmaking: How It Works	\N	paper	A new route for making steel from iron ore based on the use of hydrogen to reduce iron oxides is presented, detailed and analyzed. The main advantage of this steelmaking route is the dramatic reduction (90% off) in CO2 emissions compared to those of the current standard blast-furnace route. The first process of the route is the production of hydrogen by water electrolysis using CO2-lean electricity. The challenge is to achieve massive production of H2 in acceptable economic conditions. The second process is the direct reduction of iron ore in a shaft furnace operated with hydrogen only. The third process is the melting of the carbon-free direct reduced iron in an electric arc furnace to produce steel. From mathematical modeling of the direct reduction furnace, we show that complete metallization can be achieved in a reactor smaller than the current shaft furnaces that use syngas made from natural gas. The reduction processes at the scale of the ore pellets are described and modeled using a specific structural kinetic pellet model. Finally, the differences between the reduction by hydrogen and by carbon monoxide are discussed, from the grain scale to the reactor scale. Regarding the kinetics, reduction with hydrogen is definitely faster. Several research and development and innovation projects have very recently been launched that should confirm the viability and performance of this breakthrough and environmentally friendly ironmaking process.	\N	Metals	\N	\N	2020	10	7	922-922	10.3390/met10070922	\N	\N	https://doi.org/10.3390/met10070922	Fabrice Patisson, Olivier Mirgaux. (2020). Hydrogen Ironmaking: How It Works. Metals. https://doi.org/10.3390/met10070922	en	public	published	t	2026-08-17 11:35:12.865736+08	openalex_oa_curated	2026-08-17 11:35:12.865736+08	2026-08-17 11:35:12.865736+08	\N	\N	\N	\N
526	5	LIT-000526	Insights into the Valorization of Electric Arc Furnace Slags as Supplementary Cementitious Materials	\N	paper	Abstract The transition to hydrogen-based reduction processes within the iron and steelmaking industry will generate new types of slag compositions that require valorization routes. Using slags as supplementary cementitious materials (SCMs) addresses the carbon dioxide emissions of the cement industry since the SCM requires neither calcination nor clinkering. Conventionally, ironmaking slags from the blast furnace (BF) are recycled as SCMs, i.e., ground granulated BF slag (GGBS). Ideally, future slags from electric arc furnaces (EAFs) operating on hydrogen-based direct reduced iron should be valorized analogously. Since the hydrogen-based process route is not yet realized in an industrial scale, the literature lacks data to support this valorization route, and additionally, literature on scrap-based EAF slags is scarce. Therefore, the present study aimed to offer insights into the utilization of ore-based EAF slags as SCMs based on an industrial slag sample from an EAF operating on hot briquetted iron. The slag was remelted, modified, and water-granulated in laboratory scale, and its performance as an SCM was compared to water-granulated ladle slag and two commercial GGBS. The results showed promising reactivities measured using the R 3 isothermal calorimeter-based testing protocol. Based on the comparison to GGBS, the study indicated that generating reactive and appropriate SCMs from EAF slags will partly be a challenge in balancing the crystallization of the MeO-type solid solution rich in magnesia and addressing the iron oxide content in the amorphous phase. Graphical Abstract	\N	Journal of Sustainable Metallurgy	\N	\N	2023	10	1	96-109	10.1007/s40831-023-00778-y	\N	\N	https://doi.org/10.1007/s40831-023-00778-y	Anton Andersson, Jenny Isaksson, Andreas Lennartsson, Fredrik Engström. (2023). Insights into the Valorization of Electric Arc Furnace Slags as Supplementary Cementitious Materials. Journal of Sustainable Metallurgy. https://doi.org/10.1007/s40831-023-00778-y	en	public	published	t	2026-08-17 11:35:12.873604+08	openalex_oa_curated	2026-08-17 11:35:12.873604+08	2026-08-17 11:35:12.873604+08	\N	\N	\N	\N
527	5	LIT-000527	Recycling of ironmaking and steelmaking slags in Japan and China	\N	paper	\N	\N	International Journal of Minerals Metallurgy and Materials	\N	\N	2022	29	4	739-749	10.1007/s12613-021-2400-5	\N	\N	https://doi.org/10.1007/s12613-021-2400-5	Hiroyuki Matsuura, Xiao Yang, Guangqiang Li, Zhangfu Yuan, Fumitaka Tsukihashi. (2022). Recycling of ironmaking and steelmaking slags in Japan and China. International Journal of Minerals Metallurgy and Materials. https://doi.org/10.1007/s12613-021-2400-5	en	public	published	t	2026-08-17 11:35:12.878804+08	openalex_oa_curated	2026-08-17 11:35:12.878804+08	2026-08-17 11:35:12.878804+08	\N	\N	\N	\N
528	5	LIT-000528	CO2 Utilization in the Ironmaking and Steelmaking Process	\N	paper	Study on the resource utilization of CO2 is important for the reduction of CO2 emissions to cope with global warming and bring a beneficial metallurgical effect. In this paper, research on CO2 utilization in the sintering, blast furnace, converter, secondary refining, continuous casting, and smelting processes of stainless steel in recent years in China is carried out. Based on the foreign and domestic research and application status, the feasibility and metallurgical effects of CO2 utilization in the ferrous metallurgy process are analyzed. New techniques are shown, such as (1) flue gas circulating sintering, (2) blowing CO2 through a blast furnace tuyere and using CO2 as a pulverized coal carrier gas, (3) top and bottom blowing of CO2 in the converter, (4) ladle furnace and electric arc furnace bottom blowing of CO2, (5) CO2 as a continuous casting shielding gas, (6) CO2 for stainless steel smelting, and (7) CO2 circulation combustion. The prospects of CO2 application in the ferrous metallurgy process are widespread, and the quantity of CO2 utilization is expected to be more than 100 kg per ton of steel, although the large-scale industrial utilization of CO2 emissions is just beginning. It will facilitate the progress of metallurgical technology effectively and promote the energy conservation of the metallurgical industry strongly.	\N	Metals	\N	\N	2019	9	3	273-273	10.3390/met9030273	\N	\N	https://doi.org/10.3390/met9030273	Kai Dong, Xueliang Wang. (2019). CO2 Utilization in the Ironmaking and Steelmaking Process. Metals. https://doi.org/10.3390/met9030273	en	public	published	t	2026-08-17 11:35:12.88456+08	openalex_oa_curated	2026-08-17 11:35:12.88456+08	2026-08-17 11:35:12.88456+08	\N	\N	\N	\N
529	5	LIT-000529	Metallurgical Coke Production with Biomass Additives: Study of Biocoke Properties for Blast Furnace and Submerged Arc Furnace Purposes	\N	paper	Biocoke has the potential to reduce the fossil-based materials in metallurgical processes, along with mitigating anthropogenic CO2- and greenhouse gas (GHG) emissions. Reducing those emissions is possible by using bio-based carbon, which is CO2-neutral, as a partial replacement of fossil carbon. In this paper, the effect of adding 5, 10, 15, 30, and 45 wt.% biomass pellets on the reactivity, the physicomechanical, and electrical properties of biocoke was established to assess the possibility of using it as a fuel and reducing agent for a blast furnace (BF) or as a carbon source in a submerged arc furnace (SAF). Biocoke was obtained under laboratory conditions at final coking temperatures of 950 or 1100 °C. Research results indicate that for BF purposes, 5 wt.% biomass additives are the maximum as the reactivity increases and the strength after reaction with CO2 decreases. On the other hand, biocoke’s physicomechanical and electrical properties, obtained at a carbonization temperature of 950 °C, can be considered a promising option for the SAF.	\N	Materials	\N	\N	2022	15	3	1147-1147	10.3390/ma15031147	\N	\N	https://doi.org/10.3390/ma15031147	Oleg Bazaluk, Lina Kieush, Andrii Koveria, Johannes Schenk, A. Pfeiffer, Heng Zheng, Vasyl Lozynskyi. (2022). Metallurgical Coke Production with Biomass Additives: Study of Biocoke Properties for Blast Furnace and Submerged Arc Furnace Purposes. Materials. https://doi.org/10.3390/ma15031147	en	public	published	t	2026-08-17 11:35:12.889052+08	openalex_oa_curated	2026-08-17 11:35:12.889052+08	2026-08-17 11:35:12.889052+08	\N	\N	\N	\N
530	5	LIT-000530	Cost effective decarbonisation of blast furnace – basic oxygen furnace steel production through thermochemical sector coupling	\N	paper	We present here a first-principles study of the sector coupling between a thermochemical carbon dioxide (CO2) splitting cycle and existing blast furnace – basic oxygen furnace (BF-BOF) steel making for cost-effective decarbonisation. A double perovskite, Ba2Ca0.66Nb0.34FeO6, is proposed for the thermochemical splitting of CO2, a viable candidate due to its low reaction temperatures, high carbon monoxide (CO) yields, and 100% selectivity towards CO. The CO produced by the TC cycle replaces expensive metallurgical coke for the reduction of iron ore to metallic iron in the blast furnace (BF). The CO2 produced from the BF is used in the TC cycle to produce more CO, therefore creating a closed carbon loop, allowing for the decoupling of steel production from greenhouse gas emissions. Techno-economic analysis of the implementation of this system in UK BF-BOFs could reduce steel sector emissions by 88% while increasing the cost-competitiveness of UK steel on the global market through cost reduction. After five years, this system would save the UK steel industry £1.28 billion while reducing UK-wide emissions by 2.9%. Implementation of this system in the world's BF-BOFs could allow the steel sector to decarbonise in line with the Paris Climate Agreement to limit warming to 1.5 °C.	\N	Journal of Cleaner Production	\N	\N	2023	389	\N	135963-135963	10.1016/j.jclepro.2023.135963	\N	\N	https://doi.org/10.1016/j.jclepro.2023.135963	Harriet Kildahl, Li Wang, Lige Tong, Yulong Ding. (2023). Cost effective decarbonisation of blast furnace – basic oxygen furnace steel production through thermochemical sector coupling. Journal of Cleaner Production. https://doi.org/10.1016/j.jclepro.2023.135963	en	public	published	t	2026-08-17 11:35:12.895204+08	openalex_oa_curated	2026-08-17 11:35:12.895204+08	2026-08-17 11:35:12.895204+08	\N	\N	\N	\N
533	5	LIT-000533	Decarbonization of the Iron and Steel Industry with Direct Reduction of Iron Ore with Green Hydrogen	\N	paper	Production of iron and steel releases seven percent of the global greenhouse gas (GHG) emissions. Incremental changes in present primary steel production technologies would not be sufficient to meet the emission reduction targets. Replacing coke, used in the blast furnaces as a reducing agent, with hydrogen produced from water electrolysis has the potential to reduce emissions from iron and steel production substantially. Mass and energy flow model based on an open-source software (Python) has been developed in this work to explore the feasibility of using hydrogen direct reduction of iron ore (HDRI) coupled with electric arc furnace (EAF) for carbon-free steel production. Modeling results show that HDRI-EAF technology could reduce specific emissions from steel production in the EU by more than 35 % , at present grid emission levels (295 kgCO2/MWh). The energy consumption for 1 ton of liquid steel (tls) production through the HDRI-EAF route was found to be 3.72 MWh, which is slightly more than the 3.48 MWh required for steel production through the blast furnace (BF) basic oxygen furnace route (BOF). Pellet making and steel finishing processes have not been considered. Sensitivity analysis revealed that electrolyzer efficiency is the most important factor affecting the system energy consumption, while the grid emission factor is strongly correlated with the overall system emissions.	\N	Energies	\N	\N	2020	13	3	758-758	10.3390/en13030758	\N	\N	https://doi.org/10.3390/en13030758	Abhinav Bhaskar, Mohsen Assadi, Homam Nikpey Somehsaraei. (2020). Decarbonization of the Iron and Steel Industry with Direct Reduction of Iron Ore with Green Hydrogen. Energies. https://doi.org/10.3390/en13030758	en	public	published	t	2026-08-17 11:35:12.911102+08	openalex_oa_curated	2026-08-17 11:35:12.911102+08	2026-08-17 11:35:12.911102+08	\N	\N	\N	\N
534	5	LIT-000534	New Trends in the Application of Carbon-Bearing Materials in Blast Furnace Iron-Making	\N	paper	The iron and steel industry is still dependent on fossil coking coal. About 70% of the total steel production relies directly on fossil coal and coke inputs. Therefore, steel production contributes by ~7% of the global CO2 emission. The reduction of CO2 emission has been given highest priority by the iron- and steel-making sector due to the commitment of governments to mitigate CO2 emission according to Kyoto protocol. Utilization of auxiliary carbonaceous materials in the blast furnace and other iron-making technologies is one of the most efficient options to reduce the coke consumption and, consequently, the CO2 emission. The present review gives an insight of the trends in the applications of auxiliary carbon-bearing material in iron-making processes. Partial substitution of top charged coke by nut coke, lump charcoal, or carbon composite agglomerates were found to not only decrease the dependency on virgin fossil carbon, but also improve the blast furnace performance and increase the productivity. Partial or complete substitution of pulverized coal by waste plastics or renewable carbon-bearing materials like waste plastics or biomass help in mitigating the CO2 emission due to its high H2 content compared to fossil carbon. Injecting such reactive materials results in improved combustion and reduced coke consumption. Moreover, utilization of integrated steel plant fines and gases becomes necessary to achieve profitability to steel mill operation from both economic and environmental aspects. Recycling of such results in recovering the valuable components and thereby decrease the energy consumption and the need of landfills at the steel plants as well as reduce the consumption of virgin materials and reduce CO2 emission. On the other hand, developed technologies for iron-making rather than blast furnace opens a window and provide a good opportunity to utilize auxiliary carbon-bearing materials that are difficult to utilize in conventional blast furnace iron-making.	\N	Minerals	\N	\N	2018	8	12	561-561	10.3390/min8120561	\N	\N	https://doi.org/10.3390/min8120561	Hesham M. Ahmed. (2018). New Trends in the Application of Carbon-Bearing Materials in Blast Furnace Iron-Making. Minerals. https://doi.org/10.3390/min8120561	en	public	published	t	2026-08-17 11:35:12.916683+08	openalex_oa_curated	2026-08-17 11:35:12.916683+08	2026-08-17 11:35:12.916683+08	\N	\N	\N	\N
535	5	LIT-000535	High oxygen and SNG injection in blast furnace ironmaking with Power to Gas integration and CO2 recycling	\N	paper	In the last years, reduction of CO2 emissions from the steel industry has been of great importance. Carbon capture, oxygen blast furnaces and top gas recycling technologies, among others, have been deeply studied as low carbon solutions. In this paper, a novel integration of carbon capture and power to gas technologies in the steelmaking industry is presented. Green hydrogen via proton exchange membrane (PEM) electrolysis and CO2 via methyldiethanolamine (MDEA) scrubbing from the blast furnace gas (BFG) are used to produce synthetic natural gas in an isothermal fixed bed methanation plant. The latter gas is injected into the blast furnace, closing a carbon loop and reducing coal consumption. The oxygen by-produced in the electrolyser covers the entire oxygen demand of the steelmaking plant and avoids the need for an air separation unit (ASU). The novelty of this work relies on the variation of the oxygen enrichment and its temperature in the hot blast, and how it influences the power to gas integration concept. This power to gas integration is compared with a conventional BF-BOF plant from a technical, economic, energy and environmental point of view. Both plant process configurations were implemented in Aspen Plus simulations, assessing the fossil fuel demand, energy penalty, cost and CO2 emissions. Emission reduction up to 34% can be achieved with power to gas integration, with an energy penalty of 17 MJ/tHM and a cost of 352 €/tCO2.	\N	Journal of Cleaner Production	\N	\N	2023	405	\N	137001-137001	10.1016/j.jclepro.2023.137001	\N	\N	https://doi.org/10.1016/j.jclepro.2023.137001	Jorge Perpiñán, Manuel Bailera, Begoña Peña, Luis M. Romeo, Valérie Eveloy. (2023). High oxygen and SNG injection in blast furnace ironmaking with Power to Gas integration and CO2 recycling. Journal of Cleaner Production. https://doi.org/10.1016/j.jclepro.2023.137001	en	public	published	t	2026-08-17 11:35:12.921746+08	openalex_oa_curated	2026-08-17 11:35:12.921746+08	2026-08-17 11:35:12.921746+08	\N	\N	\N	\N
536	5	LIT-000536	Efficiency of Biomass Use for Blast Furnace Injection	\N	paper	Numerous studies and available experience proved the feasibility and benefits of the biomass usage in various metallurgical applications, particularly, by its injection into the blast furnace (BF). This contribution focuses on three aspects, which could increase the economic efficiency of this technology.	\N	ISIJ International	\N	\N	2019	59	12	2212-2219	10.2355/isijinternational.isijint-2019-337	\N	\N	https://doi.org/10.2355/isijinternational.isijint-2019-337	Alexander Babich, Dieter Senk, Jon Solar, Isabel de Marco. (2019). Efficiency of Biomass Use for Blast Furnace Injection. ISIJ International. https://doi.org/10.2355/isijinternational.isijint-2019-337	en	public	published	t	2026-08-17 11:35:12.928059+08	openalex_oa_curated	2026-08-17 11:35:12.928059+08	2026-08-17 11:35:12.928059+08	\N	\N	\N	\N
537	5	LIT-000537	Evolution of Blast Furnace Process toward Reductant Flexibility and Carbon Dioxide Mitigation in Steel Works	\N	paper	Blast furnace has been regarded as a highly optimized process as a result of various technological improvements over its long history. However, from the viewpoints of resources, energy and global warming, continuing evolution toward reductant flexibility and CO2 mitigation is desired. This review focuses on the progressive design of an ambitious blast furnace for the future.	\N	ISIJ International	\N	\N	2016	56	10	1681-1696	10.2355/isijinternational.isijint-2016-210	\N	\N	https://doi.org/10.2355/isijinternational.isijint-2016-210	Tatsuro Ariyama, Michitaka Sato, Taihei Nouchi, Koichi Takahashi. (2016). Evolution of Blast Furnace Process toward Reductant Flexibility and Carbon Dioxide Mitigation in Steel Works. ISIJ International. https://doi.org/10.2355/isijinternational.isijint-2016-210	en	public	published	t	2026-08-17 11:35:12.932898+08	openalex_oa_curated	2026-08-17 11:35:12.932898+08	2026-08-17 11:35:12.932898+08	\N	\N	\N	\N
538	5	LIT-000538	Woody biomass waste derivatives in decarbonised blast furnace ironmaking process	\N	paper	\N	\N	Renewable and Sustainable Energy Reviews	\N	\N	2024	199	\N	114465-114465	10.1016/j.rser.2024.114465	\N	\N	https://doi.org/10.1016/j.rser.2024.114465	R.Q. Wang, L. Jiang, Yaodong Wang, Carolina Font-Palma, Vasiliki Skoulou, Anthony Paul Roskilly. (2024). Woody biomass waste derivatives in decarbonised blast furnace ironmaking process. Renewable and Sustainable Energy Reviews. https://doi.org/10.1016/j.rser.2024.114465	en	public	published	t	2026-08-17 11:35:12.938667+08	openalex_oa_curated	2026-08-17 11:35:12.938667+08	2026-08-17 11:35:12.938667+08	\N	\N	\N	\N
539	5	LIT-000539	A review of ironmaking by direct reduction processes: Quality requirements and sustainability	\N	paper	Currently the majority of the world’s steel is produced through either one of the two main routes; the integrated Blast Furnace – Basic Oxygen Furnace (BF – BOF) route or the Direct Reduced Iron - Electric Arc Furnace (DRI - EAF) route. In the former, the blast furnace uses iron ore, scrap metal, coke and pulverized coal as raw materials to produce hot metal for conversion in the BOF. Although it is still the prevalent process, blast furnace hot metal production has declined over the years due to diminishing quality of metallurgical coke, low supply of scrap metal and environmental problems associated with the process. These factors have contributed to the development of alternative technologies of ironmaking, of which Direct Reduction (DR) processes are expected to emerge as preferred alternatives in the future. This study reviews the different DR processes used to produce Direct Reduced Iron, providing an analysis on the quality requirements of iron-bearing ores for use in these processes. The study also discusses the environmental sustainability of such processes. DR processes reduce iron ore in its solid state by the use of either natural gas or coal as reducing agents, and they have a comparative advantage of low capital costs, low emissions and production flexibility over the BF process.	\N	Procedia Manufacturing	\N	\N	2019	35	\N	242-245	10.1016/j.promfg.2019.05.034	\N	\N	https://doi.org/10.1016/j.promfg.2019.05.034	Comfort Ramakgala, Gwiranai Danha. (2019). A review of ironmaking by direct reduction processes: Quality requirements and sustainability. Procedia Manufacturing. https://doi.org/10.1016/j.promfg.2019.05.034	en	public	published	t	2026-08-17 11:35:12.948038+08	openalex_oa_curated	2026-08-17 11:35:12.948038+08	2026-08-17 11:35:12.948038+08	\N	\N	\N	\N
540	5	LIT-000540	Progress Toward Biocarbon Utilization in Electric Arc Furnace Steelmaking: Current Status and Future Prospects	\N	paper	Abstract Steel is an essential material in modern infrastructure and industry, but its production is associated with significant carbon dioxide emissions. Biocarbon utilization in electric arc furnace (EAF) steelmaking represents a promising pathway toward reducing the carbon footprint of steel production. This review draws new perspectives on the current state of biocarbon utilization in EAF steelmaking by collectively examining the literature from multiple scales of testing, from laboratory experiments to industrial trials. The scientific insights from each scale are defined and the results are collectively pooled to give a comprehensive understanding of biocarbon’s performance for EAF applications. Several recent progressions are identified along with critical limitations, such as biocarbon’s high reactivity or low density. However, solution pathways like agglomeration are established from the thorough understanding developed by this study. These insights aim to enhance the progression of biocarbon utilization in the EAF process, ultimately facilitating the development of more efficient and sustainable steelmaking. The proposed areas for future research, such as optimizing key biocarbon properties or improved injection systems, are expected to have significant impact on the next phase of biocarbon adoption. Graphical Abstract	\N	Journal of Sustainable Metallurgy	\N	\N	2024	10	4	2047-2067	10.1007/s40831-024-00940-0	\N	\N	https://doi.org/10.1007/s40831-024-00940-0	Christopher DiGiovanni, Thomas Echterhof. (2024). Progress Toward Biocarbon Utilization in Electric Arc Furnace Steelmaking: Current Status and Future Prospects. Journal of Sustainable Metallurgy. https://doi.org/10.1007/s40831-024-00940-0	en	public	published	t	2026-08-17 11:35:12.954251+08	openalex_oa_curated	2026-08-17 11:35:12.954251+08	2026-08-17 11:35:12.954251+08	\N	\N	\N	\N
541	5	LIT-000541	Recycling Perspectives of Electric Arc Furnace Slag in the United States: A Review	\N	paper	This article presents a comprehensive review of electric arc furnace (EAF) slag recycling in the United States, examining its classification and the associated challenges and opportunities of its industrial use. The study affirms EAF slag's nonhazardous status. The main challenges identified in EAF slag applications include substantial variations in composition and volume instability during/after hydration. Analysis of the U.S. recycling practices reveals that EAF slag is predominantly reused, with minimal landfill disposal. However, its prevalent use as a low value‐added aggregate in construction applications underscores the industry's ongoing challenge to get additional value from EAF slag recycling. Despite these challenges, the study highlights a great potential for increased value extraction from EAF slag recycling. Beyond conventional applications as a clinker material for the cement industry, the review explores modern technologies for steelmaking slag recycling, revealing options for recovering valuable metals such as Cr, V, Mo, and Fe through methods such as leaching, reduction, and oxidation.	\N	steel research international	\N	\N	2024	96	8	\N	10.1002/srin.202300854	\N	\N	https://doi.org/10.1002/srin.202300854	Matthew Kurecki, N. Meena, Tetiana Shyrokykh, Yuri Korobeinikov, Tova Jarnerud, Z. Voß, Eugene B. Pretorius, Jeremy Jones, Seetharaman Sridhar. (2024). Recycling Perspectives of Electric Arc Furnace Slag in the United States: A Review. steel research international. https://doi.org/10.1002/srin.202300854	en	public	published	t	2026-08-17 11:35:12.959307+08	openalex_oa_curated	2026-08-17 11:35:12.959307+08	2026-08-17 11:35:12.959307+08	\N	\N	\N	\N
542	5	LIT-000542	Energy system requirements of fossil-free steelmaking using hydrogen direct reduction	\N	paper	The iron and steel industry is one of the world's largest industrial emitters of greenhouse gases. One promising option for decarbonising the industry is hydrogen direct reduction of iron (H-DR) with electric arc furnace (EAF) steelmaking, powered by zero carbon electricity. However, to date, little attention has been given to the energy system requirements of adopting such a highly energy-intensive process. This study integrates a newly developed long-term energy system planning tool, with a thermodynamic process model of H-DR/EAF steelmaking developed by Vogl et al. (2018), to assess the optimal combination of generation and storage technologies needed to provide a reliable supply of electricity and hydrogen. The modelling tools can be applied to any country or region and their use is demonstrated here by application to the UK iron and steel industry as a case study. It is found that the optimal energy system comprises 1.3 GW of electrolysers, 3 GW of wind power, 2.5 GW of solar, 60 MW of combined cycle gas with carbon capture, 600 GWh/600 MW of hydrogen storage, and 30 GWh/130 MW of compressed air energy storage. The hydrogen storage requirements of the industry can be significantly reduced by maintaining some dispatchable generation, for example from 600 GWh with no restriction on dispatchable generation to 140 GWh if 20% of electricity demand is met using dispatchable generation. The marginal abatement costs of a switch to hydrogen-based steelmaking are projected to be less than carbon price forecasts within 5–10 years.	\N	Journal of Cleaner Production	\N	\N	2021	312	\N	127665-127665	10.1016/j.jclepro.2021.127665	\N	\N	https://doi.org/10.1016/j.jclepro.2021.127665	Andrew Pimm, Tim Cockerill, William F. Gale. (2021). Energy system requirements of fossil-free steelmaking using hydrogen direct reduction. Journal of Cleaner Production. https://doi.org/10.1016/j.jclepro.2021.127665	en	public	published	t	2026-08-17 11:35:12.966864+08	openalex_oa_curated	2026-08-17 11:35:12.966864+08	2026-08-17 11:35:12.966864+08	\N	\N	\N	\N
543	5	LIT-000543	The Behavior of Direct Reduced Iron in the Electric Arc Furnace Hotspot	\N	paper	Hydrogen-based direct reduction is a promising technology for CO2 lean steelmaking. The electric arc furnace is the most relevant aggregate for processing direct reduced iron (DRI). As DRI is usually added into the arc, the behavior in this area is of great interest. A laboratory-scale hydrogen plasma smelting reduction (HPSR) reactor was used to analyze that under inert conditions. Four cases were compared: carbon-free and carbon-containing DRI from DR-grade pellets as well as fines from a fluidized bed reactor were melted batch-wise. A slag layer’s influence was investigated using DRI from the BF-grade pellets and the continuous addition of slag-forming oxides. While carbon-free materials show a porous structure with gangue entrapments, the carburized DRI forms a dense regulus with the oxides collected on top. The test with slag-forming oxides demonstrates the mixing effect of the arc’s electromagnetic forces. The cross-section shows a steel melt framed by a slag layer. These experiments match the past work in that carburized DRI is preferable, and material feed to the hotspot is critical for the EAF operation.	\N	Metals	\N	\N	2023	13	5	978-978	10.3390/met13050978	\N	\N	https://doi.org/10.3390/met13050978	A. Pfeiffer, Daniel Ernst, Heng Zheng, Gerald Wimmer, Johannes Schenk. (2023). The Behavior of Direct Reduced Iron in the Electric Arc Furnace Hotspot. Metals. https://doi.org/10.3390/met13050978	en	public	published	t	2026-08-17 11:35:12.973686+08	openalex_oa_curated	2026-08-17 11:35:12.973686+08	2026-08-17 11:35:12.973686+08	\N	\N	\N	\N
544	5	LIT-000544	Leaching of Metals from Spent Lithium-Ion Batteries	\N	paper	The recycling of valuable metals from spent lithium-ion batteries (LIBs) is becoming increasingly important due to the depletion of natural resources and potential pollution from the spent batteries. In this work, different types of acids (2 M citric (C6H8O7), 1 M oxalic (C2H2O4), 2 M sulfuric (H2SO4), 4 M hydrochloric (HCl), and 1 M nitric (HNO3) acid)) and reducing agents (hydrogen peroxide (H2O2), glucose (C6H12O6) and ascorbic acid (C6H8O6)) were selected for investigating the recovery of valuable metals from waste LIBs. The crushed and sieved material contained on average 23% (w/w) cobalt, 3% (w/w) lithium, and 1–5% (w/w) nickel, copper, manganese, aluminum, and iron. Results indicated that mineral acids (4 M HCl and 2 M H2SO4 with 1% (v/v) H2O2) produced generally higher yields compared with organic acids, with a nearly complete dissolution of lithium, cobalt, and nickel at 25 °C with a slurry density of 5% (w/v). Further leaching experiments carried out with H2SO4 media and different reducing agents with a slurry density of 10% (w/v) show that nearly all of the cobalt and lithium can be leached out in sulfuric acid (2 M) when using C6H8O6 as a reducing agent (10% g/gscraps) at 80 °C.	\N	Recycling	\N	\N	2017	2	4	20-20	10.3390/recycling2040020	\N	\N	https://doi.org/10.3390/recycling2040020	Miamari Aaltonen, Chao Peng, Benjamin P. Wilson, Mari Lundström. (2017). Leaching of Metals from Spent Lithium-Ion Batteries. Recycling. https://doi.org/10.3390/recycling2040020	en	public	published	t	2026-08-17 11:35:14.249322+08	openalex_oa_curated	2026-08-17 11:35:14.249322+08	2026-08-17 11:35:14.249322+08	\N	\N	\N	\N
545	5	LIT-000545	Hydrometallurgical recycling of EV lithium-ion batteries: Effects of incineration on the leaching efficiency of metals using sulfuric acid	\N	paper	The growing demand for lithium-ion batteries will result in an increasing flow of spent batteries, which must be recycled to prevent environmental and health problems, while helping to mitigate the raw materials dependence and risks of shortage and promoting a circular economy. Combining pyrometallurgical and hydrometallurgical recycling approaches has been the focus of recent studies, since it can bring many advantages. In this work, the effects of incineration on the leaching efficiency of metals from EV LIBs were evaluated. The thermal process was applied as a pre-treatment for the electrode material, aiming for carbothermic reduction of the valuable metals by the graphite contained in the waste. Leaching efficiencies above 70% were obtained for Li, Mn, Ni and Co after 60 min of leaching even when using 0.5 M sulfuric acid, which can be linked to the formation of more easily leachable compounds during the incineration process. When the incineration temperature was increased (600-700 °C), the intensity of graphite signals decreased and other oxides were identified, possibly due to the increase in oxidative conditions. Higher leaching efficiencies of Mn, Ni, Co, and Li were reached at lower temperatures of incineration (400-500 °C) and at higher leaching times, which could be related to the partial carbothermic reduction of the metals.	\N	Waste Management	\N	\N	2021	125	\N	192-203	10.1016/j.wasman.2021.02.039	\N	\N	https://doi.org/10.1016/j.wasman.2021.02.039	Nathália Vieceli, R. Casasola, Gabriele Lombardo, Burçak Ebin, Martina Petraniková. (2021). Hydrometallurgical recycling of EV lithium-ion batteries: Effects of incineration on the leaching efficiency of metals using sulfuric acid. Waste Management. https://doi.org/10.1016/j.wasman.2021.02.039	en	public	published	t	2026-08-17 11:35:14.256458+08	openalex_oa_curated	2026-08-17 11:35:14.256458+08	2026-08-17 11:35:14.256458+08	\N	\N	\N	\N
546	5	LIT-000546	Solvometallurgy: An Emerging Branch of Extractive Metallurgy	\N	paper	This position paper introduces the reader to the concept of solvometallurgy, the term used to describe the extraction of metals from ores, industrial process residues, production scrap, and urban waste using non-aqueous solutions. Here, non-aqueous is not used to imply anhydrous, but rather a low water content. The unit operations are as follows: solvent leaching; separation of the residue; purification of the leach solution by non-aqueous solvent extraction or non-aqueous ion exchange; and metal recovery by precipitation or electrolysis in non-aqueous electrolytes. Solvometallurgy is similar to hydrometallurgy in that both the branches of extractive metallurgy use low-temperature processes, but with solvometallurgy, there is no discrete water phase. Both branches use organic or inorganic solvents (excluding water in the case of solvometallurgy). However, for solvometallurgical processes to be sustainable, they must be based on green solvents, which means that all toxic or environmentally harmful solvents must be avoided. Solvometallurgy is complementary to pyrometallurgy and hydrometallurgy, but this new approach offers several advantages. First, the consumption of water is very limited, and so the generation of wastewater can be avoided. Second, the leaching and solvent extraction can be combined to form a single step, resulting in more simplified process flow sheets. Third, solvent leaching is often more selective than leaching with acidic aqueous solutions, leading to reduced acid consumption and fewer purification steps. Fourth, solvometallurgy is useful for the treatment of ores rich in soluble silica (e.g., eudialyte) because no silica gel is formed. In short, solvometallurgy is in a position to help develop the near-zero-waste metallurgical processes, and with levels of energy consumption that are much lower than those with the high-temperature processes. The Technology Readiness Level (TRL) of this emerging branch of extractive metallurgy is still low (TRL = 3–4), which is a disadvantage for short-term implementation, but offers a great opportunity for further research, development, and innovation.	\N	Journal of Sustainable Metallurgy	\N	\N	2017	3	3	570-600	10.1007/s40831-017-0128-2	\N	\N	https://doi.org/10.1007/s40831-017-0128-2	Koen Binnemans, Peter Tom Jones. (2017). Solvometallurgy: An Emerging Branch of Extractive Metallurgy. Journal of Sustainable Metallurgy. https://doi.org/10.1007/s40831-017-0128-2	en	public	published	t	2026-08-17 11:35:14.264401+08	openalex_oa_curated	2026-08-17 11:35:14.264401+08	2026-08-17 11:35:14.264401+08	\N	\N	\N	\N
550	5	LIT-000550	A comprehensive review of processing strategies for iron precipitation residues from zinc hydrometallurgy	\N	paper	Comprehensive amounts of valuable elements are lost due to the disposal of waste materials which are generated during the hydrometallurgical production of zinc. Those wastes, mainly jarosite or goethite, are predominantly immobilized and disposed on open landfills whereby the contained elements are not extracted. Several strategies were investigated to face increasing needs regarding ecological and economical improvements of the current situation. This review compares processes for immobilization and hydro-, as well as pyrometallurgical treatments of iron precipitation residues. The Jarofix process to immobilize jarosite waste is widely used to generate a product with good elution properties for subsequent safe disposal. It is the only accepted and used method for the dedicated treatment of jarosite, resulting in significant losses of valuable metals and land use in the course of the disposal procedure. A few pyrometallurgical processes are in operation which use top submerged lance reactors or waelz kilns for the co-treatment of jarosite waste on industrial scale. However, a broad variety of hydrometallurgical and pyrometallurgical strategies for the utilization of iron precipitation residues was pursued solely on a laboratory scale. Due to intensifying ecological restrictions and the geographic concentration of critical elements like indium, silver, gallium and germanium, the recycling of jarosite and goethite is constantly being more focused. This literature review gives a comprising overview on strategies which were developed for the processing of those waste materials.	\N	Cleaner Engineering and Technology	\N	\N	2021	4	\N	100214-100214	10.1016/j.clet.2021.100214	\N	\N	https://doi.org/10.1016/j.clet.2021.100214	Lukas Hoeber, Stefan Steinlechner. (2021). A comprehensive review of processing strategies for iron precipitation residues from zinc hydrometallurgy. Cleaner Engineering and Technology. https://doi.org/10.1016/j.clet.2021.100214	en	public	published	t	2026-08-17 11:35:14.284032+08	openalex_oa_curated	2026-08-17 11:35:14.284032+08	2026-08-17 11:35:14.284032+08	\N	\N	\N	\N
551	5	LIT-000551	Recent advances on hydrometallurgical recovery of critical and precious elements from end of life electronic wastes - a review	\N	paper	Waste electrical and electronic equipment (WEEE) contains economically significant levels of precious, critical metals and rare earth elements, apart from base metals and other toxic compounds. Recycling and recovery of critical elements from WEEEs using a cost-effective technology are now one of the top priorities in metallurgy due to the rapid depletion of their natural resources. More than 150 publications on WEEE management, leaching and recovery of metals from WEEE were reviewed in this work, with special emphasize on the recent research (2015)(2016)(2017)(2018). This paper summarizes the recent progress regarding various hydrometallurgical processes for the leaching of critical elements from WEEEs. Various methodologies and techniques for critical elements selective recovery (using ionic liquids, solvent extraction, electrowinning, adsorption, and precipitation) from the WEEEs leachates are discussed. Future prospects regarding the use of WEEEs as secondary resources for critical raw materials and its technoeconomical and commercial beneficiaries are discussed.	\N	Critical Reviews in Environmental Science and Technology	\N	\N	2019	49	3	212-275	10.1080/10643389.2018.1540760	\N	\N	https://doi.org/10.1080/10643389.2018.1540760	Manivannan Sethurajan, Eric D. van Hullebusch, Danilo Fontana, Ata Akçıl, Hacı Deveci, Bojan Batinić, João Paulo Leal, T. Almeida Gasche, Mehmet Ali Küçüker, Kerstin Kuchta, Isabel F.F. Neto, Helena M. V. M. Soares, Andrzej Chmielarz. (2019). Recent advances on hydrometallurgical recovery of critical and precious elements from end of life electronic wastes - a review. Critical Reviews in Environmental Science and Technology. https://doi.org/10.1080/10643389.2018.1540760	en	public	published	t	2026-08-17 11:35:14.288379+08	openalex_oa_curated	2026-08-17 11:35:14.288379+08	2026-08-17 11:35:14.288379+08	\N	\N	\N	\N
552	5	LIT-000552	Current Status and Future Perspective of Recycling Copper by Hydrometallurgy from Waste Printed Circuit Boards	\N	paper	The current replacement of electronic products is speeding up, resulting in a growing number of e-waste. Electronic waste, especially waste print circuit boards contain large amounts of copper, which not only bring greater ecological threat, but also cause a serious waste of copper resources. Therefore, the study on clean, effective copper leaching technology has a very important practical significance to reduce environmental hazards of waste print circuit board and resources recycling. Hydrometallurgical is a better technology for recycling copper from waste print circuit boards. In this article, hydrometallurgical copper recovery system is divided into four categories: acid leaching, ammonia - ammonium leaching, chloride leaching, as well as other ways of leaching. The advantages and disadvantages of leaching of copper system are analyzed in the process of copper resource utilization. Studies abound on recycling copper from copper-containing waste with citric acid and other complexing agents as the leaching reagent, but studies on recycling copper from waste print circuit boards are rarely reported, which can be used for reference. The trends of the research are using environmentally friendly reagent as leaching agent, selecting the appropriate leaching solution at a certain temperature and pressure and optimizing the subsequent separation procedure. Recycling of waste gas and waste leachate generated in the hydrometallurgical processcan further reduce chemical costs and meet increasingly exacting environmental requirements.	\N	Procedia Environmental Sciences	\N	\N	2016	31	\N	162-170	10.1016/j.proenv.2016.02.022	\N	\N	https://doi.org/10.1016/j.proenv.2016.02.022	Yan Xu, Jinhui Li, Lili Liu. (2016). Current Status and Future Perspective of Recycling Copper by Hydrometallurgy from Waste Printed Circuit Boards. Procedia Environmental Sciences. https://doi.org/10.1016/j.proenv.2016.02.022	en	public	published	t	2026-08-17 11:35:14.296554+08	openalex_oa_curated	2026-08-17 11:35:14.296554+08	2026-08-17 11:35:14.296554+08	\N	\N	\N	\N
553	5	LIT-000553	Research Progress on Heavy Metals Pollution in the Soil of Smelting Sites in China	\N	paper	Contamination by heavy metals is a significant issue worldwide. In recent decades, soil heavy metals pollutants in China had adverse impacts on soil quality and threatened food security and human health. Anthropogenic inputs mainly generate heavy metal contamination in China. In this review, the approaches were used in these investigations, focusing on geochemical strategies and metal isotope methods, particularly useful for determining the pathway of mining and smelting derived pollution in the soil. Our findings indicate that heavy metal distribution substantially impacts topsoils around mining and smelting sites, which release massive amounts of heavy metals into the environment. Furthermore, heavy metal contamination and related hazards posed by Pb, Cd, As, and Hg are more severe to plants, soil organisms, and humans. It's worth observing that kids are particularly vulnerable to Pb toxicity. And this review also provides novel approaches to control and reduce the impacts of heavy metal pollution. Hydrometallurgy offers a potential method for extracting metals and removing potentially harmful heavy metals from waste to reduce pollution. However, environmentally friendly remediation of contaminated sites is a significant challenge. This paper also evaluates current technological advancements in the remediation of polluted soil, such as stabilization/solidification, natural attenuation, electrokinetic remediation, soil washing, and phytoremediation. The ability of biological approaches, especially phytoremediation, is cost-effective and favorable to the environment.	\N	Toxics	\N	\N	2022	10	5	231-231	10.3390/toxics10050231	\N	\N	https://doi.org/10.3390/toxics10050231	Muhammad Adnan, Baohua Xiao, Peiwen Xiao, Peng Zhao, Ruolan Li, Shaheen Bibi. (2022). Research Progress on Heavy Metals Pollution in the Soil of Smelting Sites in China. Toxics. https://doi.org/10.3390/toxics10050231	en	public	published	t	2026-08-17 11:35:14.300947+08	openalex_oa_curated	2026-08-17 11:35:14.300947+08	2026-08-17 11:35:14.300947+08	\N	\N	\N	\N
557	5	LIT-000557	Life cycle assessment of cobalt extraction process	\N	paper	This paper presents the results of an investigation carried out on the impacts of cobalt extraction process using a life cycle assessment by considering a cradle-to-gate system. Life cycle inventory data was collected from the EcoInvent and Australian Life cycle assessment database (AusLCI) and analysis were performed using SimaPro software employing the International Reference Life Cycle Data System (ILCD) method, and Cumulative Energy Demand method (CED) for per kg of cobalt production. Several impact categories are considered in the analysis i.e. global warming, ozone depletion, eutrophication, land use, water use, fossil fuels, minerals, human toxicity, ecotoxicity, and cumulative energy demand. The analysis results indicate that among the impact categories, eutrophication and global warming impacts are noteworthy. Medium voltage electricity used in cobalt production and the blasting operation appears to be causing most of the impact and emission into the environment. The sensitivity analysis was carried out using three different case scenarios by altering the electricity generation sources of UCTE (Synchronous Grid of Continental Europe) to investigate the proportional variation of impact analysis results. Furthermore, the impacts caused by cobalt production are compared with nickel and copper production processes to reveal their relative impacts on the environment and ecosystems.	\N	Journal of Sustainable Mining	\N	\N	2019	18	3	150-161	10.1016/j.jsm.2019.03.002	\N	\N	https://doi.org/10.1016/j.jsm.2019.03.002	Shahjadi Hisan Farjana, Nazmul Huda, M. A. Parvez Mahmud. (2019). Life cycle assessment of cobalt extraction process. Journal of Sustainable Mining. https://doi.org/10.1016/j.jsm.2019.03.002	en	public	published	t	2026-08-17 11:35:14.325598+08	openalex_oa_curated	2026-08-17 11:35:14.325598+08	2026-08-17 11:35:14.325598+08	\N	\N	\N	\N
558	5	LIT-000558	Selective Metal Recovery from Jarosite Residue by Leaching with Acid-Equilibrated Ionic Liquids and Precipitation-Stripping	\N	paper	The recovery of valuable metals from industrial process residues is complex because those metals are often present in very low concentrations and locked in complex matrices. Hence it is important to develop a process that selectively recovers the metal(s) of interest, while the undesired metals remain in the solid residue. Conventional pyrometallurgical and hydrometallurgical routes suffer from high cost and poor selectivity. In this work, a solvometallurgical approach was investigated for the selective leaching of lead and zinc from iron-rich jarosite of the zinc industry. Solvometallurgy uses organic solvents rather than water in order to reduce energy, acid, and water consumption and to improve selectivity and reactivity. The screening of different solvometallurgical lixiviants showed that the presence of chloride anions in the lixiviant was crucial for the leaching of lead. The ionic liquids Aliquat 336 ([A336][Cl]) and Cyphos IL 101 ([C101][Cl]), after equilibration with HCl, leached more lead and zinc compared to the other lixiviants. [A336][Cl] and [C101][Cl] equilibrated with 0.5 mol L –1 HCl, were selected for the optimization study because of their higher selectivity toward lead and zinc and lower codissolution of iron, compared to the same ionic liquids equilibrated with a higher concentration of HCl. At optimized leaching conditions, the metal/iron mass ratio increased from 1:4 for Pb/Fe, and from 1:7 for Zn/Fe in the initial jarosite, to over 2:1 and 1:2, in the leachate, respectively. The dissolved metals were recovered by selective precipitation-stripping with an aqueous ammonia solution. Finally, the corresponding flowsheets were developed for the recovery of zinc and lead for both [A336][Cl] and [C101][Cl].	\N	ACS Sustainable Chemistry & Engineering	\N	\N	2019	7	4	4239-4246	10.1021/acssuschemeng.8b05938	\N	\N	https://doi.org/10.1021/acssuschemeng.8b05938	Thupten Palden, Mercedes Regadío, Bieke Onghena, Koen Binnemans. (2019). Selective Metal Recovery from Jarosite Residue by Leaching with Acid-Equilibrated Ionic Liquids and Precipitation-Stripping. ACS Sustainable Chemistry & Engineering. https://doi.org/10.1021/acssuschemeng.8b05938	en	public	published	t	2026-08-17 11:35:14.331246+08	openalex_oa_curated	2026-08-17 11:35:14.331246+08	2026-08-17 11:35:14.331246+08	\N	\N	\N	\N
559	5	LIT-000559	Bioleaching metal-bearing wastes and by-products for resource recovery: a review	\N	paper	Abstract The global transition to a circular economy calls for research and development on technologies facilitating sustainable resource recovery from wastes and by-products. Metal-bearing materials, including electronic wastes, tailings, and metallurgical by-products, are increasingly viewed as valuable resources, with some possessing comparable or superior quality to natural ores. Bioleaching, an eco-friendly and cost-effective alternative to conventional hydrometallurgical and pyrometallurgical methods, uses microorganisms and their metabolites to extract metals from unwanted metal-bearing materials. The performance of bioleaching is influenced by pH, solid concentration, energy source, agitation rate, irrigation rate, aeration rate, and inoculum concentration. Optimizing these parameters improves yields and encourages the wider application of bioleaching. Here, we review the microbial diversity and specific mechanisms of bioleaching for metal recovery. We describe the current operations and approaches of bioleaching at various scales and summarise the influence of a broad range of operational parameters. Finally, we address the primary challenges in scaling up bioleaching applications and propose an optimisation strategy for future bioleaching research.	\N	Environmental Chemistry Letters	\N	\N	2023	21	6	3329-3350	10.1007/s10311-023-01611-4	\N	\N	https://doi.org/10.1007/s10311-023-01611-4	Ipek Tezyapar Kara, K Kremser, Stuart Wagland, Frédéric Coulon. (2023). Bioleaching metal-bearing wastes and by-products for resource recovery: a review. Environmental Chemistry Letters. https://doi.org/10.1007/s10311-023-01611-4	en	public	published	t	2026-08-17 11:35:14.340464+08	openalex_oa_curated	2026-08-17 11:35:14.340464+08	2026-08-17 11:35:14.340464+08	\N	\N	\N	\N
560	5	LIT-000560	Efficient Synchronous Extraction of Nickel, Copper, and Cobalt from Low–Nickel Matte by Sulfation Roasting‒Water Leaching Process	\N	paper	Abstract Considering that the low recovery efficiency and the massive loss of valuable metals by the traditional pyrometallurgical process smelting low‒nickel matte. Therefore, this paper focuses on studying the optimal process parameters and the mechanism of sulphation roasting followed by water leaching achieving efficient synchronous extraction of nickel (Ni), copper (Cu), and cobalt (Co) from low‒nickel matte with sodium sulfate as the sulfating addictive. Under optimal conditions, the recovery efficiency of Ni, Cu, and Co metals can achieve 95%, 99%, and 94%, respectively, whereas the recovery efficiency of Fe metal is less than 1%. The results revealed that the mechanism of the sulfating roasting pretreatment could form a liquidus eutectic compound sulfates [Na 2 Me(SO 4 ) 2 ] (Me = Ni, Cu, Co) at the solid–solid interface, which plays a significant role in promoting the leaching efficiency of valuable metals. Not only enhance the reaction kinetics of sulfation, but improve the utilization efficiency of SO 2 /SO 3 . Thus, the sulfation roasting‒water leaching process developing an efficient and eco-friendly pathway to simultaneous extraction of Ni, Cu, and Co valuable metals from low grade sulfide ores.	\N	Scientific Reports	\N	\N	2020	10	1	9916-9916	10.1038/s41598-020-66894-x	\N	\N	https://doi.org/10.1038/s41598-020-66894-x	Qiangchao Sun, Hongwei Cheng, Xiaoyong Mei, Yanbo Liu, Guangshi Li, Qian Xu, Xionggang Lu. (2020). Efficient Synchronous Extraction of Nickel, Copper, and Cobalt from Low–Nickel Matte by Sulfation Roasting‒Water Leaching Process. Scientific Reports. https://doi.org/10.1038/s41598-020-66894-x	en	public	published	t	2026-08-17 11:35:14.345748+08	openalex_oa_curated	2026-08-17 11:35:14.345748+08	2026-08-17 11:35:14.345748+08	\N	\N	\N	\N
561	5	LIT-000561	Comprehensive recovery and recycle of jarosite residues from zinc hydrometallurgy	\N	paper	In this paper, a new method for the comprehensive recovery and recycle of jarosite residues (JR) is proposed. By direct reduction followed by magnetic separation, lead, zinc and iron are separated and recovered from JR and sulfur is fixed. The non-magnetic tails (NMT) of the magnetic separation is used for removing of Cd, As and Pb heavy metal ions from acidic wastewater of zinc hydrometallurgy. Test work results showed that the volatilization rates of lead and zinc were 96.97% and 99.89%, respectively, the sulfur fixation rate with CaO was 98.91% under optimal conditions of reduced roasting at 1523 K for 60 min. A magnetic iron concentrate was obtained containing 95.68% iron at a recovery of 76.26% by grinding-magnetic separation process. The removal rates of Cd, As and Pb ions were 99.98%, 93.75% and 99.80% respectively. The content of Cd, As and Pb ions in the treated wastewater met the emission standards at 120 g/L NMT dosage and for a contact time of 90 mins. The proposed method is considered as an environmentally-friendly and efficient approach to the comprehensive recovery and recycle of JR and the removal of toxic cadmium, arsenic and lead ions from acidic wastewater of zinc hydrometallurgy.	\N	Chemical Engineering Journal Advances	\N	\N	2020	3	\N	100023-100023	10.1016/j.ceja.2020.100023	\N	\N	https://doi.org/10.1016/j.ceja.2020.100023	Yayun Wang, Huifen Yang, Ge Zhang, Jinxing Kang, Chuan-Long Wang. (2020). Comprehensive recovery and recycle of jarosite residues from zinc hydrometallurgy. Chemical Engineering Journal Advances. https://doi.org/10.1016/j.ceja.2020.100023	en	public	published	t	2026-08-17 11:35:14.352369+08	openalex_oa_curated	2026-08-17 11:35:14.352369+08	2026-08-17 11:35:14.352369+08	\N	\N	\N	\N
562	5	LIT-000562	Separation and recovery of critical metal ions using ionic liquids	\N	paper	Separation and purification of critical metal ions such as rare-earth elements (REEs), scandium and niobium from their minerals is difficult and often determines if extraction is economically and environmentally feasible. Solvent extraction is a commonly used metal-ion separation process, usually favored because of its simplicity, speed and wide scope, which is why it is often employed for separating trace metals from their minerals. However, the types of solvents widely used for the recovery of metal ions have adverse environmental impact. Alternatives to solvent extraction have been explored and advances in separation technologies have shown commercial establishment of liquid membranes as an alternative to conventional solvent extraction for the recovery of metals and other valuable materials. Liquid membrane transport incorporates solvent extraction and membrane separation in one continuously operating system. Both methods conventionally use solvents that are harmful to the environment, however, the introduction of ionic liquids (ILs) over the last decade is set to minimize the environmental impact of both solvent extraction and liquid membrane separation processes. ILs are a family of organic molten salts with low or negligible vapour pressure which may be formed below 100 °C. Such liquids are also highly thermally stable and less toxic. Their ionic structure makes them thermodynamically favorable solvents for the extraction of metallic ions. The main aim of this article is to review the current achievements in the separation of REE, scandium, niobium and vanadium from their minerals, using ILs in either solvent extraction or liquid membrane processes. The mechanism of separation using ILs is discussed and the engineering constraints to their application are identified.	\N	Advances in Manufacturing	\N	\N	2016	4	1	33-46	10.1007/s40436-015-0132-3	\N	\N	https://doi.org/10.1007/s40436-015-0132-3	Terence Makanyire, Sergio Sánchez‐Segado, Animesh Jha. (2016). Separation and recovery of critical metal ions using ionic liquids. Advances in Manufacturing. https://doi.org/10.1007/s40436-015-0132-3	en	public	published	t	2026-08-17 11:35:14.358293+08	openalex_oa_curated	2026-08-17 11:35:14.358293+08	2026-08-17 11:35:14.358293+08	\N	\N	\N	\N
563	5	LIT-000563	Nickel Extraction from Olivine: Effect of Carbonation Pre-Treatment	\N	paper	In this work, we explore a novel mineral processing approach using carbon dioxide to promote mineral alterations that lead to improved extractability of nickel from olivine ((Mg,Fe)2SiO4). The precept is that by altering the morphology and the mineralogy of the ore via mineral carbonation, the comminution requirements and the acid consumption during hydrometallurgical processing can be reduced. Furthermore, carbonation pre-treatment can lead to mineral liberation and concentration of metals in physically separable phases. In a first processing step, olivine is fully carbonated at high CO2 partial pressures (35 bar) and optimal temperature (200 °C) with the addition of pH buffering agents. This leads to a powdery product containing high carbonate content. The main products of the carbonation reaction include quasi-amorphous colloidal silica, chromium-rich metallic particles, and ferro-magnesite ((Mg1−x,Fex)CO3). Carbonated olivine was subsequently leached using an array of inorganic and organic acids to test their leaching efficiency. Compared to leaching from untreated olivine, the percentage of nickel extracted from carbonated olivine by acid leaching was significantly increased. It is anticipated that the mineral carbonation pre-treatment approach may also be applicable to other ultrabasic and lateritic ores.	\N	Metals	\N	\N	2015	5	3	1620-1644	10.3390/met5031620	\N	\N	https://doi.org/10.3390/met5031620	Rafael M. Santos, Aldo Van Audenaerde, Yi Wai Chiang, Remus Ion Iacobescu, Pol Knops, Tom Van Gerven. (2015). Nickel Extraction from Olivine: Effect of Carbonation Pre-Treatment. Metals. https://doi.org/10.3390/met5031620	en	public	published	t	2026-08-17 11:35:14.363148+08	openalex_oa_curated	2026-08-17 11:35:14.363148+08	2026-08-17 11:35:14.363148+08	\N	\N	\N	\N
564	5	LIT-000564	Hierarchical nature of hydrogen-based direct reduction of iron oxides	\N	paper	Fossil-free ironmaking is indispensable for reducing massive anthropogenic CO2 emissions in the steel industry. Hydrogen-based direct reduction (HyDR) is among the most attractive solutions for green ironmaking, with high technology readiness. The underlying mechanisms governing this process are characterized by a complex interaction of several chemical (phase transformations), physical (transport), and mechanical (stresses) phenomena. Their interplay leads to rich microstructures, characterized by a hierarchy of defects ranging across several orders of magnitude in length, including vacancies, dislocations, internal interfaces, and free surfaces in the form of cracks and pores. These defects can all act as reaction, nucleation, and diffusion sites, shaping the overall reduction kinetics. A clear understanding of the roles and interactions of these dynamically-evolving nano-/microstructure features is missing. Gaining better insights into these effects could enable improved access to the microstructure-based design of more efficient HyDR methods, with potentially high impact on the urgently needed decarbonization in the steel industry.	\N	Scripta Materialia	\N	\N	2022	213	\N	114571-114571	10.1016/j.scriptamat.2022.114571	\N	\N	https://doi.org/10.1016/j.scriptamat.2022.114571	Yan Ma, Isnaldi Rodrigues de Souza Filho, Yang Bai, Johannes Schenk, Fabrice Patisson, Arik Beck, Jeroen A. van Bokhoven, Marc‐Georg Willinger, Kejiang Li, Degang Xie, Dirk Ponge, Stefan Zaefferer, Baptiste Gault, Jaber Rezaei Mianroodi, Dierk Raabe. (2022). Hierarchical nature of hydrogen-based direct reduction of iron oxides. Scripta Materialia. https://doi.org/10.1016/j.scriptamat.2022.114571	en	public	published	t	2026-08-17 11:35:16.827262+08	openalex_oa_curated	2026-08-17 11:35:16.827262+08	2026-08-17 11:35:16.827262+08	\N	\N	\N	\N
565	5	LIT-000565	Decarbonization scenarios for the iron and steel industry in context of a sectoral carbon budget: Germany as a case study	\N	paper	CO2 emissions from global steel production may jeopardize climate goals of 1.5 °C unless current steel production practices will be rapidly decarbonized. At present, primary iron and steel production is still heavily dependent on fossil fuels, primarily coke. This study aims to determine which decarbonization pathways can achieve the strongest emission reductions of the iron and steel industry in Germany by 2050. Moreover, we estimate whether the German iron and steel industry will be able to stay within its sectoral carbon budgets for a 1.5 °C or 1.75 °C target. We developed three decarbonization scenarios for German steel production: an electrification, coal-exit, and a carbon capture and storage (CCS) scenario. They describe a phase-out of coal-fired production plants and an introduction of electricity-based, low-carbon iron production technologies, i.e. hydrogen-based direct reduction and electrowinning of iron ore. The scenarios consider the age and lifetimes of existing coal-based furnaces, the maturity of emerging technologies, and increasing recycling shares. Based on specific energy requirements and reaction-related emissions per technology, we calculated future CO2 emissions of future steel production in Germany. We found that under the decarbonization scenarios, annual CO2 emissions decrease by up to 83% in 2050 relative to 2020. The reductions of cumulative emissions by 2050 range from 24% (360 Mt CO2) under the electrification scenario up to the maximum of 46% (677 Mt CO2) under the CCS scenario compared to a reference scenario. This clearly demonstrates that the technology pathway matters. Nevertheless, the German steel sector will exceed its sectoral CO2 budget for a 1.5 °C warming scenario between 2023 and 2037. Thus, drastic measures are required very soon to sufficiently limit future CO2 emissions from German steel production, such as, a rapid decarbonization of the electricity mix, the construction of a hydrogen and CCS infrastructure, or early shutdowns of current coal-based furnaces.	\N	Journal of Cleaner Production	\N	\N	2022	380	\N	134846-134846	10.1016/j.jclepro.2022.134846	\N	\N	https://doi.org/10.1016/j.jclepro.2022.134846	Carina Harpprecht, Tobias Naegler, Bernhard Steubing, Arnold Tukker, Sonja Simon. (2022). Decarbonization scenarios for the iron and steel industry in context of a sectoral carbon budget: Germany as a case study. Journal of Cleaner Production. https://doi.org/10.1016/j.jclepro.2022.134846	en	public	published	t	2026-08-17 11:35:16.869886+08	openalex_oa_curated	2026-08-17 11:35:16.869886+08	2026-08-17 11:35:16.869886+08	\N	\N	\N	\N
566	5	LIT-000566	Techno-economic analysis of wind-powered green hydrogen production to facilitate the decarbonization of hard-to-abate sectors: A case study on steelmaking	\N	paper	Green hydrogen is among the most promising energy vectors that may enable the decarbonization of our society. The present study addresses the decarbonization of hard-to-abate sectors via the deployment of sustainable alternatives to current technologies and processes where the complete replacement of fossil fuels is deemed not nearly immediate. In particular, the investigated case study tackles the emission reduction potential of steelmaking in the Italian industrial framework via the implementation of dedicated green hydrogen production systems to feed Hydrogen Direct Reduction process, the main alternative to the traditional polluting routes towards emissions abatement. Green hydrogen is produced via the coupling of an onshore wind farm with lithium-ion batteries, alkaline type electrolyzers and the interaction with the electricity grid. Building on a power generation dataset from a real utility-scale wind farm, techno-economic analyses are carried out for a large number of system configurations, varying components size and layout to assess its performance on the basis of two main key parameters, the levelized cost of hydrogen (LCOH) and the Green Index (GI), the latter presented for the first time in this study. The optimal system design and operation logics are investigated accounting for the necessity of providing a constant mass flow rate of H2 and thus considering the interaction with the electricity network instead of relying solely on RES surplus. In-house-developed models that account for performances degradation over time of different technologies are adapted and used for the case study. The effect of different storage technologies is evaluated via a sensitivity analysis on different components and electricity pricing strategy to understand how to favour green hydrogen penetration in the heavy industry. Furthermore, for a better comprehension and contextualization of the proposed solutions, their emission-reduction potential is quantified and presented in comparison with the current scenario of EU-27 countries. In the optimal case, the emission intensity related to the steelmaking process can be lowered to 235 kg of CO2 per ton of output steel, 88 % less than the traditional route. A higher cost of the process must be accounted, resulting in an LCOH of such solutions around 6.5 €/kg.	\N	Applied Energy	\N	\N	2023	342	\N	121198-121198	10.1016/j.apenergy.2023.121198	\N	\N	https://doi.org/10.1016/j.apenergy.2023.121198	Francesco Superchi, Alessandro Mati, Carlo Carcasci, Alessandro Bianchini. (2023). Techno-economic analysis of wind-powered green hydrogen production to facilitate the decarbonization of hard-to-abate sectors: A case study on steelmaking. Applied Energy. https://doi.org/10.1016/j.apenergy.2023.121198	en	public	published	t	2026-08-17 11:35:16.881161+08	openalex_oa_curated	2026-08-17 11:35:16.881161+08	2026-08-17 11:35:16.881161+08	\N	\N	\N	\N
567	5	LIT-000567	Adopting hydrogen direct reduction for the Swedish steel industry: A technological innovation system (TIS) study	\N	paper	The Swedish steel industry stands before a potential transition to drastically lower its CO 2 emissions using direct hydrogen reduction instead of continuing with coke-based blast furnaces. Previous studies have identified hydrogen direct reduction as a promising option. We build upon earlier efforts by performing a technological innovation system study to systematically examine the barriers to a transition to hydrogen direct reduction and by providing deepened quantitative empirics to support the analysis. We also add extended paper and patent analysis methodology which is particularly useful for identifying actors and their interactions in a technological system. We conclude that while the innovation system is currently focused on such a transition, notable barriers remain, particularly in coordination of the surrounding technical infrastructure and the issue of maintaining legitimacy for such a transition in the likely event that policies to address cost pressures will be required to support this development.	\N	Journal of Cleaner Production	\N	\N	2019	242	\N	118185-118185	10.1016/j.jclepro.2019.118185	\N	\N	https://doi.org/10.1016/j.jclepro.2019.118185	Duncan Kushnir, Teis Hansen, Valentin Vogl, Max Åhman. (2019). Adopting hydrogen direct reduction for the Swedish steel industry: A technological innovation system (TIS) study. Journal of Cleaner Production. https://doi.org/10.1016/j.jclepro.2019.118185	en	public	published	t	2026-08-17 11:35:16.888978+08	openalex_oa_curated	2026-08-17 11:35:16.888978+08	2026-08-17 11:35:16.888978+08	\N	\N	\N	\N
568	5	LIT-000568	A General Vision for Reduction of Energy Consumption and CO2 Emissions from the Steel Industry	\N	paper	The 2018 IPCC (The Intergovernmental Panel on Climate Change’s) report defined the goal to limit global warming to 1.5 °C by 2050. This will require “rapid and far-reaching transitions in land, energy, industry, buildings, transport, and cities”. The challenge falls on all sectors, especially energy production and industry. In this regard, the recent progress and future challenges of greenhouse gas emissions and energy supply are first briefly introduced. Then, the current situation of the steel industry is presented. Steel production is predicted to grow by 25–30% by 2050. The dominant iron-making route, blast furnace (BF), especially, is an energy-intensive process based on fossil fuel consumption; the steel sector is thus responsible for about 7% of all anthropogenic CO2 emissions. In order to take up the 2050 challenge, emissions should see significant cuts. Correspondingly, specific emissions (t CO2/t steel) should be radically decreased. Several large research programs in big steelmaking countries and the EU have been carried out over the last 10–15 years or are ongoing. All plausible measures to decrease CO2 emissions were explored here based on the published literature. The essential results are discussed and concluded. The specific emissions of “world steel” are currently at 1.8 t CO2/t steel. Improved energy efficiency by modernizing plants and adopting best available technologies in all process stages could decrease the emissions by 15–20%. Further reductions towards 1.0 t CO2/t steel level are achievable via novel technologies like top gas recycling in BF, oxygen BF, and maximal replacement of coke by biomass. These processes are, however, waiting for substantive industrialization. Generally, substituting hydrogen for carbon in reductants and fuels like natural gas and coke gas can decrease CO2 emissions remarkably. The same holds for direct reduction processes (DR), which have spread recently, exceeding 100 Mt annual capacity. More radical cut is possible via CO2 capture and storage (CCS). The technology is well-known in the oil industry; and potential applications in other sectors, including the steel industry, are being explored. While this might be a real solution in propitious circumstances, it is hardly universally applicable in the long run. More auspicious is the concept that aims at utilizing captured carbon in the production of chemicals, food, or fuels e.g., methanol (CCU, CCUS). The basic idea is smart, but in the early phase of its application, the high energy-consumption and costs are disincentives. The potential of hydrogen as a fuel and reductant is well-known, but it has a supporting role in iron metallurgy. In the current fight against climate warming, H2 has come into the “limelight” as a reductant, fuel, and energy storage. The hydrogen economy concept contains both production, storage, distribution, and uses. In ironmaking, several research programs have been launched for hydrogen production and reduction of iron oxides. Another global trend is the transfer from fossil fuel to electricity. “Green” electricity generation and hydrogen will be firmly linked together. The electrification of steel production is emphasized upon in this paper as the recycled scrap is estimated to grow from the 30% level to 50% by 2050. Finally, in this review, all means to reduce specific CO2 emissions have been summarized. By thorough modernization of production facilities and energy systems and by adopting new pioneering methods, “world steel” could reach the level of 0.4–0.5 t CO2/t steel and thus reduce two-thirds of current annual emissions.	\N	Metals	\N	\N	2020	10	9	1117-1117	10.3390/met10091117	\N	\N	https://doi.org/10.3390/met10091117	Lauri Holappa. (2020). A General Vision for Reduction of Energy Consumption and CO2 Emissions from the Steel Industry. Metals. https://doi.org/10.3390/met10091117	en	public	published	t	2026-08-17 11:35:16.898726+08	openalex_oa_curated	2026-08-17 11:35:16.898726+08	2026-08-17 11:35:16.898726+08	\N	\N	\N	\N
569	5	LIT-000569	Challenges and Opportunities in Green Hydrogen Adoption for Decarbonizing Hard-to-Abate Industries: A Comprehensive Review	\N	paper	The decarbonization of hard-to-abate industries is crucial for keeping global warming to below 2°C. Green or renewable hydrogen, synthesized through water electrolysis, has emerged as a sustainable alternative for fossil fuels in energy-intensive sectors such as aluminum, cement, chemicals, steel, and transportation. However, the scalability of green hydrogen production faces challenges including infrastructure gaps, energy losses, excessive power consumption, and high costs throughout the value chain. Therefore, this study analyzes the challenges within the green hydrogen value chain, focusing on the development of nascent technologies. Presenting a comprehensive synthesis of contemporary knowledge, this study assesses the potential impacts of green hydrogen on hard-to-abate sectors, emphasizing the expansion of clean energy infrastructure. Through an exploration of emerging renewable hydrogen technologies, the study investigates aspects such as economic feasibility, sustainability assessments, and the achievement of carbon neutrality. Additionally, considerations extend to the potential for large-scale renewable electricity storage and the realization of net-zero goals. The findings of this study suggest that emerging technologies have the potential to significantly increase green hydrogen production, offering affordable solutions for decarbonization. The study affirms that global-scale green hydrogen production could satisfy up to 24% of global energy needs by 2050, resulting in the abatement of 60 gigatons of greenhouse gas (GHG) emissions - equivalent to 6% of total cumulativeCO2emission reductions. To comprehensively evaluate the impact of the hydrogen economy on ecosystem decarbonization, this article analyzes the feasibility of three business models that emphasize choices for green hydrogen production and delivery. Finally, the study proposes potential directions for future research on hydrogen valleys, aiming to foster interconnected hydrogen ecosystems.	\N	IEEE Access	\N	\N	2024	12	\N	23363-23388	10.1109/access.2024.3363869	\N	\N	https://doi.org/10.1109/access.2024.3363869	M. Jayachandran, Ranjith Kumar Gatla, Aymen Flah, Ahmad H. Milyani, Hisham M. Milyani, Vojtěch Blažek, Lukáš Prokop, Habib Kraiem. (2024). Challenges and Opportunities in Green Hydrogen Adoption for Decarbonizing Hard-to-Abate Industries: A Comprehensive Review. IEEE Access. https://doi.org/10.1109/access.2024.3363869	en	public	published	t	2026-08-17 11:35:16.905654+08	openalex_oa_curated	2026-08-17 11:35:16.905654+08	2026-08-17 11:35:16.905654+08	\N	\N	\N	\N
570	5	LIT-000570	Pathways for Low-Carbon Transition of the Steel Industry—A Swedish Case Study	\N	paper	The concept of techno-economic pathways is used to investigate the potential implementation of CO2 abatement measures over time towards zero-emission steelmaking in Sweden. The following mitigation measures are investigated and combined in three pathways: top gas recycling blast furnace (TGRBF); carbon capture and storage (CCS); substitution of pulverized coal injection (PCI) with biomass; hydrogen direct reduction of iron ore (H-DR); and electric arc furnace (EAF), where fossil fuels are replaced with biomass. The results show that CCS in combination with biomass substitution in the blast furnace and a replacement primary steel production plant with EAF with biomass (Pathway 1) yield CO2 emission reductions of 83% in 2045 compared to CO2 emissions with current steel process configurations. Electrification of the primary steel production in terms of H-DR/EAF process (Pathway 2), could result in almost fossil-free steel production, and Sweden could achieve a 10% reduction in total CO2 emissions. Finally, (Pathway 3) we show that increased production of hot briquetted iron pellets (HBI), could lead to decarbonization of the steel industry outside Sweden, assuming that the exported HBI will be converted via EAF and the receiving country has a decarbonized power sector.	\N	Energies	\N	\N	2020	13	15	3840-3840	10.3390/en13153840	\N	\N	https://doi.org/10.3390/en13153840	Alla Toktarova, Ida Karlsson, Johan Rootzén, Lisa Göransson, Mikael Odenberger, Filip Johnsson. (2020). Pathways for Low-Carbon Transition of the Steel Industry—A Swedish Case Study. Energies. https://doi.org/10.3390/en13153840	en	public	published	t	2026-08-17 11:35:16.916783+08	openalex_oa_curated	2026-08-17 11:35:16.916783+08	2026-08-17 11:35:16.916783+08	\N	\N	\N	\N
572	5	LIT-000572	Global green hydrogen-based steel opportunities surrounding high quality renewable energy and iron ore deposits	\N	paper	emissions and requires deep reform to disconnect from fossil fuels. Here, we investigate the market competitiveness of one of the widely considered decarbonisation routes for primary steel production: green hydrogen-based direct reduction of iron ore followed by electric arc furnace steelmaking. Through analysing over 300 locations by combined use of optimisation and machine learning, we show that competitive renewables-based steel production is located nearby the tropic of Capricorn and Cancer, characterised by superior solar with supplementary onshore wind, in addition to high-quality iron ore and low steelworker wages. If coking coal prices remain high, fossil-free steel could attain competitiveness in favourable locations from 2030, further improving towards 2050. Large-scale implementation requires attention to the abundance of suitable iron ore and other resources such as land and water, technical challenges associated with direct reduction, and future supply chain configuration.	\N	Nature Communications	\N	\N	2023	14	1	2578-2578	10.1038/s41467-023-38123-2	\N	\N	https://doi.org/10.1038/s41467-023-38123-2	Alexandra Devlin, Jannik Kossen, Haulwen Goldie-Jones, Aidong Yang. (2023). Global green hydrogen-based steel opportunities surrounding high quality renewable energy and iron ore deposits. Nature Communications. https://doi.org/10.1038/s41467-023-38123-2	en	public	published	t	2026-08-17 11:35:16.931434+08	openalex_oa_curated	2026-08-17 11:35:16.931434+08	2026-08-17 11:35:16.931434+08	\N	\N	\N	\N
573	5	LIT-000573	The Role of Hydrogen in Decarbonizing U.S. Iron and Steel Production	\N	paper	High Resolution Image Download MS PowerPoint Slide This study investigates the role of hydrogen as a decarbonization strategy for the iron and steel industry in the United States (U.S.) in the presence of an economy-wide net zero CO 2 emissions target. Our analysis shows that hydrogen-based direct reduced iron (H 2 DRI) provides a cost-effective decarbonization strategy only under a relatively narrow set of conditions. Using today’s best estimates of the capital and variable costs of alternative decarbonized iron and steelmaking technologies in a U.S. economy-wide simulation framework, we find that carbon capture technologies can achieve comparable decarbonization levels by 2050 and greater cumulative emissions reductions from iron and steel production at a lower cost. Simulations suggest hydrogen contributes to economy-wide decarbonization, but H 2 DRI is not the preferred use case for hydrogen in most scenarios. The average abatement cost for U.S. iron and steel production could be as low as $70/tonne CO 2 with existing technologies plus carbon capture, while the cost with H 2 DRI rises to over $500/tonne CO 2 . We also find that IRA tax credits are insufficient to spur hydrogen use in steelmaking in our model and that a green steel production tax credit would need to be as high as $300/tonne steel to lead to sustained H 2 DRI use.	\N	Environmental Science & Technology	\N	\N	2025	59	10	4915-4925	10.1021/acs.est.4c05756	\N	\N	https://doi.org/10.1021/acs.est.4c05756	Katherine Jordan, Paulina Jaramillo, Valerie J. Karplus, P. J. Adams, Nicholas Z. Muller. (2025). The Role of Hydrogen in Decarbonizing U.S. Iron and Steel Production. Environmental Science & Technology. https://doi.org/10.1021/acs.est.4c05756	en	public	published	t	2026-08-17 11:35:16.938314+08	openalex_oa_curated	2026-08-17 11:35:16.938314+08	2026-08-17 11:35:16.938314+08	\N	\N	\N	\N
574	5	LIT-000574	Introduction to Green Hydrogen	\N	paper	Green hydrogen, produced through water electrolysis powered by renewable energy, is an essential component of future global energy systems.Green hydrogen is produced through water electrolysis powered by renewable energy sources, such as wind, solar, or hydropower, or possibly nuclear energy, resulting in low carbon emissions. 1While the CO equivalent per kilogram of hydrogen produced (kgCOe/kgH) depends on many factors and requires a lifecycle analysis to assess.The U.S. Department of Energy's Section 45V tax credit targets green hydrogen at below 0.45 kgCOe/kgH. 2This requires minimizing emissions throughout the entire production process, including electricity use and upstream activities.These emissions are much lower than "gray" hydrogen from reforming natural gas (CH 4 + 2H 2 O CO 2 + 4H 2 ) with ~10 kgCOe/kgH and "blue" hydrogen using natural gas with carbon capture and ~4 kgCOe/kgH. 3	\N	Chemical Reviews	\N	\N	2024	124	23	13095-13098	10.1021/acs.chemrev.4c00787	\N	\N	https://doi.org/10.1021/acs.chemrev.4c00787	Shannon W. Boettcher. (2024). Introduction to Green Hydrogen. Chemical Reviews. https://doi.org/10.1021/acs.chemrev.4c00787	en	public	published	t	2026-08-17 11:35:16.943909+08	openalex_oa_curated	2026-08-17 11:35:16.943909+08	2026-08-17 11:35:16.943909+08	\N	\N	\N	\N
575	5	LIT-000575	Hydrogen as an alternative fuel: A comprehensive review of challenges and opportunities in production, storage, and transportation	\N	paper	The rapid growth of the global population and industrial activities has significantly increased greenhouse gases (GHGs) emissions, with projections indicating a temperature rise of 3–6 °C by 2050. Urgent action is needed to limit global warming to 1.5 °C above pre-industrial levels. Hydrogen, with its high energy density and compatibility with renewable energy systems, presents a promising clean energy solution to mitigate GHGs emissions. Yet, its widespread adoption faces challenges such as high production costs, limited infrastructure, and an underdeveloped value chain. At present, approximately 96% of global hydrogen production relies on fossil fuels, contributing to substantial emissions, while only 4% comes from water electrolysis. Green hydrogen, produced via electrolysis with 55–80% efficiency, remains expensive at $2.28–7.39/kg, compared to grey hydrogen at $0.67–1.31/kg, which generates 8.5 kg CO₂ per kg of hydrogen production. Hydrogen's low density poses challenges for storage, while transportation risks and insufficient infrastructure create further obstacles. The lack of global standards and investment uncertainties further impede the development of a comprehensive hydrogen economy. This review evaluates hydrogen's potential as a sustainable energy carrier, providing insights into advancements and ongoing challenges in production, storage, and transportation. Key findings highlight the necessity of coordinated efforts to enhance storage technologies, lower production costs, and establish supportive policies, highlighting hydrogen's critical role in achieving a sustainable energy transition. • Analyzed hydrogen's potential as a sustainable and clean energy carrier. • Reviewed global advancements and trends in hydrogen production and utilization. • Addressed key technical challenges in adopting hydrogen as an alternative fuel. • Evaluated opportunities in hydrogen production, storage, and transport systems. • Assessed barriers in hydrogen infrastructure, addressing technical challenges.	\N	International Journal of Hydrogen Energy	\N	\N	2025	102	\N	1026-1044	10.1016/j.ijhydene.2025.01.033	\N	\N	https://doi.org/10.1016/j.ijhydene.2025.01.033	Md Monjur Hossain Bhuiyan, Zahed Siddique. (2025). Hydrogen as an alternative fuel: A comprehensive review of challenges and opportunities in production, storage, and transportation. International Journal of Hydrogen Energy. https://doi.org/10.1016/j.ijhydene.2025.01.033	en	public	published	t	2026-08-17 11:35:16.948811+08	openalex_oa_curated	2026-08-17 11:35:16.948811+08	2026-08-17 11:35:16.948811+08	\N	\N	\N	\N
576	5	LIT-000576	Deploying green hydrogen to decarbonize China’s coal chemical sector	\N	paper	Abstract China’s coal chemical sector uses coal as both a fuel and feedstock and its increasing greenhouse gas (GHG) emissions are hard to abate by electrification alone. Here we explore the GHG mitigation potential and costs for onsite deployment of green H 2 and O 2 in China’s coal chemical sector, using a life-cycle assessment and techno-economic analyses. We estimate that China’s coal chemical production resulted in GHG emissions of 1.1 gigaton CO 2 equivalent (GtCO 2 eq) in 2020, equal to 9% of national emissions. We project GHG emissions from China’s coal chemical production in 2030 to be 1.3 GtCO 2 eq, ~50% of which can be reduced by using solar or wind power-based electrolytic H 2 and O 2 to replace coal-based H 2 and air separation-based O 2 at a cost of 10 or 153 Chinese Yuan (CNY)/tCO 2 eq, respectively. We suggest that provincial regions determine whether to use solar or wind power for water electrolysis based on lowest cost options, which collectively reduce 53% of the 2030 baseline GHG emissions at a cost of 9 CNY/tCO 2 eq. Inner Mongolia, Shaanxi, Ningxia, and Xinjiang collectively account for 52% of total GHG mitigation with net cost reductions. These regions are well suited for pilot policies to advance demonstration projects.	\N	Nature Communications	\N	\N	2023	14	1	8104-8104	10.1038/s41467-023-43540-4	\N	\N	https://doi.org/10.1038/s41467-023-43540-4	Yang Guo, Liqun Peng, Jinping Tian, Denise L. Mauzerall. (2023). Deploying green hydrogen to decarbonize China’s coal chemical sector. Nature Communications. https://doi.org/10.1038/s41467-023-43540-4	en	public	published	t	2026-08-17 11:35:16.955279+08	openalex_oa_curated	2026-08-17 11:35:16.955279+08	2026-08-17 11:35:16.955279+08	\N	\N	\N	\N
578	5	LIT-000578	The role of new energy in carbon neutral	\N	paper	Carbon dioxide is an important medium of the global carbon cycle, and has the dual properties of realizing the conversion of organic matter in the ecosystem and causing the greenhouse effect. The fixed or available carbon dioxide in the atmosphere is defined as “gray carbon”, while the carbon dioxide that cannot be fixed or used and remains in the atmosphere is called “black carbon”. Carbon neutral is the consensus of human development, but its implementation still faces many challenges in politics, resources, technology, market, and energy structure, etc. It is proposed that carbon replacement, carbon emission reduction, carbon sequestration, and carbon cycle are the four main approaches to achieve carbon neutral, among which carbon replacement is the backbone. New energy has become the leading role of the third energy conversion and will dominate carbon neutral in the future. Nowadays, solar energy, wind energy, hydropower, nuclear energy and hydrogen energy are the main forces of new energy, helping the power sector to achieve low carbon emissions. “Green hydrogen” is the reserve force of new energy, helping further reduce carbon emissions in industrial and transportation fields. Artificial carbon conversion technology is a bridge connecting new energy and fossil energy, effectively reducing the carbon emissions of fossil energy. It is predicted that the peak value of China's carbon dioxide emissions will reach 110×108 t in 2030. The study predicts that China's carbon emissions will drop to 22×108 t, 33×108 t and 44×108 t, respectively, in 2060 according to three scenarios of high, medium, and low levels. To realize carbon neutral in China, seven implementation suggestions have been put forward to build a new “three small and one large” energy structure in China and promote the realization of China's energy independence strategy.	\N	Petroleum Exploration and Development	\N	\N	2021	48	2	480-491	10.1016/s1876-3804(21)60039-3	\N	\N	https://doi.org/10.1016/s1876-3804(21)60039-3	Caineng Zou, Bo Xiong, Huaqing Xue, Dewen Zheng, GE Zhi-xin, Ying Wang, Luyang Jiang, Songqi Pan, Songtao Wu. (2021). The role of new energy in carbon neutral. Petroleum Exploration and Development. https://doi.org/10.1016/s1876-3804(21)60039-3	en	public	published	t	2026-08-17 11:35:16.967286+08	openalex_oa_curated	2026-08-17 11:35:16.967286+08	2026-08-17 11:35:16.967286+08	\N	\N	\N	\N
579	5	LIT-000579	The view of technological innovation in coal industry under the vision of carbon neutralization	\N	paper	Abstract This paper analyzed the current situation and development trends of energy consumption and carbon emissions, and the current situation and development trend of coal consumption in China. In the context of recently established carbon peak and carbon neutralization targets, this paper put forward the main problems associated with the green and low-carbon development and utilization of coal. Five key technological innovation directions in mining were proposed, including green coal development, intelligent and efficient mining, low-carbon utilization and conversion of coal, energy conservation and emission reduction, carbon capture, utilization and storage (CCUS). Focusing on the above technological innovation directions, it is suggested to carry out three basic theories, including the theory of green efficient intelligent mining, clean and low-carbon utilization and transformation of coal, and CCUS. Meanwhile, it is proposed to develop 12 key technologies, including green coal mining and ecological environment protection, efficient coal mining and intelligent mine construction, key technologies and equipment for efficient coal processing, underground coal gasification and mining, ultra-high parameter and ultra-supercritical power generation technology, intelligent and flexible coal-fired power generation technology, new power cycle coal-fired power generation technology, the development of coal-based special fuels, coal-based bulk and specialty chemicals, energy conservation and consumption reduction, large-scale and low-cost carbon capture, CO 2 utilization and storage. Finally, necessary measures from the governmental perspective were also proposed.	\N	International Journal of Coal Science & Technology	\N	\N	2021	8	6	1197-1207	10.1007/s40789-021-00458-w	\N	\N	https://doi.org/10.1007/s40789-021-00458-w	Quansheng Li. (2021). The view of technological innovation in coal industry under the vision of carbon neutralization. International Journal of Coal Science & Technology. https://doi.org/10.1007/s40789-021-00458-w	en	public	published	t	2026-08-17 11:35:16.975195+08	openalex_oa_curated	2026-08-17 11:35:16.975195+08	2026-08-17 11:35:16.975195+08	\N	\N	\N	\N
580	5	LIT-000580	Mineralization Technology for Carbon Capture, Utilization, and Storage	\N	paper	Carbon capture, utilisation and storage (CCUS) is a technology approach to the management of anthropogenic emissions to atmosphere. The mineralisation of CO2 gas is one approach receiving increased attention. By injecting CO2 into host rocks, or via an ex-situ application step, geological formations have the capacity to react with and store huge volumes of this gas via the formation of carbonate minerals. Currently the technology involved is not advanced enough to handle large volumes of CO2 gas. An alternative mineral feedstock material is the Gt of industrial process wastes that are often disposed to landfill. Suitable solid industrial wastes include thermal process residues which are voluminous and fairly consistent in nature. By applying an accelerated carbonation step to solid waste there is potential to sequestrate meaningful quantities of CO2 in carbonate-cemented products that have re-use value. The manufacture of carbonated aggregates is already commercially established in Europe and recent advances in technology have enabled mobile plant that directly utilises flue-gas derived CO2 in the manufactured carbonated aggregate process. The present work discusses the basis for mineralisation in geologically derived minerals and industrial wastes, with a focus being on the production of products with value. An assessment of mineralised construction aggregates suggests that CCUS technology can manage significant quantities of this carbon dioxide.	\N	Frontiers in Energy Research	\N	\N	2020	8	\N	\N	10.3389/fenrg.2020.00142	\N	\N	https://doi.org/10.3389/fenrg.2020.00142	Colin D. Hills, Nimisha Tripathi, Paula J. Carey. (2020). Mineralization Technology for Carbon Capture, Utilization, and Storage. Frontiers in Energy Research. https://doi.org/10.3389/fenrg.2020.00142	en	public	published	t	2026-08-17 11:35:16.980405+08	openalex_oa_curated	2026-08-17 11:35:16.980405+08	2026-08-17 11:35:16.980405+08	\N	\N	\N	\N
581	5	LIT-000581	Minimizing CO <sub>2</sub> emissions with renewable energy: a comparative study of emerging technologies in the steel industry	\N	paper	Implementing CCUS technologies at existing steel plants reduces CO <sub>2</sub> emissions by 70%, requiring 1.1 MW h per ton of renewable electricity. H <sub>2</sub> -based steel-making and CCU technologies require 4 and 8 times more electricity to reach similar reductions.	\N	Energy & Environmental Science	\N	\N	2020	13	7	1923-1932	10.1039/d0ee00787k	\N	\N	https://doi.org/10.1039/d0ee00787k	Marian Flores-Granobles, Mark Saeys. (2020). Minimizing CO <sub>2</sub> emissions with renewable energy: a comparative study of emerging technologies in the steel industry. Energy & Environmental Science. https://doi.org/10.1039/d0ee00787k	en	public	published	t	2026-08-17 11:35:16.986687+08	openalex_oa_curated	2026-08-17 11:35:16.986687+08	2026-08-17 11:35:16.986687+08	\N	\N	\N	\N
586	5	LIT-000586	A synopsis manual about recycling steel slag as a cementitious material	\N	paper	Steel slag (SS) is an industrial product of steel making. It can be produced in either an electric arc furnace (EAF), of which steel is produced by melting scrap steel, or a basic oxygen furnace (BOF), of which iron is converted to steel. SS can be used in many fields such as soil improvement, agricultural fertilizer, asphalt concrete, road construction, as a part of concrete/mortar aggregate and as a part of cement. In the current article, a short review of the previous studies using SS as a part of cement in paste, mortar and concrete is conducted. The effects of SS on the fresh, hardened properties and durability of paste, mortar and concrete have been reviewed and summarized. Additionally, different additives and special curing conditions used to improve some properties of SS matrices have been briefed.	\N	Journal of Materials Research and Technology	\N	\N	2019	8	5	4940-4955	10.1016/j.jmrt.2019.06.038	\N	\N	https://doi.org/10.1016/j.jmrt.2019.06.038	Alaa M. Rashad. (2019). A synopsis manual about recycling steel slag as a cementitious material. Journal of Materials Research and Technology. https://doi.org/10.1016/j.jmrt.2019.06.038	en	public	published	t	2026-08-17 11:35:19.264521+08	openalex_oa_curated	2026-08-17 11:35:19.264521+08	2026-08-17 11:35:19.264521+08	\N	\N	\N	\N
582	5	LIT-000582	Atmospheric Carbon Capture Performance of Legacy Iron and Steel Waste	\N	paper	High Resolution Image Download MS PowerPoint Slide Legacy iron (Fe) and steel wastes have been identified as a significant source of silicate minerals, which can undergo carbonation reactions and thus sequester carbon dioxide (CO 2 ). In reactor experiments, i.e., at elevated temperatures, pressures, or CO 2 concentrations, these wastes have high silicate to carbonate conversion rates. However, what is less understood is whether a more “passive” approach to carbonation can work, i.e., whether a traditional slag emplacement method (heaped and then buried) promotes or hinders CO 2 sequestration. In this paper, the results of characterization of material retrieved from a first of its kind drilling program on a historical blast furnace slag heap at Consett, U.K., are reported. The mineralogy of the slag material was near uniform, consisting mainly of melilite group minerals with only minor amounts of carbonate minerals detected. Further analysis established that total carbon levels were on average only 0.4% while average calcium (Ca) levels exceeded 30%. It was calculated that only ∼3% of the CO 2 sequestration potential of the >30 Mt slag heap has been utilized. It is suggested that limited water and gas interaction and the mineralogy and particle size of the slag are the main factors that have hindered carbonation reactions in the slag heap.	\N	Environmental Science & Technology	\N	\N	2019	53	16	9502-9511	10.1021/acs.est.9b01265	\N	\N	https://doi.org/10.1021/acs.est.9b01265	Huw Pullin, Andrew W. Bray, Ian T. Burke, Duncan Muir, Devin Sapsford, William M. Mayes, Phil Renforth. (2019). Atmospheric Carbon Capture Performance of Legacy Iron and Steel Waste. Environmental Science & Technology. https://doi.org/10.1021/acs.est.9b01265	en	public	published	t	2026-08-17 11:35:16.991655+08	openalex_oa_curated	2026-08-17 11:35:16.991655+08	2026-08-17 11:35:16.991655+08	\N	\N	\N	\N
583	5	LIT-000583	Decarbonising the iron and steel industries: Production of carbon-negative direct reduced iron by using biosyngas	\N	paper	Bioenergy with carbon capture and storage (CCS) in iron and steel production offers significant potential for CO2 emission reduction and may even result in carbon-negative steel. With a strong ambition to reach net-zero emissions, some countries, such as Sweden, have recently proposed measures to incentivise bioenergy with CCS (BECCS), which opens a window of opportunities to enable the production of carbon-negative steel. One of the main potential applications of this route is to decarbonise the iron reduction processes that account for 85 % of the total CO2 emission in the iron and steel plants. In this study, gasification is proposed to convert biomass into biosyngas to reduce iron ore directly. Different cases of integrating the biomass gasifier, Direct Reduced Iron (DRI) shaft furnace, and CCS are evaluated through process simulation work. Based on the result of the work, the proposed biosyngas DRI route has comparable energy demand compared to other DRI routes, such as the well-established coal gasification and natural gas DRI route. The proposed process can also capture 0.65–1.13 t of CO2 per t DRI depending on the integration scenarios, which indicates a promising route to achieving carbon-negative steel production.	\N	Energy Conversion and Management	\N	\N	2023	281	\N	116806-116806	10.1016/j.enconman.2023.116806	\N	\N	https://doi.org/10.1016/j.enconman.2023.116806	Ilman Nuran Zaini, Anissa Nurdiawati, Joel Gustavsson, Wenjing Wei, Henrik Thunman, Rutger Gyllenram, Peter Samuelsson, Weihong Yang. (2023). Decarbonising the iron and steel industries: Production of carbon-negative direct reduced iron by using biosyngas. Energy Conversion and Management. https://doi.org/10.1016/j.enconman.2023.116806	en	public	published	t	2026-08-17 11:35:16.998162+08	openalex_oa_curated	2026-08-17 11:35:16.998162+08	2026-08-17 11:35:16.998162+08	\N	\N	\N	\N
584	5	LIT-000584	Mining and metallurgical wastes: a review of recycling and re-use practices	\N	paper	Mining is a complex process involving activities that range from exploration through mine development, mineral beneficiation, metal extraction, smelting, refining, reclamation, and remediation In the process of extracting the metal values, these activities produce significant amounts of wastes, typically consisting of (1) solid wastes in the form of waste rock, dusts, sludges, and slags, (2) liquid wastes in the form of waste water and effluents, and (3) gaseous emissions. In South Africa, mining and metallurgical wastes constitute one of the biggest challenges to the environment. If not managed properly, the anthropogenic effects of these mining and metal extraction activities can result in irreversible damage to the environment and a hazard to humans. In South Africa, in particular, these types of wastes are usually disposed of in landfills, thereby creating serious environmental and health challenges for communities. Mitigating the effects of such mining, metallurgical, and metal manufacturing processes requires a holistic waste management approach that incorporates reduction in the amount of waste produced, in-process recycling, and finding new markets and applications in other sectors of the economy (Lottermoser, 2011; Environmental Protection Agency, 2015; World Steel Association, 2015; Ndlovu, Simate, and Matinde, 2017). As such, increasing the recycling and re-use of the different types of wastes is a potential panacea to the environmental and health challenges posed by these waste streams. Despite the environmental challenges associated with these types of wastes, the mining and metal extraction industries can be integrated to form a circular economy model that promotes zero waste through the re-use and recycling of these waste materials The different waste streams can in fact be considered as secondary sources of valuable metals and other resources.	\N	Journal of the Southern African Institute of Mining and Metallurgy	\N	\N	2018	118	8	\N	10.17159/2411-9717/2018/v118n8a5	\N	\N	https://doi.org/10.17159/2411-9717/2018/v118n8a5	Elias Matinde. (2018). Mining and metallurgical wastes: a review of recycling and re-use practices. Journal of the Southern African Institute of Mining and Metallurgy. https://doi.org/10.17159/2411-9717/2018/v118n8a5	en	public	published	t	2026-08-17 11:35:19.254964+08	openalex_oa_curated	2026-08-17 11:35:19.254964+08	2026-08-17 11:35:19.254964+08	\N	\N	\N	\N
585	5	LIT-000585	Utilization of Red Mud as a Source for Metal Ions—A Review	\N	paper	An overview is presented on the prospective use of red mud as a resource in this review. Various scopes are suggested for the utilization of red mud to maintain a sustainable environment. The potential use of red mud covers the valuable metal recovery that could emphasize the use of red mud as a resource. Red mud could act as reduced slag in the metallurgical field for the extraction of minerals and metals for upscale application. Although many studies have revealed the potential utilization of red mud, most of them are only limited to a lab-scale basis. Therefore, a large-scale investigation on recycling of red mud for the extraction in the area of the metal recovery section will draw attention to the extensive use of red mud. Metal ions of major elements Fe (44 wt.%), Al (18.2 wt.%), Si (14.3 wt.%), Ti (9.3 wt.%), Na (6.2 wt.%), Ca (4.4 wt.%) as major elements and of Mg, V, Mn, Cr, K as minor elements and rare earth elements such as Ce (102 mg/kg), La (56 mg/kg), Sc (47 mg/kg), Nd (45 mg/kg), Sm (9 mg/kg). Moreover, an appropriate in-house metal recovery facility with the alumina industry will come out as a cost-benefit analysis.	\N	Materials	\N	\N	2021	14	9	2211-2211	10.3390/ma14092211	\N	\N	https://doi.org/10.3390/ma14092211	Sneha Samal. (2021). Utilization of Red Mud as a Source for Metal Ions—A Review. Materials. https://doi.org/10.3390/ma14092211	en	public	published	t	2026-08-17 11:35:19.259056+08	openalex_oa_curated	2026-08-17 11:35:19.259056+08	2026-08-17 11:35:19.259056+08	\N	\N	\N	\N
587	5	LIT-000587	Stabilization of a Clayey Soil with Ladle Metallurgy Furnace Slag Fines	\N	paper	The research study described in this paper investigated the potential to use steel furnace slag (SFS) as a stabilizing additive for clayey soils. Even though SFS has limited applications in civil engineering infrastructure due to the formation of deleterious expansion in the presence of water, the free CaO and free MgO contents allow for the SFS to be a potentially suitable candidate for clayey soil stabilization and improvement. In this investigation, a kaolinite clay was stabilized with 10% and 15% ladle metallurgy furnace (LMF) slag fines by weight. This experimental study also included testing of the SFS mixtures with the activator calcium chloride (CaCl2), which was hypothesized to accelerate the hydration of the dicalcium silicate phase in the SFS, but the results show that the addition of CaCl2 was not found to be effective. Relative to the unmodified clay, the unconfined compressive strength increased by 67% and 91% when 10% and 15% LMF slag were utilized, respectively. Likewise, the dynamic modulus increased by 212% and 221% by adding 10% and 15% LMF slag, respectively. Specifically, the LMF slag fines are posited to primarily contribute to a mechanical rather than chemical stabilization mechanism. Overall, these findings suggest the effective utilization of SFS as a soil stabilization admixture to overcome problems associated with dispersive soils, but further research is required.	\N	Materials	\N	\N	2020	13	19	4251-4251	10.3390/ma13194251	\N	\N	https://doi.org/10.3390/ma13194251	Alexander S. Brand, Punit Singhvi, Ebenezer O. Fanijo, Erol Tutumluer. (2020). Stabilization of a Clayey Soil with Ladle Metallurgy Furnace Slag Fines. Materials. https://doi.org/10.3390/ma13194251	en	public	published	t	2026-08-17 11:35:19.26955+08	openalex_oa_curated	2026-08-17 11:35:19.26955+08	2026-08-17 11:35:19.26955+08	\N	\N	\N	\N
588	5	LIT-000588	Research Progress on Controlled Low-Strength Materials: Metallurgical Waste Slag as Cementitious Materials	\N	paper	Increasing global cement and steel consumption means that a significant amount of greenhouse gases and metallurgical wastes are discharged every year. Using metallurgical waste as supplementary cementitious materials (SCMs) shows promise as a strategy for reducing greenhouse gas emissions by reducing cement production. This strategy also contributes to the utilization and management of waste resources. Controlled low-strength materials (CLSMs) are a type of backfill material consisting of industrial by-products that do not meet specification requirements. The preparation of CLSMs using metallurgical waste slag as the auxiliary cementing material instead of cement itself is a key feature of the sustainable development of the construction industry. Therefore, this paper reviews the recent research progress on the use of metallurgical waste residues (including blast furnace slag, steel slag, red mud, and copper slag) as SCMs to partially replace cement, as well as the use of alkali-activated metallurgical waste residues as cementitious materials to completely replace cement for the production of CLSMs. The general background information, mechanical features, and properties of pozzolanic metallurgical slag are introduced, and the relationship and mechanism of metallurgical slag on the performance and mechanical properties of CLSMs are analyzed. The analysis and observations in this article offer a new resource for SCM development, describe a basis for using metallurgical waste slag as a cementitious material for CLSM preparation, and offer a strategy for reducing the environmental problems associated with the treatment of metallurgical waste.	\N	Materials	\N	\N	2022	15	3	727-727	10.3390/ma15030727	\N	\N	https://doi.org/10.3390/ma15030727	Yiliang Liu, Youpo Su, Guoqiang Xu, Yanhua Chen, Gaoshuai You. (2022). Research Progress on Controlled Low-Strength Materials: Metallurgical Waste Slag as Cementitious Materials. Materials. https://doi.org/10.3390/ma15030727	en	public	published	t	2026-08-17 11:35:19.274664+08	openalex_oa_curated	2026-08-17 11:35:19.274664+08	2026-08-17 11:35:19.274664+08	\N	\N	\N	\N
589	5	LIT-000589	Resource utilization of slag from desulphurization and slag skimming: A comprehensive recycling process of all components	\N	paper	In order to make the slag from desulphurization and slag skimming (SDSS) to be comprehensively recycled and utilized, a combined process of beneficiation and building materials preparation was proposed to recover iron from SDSS, meanwhile to apply the remaining slag tailings as cement admixture. From this process, three iron-rich products were recovered in stages by clean gravity - magnetic separation, slag tailings were left. Slag powder was prepared by ultrafine grinding of slag tailings. The stability, setting time and cement mortar strength of the slag tailings cements (STC) which were mixed with Portland cement and slag powder were studied respectively. The results showed that a proper overall performance still could be obtained at the slag powder content of 30%. Chemical composition analysis, X-ray diffraction (XRD) analysis, metallographic microscope and scanning electron microscope (SEM) analysis were employed to assess the characteristics of the SDSS and the products obtained from the whole process. The results indicated that the three iron-rich products could be used as a raw material for steelmaking and ironmaking and the relatively large amount of calcium silicate (C2S) and tricalcium silicate (C3S) in the slag tailings make the addition of slag powder into the Portland cement feasible.	\N	International Journal of Mining Science and Technology	\N	\N	2022	32	3	585-593	10.1016/j.ijmst.2022.01.001	\N	\N	https://doi.org/10.1016/j.ijmst.2022.01.001	Xiao Liu, Peng Gao, Yuexin Han. (2022). Resource utilization of slag from desulphurization and slag skimming: A comprehensive recycling process of all components. International Journal of Mining Science and Technology. https://doi.org/10.1016/j.ijmst.2022.01.001	en	public	published	t	2026-08-17 11:35:19.281146+08	openalex_oa_curated	2026-08-17 11:35:19.281146+08	2026-08-17 11:35:19.281146+08	\N	\N	\N	\N
590	5	LIT-000590	Valuable Recovery Technology and Resource Utilization of Chromium-Containing Metallurgical Dust and Slag: A Review	\N	paper	As a type of metallurgical solid waste with a significant output, chromium-containing metallurgical dust and slag are gaining increasing attention. They mainly include stainless steel dust, stainless steel slag, ferrochrome dust, and ferrochrome slag, which contain significant amounts of valuable elements, such as chromium, iron, and zinc, as well as large amounts of toxic substances, such as hexavalent chromium. Achieving the harmless and resourceful comprehensive utilization of chromium-containing metallurgical dust and slag is of great significance to ensuring environmental safety and the sustainable development of resources. This paper outlines the physicochemical properties of stainless steel dust, stainless steel slag, ferrochrome dust, and ferrochrome slag. The current treatment technologies of chromium-containing metallurgical dust and slag by hydrometallurgy, the pyrometallurgical process, and the stabilization/solidification process are introduced. Moreover, the comprehensive utilization of resources of chromium-containing metallurgical dust and slag in the preparation processes of construction materials, glass ceramics, and refractories is elaborated. The aim of this paper is to provide guidance for exploring effective technology to solve the problem of chromium-containing metallurgical dust and slag.	\N	Metals	\N	\N	2023	13	10	1768-1768	10.3390/met13101768	\N	\N	https://doi.org/10.3390/met13101768	Ju Xu, Mengke Liu, Guojun Ma, Dingli Zheng, Xiang Zhang, Yanglai Hou. (2023). Valuable Recovery Technology and Resource Utilization of Chromium-Containing Metallurgical Dust and Slag: A Review. Metals. https://doi.org/10.3390/met13101768	en	public	published	t	2026-08-17 11:35:19.286176+08	openalex_oa_curated	2026-08-17 11:35:19.286176+08	2026-08-17 11:35:19.286176+08	\N	\N	\N	\N
591	5	LIT-000591	Utilisation perspective on water quenched and air-cooled blast furnace slags	\N	paper	\N	\N	Journal of Cleaner Production	\N	\N	2020	262	\N	121354-121354	10.1016/j.jclepro.2020.121354	\N	\N	https://doi.org/10.1016/j.jclepro.2020.121354	Sunil Kumar Tripathy, Jayalaxmi Dasu, Y. Rama Murthy, Gajanan U. Kapure, Atanu Ranajan Pal, Lev O. Filippov. (2020). Utilisation perspective on water quenched and air-cooled blast furnace slags. Journal of Cleaner Production. https://doi.org/10.1016/j.jclepro.2020.121354	en	public	published	t	2026-08-17 11:35:19.291983+08	openalex_oa_curated	2026-08-17 11:35:19.291983+08	2026-08-17 11:35:19.291983+08	\N	\N	\N	\N
595	5	LIT-000595	Recycling Nickel Slag by Aluminum Dross: Iron-extraction and Secondary Slag Stabilization	\N	paper	Nickel slag is a metallurgical solid waste from nickel refineries, which can be recycled as one of excellent secondary sources due to valuable iron contents. In this work, the approach of recycling nickel slag by aluminum dross was proposed, and the processes of network modification of slags and reduction were successively investigated at 1773 K. Upon the thermodynamic calculations, CaO was chosen as the modifier in order to obtain a higher activity of ‘FeO’, and basicity of the modified slag was determined as 1.0. Element mapping analysis of the modified slag showed that ‘FeO’ had been separated from the structure of nickel slag. After aluminothermic reduction for 120 min, the recovery degree of iron and copper was 94.35% and 97.89%, respectively. In addition, the secondary slag stabilization was discussed, and the utilization of the produced Fe–Cu alloy and the secondary slag was analyzed.	\N	ISIJ International	\N	\N	2019	60	3	602-609	10.2355/isijinternational.isijint-2019-173	\N	\N	https://doi.org/10.2355/isijinternational.isijint-2019-173	Guangzong Zhang, Nan Wang, Min Chen, Yanqing Cheng. (2019). Recycling Nickel Slag by Aluminum Dross: Iron-extraction and Secondary Slag Stabilization. ISIJ International. https://doi.org/10.2355/isijinternational.isijint-2019-173	en	public	published	t	2026-08-17 11:35:19.323195+08	openalex_oa_curated	2026-08-17 11:35:19.323195+08	2026-08-17 11:35:19.323195+08	\N	\N	\N	\N
596	5	LIT-000596	Zinc and Lead Metallurgical Slags as a Potential Source of Metal Recovery: A Review	\N	paper	This article presents the mineralogical and chemical characteristics of zinc and lead smelting slags, with particular reference to the slags formed during the simultaneous production of Zn and Pb by the Imperial Smelting Process. These slags, because of the presence of many metals in their composition, mainly in the form of crystalline phases, are a valuable source for their extraction. Slags from Zn-Pb metallurgy are processed on an industrial scale using pyrometallurgical and hydrometallurgical methods, alongside which a number of experiments conducted to recover metals as efficiently as possible, including bioleaching experiments.	\N	Materials	\N	\N	2023	16	23	7295-7295	10.3390/ma16237295	\N	\N	https://doi.org/10.3390/ma16237295	Katarzyna Nowińska, Zdzisław Adamczyk. (2023). Zinc and Lead Metallurgical Slags as a Potential Source of Metal Recovery: A Review. Materials. https://doi.org/10.3390/ma16237295	en	public	published	t	2026-08-17 11:35:19.329742+08	openalex_oa_curated	2026-08-17 11:35:19.329742+08	2026-08-17 11:35:19.329742+08	\N	\N	\N	\N
597	5	LIT-000597	Properties of Concrete with Recycled Concrete Aggregate Containing Metallurgical Sludge Waste	\N	paper	Sand has been considered to be something of an immeasurable quantity. There are many indications that this view is no longer valid and that the limiting of natural aggregates usage is doubly justified. Firstly, the extraction of natural aggregates is expensive and has a huge impact on the environment. The main issues in sand and gravel mining are the large areas that are affected, ground water level changes, illegal mining, unsuitability of desert and marine sand, and costs of transport. Secondly, metallurgical waste can be used as a substitute for natural aggregates. This is doubly beneficial-the waste is recycled and the use of natural aggregates is reduced. Waste is stored in landfills that take up large areas and there is also the possibility of ground and groundwater pollution by hazardous compounds. The research presented in this article focuses on the technological conditions of using metallurgical waste in its original form and as a component of recycled concrete aggregate (RCA). The use of metallurgical sludge waste or crushed or round RCA to produce concrete deteriorates the consistency and does not significantly affect the air content and density of the concrete mix. RCA lowers the density of hardened concrete. Metallurgical sludge waste or RCA usage adversely affect the absorbability and permeability of concrete. Concrete containing metallurgical sludge waste is of higher compressive strength after 7 and 28 days, with up to 60% of waste as a sand replacement. RCA concrete achieved higher compressive strength also.	\N	Materials	\N	\N	2020	13	6	1448-1448	10.3390/ma13061448	\N	\N	https://doi.org/10.3390/ma13061448	Jan Pizoń, Jacek Gołaszewski, Mohamed Alwaeli, Patryk Szwan. (2020). Properties of Concrete with Recycled Concrete Aggregate Containing Metallurgical Sludge Waste. Materials. https://doi.org/10.3390/ma13061448	en	public	published	t	2026-08-17 11:35:19.33708+08	openalex_oa_curated	2026-08-17 11:35:19.33708+08	2026-08-17 11:35:19.33708+08	\N	\N	\N	\N
598	5	LIT-000598	Utilization of tailings in cement and concrete: A review	\N	paper	Abstract One of the advantages of cement and the cement concrete industry in sustainability is the ability to utilize large amounts of industrial solid wastes such as fly ash and ground granulated blast furnace slag. Tailings are solid wastes of the ore beneficiation process in the extractive industry and are available in huge amounts in some countries. This paper reviews the potential utilization of tailings as a replacement for fine aggregates, as supplementary cementitious materials (SCMs) in mortar or concrete, and in the production of cement clinker. It was shown in previous research that while tailings had been used as a replacement for both fine aggregate and cement, the workability of mortar or concrete reduced. Also, at a constant water to cement ratio, the compressive strength of concrete increased with the tailings as fine aggregate. However, the compressive strength of concrete decreased as the replacement content of the tailings as SCMs increased, even whentailings were ground into smaller particles. Not much research has been dedicated to the durability of concrete with tailings, but it is beneficial for heavy metals in tailings to stabilize/solidify in concrete. The clinker can be produced by using the tailings, even if the tailings have a low SiO2 content. As a result, the utilization of tailings in cement and concrete will be good for the environment both in the solid waste processing and virgin materials using in the construction industry.	\N	Science and Engineering of Composite Materials	\N	\N	2019	26	1	449-464	10.1515/secm-2019-0029	\N	\N	https://doi.org/10.1515/secm-2019-0029	Mifeng Gou, Longfei Zhou, Nathalene Wei Ying Then. (2019). Utilization of tailings in cement and concrete: A review. Science and Engineering of Composite Materials. https://doi.org/10.1515/secm-2019-0029	en	public	published	t	2026-08-17 11:35:19.349315+08	openalex_oa_curated	2026-08-17 11:35:19.349315+08	2026-08-17 11:35:19.349315+08	\N	\N	\N	\N
599	5	LIT-000599	Summary of Research Progress on Metallurgical Utilization Technology of Red Mud	\N	paper	Red mud is a highly alkaline solid waste discharged in the alumina production process. Because of its large amount of discharge and high alkalinity, it is mostly stored in dams, occupying a large number of land resources and posing a great safety hazard to the ecological environment. The large-scale consumption of red mud is a global technical problem. Different alumina production processes will produce different types of red mud, mainly Bayer process red mud. In addition to its overall utilization in the field of building materials, agriculture, the environment, and the chemical industry, red mud also contains valuable metal elements, such as titanium, iron, scandium, and aluminum, and is an important secondary mineral resource. This paper focuses on the principle and characteristics of red mud metallurgical treatment for the extraction of valuable components and looks forward to the prospect of large-scale, harmless, and high-value comprehensive utilization technology for red mud in China.	\N	Minerals	\N	\N	2023	13	6	737-737	10.3390/min13060737	\N	\N	https://doi.org/10.3390/min13060737	Xiaofei Li, Ting‐an Zhang, Guozhi Lv, Kun Wang, Song Wang. (2023). Summary of Research Progress on Metallurgical Utilization Technology of Red Mud. Minerals. https://doi.org/10.3390/min13060737	en	public	published	t	2026-08-17 11:35:19.356056+08	openalex_oa_curated	2026-08-17 11:35:19.356056+08	2026-08-17 11:35:19.356056+08	\N	\N	\N	\N
600	5	LIT-000600	Adverse Effects of Using Metallurgical Slags as Supplementary Cementitious Materials and Aggregate: A Review	\N	paper	This paper discusses a sustainable way to prepare construction materials from metallurgical slags. Steel slag, copper slag, lead-zinc slag, and electric furnace ferronickel slag are the most common metallurgical slags that could be used as supplementary cementitious materials (SCMs) and aggregates. However, they have some adverse effects that could significantly limit their applications when used in cement-based materials. The setting time is significantly delayed when steel slag is utilized as an SCM. With the addition of 30% steel slag, the initial setting time and final setting time are delayed by approximately 60% and 40%, respectively. Because the specific gravity of metallurgical slags is 10-40% higher than that of natural aggregates, metallurgical slags tend to promote segregation when utilized as aggregates. Furthermore, some metallurgical slags deteriorate the microstructure of hardened pastes, resulting in higher porosity, lower mechanical properties, and decreased durability. In terms of safety, there are issues with the soundness of steel slag, the alkali-silica reaction involving cement and electric furnace ferronickel slag, and the environmental safety concerns, due to the leaching of heavy metals from copper slag and lead-zinc slag.	\N	Materials	\N	\N	2022	15	11	3803-3803	10.3390/ma15113803	\N	\N	https://doi.org/10.3390/ma15113803	Qiang Zhao, Lang Pang, Dengquan Wang. (2022). Adverse Effects of Using Metallurgical Slags as Supplementary Cementitious Materials and Aggregate: A Review. Materials. https://doi.org/10.3390/ma15113803	en	public	published	t	2026-08-17 11:35:19.36514+08	openalex_oa_curated	2026-08-17 11:35:19.36514+08	2026-08-17 11:35:19.36514+08	\N	\N	\N	\N
601	5	LIT-000601	Systematic Research on the Application of Steel Slag Resources under the Background of Big Data	\N	paper	The large‐scale and resourceful utilization of solid waste is one of the important ways of sustainable development. The big data brings hope for further development in all walks of life, because huge amounts of data insist on the principle of “turning waste into treasure”. The steel big data has been taken as the research object in this paper. Firstly, a big data collection and storage system has been set up based on the Hadoop platform. Secondly, the steel slag prediction model based on the convolution neural network (CNN) is established. The material data of steelmaking, the operation data of steelmaking process, and the data of steel slag composition are put into the model from the Hadoop platform, and the prediction of the slag composition is further realized. Then, the alternatives for resource recovery are obtained according to the predicted composition of the steel slag. And considering the three aspects of economic feasibility, resource suitability, and environmental acceptance, the comprehensive evaluation system based on AHP is established to realize the recommendation of the optimal resource approach. Finally, taking a steel plant in Hebei as an example, the alternatives according to the prediction of the composition of steel slag are blast furnace iron‐making, recycling waste steel, and cement admixture. The comprehensive evaluation values of the three resources are 0.48, 0.57, and 0.76, respectively, and the optimized resource of the steel slag produced by the steel plant is used as the cement admixture.	\N	Complexity	\N	\N	2018	2018	1	\N	10.1155/2018/6703908	\N	\N	https://doi.org/10.1155/2018/6703908	Le Kang, Hui Du, Hao Zhang, Wan Li. (2018). Systematic Research on the Application of Steel Slag Resources under the Background of Big Data. Complexity. https://doi.org/10.1155/2018/6703908	en	public	published	t	2026-08-17 11:35:19.372295+08	openalex_oa_curated	2026-08-17 11:35:19.372295+08	2026-08-17 11:35:19.372295+08	\N	\N	\N	\N
602	5	LIT-000602	Various Options for Mining and Metallurgical Waste in the Circular Economy: A Review	\N	paper	In the last few years, the mining and metallurgy industry has made concerted efforts to improve waste management through a byproduct recovery strategy, mainly focusing on developing innovative technologies to provide sustainable solutions. This strategy has seen the metallurgy industry exploit more natural resources in waste streams while reducing its environmental impact, making the ‘zero-waste’ goal possible. As such, the concept of circular economy emerged, which seeks to improve the environmental sustainability of mining operations by recycling and reusing the generated waste as raw materials for producing other new products. This paper aims to analyze the findings from published studies on the treatment and stabilization technologies of metallurgical waste or byproducts for the construction industry. Furthermore, the paper synthesizes information on processes and treatment strategies to beneficiate the waste materials for application in the building and construction sector. Finally, the paper identifies knowledge gaps in the literature, using a comprehensive overview of the superior results achieved by the metallurgical industry and potential synergies with other industrial sectors. In conclusion, the paper presents future opportunities while highlighting specific areas that may be further explored. This review paper is helpful to researchers in the mining waste management discipline to have an aerial view of what has already been achieved in the field to improve the existing processes for environment preservation.	\N	Sustainability	\N	\N	2023	15	3	2518-2518	10.3390/su15032518	\N	\N	https://doi.org/10.3390/su15032518	Thobeka Pearl Makhathini, Joseph K. Bwapwa, Sphesihle Mtsweni. (2023). Various Options for Mining and Metallurgical Waste in the Circular Economy: A Review. Sustainability. https://doi.org/10.3390/su15032518	en	public	published	t	2026-08-17 11:35:19.380494+08	openalex_oa_curated	2026-08-17 11:35:19.380494+08	2026-08-17 11:35:19.380494+08	\N	\N	\N	\N
603	5	LIT-000603	Recovery of Al, Cr and V from steel slag by bioleaching: Batch and column experiments	\N	paper	Steel slag is a major by-product of the steel industry and a potential resource of technology critical elements. For this study, a basic oxygen furnace (BOF) steel slag was tested for bacterial leaching and recovery of aluminium (Al), chromium (Cr), and vanadium (V). Mixed acidophilic bacteria were adapted to the steel slag up to 5% (w/v). In the batch tests, Al, Cr, and V were bioleached significantly more from steel slag than in control treatments. No statistical difference was observed arising from the duration of the leaching (3 vs 6 d) in the batch tests. Al and Cr concentrations in the leachate were higher for the smaller particle size of the steel slag (<75 μm), but no difference was observed for V. In the column tests, no statistical difference was found for pH, Al, Cr and V between the live culture (one-step bioleaching) and the supernatant (two-step bioleaching). The results show that the culture supernatant can be effectively used in an upscaled industrial application for metal recovery. If bioleaching is used in the 170–250 million tonnes of steel slag produced per year globally, significant recoveries of metals (100% of Al, 84% of Cr and 8% of V) can be achieved, depending on the slag composition. The removal and recovery percentages of metals from the leachate with Amberlite ® IRA-400 are relatively modest (<67% and <5%, respectively), due to the high concentration of competing ions (SO 4 2− , PO 4 3− ) in the culture medium. Other ion exchange resins can be better suited for the leachate or methods such as selective precipitation could improve the performance of the resin. Further research is needed to minimise interference and maximise metal recovery. • Bioleaching of Al, Cr and V was significantly higher than the control. • Lower particle size (<75 μm) significantly increased bioleaching of Al and Cr. • There was no statistical difference between 3-day and 6-day leaching. • Life culture and the supernatant had a similar performance in columns. • Secondary bioleaching could be used to recover metals from steel slag.	\N	Journal of Environmental Management	\N	\N	2018	222	\N	30-36	10.1016/j.jenvman.2018.05.056	\N	\N	https://doi.org/10.1016/j.jenvman.2018.05.056	Helena I. Gomes, Valerio Funari, William M. Mayes, Mike Rogerson, Timothy J. Prior. (2018). Recovery of Al, Cr and V from steel slag by bioleaching: Batch and column experiments. Journal of Environmental Management. https://doi.org/10.1016/j.jenvman.2018.05.056	en	public	published	t	2026-08-17 11:35:19.387514+08	openalex_oa_curated	2026-08-17 11:35:19.387514+08	2026-08-17 11:35:19.387514+08	\N	\N	\N	\N
144	2	LIT-000144	Resource Utilization of Magnesium Slag	\N	book	The industrial solid waste recycling team at North Minzu University has done much research on resource utilization of magnesium slag. This chapter mainly introduces a discussion of resource utilization of magnesium slag. This includes the use of magnesium slag to prepare glass ceramics, porous ceramics, and sulfoaluminate cement clinker, fixing/stabilizing heavy metals in acidic residue generated by lead-zinc smelting, and modifying copper slag.	The industrial solid waste recycling team at North Minzu University has done much research on resource utilization of magnesium slag. This chapter mainly introduces a discussion of resource utilization of magnesium slag. This includes the use of magnesium slag to prepare glass ceramics, porous ceramics, and sulfoaluminate cement clinker, fixing/stabilizing heavy metals in acidic residue generated by lead-zinc smelting, and modifying copper slag.	SpringerBriefs in Materials	\N	\N	2021	\N	\N	121-141	10.1007/978-981-16-2171-0_5	\N	\N	https://doi.org/10.1007/978-981-16-2171-0_5	Wu Lan’er, Han Fenglan, Liu Guiqun. (2021). Resource Utilization of Magnesium Slag. SpringerBriefs in Materials. 121-141. https://doi.org/10.1007/978-981-16-2171-0_5.	en	public	published	f	2026-07-28 10:26:08.861471+08	crossref_import	2026-07-28 10:26:08.861471+08	2026-08-17 11:35:50.676321+08	\N	\N	\N	\N
25	2	LIT-000025	List of Symbols	\N	paper	° indicates standard state * indicates quantity at equilibrium ¯ indicates mean value Subscripts for a component X or for a quantity such as a flowrate F or a flux: X(s,l,g) indicates the physical state of the component X (metal) indicates a component X dissolved in a metallic phase (X) (slag) indicates a component (element or compound) dissolved in a slag {X} (matte) indicates a component (element or compound) dissolved in a matte X(aq) indicates a component X dissolved in an aqueous solution [X] = C X is the molar concentration of component X in a solutionFor the content (mole fraction, concentration, mass fraction) or for the flux (flow rate) of a component X in a phase α at a specific location, for example at the (in the vicinity of the) interface between two phases, this is indicated by subscript s:x X(α)s ; C X(α)s ; %X (α)s (%X (M)s , %X (slag)s , %X {matte) ), F X(α)s	° indicates standard state * indicates quantity at equilibrium ¯ indicates mean value Subscripts for a component X or for a quantity such as a flowrate F or a flux: X(s,l,g) indicates the physical state of the component X (metal) indicates a component X dissolved in a metallic phase (X) (slag) indicates a component (element or compound) dissolved in a slag {X} (matte) indicates a component (element or compound) dissolved in a matte X(aq) indicates a component X dissolved in an aqueous solution [X] = C X is the molar concentration of component X in a solutionFor the content (mole fraction, concentration, mass fraction) or for the flux (flow rate) of a component X in a phase α at a specific location, for example at the (in the vicinity of the) interface between two phases, this is indicated by subscript s:x X(α)s ; C X(α)s ; %X (α)s (%X (M)s , %X (slag)s , %X {matte) ), F X(α)s	Extractive Metallurgy 1	\N	\N	2013	\N	\N	325-336	10.1002/9781118618974.oth1	\N	\N	https://doi.org/10.1002/9781118618974.oth1	(2013). List of Symbols. Extractive Metallurgy 1. 325-336. https://doi.org/10.1002/9781118618974.oth1.	en	public	published	f	2026-07-28 10:26:04.190422+08	crossref_import	2026-07-28 10:26:04.190422+08	2026-08-17 11:35:51.056947+08	\N	\N	\N	\N
\.


--
-- Data for Name: domains; Type: TABLE DATA; Schema: literature; Owner: -
--

COPY literature.domains (domain_code, domain_name, description, route_path, sort_order, is_active) FROM stdin;
basic_principles	冶金基础原理	\N	/basic-principles	1	t
steel_metallurgy	钢铁冶金	\N	/steel-metallurgy	2	t
non_ferrous	有色冶金	\N	/non-ferrous	3	t
energy_restructuring	冶金能源重构	\N	/energy-restructuring	4	t
resource_utilization	冶金资源利用	\N	/resource-utilization	5	t
\.


--
-- Data for Name: keywords; Type: TABLE DATA; Schema: literature; Owner: -
--

COPY literature.keywords (keyword_id, keyword_name) FROM stdin;
1588	Binary number
1589	Particle (ecology)
1590	Surface energy
1591	Nano-
1596	Molecular dynamics
1597	Physical metallurgy
1603	Extrapolation
1611	Mathematics
1612	Predictability
1617	Consistency (knowledge bases)
1618	Standard molar entropy
1636	Aerospace
1695	Ground granulated blast-furnace slag
1641	Aerospace engineering
1642	Quinary
1738	Carbon dioxide
1649	Machine learning
1650	Artificial intelligence
1654	Oxide
1655	Homogeneous
1517	Statistical physics
1716	Flue gas
1659	State of matter
1812	Pyrolysis
1671	Ultimate tensile strength
1672	Homogenization (climate)
1929	Bioleaching
1542	Annealing (glass)
1688	Syngas
50	Frontmatter
1683	Pelletizing
53	Index
156	In-Situ
1490	Microstructure
1768	Electrolysis
1825	Raw material
1853	Electricity
1687	Iron ore
1712	Ferrous metallurgy
1713	Continuous casting
1706	Waste management
1786	Carbon capture and storage (timeline)
1686	Hydrogen production
1679	Composite material
1922	Platinum group
1722	Carbonization
1728	Reactivity (psychology)
1778	Combustion
1723	Coke
1717	Blast furnace gas
100	List
101	Symbols
1771	Coal
1783	Power to gas
1699	Scrap
1784	Natural gas
1785	Air separation
1735	Greenhouse gas
115	Summaries
116	Other
117	Volumes
1788	Methanation
1704	Environmental science
5	SYSTEM
1829	Carbon footprint
1605	Process (computing)
1865	Electric arc
1892	Electrowinning
1866	Porosity
1900	Sodium hydroxide
1890	Aqueous solution
1797	Flexibility (engineering)
1869	Nitric acid
1799	Viewpoints
1694	Cementitious
1696	Smelting
1809	Charcoal
1682	Direct reduced iron
1847	Dispatchable generation
163	Study
1826	Pyrometallurgy
1874	Manganese
1878	Incineration
1841	Leaching (pedology)
1910	Electrochemistry
1887	Hydrometallurgy
1506	Metallurgy
24	Development
1496	Thermodynamics
1906	Hydroxide
1907	Vanadate
1911	Sodium
1913	Hydrate
1855	Energy storage
1896	Electrolyte
1917	Phosphonium
1751	Reduction (mathematics)
1921	Chloride
15	process
1894	Solvent
1924	Thiourea
1925	Phosphinate
1930	Goethite
1901	Reagent
1899	Printed circuit board
157	Analysis
1684	Blast furnace
1815	Pulp and paper industry
1870	Sulfuric acid
220	study
1926	Platinum
1867	Cobalt
33	TECHNOLOGY
1927	Jarosite
1736	Pig iron
1724	Carbon fibers
1875	Inorganic chemistry
1698	Basic oxygen steelmaking
1873	Oxalic acid
188	Emissions
1703	China
110	Reduction
178	Effect
1908	Zinc
1660	Chemical physics
1898	Hydrochloric acid
10	STEELMAKING
63	Metallurgical
1851	Electricity generation
1872	Nickel
1689	Pellets
1681	Electric arc furnace
1690	Slag (welding)
1876	Nuclear chemistry
158	Method
122	Slags
1725	Biomass (ecology)
44	Transport
13	effect
1902	Metal
237	Reduced
2162	World Wide Web
239	Proportion
240	Metallic
241	Charge
242	Technological
2089	Software deployment
2095	Wind power
2098	Technological innovation system
2099	Legitimacy
2100	Industrial organization
2101	Technological change
1978	Tailings
1942	Hazardous waste
267	EFSOP®
270	REAL-TIME
271	WATER
272	DETECTION
1954	Electronic waste
1958	Pollution
1961	Heavy metals
1962	Environmental chemistry
1963	Soil contamination
1967	Actinide
1968	Diluent
1971	Solvent extraction
1973	Lanthanide
1982	Ferrous
1983	Copper extraction techniques
2103	Transition (genetics)
1988	Slurry
1991	Dissolution
1992	Battery (electricity)
1996	Chemical engineering
1997	Life-cycle assessment
1999	Ecotoxicity
2006	Eutrophication
2012	Lixiviant
2013	Selectivity
2014	Aliquat 336
2027	Roasting
1888	Extractive metallurgy
2022	Acidithiobacillus ferrooxidans
324	Comparative
287	studies
326	discharge
327	hydronium
328	ions
329	zinc
2023	Biochemical engineering
2000	Environmental engineering
2031	Sulfation
1950	Copper
2034	Chalcopyrite
2042	Cadmium
2121	Sustainability
2044	Wastewater
1969	Ionic liquid
469	Utilizing
470	Russian
471	polymer
472	anion
473	active
474	depressants
2049	Vanadium
2051	Separation process
2053	Niobium
2054	Membrane
476	out-of-balance
2058	Olivine
2059	Magnesite
2062	Ultramafic rock
427	sodium
428	silicate
429	polysaccharides
431	talcose
2065	Mineral
2057	Carbonation
2071	Diffusion
2077	Context (archaeology)
2081	Electrification
2102	Business
478	converting
480	matte
481	oxidized
310	nickel
2106	Innovation system
484	sulfide
523	Hydrogen
2196	Carbon neutrality
2111	Energy consumption
2112	Efficient energy use
330	copper
2166	Hydrogen storage
2115	Consumption (sociology)
2005	Global warming
2157	Economics
526	Future
2119	Hydrogen technologies
2202	Carbon sequestration
2158	Library science
2160	Citation
2134	Pulverized coal-fired boiler
2183	Clean coal
2161	National laboratory
2083	Production (economics)
2169	Alternative fuels
430	flotation
432	copper-nickel
433	ores
2124	Hydrogen fuel
2172	Fuel cells
2193	Bio-energy with carbon capture and storage
2184	Chemical industry
1964	Environmental protection
308	aluminum
2189	Kinetics
176	steelmaking
2197	Carbon-neutral fuel
2199	Negative carbon dioxide emission
1744	Fossil fuel
2205	Clean coal technology
2206	Coal mining
1953	Resource recovery
527	Breakthrough
528	Low-carbon
1970	Extraction (chemistry)
531	ULCOS
2003	Renewable energy
2086	Natural resource economics
2063	Carbonate
2041	Magnetic separation
159	Steelmaking
1948	Leachate
516	Zero
236	Direct
300	During
304	processes
505	hydrogen
530	Technology
492	Mechanical
426	Joint
477	Optimization
265	Research
525	Progress
2208	Energy conservation
2096	Environmental economics
2221	Mineralization (soil science)
2225	Emerging technologies
2227	Electricity system
2234	Silicate
2240	Silicate minerals
2242	Heap (data structure)
2246	Wood gas generator
2256	Mining engineering
2052	Metal ions in aqueous solution
2275	Durability
2277	Curing (chemistry)
2279	Kaolinite
2282	Soil stabilization
569	The-state-Art
571	technology
2284	Ladle
2285	Calcium silicate
2288	Clay soil
2297	Industrial waste
2305	Portland cement
591	road
593	neutrality
594	metallurgical
595	industry
746	Treatments
599	Changes
601	Content
2309	Ferrochrome
2315	Hexavalent chromium
612	Advanced
614	Techniques
615	Impurity
616	Management
617	High-Purity
618	Quartz
619	Diverse
2331	Resource (disambiguation)
2333	Agriculture
2335	Steel mill
572	based
2352	Arsenic
2356	Population
2361	Dross
2366	Aluminium
2373	Zinc smelting
2381	Properties of concrete
2292	Cement
2286	Compressive strength
2391	Clinker (cement)
2392	Fly ash
2272	Mortar
519	carbon
2307	Beneficiation
2325	Aggregate (composite)
2259	Red mud
2398	Alkalinity
2399	Bayer process
2402	Bauxite
2291	Copper slag
2412	Ferroalloy
2418	Big data
2424	Data mining
555	Preparation
2427	Circular economy
609	Energy
667	Hydrogen‐Based
670	Low‐Carbon
2342	Reuse
2430	Exploit
2330	Sustainable development
2433	Natural resource
2436	Zero waste
2311	Chromium
2468	Crystallite
2469	Tetragonal crystal system
2472	Monoclinic crystal system
2475	Condensed matter physics
2481	Toughening
547	Toward
2466	Martensite
2483	Stress field
2484	Isothermal process
464	metallurgy
2456	Stress (linguistics)
2490	Ion exchange
2492	Oxalate
2496	Lithium (medication)
2497	Phosphogypsum
2499	Chelating resin
2500	Elution
2502	Chelation
2504	Ion-exchange resin
686	metal
2505	Adsorption
238	Iron
613	Processing
777	Resource
731	Utilization
829	Magnesium
722	Slag
719	Recycling
852	高效炼钢工艺在转炉冶金中的应用与优化
853	高炉炼铁工艺节能减排技术探讨
854	颠覆性技术研究（一）——理论起源
855	概念界定与五维分析框架
584	Green
858	prospective
860	new
861	pollutants
863	Foreign
864	Investment
865	State
866	Capitalism
984	Practices
868	National
871	PLC
872	在钢铁冶金企业电气自动化控制中应用
873	冶金机械设备管理与维护策略研究
874	动力电池铝箔的性能衰减机理及工艺改进
875	机械设计和机械制造技术研究
876	Prediction
881	Hardness
882	Thermal
883	汽车冲压模具设计制造与维修研究
884	攀西力马河镁铁-超镁铁岩浆演化与镍成矿
885	来自矿物化学的证据
886	烧结过程温度场模拟及矿相演变规律研究
975	Critical
2449	Adiabatic process
843	preparation
892	properties
894	applications
895	BIM
896	技术在暖通空调设计中的高效应用
897	机械设计制造及其自动化的应用分析
898	广东大宝山斑岩成矿系统的年代学特征
899	成矿环境与找矿方向
900	汽车防撞横梁冲压工艺研究及模具设计探讨
901	西藏罗布莎-香卡山-康金拉矿集区铬铁矿找矿突破及其启示
902	冶金机械自动化校准的溯源性体系构建研究
903	冶金设计中总图设计的核心要点研究
904	冶金行业安全事故案例分析及其教训总结
905	冶金铁路无人调车机械系统的路径规划与控制研究
906	新能源汽车动力电池系统技术发展趋势探究
907	热处理对激光选区熔化316H不锈钢力学性能的影响
908	工业碳锁定的空间关联格局及其驱动机制
909	热阴极电子束冷床炉预热过程控制
2450	Nickel titanium
2451	Refrigeration
912	冶金炼钢转炉机械设备维修管理探讨
2452	Dissipative system
915	全流程自动化连铸装备在高合金钢生产中的铸坯质量提升研究
916	轧钢产品表面质量控制及优化方法
917	汽车配件的生产工艺及其质量控制研究
918	炼钢过程中夹杂物的形态控制与去除
919	电机机座加工工艺与加工精度分析
920	水利工程设备监造中的无损检测技术应用
921	机械工程材料与热加工工艺
922	工程机械齿轮加工与热处理工艺研究
923	浅谈冶金机械及自动化
992	欧盟
926	Different
927	Annealing
993	CBAM
932	钢筋混凝土结构建筑建材的碳排放影响因素研究
933	煤炭产品碳足迹评估研究综述
934	基于公铁联运的沥青集装箱多式联运路径优化研究
935	国土空间规划视域下资源型城市绿色发展
936	理论逻辑
937	现实困境与实现路径
938	空分技术在化工生产与煤化工中的应用及发展趋势
939	关于建筑材料中耐火材料的发展及技术特点分析
941	Progresses
887	Recent
943	Sources
944	Accumulation
928	Processes
976	Challenges
947	Influencing
948	高强钢在大型集装箱船船体结构中的应用与焊接性能评估
949	煤气回收作业人员的安全培训与操作规范研究
950	有色冶金行业大气多污染物全过程控制耦合技术
951	城市更新项目中机电拆除探讨
952	X射线荧光光谱分析法在矿石检测中的应用与实践
953	浅谈土壤环境质量影响状况及成因分析
954	固体废物处理与资源化利用途径探索
955	采矿工程废弃物资源化利用途径与环境效益评价
956	矿化过程中铁-稀土组合的成因机理讨论与展望
960	Replacing
961	Phenol-Based
962	Extractants
983	The
965	碰撞造山带地壳多层次熔融
966	对秦岭造山带三叠纪地壳演化与多金属成矿的启示
2457	Pseudoelasticity
979	Advances
929	on
857	and
982	Commercialization
987	Prospects
859	of
989	Artificial
990	Intelligence
991	低温压力容器的焊接制造
994	实施对中国出口企业的挑战与应对
995	压力容器焊接技术分析
996	WK-35
997	电铲底架梁裂纹分析与焊接修复工艺
998	工业固废再生骨料在绿色公路基层中的环境与力学性能研究
999	公路修建技术中材料和能源的节约
1000	新能源交通工程的发展与应用
2454	SMA*
2462	Diffusionless transformation
2460	Plasticity
2455	Deformation (meteorology)
2447	Shape-memory alloy
1001	绿色氧化技术在有机合成中的研究现状与环境效益
1002	基于生命周期理论的水利工程施工期碳排放核算方法与应用
1006	Environmentally
1007	Friendly
1008	Water-Based
1009	Drilling
1010	Fluid
1011	沿海港口码头结构耐久性防护措施探析
1012	石油化工配管中高温材料耐腐蚀性提升技术探讨
1014	Net
890	the
1019	Road
1021	连续退火炉自动控制系统研究
1022	火力发电汽轮机供水水质处理技术创新与应用
1023	地质样品中铬及铬同位素的分析
1024	Differences
1026	aggregation
1029	heavy
1031	activity
1032	Action
1033	Plans
1035	Policy
1036	Recommendations
1038	Vehicle
1039	Grid
1041	热解炉富氧干馏运行优化及荒煤气提质实践
1042	冶金工程中低碳炼铁技术的工艺优化与碳排放分析
1532	Strain rate
1044	面向“双碳”目标的铜冶炼清洁生产技术路径优化
1045	能源动力产业的绿色低碳环保技术与应用分析
1046	Prevalence
1048	distribution
1049	patterns
1051	drug
1052	resistance
1230	cs.CL
1158	physics.optics
870	in
1512	Configuration entropy
1063	提金尾渣资源综合化利用研究
1156	cond-mat.soft
1067	高炉型钛渣中二氧化钛的活度
1069	冶金废水深度处理及资源化回用工艺在矿山项目中的应用
1070	铜渣选矿工艺的现状与发展趋势研究
1071	产教融合背景下AIGC赋能建筑工程专业教学模式的实践——以《建筑材料》课程为例
1072	高层建筑工程施工中桩基础施工技术
1106	cond-mat.stat-mech
1074	智慧水利在水利水电工程管理中的应用研究
1075	钻孔灌注桩在水利水电工程施工中的应用探讨
1076	盾构法隧道施工在水利工程建设中的应用
1077	水利水电工程防渗技术研究
1521	Corrosion
1079	水利水电施工中混凝土施工技术的应用
1080	水利施工中输水隧洞施工
1081	Calculation
1082	Verification
1083	And
1084	Empirical
1088	Transition
1507	Engineering
1155	cond-mat.other
1569	Work (physics)
1116	physics.app-ph
1099	Performance
1102	Nano-Iron
1103	Oxide@Carbon
1104	Cloth
1105	cond-mat.quant-gas
1515	Solid solution
1111	hep-ph
1112	hep-th
1233	cs.IR
1552	Physics
1107	cond-mat.mtrl-sci
1123	math-ph
1232	cs.AI
1110	hep-lat
1127	cs.CE
1118	physics.chem-ph
1260	cond-mat.supr-con
1196	physics.flu-dyn
1495	Management science
1166	physics.ins-det
1176	cond-mat.mes-hall
1574	Ab initio
1555	Systems engineering
1568	Precipitation
1115	cond-mat.str-el
1133	cs.LG
1135	physics.comp-ph
1513	Entropy (arrow of time)
1561	Chemistry
1171	cond-mat.dis-nn
1489	CALPHAD
1527	Adiabatic shear band
1528	Shear band
1531	Shear (geology)
1494	Computer science
1538	Atom probe
1576	Density functional theory
1488	High entropy alloys
1497	Data science
1541	Transmission electron microscopy
1557	Process engineering
1492	Alloy
1566	Enthalpy
1567	Stability (learning theory)
1491	Materials science
1537	Nucleation
1578	Stacking
1579	Stacking fault
1509	Intermetallic
1581	Ab initio quantum chemistry methods
1501	Ductility (Earth science)
1493	Phase diagram
1504	Nanotechnology
1529	Crystal twinning
1503	Fracture toughness
1502	Toughness
1505	Engineering physics
1558	Phase (matter)
1539	Grain boundary
\.


--
-- Data for Name: sources; Type: TABLE DATA; Schema: literature; Owner: -
--

COPY literature.sources (source_id, source_name, source_type, provider, access_url, license_note, security_level, is_active, created_at, updated_at) FROM stdin;
2	CrossRef	journal	CrossRef	https://www.crossref.org	\N	public	t	2026-07-28 10:25:58.658471+08	2026-07-28 10:25:58.658471+08
3	OpenAlex	journal	OpenAlex	https://openalex.org	\N	public	t	2026-07-30 16:18:20.210044+08	2026-07-30 16:18:20.210044+08
4	arXiv	journal	arXiv	https://arxiv.org	\N	public	t	2026-07-30 16:24:25.811101+08	2026-07-30 16:24:25.811101+08
5	OpenAlex OA Curated	journal	OpenAlex	https://openalex.org	仅导入 OpenAlex 标记为开放获取且提供 pdf_url 的记录	public	t	2026-08-17 11:35:09.027388+08	2026-08-17 11:35:09.027388+08
6	Google Scholar Discovery	journal	Google Scholar	https://scholar.google.com	Scholar 用于人工发现与引用排序；元数据和开放 PDF 由 OpenAlex 验证	public	t	2026-08-17 11:44:07.337978+08	2026-08-17 11:44:07.337978+08
\.


--
-- Name: attachments_attachment_id_seq; Type: SEQUENCE SET; Schema: literature; Owner: -
--

SELECT pg_catalog.setval('literature.attachments_attachment_id_seq', 462, true);


--
-- Name: authors_author_id_seq; Type: SEQUENCE SET; Schema: literature; Owner: -
--

SELECT pg_catalog.setval('literature.authors_author_id_seq', 2056, true);


--
-- Name: document_code_seq; Type: SEQUENCE SET; Schema: literature; Owner: -
--

SELECT pg_catalog.setval('literature.document_code_seq', 609, true);


--
-- Name: documents_document_id_seq; Type: SEQUENCE SET; Schema: literature; Owner: -
--

SELECT pg_catalog.setval('literature.documents_document_id_seq', 609, true);


--
-- Name: keywords_keyword_id_seq; Type: SEQUENCE SET; Schema: literature; Owner: -
--

SELECT pg_catalog.setval('literature.keywords_keyword_id_seq', 2506, true);


--
-- Name: sources_source_id_seq; Type: SEQUENCE SET; Schema: literature; Owner: -
--

SELECT pg_catalog.setval('literature.sources_source_id_seq', 6, true);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (attachment_id);


--
-- Name: authors authors_pkey; Type: CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.authors
    ADD CONSTRAINT authors_pkey PRIMARY KEY (author_id);


--
-- Name: document_authors document_authors_pkey; Type: CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.document_authors
    ADD CONSTRAINT document_authors_pkey PRIMARY KEY (document_id, author_id);


--
-- Name: document_domains document_domains_pkey; Type: CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.document_domains
    ADD CONSTRAINT document_domains_pkey PRIMARY KEY (document_id, domain_code);


--
-- Name: document_keywords document_keywords_pkey; Type: CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.document_keywords
    ADD CONSTRAINT document_keywords_pkey PRIMARY KEY (document_id, keyword_id);


--
-- Name: documents documents_document_code_key; Type: CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.documents
    ADD CONSTRAINT documents_document_code_key UNIQUE (document_code);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (document_id);


--
-- Name: domains domains_pkey; Type: CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.domains
    ADD CONSTRAINT domains_pkey PRIMARY KEY (domain_code);


--
-- Name: keywords keywords_keyword_name_key; Type: CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.keywords
    ADD CONSTRAINT keywords_keyword_name_key UNIQUE (keyword_name);


--
-- Name: keywords keywords_pkey; Type: CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.keywords
    ADD CONSTRAINT keywords_pkey PRIMARY KEY (keyword_id);


--
-- Name: sources sources_pkey; Type: CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.sources
    ADD CONSTRAINT sources_pkey PRIMARY KEY (source_id);


--
-- Name: idx_authors_name; Type: INDEX; Schema: literature; Owner: -
--

CREATE INDEX idx_authors_name ON literature.authors USING btree (author_name);


--
-- Name: idx_documents_featured; Type: INDEX; Schema: literature; Owner: -
--

CREATE INDEX idx_documents_featured ON literature.documents USING btree (is_featured, status, security_level);


--
-- Name: idx_documents_scholar_citations; Type: INDEX; Schema: literature; Owner: -
--

CREATE INDEX idx_documents_scholar_citations ON literature.documents USING btree (scholar_citation_count DESC) WHERE (scholar_citation_count IS NOT NULL);


--
-- Name: idx_documents_source; Type: INDEX; Schema: literature; Owner: -
--

CREATE INDEX idx_documents_source ON literature.documents USING btree (source_id);


--
-- Name: idx_documents_status; Type: INDEX; Schema: literature; Owner: -
--

CREATE INDEX idx_documents_status ON literature.documents USING btree (status, security_level);


--
-- Name: idx_documents_title; Type: INDEX; Schema: literature; Owner: -
--

CREATE INDEX idx_documents_title ON literature.documents USING gin (to_tsvector('simple'::regconfig, ((COALESCE(title, ''::text) || ' '::text) || COALESCE(abstract, ''::text))));


--
-- Name: idx_documents_title_abstract; Type: INDEX; Schema: literature; Owner: -
--

CREATE INDEX idx_documents_title_abstract ON literature.documents USING gin (to_tsvector('simple'::regconfig, ((COALESCE(title, ''::text) || ' '::text) || COALESCE(abstract, ''::text))));


--
-- Name: idx_documents_type; Type: INDEX; Schema: literature; Owner: -
--

CREATE INDEX idx_documents_type ON literature.documents USING btree (document_type);


--
-- Name: idx_documents_year; Type: INDEX; Schema: literature; Owner: -
--

CREATE INDEX idx_documents_year ON literature.documents USING btree (publication_year DESC);


--
-- Name: uq_documents_doi; Type: INDEX; Schema: literature; Owner: -
--

CREATE UNIQUE INDEX uq_documents_doi ON literature.documents USING btree (lower((doi)::text)) WHERE (doi IS NOT NULL);


--
-- Name: documents trg_documents_code; Type: TRIGGER; Schema: literature; Owner: -
--

CREATE TRIGGER trg_documents_code BEFORE INSERT ON literature.documents FOR EACH ROW WHEN ((new.document_code IS NULL)) EXECUTE FUNCTION literature.generate_document_code();


--
-- Name: documents trg_documents_updated_at; Type: TRIGGER; Schema: literature; Owner: -
--

CREATE TRIGGER trg_documents_updated_at BEFORE UPDATE ON literature.documents FOR EACH ROW EXECUTE FUNCTION literature.update_timestamp();


--
-- Name: sources trg_sources_updated_at; Type: TRIGGER; Schema: literature; Owner: -
--

CREATE TRIGGER trg_sources_updated_at BEFORE UPDATE ON literature.sources FOR EACH ROW EXECUTE FUNCTION literature.update_timestamp();


--
-- Name: attachments attachments_document_id_fkey; Type: FK CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.attachments
    ADD CONSTRAINT attachments_document_id_fkey FOREIGN KEY (document_id) REFERENCES literature.documents(document_id) ON DELETE CASCADE;


--
-- Name: document_authors document_authors_author_id_fkey; Type: FK CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.document_authors
    ADD CONSTRAINT document_authors_author_id_fkey FOREIGN KEY (author_id) REFERENCES literature.authors(author_id);


--
-- Name: document_authors document_authors_document_id_fkey; Type: FK CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.document_authors
    ADD CONSTRAINT document_authors_document_id_fkey FOREIGN KEY (document_id) REFERENCES literature.documents(document_id) ON DELETE CASCADE;


--
-- Name: document_domains document_domains_document_id_fkey; Type: FK CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.document_domains
    ADD CONSTRAINT document_domains_document_id_fkey FOREIGN KEY (document_id) REFERENCES literature.documents(document_id) ON DELETE CASCADE;


--
-- Name: document_domains document_domains_domain_code_fkey; Type: FK CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.document_domains
    ADD CONSTRAINT document_domains_domain_code_fkey FOREIGN KEY (domain_code) REFERENCES literature.domains(domain_code);


--
-- Name: document_keywords document_keywords_document_id_fkey; Type: FK CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.document_keywords
    ADD CONSTRAINT document_keywords_document_id_fkey FOREIGN KEY (document_id) REFERENCES literature.documents(document_id) ON DELETE CASCADE;


--
-- Name: document_keywords document_keywords_keyword_id_fkey; Type: FK CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.document_keywords
    ADD CONSTRAINT document_keywords_keyword_id_fkey FOREIGN KEY (keyword_id) REFERENCES literature.keywords(keyword_id);


--
-- Name: documents documents_source_id_fkey; Type: FK CONSTRAINT; Schema: literature; Owner: -
--

ALTER TABLE ONLY literature.documents
    ADD CONSTRAINT documents_source_id_fkey FOREIGN KEY (source_id) REFERENCES literature.sources(source_id);


--
-- PostgreSQL database dump complete
--

\unrestrict oOkYhytRY1eP3UEmHIQ5fFOsgbjhM1qeUoJ6H0sGgXwMiGdYEwkE7eLbaAP2Efb

